/**
 * SecureDeployX Database Setup Script
 * 
 * This script initializes the database with default values and an admin user.
 * It can be run with: node setup-db.js <admin_email> <admin_password>
 */

import { db } from './server/db.js';
import { eq } from 'drizzle-orm';
import { 
  users, 
  apiProviders, 
  templateSettings, 
  subscriptions, 
  cloudCredentials
} from './shared/schema.js';
import { createHash, randomBytes, scryptSync } from 'crypto';

// Helper function to hash passwords
function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 64).toString('hex');
  return `${hash}.${salt}`;
}

/**
 * Setup the database with initial data
 */
async function setupDatabase() {
  console.log('\x1b[33m%s\x1b[0m', 'Setting up the SecureDeployX database...');
  
  // Get admin credentials from command line arguments
  const adminEmail = process.argv[2] || 'admin@example.com';
  const adminPassword = process.argv[3] || 'securepassword';
  
  console.log(`Using admin email: ${adminEmail}`);
  console.log(`Using admin password: ${'*'.repeat(adminPassword.length)}`);
  
  try {
    // Check if admin user already exists
    const existingAdmin = await db.select().from(users).where(eq(users.email, adminEmail)).limit(1);
    
    if (existingAdmin.length > 0) {
      console.log('\x1b[33m%s\x1b[0m', 'Admin user already exists. Skipping admin creation.');
    } else {
      // Create admin user
      console.log('\x1b[34m%s\x1b[0m', 'Creating admin user...');
      
      const hashedPassword = hashPassword(adminPassword);
      
      const [adminUser] = await db.insert(users).values({
        username: 'admin',
        email: adminEmail,
        passwordHash: hashedPassword,
        role: 'admin',
        status: 'active',
        createdAt: new Date()
      }).returning();
      
      console.log('\x1b[32m%s\x1b[0m', 'Admin user created successfully!');
      console.log('\x1b[0m', `User ID: ${adminUser.id}`);
    }
    
    // Setup API providers
    console.log('\x1b[34m%s\x1b[0m', 'Setting up API providers...');
    
    const existingProviders = await db.select().from(apiProviders).limit(1);
    
    if (existingProviders.length === 0) {
      // Create mock providers
      await db.insert(apiProviders).values([
        {
          provider: 'mock',
          apiKey: 'mock-api-key',
          isActive: true,
          settings: {},
          baseUrl: null,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          provider: 'openai',
          apiKey: '', // Will be set by user
          isActive: false,
          settings: {},
          baseUrl: 'https://api.openai.com/v1',
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          provider: 'gemini',
          apiKey: '', // Will be set by user
          isActive: false,
          settings: {},
          baseUrl: 'https://generativelanguage.googleapis.com/v1',
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ]);
      
      console.log('\x1b[32m%s\x1b[0m', 'API providers created successfully!');
    } else {
      console.log('\x1b[33m%s\x1b[0m', 'API providers already exist. Skipping creation.');
    }
    
    // Setup template settings
    console.log('\x1b[34m%s\x1b[0m', 'Setting up template settings...');
    
    const existingTemplates = await db.select().from(templateSettings).limit(1);
    
    if (existingTemplates.length === 0) {
      const adminId = (await db.select().from(users).where(eq(users.role, 'admin')).limit(1))[0]?.id;
      
      if (adminId) {
        // Create template settings for different user types
        await db.insert(templateSettings).values([
          {
            name: 'Basic User',
            type: 'user',
            permissions: {
              canCreateProjects: true,
              canRunScans: true,
              canExportReports: true,
              canUseAI: false,
              canDeployToAWS: false,
              canDeployToRender: true,
              canAccessAdvancedSEO: false,
              canAccessServerFiles: false,
              canUseCollaboration: false,
              canAccessTrafficBoost: false
            },
            description: 'Basic user settings with limited features',
            features: {
              maxProjects: 3,
              maxScansPerDay: 5,
              maxDeploymentsPerDay: 2,
              supportedLanguages: ['javascript', 'python', 'php'],
              supportedDeploymentPlatforms: ['python', 'php', 'wordpress']
            },
            uiSettings: {
              theme: 'light',
              dashboardLayout: 'simple',
              showStatistics: true,
              showAdvancedOptions: false
            },
            isDefault: true,
            createdBy: adminId,
            createdAt: new Date(),
            updatedAt: new Date()
          },
          {
            name: 'Pro Developer',
            type: 'developer',
            permissions: {
              canCreateProjects: true,
              canRunScans: true,
              canExportReports: true,
              canUseAI: true,
              canDeployToAWS: true,
              canDeployToRender: true,
              canAccessAdvancedSEO: true,
              canAccessServerFiles: true,
              canUseCollaboration: true,
              canAccessTrafficBoost: true
            },
            description: 'Professional developer settings with advanced features',
            features: {
              maxProjects: 10,
              maxScansPerDay: 20,
              maxDeploymentsPerDay: 10,
              supportedLanguages: ['javascript', 'python', 'php', 'java', 'csharp', 'ruby'],
              supportedDeploymentPlatforms: ['python', 'php', 'wordpress', 'aws', 'render', 'asp.net']
            },
            uiSettings: {
              theme: 'dark',
              dashboardLayout: 'advanced',
              showStatistics: true,
              showAdvancedOptions: true
            },
            isDefault: false,
            createdBy: adminId,
            createdAt: new Date(),
            updatedAt: new Date()
          },
          {
            name: 'Project Manager',
            type: 'manager',
            permissions: {
              canCreateProjects: true,
              canRunScans: true,
              canExportReports: true,
              canUseAI: true,
              canDeployToAWS: true,
              canDeployToRender: true,
              canAccessAdvancedSEO: true,
              canAccessServerFiles: false,
              canUseCollaboration: true,
              canAccessTrafficBoost: true
            },
            description: 'Project manager settings with team collaboration features',
            features: {
              maxProjects: 15,
              maxScansPerDay: 15,
              maxDeploymentsPerDay: 5,
              supportedLanguages: ['javascript', 'python', 'php', 'java'],
              supportedDeploymentPlatforms: ['python', 'php', 'wordpress', 'aws', 'render']
            },
            uiSettings: {
              theme: 'system',
              dashboardLayout: 'team',
              showStatistics: true,
              showAdvancedOptions: true
            },
            isDefault: false,
            createdBy: adminId,
            createdAt: new Date(),
            updatedAt: new Date()
          }
        ]);
        
        console.log('\x1b[32m%s\x1b[0m', 'Template settings created successfully!');
      } else {
        console.log('\x1b[31m%s\x1b[0m', 'No admin user found. Skipping template settings creation.');
      }
    } else {
      console.log('\x1b[33m%s\x1b[0m', 'Template settings already exist. Skipping creation.');
    }
    
    // Setup subscription plans
    console.log('\x1b[34m%s\x1b[0m', 'Setting up subscription plans...');
    
    const existingSubscriptions = await db.select().from(subscriptions).limit(1);
    
    if (existingSubscriptions.length === 0) {
      const adminId = (await db.select().from(users).where(eq(users.role, 'admin')).limit(1))[0]?.id;
      
      if (adminId) {
        // Create a free subscription for the admin
        await db.insert(subscriptions).values({
          userId: adminId,
          plan: 'enterprise',
          status: 'active',
          startDate: new Date(),
          endDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365), // 1 year
          paymentMethod: 'system',
          paymentId: null,
          amount: null,
          currency: null,
          createdAt: new Date(),
          updatedAt: new Date()
        });
        
        console.log('\x1b[32m%s\x1b[0m', 'Subscription plan created successfully!');
      } else {
        console.log('\x1b[31m%s\x1b[0m', 'No admin user found. Skipping subscription plan creation.');
      }
    } else {
      console.log('\x1b[33m%s\x1b[0m', 'Subscription plans already exist. Skipping creation.');
    }
    
    // Setup example cloud credentials (for demo purposes with secure encryption)
    console.log('\x1b[34m%s\x1b[0m', 'Setting up example cloud credentials...');
    
    const existingCredentials = await db.select().from(cloudCredentials).limit(1);
    
    if (existingCredentials.length === 0) {
      const adminId = (await db.select().from(users).where(eq(users.role, 'admin')).limit(1))[0]?.id;
      
      if (adminId) {
        // Generate a secure password for the example credentials
        const securePassword = 'ExamplePassword123';
        const hashedPassword = hashPassword(securePassword);
        
        // Create example AWS credentials (with password protection)
        await db.insert(cloudCredentials).values({
          userId: adminId,
          provider: 'aws',
          name: 'Example AWS Credentials',
          credentials: JSON.stringify({
            accessKeyId: 'EXAMPLE_ACCESS_KEY_ID',
            secretAccessKey: 'EXAMPLE_SECRET_ACCESS_KEY',
            region: 'us-east-1'
          }),
          isEncrypted: true,
          passwordHash: hashedPassword,
          isActive: true,
          createdAt: new Date()
        });
        
        console.log('\x1b[32m%s\x1b[0m', 'Example cloud credentials created successfully!');
        console.log('\x1b[0m', 'Note: These are example credentials for demo purposes only.');
        console.log('\x1b[0m', 'Password for example credentials: ExamplePassword123');
      } else {
        console.log('\x1b[31m%s\x1b[0m', 'No admin user found. Skipping cloud credentials creation.');
      }
    } else {
      console.log('\x1b[33m%s\x1b[0m', 'Cloud credentials already exist. Skipping creation.');
    }
    
    console.log('\x1b[32m%s\x1b[0m', 'Database setup completed successfully!');
    console.log('\x1b[0m', '');
    console.log('\x1b[33m%s\x1b[0m', 'You can now log in with the following credentials:');
    console.log('\x1b[0m', `Email: ${adminEmail}`);
    console.log('\x1b[0m', `Password: ${'*'.repeat(adminPassword.length)}`);
    
  } catch (error) {
    console.error('\x1b[31m%s\x1b[0m', 'Error setting up database:');
    console.error(error);
    process.exit(1);
  }
  
  // Exit the process
  process.exit(0);
}

// Run the setup function
setupDatabase();