#!/bin/bash
# SecureDeployX Installation Script
# This script automates the installation process of the SecureDeployX application

# Color formatting
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}"
echo "  _____                          _____             _                  __   __"
echo " / ____|                        |  __ \           | |                 \ \ / /"
echo "| (___   ___  ___ _   _ _ __ ___| |  | | ___ _ __ | | ___  _   _      \ V / "
echo " \___ \ / _ \/ __| | | | '__/ _ \ |  | |/ _ \ '_ \| |/ _ \| | | |      > <  "
echo " ____) |  __/ (__| |_| | | |  __/ |__| |  __/ |_) | | (_) | |_| |     / . \ "
echo "|_____/ \___|\___|\__,_|_|  \___|_____/ \___| .__/|_|\___/ \__, |    /_/ \_\\"
echo "                                            | |             __/ |           "
echo "                                            |_|            |___/            "
echo -e "${NC}"
echo -e "${YELLOW}SecureDeployX Installation Script${NC}"
echo ""

# Check if Node.js is installed
check_nodejs() {
    echo -e "${YELLOW}Checking Node.js installation...${NC}"
    
    if ! command -v node &> /dev/null; then
        echo -e "${RED}Node.js is not installed.${NC}"
        
        echo -e "${YELLOW}Would you like to install Node.js? (y/n)${NC}"
        read -r install_nodejs
        
        if [[ $install_nodejs =~ ^[Yy]$ ]]; then
            echo -e "${YELLOW}Installing Node.js...${NC}"
            
            # Check the operating system
            if [[ "$OSTYPE" == "linux-gnu"* ]]; then
                # For Linux
                curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
                sudo apt-get install -y nodejs
            elif [[ "$OSTYPE" == "darwin"* ]]; then
                # For macOS
                brew install node
            else
                echo -e "${RED}Unsupported operating system. Please install Node.js manually.${NC}"
                echo -e "${RED}Visit https://nodejs.org/ for installation instructions.${NC}"
                exit 1
            fi
            
            echo -e "${GREEN}Node.js installed successfully!${NC}"
        else
            echo -e "${RED}Node.js is required to run SecureDeployX.${NC}"
            echo -e "${RED}Please install Node.js and run this script again.${NC}"
            echo -e "${RED}Visit https://nodejs.org/ for installation instructions.${NC}"
            exit 1
        fi
    else
        echo -e "${GREEN}Node.js is already installed!${NC}"
    fi
}

# Install npm dependencies
install_dependencies() {
    echo -e "${YELLOW}Installing npm dependencies...${NC}"
    
    npm install
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: Failed to install npm dependencies.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Dependencies installed successfully!${NC}"
}

# Check and setup database
setup_database() {
    echo -e "${YELLOW}Setting up database...${NC}"
    
    # Check if database exists
    if [ -z "$DATABASE_URL" ]; then
        echo -e "${YELLOW}No database connection found. Creating a new database...${NC}"
        
        # Try to create a database
        echo -e "${YELLOW}Would you like to create a PostgreSQL database? (y/n)${NC}"
        read -r create_db
        
        if [[ $create_db =~ ^[Yy]$ ]]; then
            echo -e "${YELLOW}Creating PostgreSQL database...${NC}"
            npx tsx tools/createPostgresDatabase.ts
            
            if [ $? -ne 0 ]; then
                echo -e "${RED}Failed to create database.${NC}"
                exit 1
            fi
            
            echo -e "${GREEN}Database created successfully!${NC}"
        else
            echo -e "${RED}Database is required to continue installation.${NC}"
            exit 1
        fi
    else
        echo -e "${GREEN}Database connection found!${NC}"
    fi
    
    # Update database schema
    echo -e "${YELLOW}Updating database schema...${NC}"
    npx drizzle-kit push
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: Failed to update database schema.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Database schema updated successfully!${NC}"
}

# Setup admin user
setup_admin() {
    echo -e "${YELLOW}Setting up admin user...${NC}"
    
    echo -e "${BLUE}Please provide admin user credentials:${NC}"
    echo -n "Email (default: admin@example.com): "
    read -r admin_email
    admin_email=${admin_email:-admin@example.com}
    
    echo -n "Password (default: SecurePassword123): "
    read -rs admin_password
    echo ""
    admin_password=${admin_password:-SecurePassword123}
    
    node setup-db.js "$admin_email" "$admin_password"
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: Failed to set up admin user.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Admin user setup completed successfully!${NC}"
    echo -e "You can log in with the following credentials:"
    echo -e "Email: ${BLUE}${admin_email}${NC}"
    echo -e "Password: ${BLUE}******${NC}"
}

# Setup environment variables
setup_env() {
    echo -e "${YELLOW}Setting up environment variables...${NC}"
    
    if [ ! -f ".env" ]; then
        echo -e "${YELLOW}Creating .env file...${NC}"
        
        cat > .env << EOL
# SecureDeployX Environment Variables

# Database
# These are automatically set by the database creation process

# Session Secret (automatically generated)
SESSION_SECRET=$(openssl rand -hex 32)

# Gemini API (optional)
# GEMINI_API_KEY=your_gemini_api_key_here

# OpenAI API (optional)
# OPENAI_API_KEY=your_openai_api_key_here

# PayPal API (optional)
# PAYPAL_CLIENT_ID=your_paypal_client_id_here
# PAYPAL_CLIENT_SECRET=your_paypal_client_secret_here

# AWS Integration (optional)
# AWS_ACCESS_KEY_ID=your_aws_access_key_id_here
# AWS_SECRET_ACCESS_KEY=your_aws_secret_access_key_here
# AWS_REGION=us-east-1
EOL
        
        echo -e "${GREEN}.env file created successfully!${NC}"
        
        echo -e "${YELLOW}Would you like to add AI service API keys now? (y/n)${NC}"
        read -r add_api_keys
        
        if [[ $add_api_keys =~ ^[Yy]$ ]]; then
            echo -e "${BLUE}Please provide API keys:${NC}"
            
            echo -n "Gemini API Key (leave blank to skip): "
            read -r gemini_api_key
            
            if [ -n "$gemini_api_key" ]; then
                sed -i "s/# GEMINI_API_KEY=your_gemini_api_key_here/GEMINI_API_KEY=${gemini_api_key}/g" .env
            fi
            
            echo -n "OpenAI API Key (leave blank to skip): "
            read -r openai_api_key
            
            if [ -n "$openai_api_key" ]; then
                sed -i "s/# OPENAI_API_KEY=your_openai_api_key_here/OPENAI_API_KEY=${openai_api_key}/g" .env
            fi
            
            echo -e "${GREEN}API keys added successfully!${NC}"
        fi
    else
        echo -e "${GREEN}.env file already exists!${NC}"
    fi
}

# Main function
main() {
    echo -e "${YELLOW}Starting SecureDeployX installation...${NC}"
    
    check_nodejs
    install_dependencies
    setup_env
    setup_database
    setup_admin
    
    echo -e "${GREEN}SecureDeployX has been installed successfully!${NC}"
    echo -e "${YELLOW}You can now run the application with: npm run dev${NC}"
    
    echo -e "${YELLOW}Would you like to start the application now? (y/n)${NC}"
    read -r start_app
    
    if [[ $start_app =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Starting the application...${NC}"
        npm run dev
    else
        echo -e "${GREEN}Installation completed successfully!${NC}"
        echo -e "${YELLOW}You can start the application by running: npm run dev${NC}"
    fi
}

# Execute main function
main