#!/bin/bash
# SecureDeployX Deployment Script
# This script automates the deployment process of the SecureDeployX application

# Color formatting
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}"
echo "  _____                          _____             _                  __   __"
echo " / ____|                        |  __ \           | |                 \ \ / /"
echo "| (___   ___  ___ _   _ _ __ ___| |  | | ___ _ __ | | ___  _   _      \ V / "
echo " \___ \ / _ \/ __| | | | '__/ _ \ |  | |/ _ \ '_ \| |/ _ \| | | |      > <  "
echo " ____) |  __/ (__| |_| | | |  __/ |__| |  __/ |_) | | (_) | |_| |     / . \ "
echo "|_____/ \___|\___|\__,_|_|  \___|_____/ \___| .__/|_|\___/ \__, |    /_/ \_\\"
echo "                                            | |             __/ |           "
echo "                                            |_|            |___/            "
echo -e "${NC}"
echo -e "${YELLOW}SecureDeployX Deployment Script${NC}"
echo ""

# Default values
ADMIN_EMAIL="admin@example.com"
ADMIN_PASSWORD="SecurePassword123"

# Function to check if database is available
check_database() {
    echo -e "${YELLOW}Checking database connection...${NC}"
    
    if [ -z "$DATABASE_URL" ]; then
        echo -e "${RED}Error: DATABASE_URL environment variable is not set.${NC}"
        
        echo -e "${YELLOW}Would you like to create a new PostgreSQL database? (y/n)${NC}"
        read -r create_db
        if [[ $create_db =~ ^[Yy]$ ]]; then
            echo -e "${YELLOW}Creating PostgreSQL database...${NC}"
            node -e "require('child_process').execSync('npx tsx tools/createPostgresDatabase.ts', {stdio: 'inherit'})"
            
            if [ $? -ne 0 ]; then
                echo -e "${RED}Failed to create database.${NC}"
                exit 1
            fi
            echo -e "${GREEN}Database created successfully!${NC}"
        else
            echo -e "${RED}Database is required to continue installation.${NC}"
            exit 1
        fi
    else
        # Try to connect to the database
        if ! node -e "const { db } = require('./server/db'); async function testConnection() { try { await db.execute('SELECT 1'); console.log('Connection successful'); } catch (e) { console.error(e); process.exit(1); } } testConnection();" >/dev/null 2>&1; then
            echo -e "${RED}Error: Could not connect to the database.${NC}"
            echo -e "${RED}Please check your DATABASE_URL environment variable.${NC}"
            exit 1
        fi
        
        echo -e "${GREEN}Database connection successful!${NC}"
    fi
}

# Create or update database schema
update_schema() {
    echo -e "${YELLOW}Updating database schema...${NC}"
    
    # Run db:push to update schema
    npx drizzle-kit push
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: Failed to update database schema.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Database schema updated successfully!${NC}"
}

# Setup admin and initial data
setup_data() {
    echo -e "${YELLOW}Would you like to customize the admin user? (y/n)${NC}"
    read -r customize_admin
    
    if [[ $customize_admin =~ ^[Yy]$ ]]; then
        echo -e "${BLUE}Please provide admin user credentials:${NC}"
        echo -n "Email (default: admin@example.com): "
        read -r custom_email
        if [ -n "$custom_email" ]; then
            ADMIN_EMAIL=$custom_email
        fi
        
        echo -n "Password (default: hidden): "
        read -rs custom_password
        echo ""
        if [ -n "$custom_password" ]; then
            ADMIN_PASSWORD=$custom_password
        fi
    fi
    
    echo -e "${YELLOW}Setting up admin user and initial data...${NC}"
    node setup-db.js "$ADMIN_EMAIL" "$ADMIN_PASSWORD"
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: Failed to set up initial data.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Initial data setup completed successfully!${NC}"
}

# Deploy application
deploy_app() {
    echo -e "${YELLOW}Building the application...${NC}"
    
    # Build the application
    npm run build
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: Failed to build the application.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Application built successfully!${NC}"
    
    echo -e "${YELLOW}Would you like to start the application now? (y/n)${NC}"
    read -r start_app
    
    if [[ $start_app =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Starting the application...${NC}"
        npm run start &
        APP_PID=$!
        
        echo -e "${GREEN}Application started successfully!${NC}"
        echo -e "The application is now running at http://localhost:5000"
        echo -e "You can log in with the following credentials:"
        echo -e "Email: ${BLUE}${ADMIN_EMAIL}${NC}"
        echo -e "Password: ${BLUE}******${NC}"
        
        echo -e "${YELLOW}Press Enter to stop the application...${NC}"
        read
        
        kill $APP_PID
    else
        echo -e "${GREEN}Application is ready to be deployed!${NC}"
        echo -e "You can start the application with: ${BLUE}npm run start${NC}"
        echo -e "Access the application at: ${BLUE}http://localhost:5000${NC}"
        echo -e "Log in with the following credentials:"
        echo -e "Email: ${BLUE}${ADMIN_EMAIL}${NC}"
        echo -e "Password: ${BLUE}******${NC}"
    fi
}

# Main function
main() {
    echo -e "${YELLOW}Starting deployment process...${NC}"
    
    check_database
    update_schema
    setup_data
    deploy_app
    
    echo -e "${GREEN}Deployment completed successfully!${NC}"
}

# Execute main function
main