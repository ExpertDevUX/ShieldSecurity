import bcrypt from 'bcryptjs';
import { db } from './server/db';
import { users } from './shared/schema';

async function createAdminUser() {
  try {
    // Admin user details
    const username = 'admin';
    const email = 'admin@example.com';
    const password = 'admin123';
    const role = 'admin';

    // Check if user already exists
    const existingUsers = await db.select().from(users).where(users.username.equals(username));
    
    if (existingUsers.length > 0) {
      console.log('Admin user already exists');
      return;
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Create the admin user directly with Drizzle
    const [newUser] = await db
      .insert(users)
      .values({
        username,
        email,
        passwordHash,
        role: role as "admin",
        status: 'active' as "active",
      })
      .returning();

    console.log('Admin user created successfully:', newUser);
  } catch (error) {
    console.error('Error creating admin user:', error);
  } finally {
    // Close the database connection
    if (db.client && typeof db.client.end === 'function') {
      await db.client.end();
    }
  }
}

// Self-executing async function
(async () => {
  await createAdminUser();
  process.exit(0);
})();