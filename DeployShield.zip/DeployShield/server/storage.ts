import {
  projects, type Project, type InsertProject,
  securityScans, type SecurityScan, type InsertSecurityScan,
  vulnerabilities, type Vulnerability, type InsertVulnerability,
  deployments, type Deployment, type InsertDeployment,
  seoAnalyses, type SEOAnalysis, type InsertSEOAnalysis,
  penTests, type PenTest, type InsertPenTest,
  tasks, type Task, type InsertTask,
  trafficBoosts, type TrafficBoost, type InsertTrafficBoost,
  pageSpeedAnalyses, type PageSpeedAnalysis, type InsertPageSpeedAnalysis,
  urlScans, type UrlScan, type InsertUrlScan,
  users, type User, type InsertUser,
  apiConfigurations, type ApiConfiguration, type InsertApiConfiguration,
  deploymentProviders, type DeploymentProvider, type InsertDeploymentProvider,
  twoFactorAuth as tfaTable, type TwoFactorAuth, type InsertTwoFactorAuth,
  notifications, type Notification, type InsertNotification,
  subscriptions, type Subscription, type InsertSubscription,
  transactions, type Transaction, type InsertTransaction,
  performanceOptimizations, type PerformanceOptimization, type InsertPerformanceOptimization,
  // User Template Settings
  templateSettings, type TemplateSettings, type InsertTemplateSettings,
  // AWS Credentials
  awsCredentials, type AwsCredentials, type InsertAwsCredentials,
  cloudCredentials, type CloudCredential, type InsertCloudCredential,
  // New Advanced Features Models (1-10)
  codeGenerations, type CodeGeneration, type InsertCodeGeneration,
  collaborationSessions, type CollaborationSession, type InsertCollaborationSession,
  collaborationParticipants, type CollaborationParticipant, type InsertCollaborationParticipant,
  collaborationMessages, type CollaborationMessage, type InsertCollaborationMessage,
  deploymentVersions, type DeploymentVersion, type InsertDeploymentVersion,
  rollbacks, type Rollback, type InsertRollback,
  complianceScans, type ComplianceScan, type InsertComplianceScan,
  ciCdIntegrations, type CiCdIntegration, type InsertCiCdIntegration,
  ciCdPipelines, type CiCdPipeline, type InsertCiCdPipeline,
  ciCdRuns, type CiCdRun, type InsertCiCdRun,
  apmMetrics, type ApmMetric, type InsertApmMetric,
  apmAlerts, type ApmAlert, type InsertApmAlert,
  incidents, type Incident, type InsertIncident,
  incidentResponses, type IncidentResponse, type InsertIncidentResponse,
  deploymentEnvironments, type DeploymentEnvironment, type InsertDeploymentEnvironment,
  environmentDeployments, type EnvironmentDeployment, type InsertEnvironmentDeployment,
  costOptimizations, type CostOptimization, type InsertCostOptimization,
  plugins, type Plugin, type InsertPlugin,
  pluginUsages, type PluginUsage, type InsertPluginUsage,
  // Interactive Learning Playground
  tutorials, type Tutorial, type InsertTutorial,
  tutorialSteps, type TutorialStep, type InsertTutorialStep,
  userTutorialProgress, type UserTutorialProgress, type InsertUserTutorialProgress,
  userStepSubmissions, type UserStepSubmission, type InsertUserStepSubmission,
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { eq, and, ne } from "drizzle-orm";
import { db } from "./db";
import bcrypt from 'bcryptjs';

// Helper function to compare passwords
async function comparePasswords(plainPassword: string, hashedPassword: string): Promise<boolean> {
  return await bcrypt.compare(plainPassword, hashedPassword);
}

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  
  // Security Scans
  getSecurityScans(projectId?: number): Promise<SecurityScan[]>;
  getSecurityScan(id: number): Promise<SecurityScan | undefined>;
  createSecurityScan(scan: InsertSecurityScan): Promise<SecurityScan>;
  
  // Vulnerabilities
  getVulnerabilities(scanId: number): Promise<Vulnerability[]>;
  getVulnerability(id: number): Promise<Vulnerability | undefined>;
  createVulnerability(vulnerability: InsertVulnerability): Promise<Vulnerability>;
  updateVulnerability(id: number, fixed: boolean): Promise<Vulnerability | undefined>;
  
  // AI-POWERED CODE GENERATION
  getCodeGenerations(projectId?: number, userId?: number): Promise<CodeGeneration[]>;
  getCodeGeneration(id: number): Promise<CodeGeneration | undefined>;
  createCodeGeneration(codeGen: InsertCodeGeneration): Promise<CodeGeneration>;
  updateCodeGenerationResult(id: number, result: string): Promise<CodeGeneration | undefined>;
  updateCodeGenerationRating(id: number, rating: number): Promise<CodeGeneration | undefined>;
  updateCodeGenerationUsage(id: number, used: boolean): Promise<CodeGeneration | undefined>;
  
  // REAL-TIME COLLABORATION
  getCollaborationSessions(projectId?: number): Promise<CollaborationSession[]>;
  getCollaborationSession(id: number): Promise<CollaborationSession | undefined>;
  createCollaborationSession(session: InsertCollaborationSession): Promise<CollaborationSession>;
  updateCollaborationSessionStatus(id: number, status: string): Promise<CollaborationSession | undefined>;
  endCollaborationSession(id: number): Promise<CollaborationSession | undefined>;
  getCollaborationParticipants(sessionId: number): Promise<CollaborationParticipant[]>;
  getCollaborationParticipant(id: number): Promise<CollaborationParticipant | undefined>;
  createCollaborationParticipant(participant: InsertCollaborationParticipant): Promise<CollaborationParticipant>;
  updateCollaborationParticipantRole(id: number, role: string): Promise<CollaborationParticipant | undefined>;
  removeCollaborationParticipant(id: number): Promise<boolean>;
  getCollaborationMessages(sessionId: number): Promise<CollaborationMessage[]>;
  createCollaborationMessage(message: InsertCollaborationMessage): Promise<CollaborationMessage>;
  
  // DEPLOYMENT ROLLBACK & VERSION CONTROL
  getDeploymentVersions(deploymentId: number): Promise<DeploymentVersion[]>;
  getDeploymentVersion(id: number): Promise<DeploymentVersion | undefined>;
  createDeploymentVersion(version: InsertDeploymentVersion): Promise<DeploymentVersion>;
  updateDeploymentVersionStatus(id: number, status: string): Promise<DeploymentVersion | undefined>;
  getRollbacks(deploymentId: number): Promise<Rollback[]>;
  getRollback(id: number): Promise<Rollback | undefined>;
  createRollback(rollback: InsertRollback): Promise<Rollback>;
  updateRollbackStatus(id: number, status: string, logs?: string): Promise<Rollback | undefined>;
  
  // Deployments
  getDeployments(projectId?: number): Promise<Deployment[]>;
  getDeployment(id: number): Promise<Deployment | undefined>;
  createDeployment(deployment: InsertDeployment): Promise<Deployment>;
  
  // SEO Analyses
  getSEOAnalyses(): Promise<SEOAnalysis[]>;
  getSEOAnalysis(id: number): Promise<SEOAnalysis | undefined>;
  createSEOAnalysis(analysis: InsertSEOAnalysis): Promise<SEOAnalysis>;
  
  // Pen Tests
  getPenTests(): Promise<PenTest[]>;
  getPenTest(id: number): Promise<PenTest | undefined>;
  createPenTest(test: InsertPenTest): Promise<PenTest>;

  // Traffic Boosts
  getTrafficBoosts(): Promise<TrafficBoost[]>;
  getTrafficBoost(id: number): Promise<TrafficBoost | undefined>;
  createTrafficBoost(boost: InsertTrafficBoost): Promise<TrafficBoost>;
  updateTrafficBoostStatus(id: number, status: string, endDate?: Date): Promise<TrafficBoost | undefined>;
  
  // Page Speed Analyses
  getPageSpeedAnalyses(): Promise<PageSpeedAnalysis[]>;
  getPageSpeedAnalysis(id: number): Promise<PageSpeedAnalysis | undefined>;
  createPageSpeedAnalysis(analysis: InsertPageSpeedAnalysis): Promise<PageSpeedAnalysis>;
  
  // URL Scans
  getUrlScans(): Promise<UrlScan[]>;
  getUrlScan(id: number): Promise<UrlScan | undefined>;
  createUrlScan(scan: InsertUrlScan): Promise<UrlScan>;

  // Progress Tracking Tasks
  getTasks(projectId?: number): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTaskProgress(id: number, progress: number, status?: string): Promise<Task | undefined>;
  
  // Users
  getUsers(): Promise<User[]>;
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: number, status: string): Promise<User | undefined>;
  updateUserRole(id: number, role: string): Promise<User | undefined>;
  updateUserPassword(id: number, passwordHash: string): Promise<User | undefined>;
  updateUserLastLogin(id: number): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // API Configurations
  getApiConfigurations(): Promise<ApiConfiguration[]>;
  getApiConfiguration(id: number): Promise<ApiConfiguration | undefined>;
  getApiConfigurationByProvider(provider: string): Promise<ApiConfiguration | undefined>;
  createApiConfiguration(config: InsertApiConfiguration): Promise<ApiConfiguration>;
  updateApiConfiguration(id: number, config: Partial<InsertApiConfiguration>): Promise<ApiConfiguration | undefined>;
  deleteApiConfiguration(id: number): Promise<boolean>;
  
  // Deployment Providers
  getDeploymentProviders(): Promise<DeploymentProvider[]>;
  getDeploymentProvider(id: number): Promise<DeploymentProvider | undefined>;
  getActiveDeploymentProviders(): Promise<DeploymentProvider[]>;
  createDeploymentProvider(provider: InsertDeploymentProvider): Promise<DeploymentProvider>;
  updateDeploymentProvider(id: number, provider: Partial<InsertDeploymentProvider>): Promise<DeploymentProvider | undefined>;
  deleteDeploymentProvider(id: number): Promise<boolean>;
  
  // Two-Factor Authentication
  getTwoFactorAuth(userId: number): Promise<TwoFactorAuth | undefined>;
  createTwoFactorAuth(twoFactor: InsertTwoFactorAuth): Promise<TwoFactorAuth>;
  updateTwoFactorAuth(userId: number, verified: boolean): Promise<TwoFactorAuth | undefined>;
  deleteTwoFactorAuth(userId: number): Promise<boolean>;

  // Notifications
  getNotifications(userId: number, read?: boolean): Promise<Notification[]>;
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  deleteNotification(id: number): Promise<boolean>;
  
  // Subscriptions
  getSubscriptions(userId?: number): Promise<Subscription[]>;
  getSubscription(id: number): Promise<Subscription | undefined>;
  getUserActiveSubscription(userId: number): Promise<Subscription | undefined>;
  getActiveSubscriptionByUserId(userId: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  createOrUpdateSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, status: string, endDate?: Date): Promise<Subscription | undefined>;
  updateSubscriptionStatus(id: number, status: string): Promise<Subscription | undefined>;
  
  // Transactions
  getTransactions(userId?: number): Promise<Transaction[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(id: number, status: string): Promise<Transaction | undefined>;
  
  // Template Settings
  getTemplateSettings(type?: string): Promise<TemplateSettings[]>;
  getTemplateSettingById(id: number): Promise<TemplateSettings | undefined>;
  getDefaultTemplateSettingByType(type: string): Promise<TemplateSettings | undefined>;
  createTemplateSetting(templateSetting: InsertTemplateSettings): Promise<TemplateSettings>;
  updateTemplateSetting(id: number, templateSetting: Partial<InsertTemplateSettings>): Promise<TemplateSettings | undefined>;
  setDefaultTemplateSetting(id: number, type: string): Promise<TemplateSettings | undefined>;
  deleteTemplateSetting(id: number): Promise<boolean>;
  
  // Performance Optimizations
  getPerformanceOptimizations(projectId?: number): Promise<PerformanceOptimization[]>;
  getPerformanceOptimization(id: number): Promise<PerformanceOptimization | undefined>;
  createPerformanceOptimization(optimization: InsertPerformanceOptimization): Promise<PerformanceOptimization>;
  updatePerformanceOptimizationStatus(id: number, status: string): Promise<PerformanceOptimization | undefined>;
  completePerformanceOptimization(id: number, results: any, afterScore: number, appliedChanges: any): Promise<PerformanceOptimization | undefined>;

  // 1. AI-Powered Code Generation
  getCodeGenerations(projectId?: number, userId?: number): Promise<CodeGeneration[]>;
  getCodeGeneration(id: number): Promise<CodeGeneration | undefined>;
  createCodeGeneration(codeGen: InsertCodeGeneration): Promise<CodeGeneration>;
  updateCodeGenerationResult(id: number, result: string): Promise<CodeGeneration | undefined>;
  updateCodeGenerationRating(id: number, rating: number): Promise<CodeGeneration | undefined>;
  updateCodeGenerationUsage(id: number, used: boolean): Promise<CodeGeneration | undefined>;
  updateCodeGenerationMetadata(id: number, metadata: any): Promise<CodeGeneration | undefined>;

  // 2. Real-time Collaboration
  getCollaborationSessions(projectId?: number): Promise<CollaborationSession[]>;
  getCollaborationSession(id: number): Promise<CollaborationSession | undefined>;
  createCollaborationSession(session: InsertCollaborationSession): Promise<CollaborationSession>;
  updateCollaborationSessionStatus(id: number, status: string): Promise<CollaborationSession | undefined>;
  endCollaborationSession(id: number): Promise<CollaborationSession | undefined>;
  
  getCollaborationParticipants(sessionId: number): Promise<CollaborationParticipant[]>;
  getCollaborationParticipant(id: number): Promise<CollaborationParticipant | undefined>;
  createCollaborationParticipant(participant: InsertCollaborationParticipant): Promise<CollaborationParticipant>;
  updateCollaborationParticipantRole(id: number, role: string): Promise<CollaborationParticipant | undefined>;
  removeCollaborationParticipant(id: number): Promise<boolean>;
  
  getCollaborationMessages(sessionId: number): Promise<CollaborationMessage[]>;
  createCollaborationMessage(message: InsertCollaborationMessage): Promise<CollaborationMessage>;

  // 3. Deployment Rollback and Version Control
  getDeploymentVersions(deploymentId: number): Promise<DeploymentVersion[]>;
  getDeploymentVersion(id: number): Promise<DeploymentVersion | undefined>;
  createDeploymentVersion(version: InsertDeploymentVersion): Promise<DeploymentVersion>;
  updateDeploymentVersionStatus(id: number, status: string): Promise<DeploymentVersion | undefined>;
  
  getRollbacks(deploymentId: number): Promise<Rollback[]>;
  getRollback(id: number): Promise<Rollback | undefined>;
  createRollback(rollback: InsertRollback): Promise<Rollback>;
  updateRollbackStatus(id: number, status: string, logs?: string): Promise<Rollback | undefined>;

  // 4. Enhanced Security Compliance
  getComplianceScans(projectId?: number): Promise<ComplianceScan[]>;
  getComplianceScan(id: number): Promise<ComplianceScan | undefined>;
  createComplianceScan(scan: InsertComplianceScan): Promise<ComplianceScan>;
  updateComplianceScanStatus(id: number, status: string): Promise<ComplianceScan | undefined>;
  completeComplianceScan(id: number, score: number, report: any, issues: any, recommendations: any): Promise<ComplianceScan | undefined>;

  // 5. CI/CD Pipeline Integration
  getCiCdIntegrations(projectId?: number): Promise<CiCdIntegration[]>;
  getCiCdIntegration(id: number): Promise<CiCdIntegration | undefined>;
  createCiCdIntegration(integration: InsertCiCdIntegration): Promise<CiCdIntegration>;
  updateCiCdIntegration(id: number, integration: Partial<InsertCiCdIntegration>): Promise<CiCdIntegration | undefined>;
  deleteCiCdIntegration(id: number): Promise<boolean>;
  
  getCiCdPipelines(integrationId: number): Promise<CiCdPipeline[]>;
  getCiCdPipeline(id: number): Promise<CiCdPipeline | undefined>;
  createCiCdPipeline(pipeline: InsertCiCdPipeline): Promise<CiCdPipeline>;
  updateCiCdPipeline(id: number, pipeline: Partial<InsertCiCdPipeline>): Promise<CiCdPipeline | undefined>;
  deleteCiCdPipeline(id: number): Promise<boolean>;
  
  getCiCdRuns(pipelineId: number): Promise<CiCdRun[]>;
  getCiCdRun(id: number): Promise<CiCdRun | undefined>;
  createCiCdRun(run: InsertCiCdRun): Promise<CiCdRun>;
  updateCiCdRunStatus(id: number, status: string, logs?: string): Promise<CiCdRun | undefined>;
  completeCiCdRun(id: number, status: string, endTime: Date, logs?: string): Promise<CiCdRun | undefined>;

  // 6. Application Performance Monitoring
  getApmMetrics(projectId: number): Promise<ApmMetric[]>;
  createApmMetric(metric: InsertApmMetric): Promise<ApmMetric>;
  
  getApmAlerts(projectId?: number, status?: string): Promise<ApmAlert[]>;
  getApmAlert(id: number): Promise<ApmAlert | undefined>;
  createApmAlert(alert: InsertApmAlert): Promise<ApmAlert>;
  updateApmAlertStatus(id: number, status: string): Promise<ApmAlert | undefined>;
  resolveApmAlert(id: number, resolvedBy: number): Promise<ApmAlert | undefined>;

  // 7. AI-Driven Incident Response
  getIncidents(projectId?: number, status?: string): Promise<Incident[]>;
  getIncident(id: number): Promise<Incident | undefined>;
  createIncident(incident: InsertIncident): Promise<Incident>;
  updateIncidentStatus(id: number, status: string): Promise<Incident | undefined>;
  assignIncident(id: number, assignedTo: number): Promise<Incident | undefined>;
  resolveIncident(id: number): Promise<Incident | undefined>;
  
  getIncidentResponses(incidentId: number): Promise<IncidentResponse[]>;
  getIncidentResponse(id: number): Promise<IncidentResponse | undefined>;
  createIncidentResponse(response: InsertIncidentResponse): Promise<IncidentResponse>;
  updateIncidentResponseStatus(id: number, status: string): Promise<IncidentResponse | undefined>;
  applyIncidentResponse(id: number, appliedBy: number, result: string): Promise<IncidentResponse | undefined>;

  // 8. Multi-Environment Deployment Management
  getDeploymentEnvironments(projectId?: number): Promise<DeploymentEnvironment[]>;
  getDeploymentEnvironment(id: number): Promise<DeploymentEnvironment | undefined>;
  createDeploymentEnvironment(environment: InsertDeploymentEnvironment): Promise<DeploymentEnvironment>;
  updateDeploymentEnvironment(id: number, environment: Partial<InsertDeploymentEnvironment>): Promise<DeploymentEnvironment | undefined>;
  toggleDeploymentEnvironmentStatus(id: number, isActive: boolean): Promise<DeploymentEnvironment | undefined>;
  
  getEnvironmentDeployments(environmentId: number): Promise<EnvironmentDeployment[]>;
  getEnvironmentDeployment(id: number): Promise<EnvironmentDeployment | undefined>;
  createEnvironmentDeployment(deployment: InsertEnvironmentDeployment): Promise<EnvironmentDeployment>;
  updateEnvironmentDeploymentStatus(id: number, status: string): Promise<EnvironmentDeployment | undefined>;

  // 9. Cost Optimization Analysis
  getCostOptimizations(projectId?: number): Promise<CostOptimization[]>;
  getCostOptimization(id: number): Promise<CostOptimization | undefined>;
  createCostOptimization(optimization: InsertCostOptimization): Promise<CostOptimization>;
  updateCostOptimizationStatus(id: number, status: string): Promise<CostOptimization | undefined>;
  completeCostOptimization(id: number, currentCost: number, projectedSavings: number, analysis: any, recommendations: any): Promise<CostOptimization | undefined>;
  implementCostOptimizationChanges(id: number, implementedChanges: any): Promise<CostOptimization | undefined>;
  
  // AWS Deployment Credentials
  getAwsCredentials(userId: number): Promise<AwsCredentials[]>;
  getAwsCredential(id: number): Promise<AwsCredentials | undefined>;
  createAwsCredential(credential: InsertAwsCredentials): Promise<AwsCredentials>;
  updateAwsCredential(id: number, credential: Partial<InsertAwsCredentials>): Promise<AwsCredentials | undefined>;
  deleteAwsCredential(id: number): Promise<boolean>;
  verifyAwsCredential(id: number, password: string): Promise<AwsCredentials | undefined>;
  updateAwsCredentialLastUsed(id: number): Promise<AwsCredentials | undefined>;
  
  // Cloud Provider Credentials (General)
  getCloudCredentials(userId: number): Promise<CloudCredential[]>;
  getCloudCredential(id: number): Promise<CloudCredential | undefined>;
  createCloudCredential(credential: InsertCloudCredential): Promise<CloudCredential>;
  updateCloudCredential(id: number, credential: Partial<InsertCloudCredential>): Promise<CloudCredential | undefined>;
  deleteCloudCredential(id: number): Promise<boolean>;
  verifyCloudCredential(id: number, password: string): Promise<CloudCredential | undefined>;

  // 10. Custom Plugin System
  getPlugins(status?: string): Promise<Plugin[]>;
  getPlugin(id: number): Promise<Plugin | undefined>;
  createPlugin(plugin: InsertPlugin): Promise<Plugin>;
  updatePluginStatus(id: number, status: string): Promise<Plugin | undefined>;
  updatePlugin(id: number, plugin: Partial<InsertPlugin>): Promise<Plugin | undefined>;
  deletePlugin(id: number): Promise<boolean>;
  
  getPluginUsages(projectId?: number, pluginId?: number): Promise<PluginUsage[]>;
  getPluginUsage(id: number): Promise<PluginUsage | undefined>;
  createPluginUsage(usage: InsertPluginUsage): Promise<PluginUsage>;
  togglePluginUsage(id: number, enabled: boolean): Promise<PluginUsage | undefined>;
  updatePluginUsageConfiguration(id: number, configuration: any): Promise<PluginUsage | undefined>;
  updatePluginUsageLastUsed(id: number): Promise<PluginUsage | undefined>;

  // Interactive Learning Playground - Tutorials
  getTutorials(filterPublished?: boolean): Promise<Tutorial[]>;
  getTutorialById(id: number): Promise<Tutorial | undefined>;
  getTutorialsByLanguage(language: string): Promise<Tutorial[]>;
  getTutorialsByDifficulty(difficulty: string): Promise<Tutorial[]>;
  createTutorial(tutorial: InsertTutorial): Promise<Tutorial>;
  updateTutorial(id: number, tutorial: Partial<InsertTutorial>): Promise<Tutorial | undefined>;
  updateTutorialPublishStatus(id: number, isPublished: boolean): Promise<Tutorial | undefined>;
  updateTutorialTotalSteps(id: number, totalSteps: number): Promise<Tutorial | undefined>;
  deleteTutorial(id: number): Promise<boolean>;
  
  // Tutorial Steps
  getTutorialSteps(tutorialId: number): Promise<TutorialStep[]>;
  getTutorialStepById(id: number): Promise<TutorialStep | undefined>;
  createTutorialStep(step: InsertTutorialStep): Promise<TutorialStep>;
  updateTutorialStep(id: number, step: Partial<InsertTutorialStep>): Promise<TutorialStep | undefined>;
  deleteTutorialStep(id: number): Promise<boolean>;
  
  // User Tutorial Progress
  getUserTutorialProgress(userId: number, tutorialId?: number): Promise<UserTutorialProgress[]>;
  getUserTutorialProgressById(id: number): Promise<UserTutorialProgress | undefined>;
  createUserTutorialProgress(progress: InsertUserTutorialProgress): Promise<UserTutorialProgress>;
  updateUserTutorialCurrentStep(id: number, currentStep: number): Promise<UserTutorialProgress | undefined>;
  updateUserTutorialCompletedSteps(id: number, completedSteps: number[]): Promise<UserTutorialProgress | undefined>;
  markTutorialComplete(id: number): Promise<UserTutorialProgress | undefined>;
  
  // User Step Submissions
  getUserStepSubmissions(userId: number, tutorialId: number, stepId?: number): Promise<UserStepSubmission[]>;
  getUserStepSubmissionById(id: number): Promise<UserStepSubmission | undefined>;
  createUserStepSubmission(submission: InsertUserStepSubmission): Promise<UserStepSubmission>;
  updateUserStepSubmissionFeedback(id: number, isCorrect: boolean, feedback: string): Promise<UserStepSubmission | undefined>;
}

export class MemStorage implements IStorage {
  sessionStore: session.Store;
  private projects: Map<number, Project>;
  private securityScans: Map<number, SecurityScan>;
  private vulnerabilities: Map<number, Vulnerability>;
  private deployments: Map<number, Deployment>;
  private seoAnalyses: Map<number, SEOAnalysis>;
  private penTests: Map<number, PenTest>;
  private tasks: Map<number, Task>;
  private trafficBoosts: Map<number, TrafficBoost>;
  private pageSpeedAnalyses: Map<number, PageSpeedAnalysis>;
  private urlScans: Map<number, UrlScan>;
  private users: Map<number, User>;
  private apiConfigurations: Map<number, ApiConfiguration>;
  private deploymentProviders: Map<number, DeploymentProvider>;
  private twoFactorAuths: Map<number, TwoFactorAuth>;
  private notifications: Map<number, Notification>;
  private subscriptions: Map<number, Subscription>;
  private transactions: Map<number, Transaction>;
  private performanceOptimizations: Map<number, PerformanceOptimization>;
  private templateSettings: Map<number, TemplateSettings>;
  // Interactive Learning Tutorial System
  private tutorials: Map<number, Tutorial>;
  private tutorialSteps: Map<number, TutorialStep>;
  private userTutorialProgress: Map<number, UserTutorialProgress>;
  private userStepSubmissions: Map<number, UserStepSubmission>;
  
  private projectsId: number;
  private scansId: number;
  private vulnerabilitiesId: number;
  private deploymentsId: number;
  private seoAnalysesId: number;
  private penTestsId: number;
  private tasksId: number;
  private trafficBoostsId: number;
  private pageSpeedAnalysesId: number;
  private urlScansId: number;
  private usersId: number;
  private apiConfigurationsId: number;
  private deploymentProvidersId: number;
  private twoFactorAuthId: number;
  private notificationsId: number;
  private subscriptionsId: number;
  private transactionsId: number;
  private performanceOptimizationsId: number;
  private templateSettingsId: number;
  
  // Tutorial-related IDs
  private tutorialsId: number;
  private tutorialStepsId: number;
  private userTutorialProgressId: number;
  private userStepSubmissionsId: number;

  constructor() {
    // Initialize session store
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    this.projects = new Map();
    this.securityScans = new Map();
    this.vulnerabilities = new Map();
    this.deployments = new Map();
    this.seoAnalyses = new Map();
    this.penTests = new Map();
    this.tasks = new Map();
    this.trafficBoosts = new Map();
    this.pageSpeedAnalyses = new Map();
    this.urlScans = new Map();
    this.users = new Map();
    this.apiConfigurations = new Map();
    this.deploymentProviders = new Map();
    this.twoFactorAuths = new Map();
    this.notifications = new Map();
    this.subscriptions = new Map();
    this.transactions = new Map();
    this.performanceOptimizations = new Map();
    this.templateSettings = new Map();
    // Initialize tutorial-related collections
    this.tutorials = new Map();
    this.tutorialSteps = new Map();
    this.userTutorialProgress = new Map();
    this.userStepSubmissions = new Map();
    
    this.projectsId = 1;
    this.scansId = 1;
    this.vulnerabilitiesId = 1;
    this.deploymentsId = 1;
    this.seoAnalysesId = 1;
    this.penTestsId = 1;
    this.tasksId = 1;
    this.trafficBoostsId = 1;
    this.pageSpeedAnalysesId = 1;
    this.urlScansId = 1;
    this.usersId = 1;
    this.apiConfigurationsId = 1;
    this.deploymentProvidersId = 1;
    this.twoFactorAuthId = 1;
    this.notificationsId = 1;
    this.subscriptionsId = 1;
    this.transactionsId = 1;
    this.performanceOptimizationsId = 1;
    this.templateSettingsId = 1;
    
    // Initialize tutorial-related IDs
    this.tutorialsId = 1;
    this.tutorialStepsId = 1;
    this.userTutorialProgressId = 1;
    this.userStepSubmissionsId = 1;
    
    // Add sample projects for demo
    this.initSampleData();
    // Add sample notifications
    this.initSampleNotifications();
  }
  
  // Initialize notifications with sample data
  private initSampleNotifications() {
    // Add sample notifications for the first user (admin)
    const notif1: InsertNotification = {
      userId: 1,
      title: "Security Alert",
      message: "New vulnerability found in your project",
      type: "warning",
      read: false
    };
    this.notifications.set(this.notificationsId++, {
      ...notif1,
      id: 1,
      createdAt: new Date()
    });
    
    const notif2: InsertNotification = {
      userId: 1,
      title: "Deployment Success",
      message: "Your project was deployed successfully",
      type: "success",
      read: false
    };
    this.notifications.set(this.notificationsId++, {
      ...notif2,
      id: 2,
      createdAt: new Date()
    });
    
    const notif3: InsertNotification = {
      userId: 1,
      title: "System Update",
      message: "New features are available",
      type: "info",
      read: false
    };
    this.notifications.set(this.notificationsId++, {
      ...notif3,
      id: 3,
      createdAt: new Date()
    });
  }

  private initSampleData() {
    // Sample users
    this.createUser({
      username: "admin",
      email: "admin@securedeployx.com",
      passwordHash: "$2a$10$XtQCwh3vVbwbr7WmH1EQ3.gCWA.XNMsGbZD3SHuXvBcKaV7KfJkDm", // hashed "admin123"
      role: "admin",
      status: "active"
    });
    
    this.createUser({
      username: "developer",
      email: "developer@securedeployx.com",
      passwordHash: "$2a$10$rJJoTzp.zDzPfA7Z8QwKfu3DZLfCsF9yXJqLKcHwYYYFQ8kHCqZ0y", // hashed "dev123"
      role: "developer",
      status: "active"
    });
    
    this.createUser({
      username: "user",
      email: "user@securedeployx.com",
      passwordHash: "$2a$10$gLGJZqUu0JZEAzKbEuuEJe1smVhJZMICVm.e5.9tNkH0Av9G7WZ1i", // hashed "user123"
      role: "user",
      status: "active"
    });
    
    // Sample template settings for different user types
    this.createTemplateSetting({
      type: "user",
      name: "Default User Template",
      isDefault: true,
      features: {
        deployment: true,
        security: true,
        seo: true,
        performance: false,
        codeTesting: false,
        trafficBoost: false,
        collaboration: false
      },
      benefits: {
        deployments: 5,
        securityScans: 3,
        seoAnalyses: 3,
        penTests: 0,
        trafficBoosts: 0
      },
      permissions: {
        canInviteUsers: false,
        canCreateProjects: true,
        canAccessApi: false,
        canExportReports: false,
        canManageTeam: false
      },
      layoutOptions: {
        theme: "light",
        dashboardLayout: "simple",
        menuOptions: ["projects", "deployments", "security", "seo"],
        widgetOptions: ["projectSummary", "securityStatus", "deploymentHistory"]
      }
    });
    
    this.createTemplateSetting({
      type: "developer",
      name: "Default Developer Template",
      isDefault: true,
      features: {
        deployment: true,
        security: true,
        seo: true,
        performance: true,
        codeTesting: true,
        trafficBoost: true,
        collaboration: false
      },
      benefits: {
        deployments: 15,
        securityScans: 10,
        seoAnalyses: 10,
        penTests: 5,
        trafficBoosts: 5
      },
      permissions: {
        canInviteUsers: true,
        canCreateProjects: true,
        canAccessApi: true,
        canExportReports: true,
        canManageTeam: false
      },
      layoutOptions: {
        theme: "dark",
        dashboardLayout: "advanced",
        menuOptions: ["projects", "deployments", "security", "seo", "performance", "code", "traffic"],
        widgetOptions: ["projectSummary", "securityStatus", "deploymentHistory", "codeQuality", "performanceMetrics"]
      }
    });
    
    this.createTemplateSetting({
      type: "manager",
      name: "Default Manager Template",
      isDefault: true,
      features: {
        deployment: true,
        security: true,
        seo: true,
        performance: true,
        codeTesting: true,
        trafficBoost: true,
        collaboration: true
      },
      benefits: {
        deployments: 30,
        securityScans: 20,
        seoAnalyses: 20,
        penTests: 10,
        trafficBoosts: 10
      },
      permissions: {
        canInviteUsers: true,
        canCreateProjects: true,
        canAccessApi: true,
        canExportReports: true,
        canManageTeam: true
      },
      layoutOptions: {
        theme: "custom",
        dashboardLayout: "enterprise",
        menuOptions: ["projects", "deployments", "security", "seo", "performance", "code", "traffic", "team", "analytics"],
        widgetOptions: ["projectSummary", "securityStatus", "deploymentHistory", "codeQuality", "performanceMetrics", "teamActivity", "resourceUtilization"]
      }
    });
    
    // Sample API configurations
    const renderApiConfig = this.createApiConfiguration({
      provider: "render",
      apiKey: "rnd_sample_key_12345",
      baseUrl: "https://api.render.com/v1",
      isActive: true,
      settings: {
        defaultTeam: "team_123",
        region: "us-west"
      }
    });
    
    const syndicaApiConfig = this.createApiConfiguration({
      provider: "syndica",
      apiKey: "syn_sample_key_67890",
      baseUrl: "https://api.syndica.io/v1",
      isActive: true,
      settings: {
        defaultNode: "mainnet",
        rateLimit: 100
      }
    });
    
    // Sample deployment providers
    this.createDeploymentProvider({
      name: "Render Web Services",
      type: "render",
      apiConfigId: renderApiConfig.id,
      isActive: true,
      settings: {
        supportedServices: ["web", "static", "cron", "private"],
        defaultPlan: "starter"
      }
    });
    
    this.createDeploymentProvider({
      name: "Syndica Solana Deployment",
      type: "syndica",
      apiConfigId: syndicaApiConfig.id,
      isActive: true,
      settings: {
        supportedNetworks: ["mainnet", "devnet", "testnet"],
        defaultConfiguration: "production"
      }
    });
    
    // Sample projects
    const ecommerceApi = this.createProject({
      name: "E-commerce API",
      repository: "https://github.com/user/e-commerce-api",
      language: "Node.js"
    });
    
    const marketingWebsite = this.createProject({
      name: "Marketing Website",
      repository: "https://github.com/user/marketing-website",
      language: "PHP"
    });
    
    const adminDashboard = this.createProject({
      name: "Admin Dashboard",
      repository: "https://github.com/user/admin-dashboard",
      language: "React"
    });
    
    // Sample security scans
    const scan1 = this.createSecurityScan({
      projectId: ecommerceApi.id,
      highSeverity: 3,
      mediumSeverity: 2,
      lowSeverity: 5,
      status: "Needs Attention"
    });
    
    const scan2 = this.createSecurityScan({
      projectId: marketingWebsite.id,
      highSeverity: 0,
      mediumSeverity: 1,
      lowSeverity: 2,
      status: "Low Risk"
    });
    
    const scan3 = this.createSecurityScan({
      projectId: adminDashboard.id,
      highSeverity: 0,
      mediumSeverity: 0,
      lowSeverity: 1,
      status: "Secure"
    });
    
    // Sample vulnerabilities
    this.createVulnerability({
      scanId: scan1.id,
      description: "SQL Injection Vulnerability",
      severity: "High",
      codeSnippet: "app.post('/api/users', (req, res) => {\n  const user = req.body;\n  // Direct use of user input without validation\n  db.query(`INSERT INTO users VALUES (${user.id}, '${user.name}')`);  res.json({ success: true });\n});",
      recommendation: "Use parameterized queries",
      filePath: "server.js",
      lineNumber: 8,
      fixed: false
    });
    
    this.createVulnerability({
      scanId: scan1.id,
      description: "Missing Error Handling",
      severity: "Medium",
      codeSnippet: "app.get('/api/products', (req, res) => {\n  db.query('SELECT * FROM products', (result) => {\n    res.json(result.rows);\n    // No error handling here\n  });\n});",
      recommendation: "Add proper error handling",
      filePath: "server.js",
      lineNumber: 14,
      fixed: false
    });
    
    // Sample deployments
    this.createDeployment({
      projectId: adminDashboard.id,
      target: "AWS EC2",
      status: "Success",
      logs: "Deployment completed successfully."
    });
    
    this.createDeployment({
      projectId: marketingWebsite.id,
      target: "Netlify",
      status: "Success",
      logs: "Site deployed and available at https://example.netlify.app"
    });
    
    this.createDeployment({
      projectId: ecommerceApi.id,
      target: "Heroku",
      status: "Failed",
      logs: "Deployment failed due to security issues."
    });

    // Sample tasks for progress tracking
    this.createTask({
      name: "Fix SQL Injection Vulnerability",
      category: "Security",
      status: "in-progress",
      progress: 60,
      projectId: ecommerceApi.id,
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) // 3 days from now
    });

    this.createTask({
      name: "Implement Error Handling",
      category: "Security",
      status: "pending",
      progress: 0,
      projectId: ecommerceApi.id,
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000) // 5 days from now
    });

    this.createTask({
      name: "Deploy to AWS EC2",
      category: "Deployment",
      status: "completed",
      progress: 100,
      projectId: adminDashboard.id
    });

    this.createTask({
      name: "SEO Optimization",
      category: "SEO",
      status: "in-progress",
      progress: 40,
      projectId: marketingWebsite.id,
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days from now
    });

    this.createTask({
      name: "Penetration Testing",
      category: "Security",
      status: "pending",
      progress: 0,
      projectId: adminDashboard.id,
      dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000) // 10 days from now
    });

    // Sample traffic boosts
    this.createTrafficBoost({
      url: "https://example.com",
      status: "active",
      proxyAmount: 100,
      duration: 60, // 60 minutes
      settings: {
        geoTargeting: ["US", "EU", "Asia"],
        deviceTypes: ["desktop", "mobile"],
        referrers: ["google", "facebook", "twitter"]
      }
    });

    this.createTrafficBoost({
      url: "https://marketingwebsite.example.com",
      status: "completed",
      proxyAmount: 50,
      duration: 30, // 30 minutes
      settings: {
        geoTargeting: ["US", "EU"],
        deviceTypes: ["desktop", "mobile", "tablet"],
        referrers: ["google", "instagram"]
      }
    });

    // Sample page speed analyses
    this.createPageSpeedAnalysis({
      url: "https://example.com",
      score: 87,
      deviceType: "mobile",
      metrics: {
        fcp: 1200, // First Contentful Paint in ms
        lcp: 2500, // Largest Contentful Paint in ms
        fid: 25,   // First Input Delay in ms
        cls: 0.05, // Cumulative Layout Shift
        ttfb: 180  // Time to First Byte in ms
      }
    });

    this.createPageSpeedAnalysis({
      url: "https://example.com",
      score: 92,
      deviceType: "desktop",
      metrics: {
        fcp: 800,  // First Contentful Paint in ms
        lcp: 1800, // Largest Contentful Paint in ms
        fid: 15,   // First Input Delay in ms
        cls: 0.03, // Cumulative Layout Shift
        ttfb: 120  // Time to First Byte in ms
      }
    });

    // Sample URL scans
    this.createUrlScan({
      url: "https://example.com",
      security: {
        https: true,
        httpStrict: true,
        mixedContent: false,
        securityHeaders: 8
      },
      seo: {
        metaTitle: true,
        metaDescription: true,
        h1Tag: true,
        canonicalTag: true,
        robotsTxt: true,
        sitemap: true
      },
      performance: {
        resourceSize: 850,
        requestCount: 35,
        cachePolicy: true,
        imageOptimization: true,
        cssMinification: true,
        jsMinification: true
      }
    });

    this.createUrlScan({
      url: "https://marketingwebsite.example.com",
      security: {
        https: true,
        httpStrict: false,
        mixedContent: true,
        securityHeaders: 5
      },
      seo: {
        metaTitle: true,
        metaDescription: true,
        h1Tag: true,
        canonicalTag: false,
        robotsTxt: true,
        sitemap: false
      },
      performance: {
        resourceSize: 1850,
        requestCount: 72,
        cachePolicy: false,
        imageOptimization: false,
        cssMinification: true,
        jsMinification: false
      }
    });
  }

  // Projects
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = this.projectsId++;
    const newProject: Project = { 
      ...project, 
      id, 
      createdAt: new Date() 
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  // Security Scans
  async getSecurityScans(projectId?: number): Promise<SecurityScan[]> {
    const scans = Array.from(this.securityScans.values());
    if (projectId) {
      return scans.filter(scan => scan.projectId === projectId);
    }
    return scans;
  }

  async getSecurityScan(id: number): Promise<SecurityScan | undefined> {
    return this.securityScans.get(id);
  }

  async createSecurityScan(scan: InsertSecurityScan): Promise<SecurityScan> {
    const id = this.scansId++;
    const newScan: SecurityScan = { 
      ...scan, 
      id, 
      scanDate: new Date() 
    };
    this.securityScans.set(id, newScan);
    return newScan;
  }

  // Vulnerabilities
  async getVulnerabilities(scanId: number): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values())
      .filter(vuln => vuln.scanId === scanId);
  }

  async getVulnerability(id: number): Promise<Vulnerability | undefined> {
    return this.vulnerabilities.get(id);
  }

  async createVulnerability(vulnerability: InsertVulnerability): Promise<Vulnerability> {
    const id = this.vulnerabilitiesId++;
    const newVulnerability: Vulnerability = { ...vulnerability, id };
    this.vulnerabilities.set(id, newVulnerability);
    return newVulnerability;
  }

  async updateVulnerability(id: number, fixed: boolean): Promise<Vulnerability | undefined> {
    const vulnerability = this.vulnerabilities.get(id);
    if (!vulnerability) return undefined;
    
    const updatedVulnerability: Vulnerability = { ...vulnerability, fixed };
    this.vulnerabilities.set(id, updatedVulnerability);
    return updatedVulnerability;
  }

  // Deployments
  async getDeployments(projectId?: number): Promise<Deployment[]> {
    const deployments = Array.from(this.deployments.values());
    if (projectId) {
      return deployments.filter(deployment => deployment.projectId === projectId);
    }
    return deployments;
  }

  async getDeployment(id: number): Promise<Deployment | undefined> {
    return this.deployments.get(id);
  }

  async createDeployment(deployment: InsertDeployment): Promise<Deployment> {
    const id = this.deploymentsId++;
    const newDeployment: Deployment = { 
      ...deployment, 
      id, 
      deploymentDate: new Date() 
    };
    this.deployments.set(id, newDeployment);
    return newDeployment;
  }

  // SEO Analyses
  async getSEOAnalyses(): Promise<SEOAnalysis[]> {
    return Array.from(this.seoAnalyses.values());
  }

  async getSEOAnalysis(id: number): Promise<SEOAnalysis | undefined> {
    return this.seoAnalyses.get(id);
  }

  async createSEOAnalysis(analysis: InsertSEOAnalysis): Promise<SEOAnalysis> {
    const id = this.seoAnalysesId++;
    const newAnalysis: SEOAnalysis = { 
      ...analysis, 
      id, 
      analysisDate: new Date() 
    };
    this.seoAnalyses.set(id, newAnalysis);
    return newAnalysis;
  }

  // Pen Tests
  async getPenTests(): Promise<PenTest[]> {
    return Array.from(this.penTests.values());
  }

  async getPenTest(id: number): Promise<PenTest | undefined> {
    return this.penTests.get(id);
  }

  async createPenTest(test: InsertPenTest): Promise<PenTest> {
    const id = this.penTestsId++;
    const newTest: PenTest = { 
      ...test, 
      id, 
      testDate: new Date() 
    };
    this.penTests.set(id, newTest);
    return newTest;
  }
  
  // Template Settings
  async getTemplateSettings(type?: string): Promise<TemplateSettings[]> {
    const settings = Array.from(this.templateSettings.values());
    if (type) {
      return settings.filter(setting => setting.type === type);
    }
    return settings;
  }
  
  async getTemplateSettingById(id: number): Promise<TemplateSettings | undefined> {
    return this.templateSettings.get(id);
  }
  
  async getDefaultTemplateSettingByType(type: string): Promise<TemplateSettings | undefined> {
    return Array.from(this.templateSettings.values())
      .find(setting => setting.type === type && setting.isDefault);
  }
  
  async createTemplateSetting(templateSetting: InsertTemplateSettings): Promise<TemplateSettings> {
    const id = this.templateSettingsId++;
    const newSetting: TemplateSettings = {
      ...templateSetting,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // If this is marked as default, update any existing defaults of the same type
    if (newSetting.isDefault) {
      const existingSettings = Array.from(this.templateSettings.values())
        .filter(setting => setting.type === newSetting.type && setting.isDefault);
      
      for (const existingSetting of existingSettings) {
        existingSetting.isDefault = false;
        this.templateSettings.set(existingSetting.id, existingSetting);
      }
    }
    
    this.templateSettings.set(id, newSetting);
    return newSetting;
  }
  
  async updateTemplateSetting(id: number, templateSetting: Partial<InsertTemplateSettings>): Promise<TemplateSettings | undefined> {
    const existingSetting = this.templateSettings.get(id);
    if (!existingSetting) return undefined;
    
    const updatedSetting: TemplateSettings = {
      ...existingSetting,
      ...templateSetting,
      updatedAt: new Date()
    };
    
    // If this is being set as default, update any existing defaults of the same type
    if (templateSetting.isDefault && updatedSetting.isDefault) {
      const otherSettings = Array.from(this.templateSettings.values())
        .filter(setting => setting.id !== id && setting.type === updatedSetting.type && setting.isDefault);
      
      for (const otherSetting of otherSettings) {
        otherSetting.isDefault = false;
        this.templateSettings.set(otherSetting.id, otherSetting);
      }
    }
    
    this.templateSettings.set(id, updatedSetting);
    return updatedSetting;
  }
  
  async setDefaultTemplateSetting(id: number, type: string): Promise<TemplateSettings | undefined> {
    const targetSetting = this.templateSettings.get(id);
    if (!targetSetting || targetSetting.type !== type) return undefined;
    
    // Update all settings of this type to not be default
    const settingsOfType = Array.from(this.templateSettings.values())
      .filter(setting => setting.type === type);
    
    for (const setting of settingsOfType) {
      setting.isDefault = setting.id === id;
      setting.updatedAt = new Date();
      this.templateSettings.set(setting.id, setting);
    }
    
    return this.templateSettings.get(id);
  }
  
  async deleteTemplateSetting(id: number): Promise<boolean> {
    const setting = this.templateSettings.get(id);
    if (!setting) return false;
    
    // Don't allow deletion of default settings
    if (setting.isDefault) return false;
    
    return this.templateSettings.delete(id);
  }

  // Tasks
  async getTasks(projectId?: number): Promise<Task[]> {
    const tasks = Array.from(this.tasks.values());
    if (projectId) {
      return tasks.filter(task => task.projectId === projectId);
    }
    return tasks;
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(task: InsertTask): Promise<Task> {
    const id = this.tasksId++;
    const newTask: Task = {
      ...task,
      id,
      createdAt: new Date()
    };
    this.tasks.set(id, newTask);
    return newTask;
  }

  async updateTaskProgress(id: number, progress: number, status?: string): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const updatedTask: Task = { 
      ...task, 
      progress,
      status: status || task.status
    };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  // Traffic Boosts
  async getTrafficBoosts(): Promise<TrafficBoost[]> {
    return Array.from(this.trafficBoosts.values());
  }

  async getTrafficBoost(id: number): Promise<TrafficBoost | undefined> {
    return this.trafficBoosts.get(id);
  }

  async createTrafficBoost(boost: InsertTrafficBoost): Promise<TrafficBoost> {
    const id = this.trafficBoostsId++;
    const newBoost: TrafficBoost = {
      ...boost,
      id,
      startDate: new Date(),
      endDate: null
    };
    this.trafficBoosts.set(id, newBoost);
    return newBoost;
  }

  async updateTrafficBoostStatus(id: number, status: string, endDate?: Date): Promise<TrafficBoost | undefined> {
    const boost = this.trafficBoosts.get(id);
    if (!boost) return undefined;
    
    const updatedBoost: TrafficBoost = {
      ...boost,
      status,
      endDate: endDate || boost.endDate
    };
    this.trafficBoosts.set(id, updatedBoost);
    return updatedBoost;
  }
  
  // Page Speed Analyses
  async getPageSpeedAnalyses(): Promise<PageSpeedAnalysis[]> {
    return Array.from(this.pageSpeedAnalyses.values());
  }

  async getPageSpeedAnalysis(id: number): Promise<PageSpeedAnalysis | undefined> {
    return this.pageSpeedAnalyses.get(id);
  }

  async createPageSpeedAnalysis(analysis: InsertPageSpeedAnalysis): Promise<PageSpeedAnalysis> {
    const id = this.pageSpeedAnalysesId++;
    const newAnalysis: PageSpeedAnalysis = {
      ...analysis,
      id,
      analysisDate: new Date()
    };
    this.pageSpeedAnalyses.set(id, newAnalysis);
    return newAnalysis;
  }
  
  // URL Scans
  async getUrlScans(): Promise<UrlScan[]> {
    return Array.from(this.urlScans.values());
  }

  async getUrlScan(id: number): Promise<UrlScan | undefined> {
    return this.urlScans.get(id);
  }

  async createUrlScan(scan: InsertUrlScan): Promise<UrlScan> {
    const id = this.urlScansId++;
    const newScan: UrlScan = {
      ...scan,
      id,
      scanDate: new Date()
    };
    this.urlScans.set(id, newScan);
    return newScan;
  }
  
  // Users
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.usersId++;
    const newUser: User = {
      ...user,
      id,
      createdAt: new Date(),
      lastLogin: null
    };
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUserStatus(id: number, status: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      status: status as any // Type assertion to fit enum
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserRole(id: number, role: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      role: role as any // Type assertion to fit enum
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserPassword(id: number, passwordHash: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      passwordHash
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserLastLogin(id: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      lastLogin: new Date()
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }
  
  // Two-Factor Authentication
  async getTwoFactorAuth(userId: number): Promise<TwoFactorAuth | undefined> {
    const allTwoFactorAuths = Array.from(this.twoFactorAuths.values());
    return allTwoFactorAuths.find(tfa => tfa.userId === userId);
  }
  
  async createTwoFactorAuth(twoFactor: InsertTwoFactorAuth): Promise<TwoFactorAuth> {
    const id = this.twoFactorAuthId++;
    const newTwoFactorAuth: TwoFactorAuth = {
      ...twoFactor,
      id,
      createdAt: new Date()
    };
    this.twoFactorAuths.set(id, newTwoFactorAuth);
    return newTwoFactorAuth;
  }
  
  async updateTwoFactorAuth(userId: number, verified: boolean): Promise<TwoFactorAuth | undefined> {
    const twoFactorAuth = Array.from(this.twoFactorAuths.values()).find(tfa => tfa.userId === userId);
    if (!twoFactorAuth) return undefined;
    
    const updatedTwoFactorAuth: TwoFactorAuth = { ...twoFactorAuth, verified };
    this.twoFactorAuths.set(twoFactorAuth.id, updatedTwoFactorAuth);
    return updatedTwoFactorAuth;
  }
  
  async deleteTwoFactorAuth(userId: number): Promise<boolean> {
    const twoFactorAuth = Array.from(this.twoFactorAuths.values()).find(tfa => tfa.userId === userId);
    if (!twoFactorAuth) return false;
    
    return this.twoFactorAuths.delete(twoFactorAuth.id);
  }
  
  // API Configurations
  async getApiConfigurations(): Promise<ApiConfiguration[]> {
    return Array.from(this.apiConfigurations.values());
  }
  
  async getApiConfiguration(id: number): Promise<ApiConfiguration | undefined> {
    return this.apiConfigurations.get(id);
  }
  
  async getApiConfigurationByProvider(provider: string): Promise<ApiConfiguration | undefined> {
    return Array.from(this.apiConfigurations.values()).find(config => 
      config.provider === provider && config.isActive
    );
  }
  
  async createApiConfiguration(config: InsertApiConfiguration): Promise<ApiConfiguration> {
    const id = this.apiConfigurationsId++;
    const now = new Date();
    const newConfig: ApiConfiguration = {
      ...config,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.apiConfigurations.set(id, newConfig);
    return newConfig;
  }
  
  async updateApiConfiguration(id: number, config: Partial<InsertApiConfiguration>): Promise<ApiConfiguration | undefined> {
    const existingConfig = this.apiConfigurations.get(id);
    if (!existingConfig) return undefined;
    
    const updatedConfig: ApiConfiguration = {
      ...existingConfig,
      ...config,
      updatedAt: new Date()
    };
    this.apiConfigurations.set(id, updatedConfig);
    return updatedConfig;
  }
  
  async deleteApiConfiguration(id: number): Promise<boolean> {
    return this.apiConfigurations.delete(id);
  }
  
  // Deployment Providers
  async getDeploymentProviders(): Promise<DeploymentProvider[]> {
    return Array.from(this.deploymentProviders.values());
  }
  
  async getDeploymentProvider(id: number): Promise<DeploymentProvider | undefined> {
    return this.deploymentProviders.get(id);
  }
  
  async getActiveDeploymentProviders(): Promise<DeploymentProvider[]> {
    return Array.from(this.deploymentProviders.values()).filter(provider => provider.isActive);
  }
  
  async createDeploymentProvider(provider: InsertDeploymentProvider): Promise<DeploymentProvider> {
    const id = this.deploymentProvidersId++;
    const newProvider: DeploymentProvider = {
      ...provider,
      id,
      createdAt: new Date()
    };
    this.deploymentProviders.set(id, newProvider);
    return newProvider;
  }
  
  async updateDeploymentProvider(id: number, provider: Partial<InsertDeploymentProvider>): Promise<DeploymentProvider | undefined> {
    const existingProvider = this.deploymentProviders.get(id);
    if (!existingProvider) return undefined;
    
    const updatedProvider: DeploymentProvider = {
      ...existingProvider,
      ...provider
    };
    this.deploymentProviders.set(id, updatedProvider);
    return updatedProvider;
  }
  
  async deleteDeploymentProvider(id: number): Promise<boolean> {
    return this.deploymentProviders.delete(id);
  }

  // Notifications
  async getNotifications(userId: number, read?: boolean): Promise<Notification[]> {
    const notifications = Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId);
    
    if (read !== undefined) {
      return notifications.filter(notification => notification.read === read);
    }
    
    return notifications;
  }
  
  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notifications.get(id);
  }
  
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const id = this.notificationsId++;
    const newNotification: Notification = { 
      ...notification, 
      id, 
      createdAt: new Date() 
    };
    this.notifications.set(id, newNotification);
    return newNotification;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification: Notification = { ...notification, read: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }
  
  async deleteNotification(id: number): Promise<boolean> {
    if (!this.notifications.has(id)) {
      return false;
    }
    
    this.notifications.delete(id);
    return true;
  }
  
  // Subscriptions
  async getSubscriptions(userId?: number): Promise<Subscription[]> {
    const subscriptions = Array.from(this.subscriptions.values());
    if (userId) {
      return subscriptions.filter(subscription => subscription.userId === userId);
    }
    return subscriptions;
  }
  
  async getSubscription(id: number): Promise<Subscription | undefined> {
    return this.subscriptions.get(id);
  }
  
  async getUserActiveSubscription(userId: number): Promise<Subscription | undefined> {
    return Array.from(this.subscriptions.values())
      .find(subscription => subscription.userId === userId && subscription.status === 'active');
  }
  
  async getActiveSubscriptionByUserId(userId: number): Promise<Subscription | undefined> {
    return Array.from(this.subscriptions.values())
      .find(subscription => subscription.userId === userId && subscription.status === 'active');
  }
  
  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const id = this.subscriptionsId++;
    const newSubscription: Subscription = { 
      ...subscription, 
      id, 
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.subscriptions.set(id, newSubscription);
    return newSubscription;
  }
  
  async createOrUpdateSubscription(subscription: InsertSubscription): Promise<Subscription> {
    // Find if user already has a subscription
    const existingSubscription = await this.getUserActiveSubscription(subscription.userId);
    
    if (existingSubscription) {
      // Update existing subscription
      const updatedSubscription: Subscription = { 
        ...existingSubscription, 
        ...subscription,
        id: existingSubscription.id,
        updatedAt: new Date()
      };
      this.subscriptions.set(existingSubscription.id, updatedSubscription);
      return updatedSubscription;
    } else {
      // Create new subscription
      return this.createSubscription(subscription);
    }
  }
  
  async updateSubscription(id: number, status: string, endDate?: Date): Promise<Subscription | undefined> {
    const subscription = this.subscriptions.get(id);
    if (!subscription) return undefined;
    
    const updatedSubscription: Subscription = { 
      ...subscription, 
      status,
      endDate: endDate || subscription.endDate,
      updatedAt: new Date()
    };
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }
  
  async updateSubscriptionStatus(id: number, status: string): Promise<Subscription | undefined> {
    const subscription = this.subscriptions.get(id);
    if (!subscription) return undefined;
    
    const updatedSubscription: Subscription = { 
      ...subscription, 
      status,
      updatedAt: new Date()
    };
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }
  
  // Transactions
  async getTransactions(userId?: number): Promise<Transaction[]> {
    const transactions = Array.from(this.transactions.values());
    if (userId) {
      return transactions.filter(transaction => transaction.userId === userId);
    }
    return transactions;
  }
  
  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionsId++;
    const newTransaction: Transaction = { 
      ...transaction, 
      id, 
      createdAt: new Date()
    };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }
  
  async updateTransactionStatus(id: number, status: string): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (!transaction) return undefined;
    
    const updatedTransaction: Transaction = { 
      ...transaction, 
      status
    };
    this.transactions.set(id, updatedTransaction);
    return updatedTransaction;
  }
  
  // Performance Optimizations
  async getPerformanceOptimizations(projectId?: number): Promise<PerformanceOptimization[]> {
    const optimizations = Array.from(this.performanceOptimizations.values());
    if (projectId) {
      return optimizations.filter(optimization => optimization.projectId === projectId);
    }
    return optimizations;
  }
  
  async getPerformanceOptimization(id: number): Promise<PerformanceOptimization | undefined> {
    return this.performanceOptimizations.get(id);
  }
  
  async createPerformanceOptimization(optimization: InsertPerformanceOptimization): Promise<PerformanceOptimization> {
    const id = this.performanceOptimizationsId++;
    const newOptimization: PerformanceOptimization = {
      ...optimization,
      id,
      createdAt: new Date(),
      completedAt: null,
      results: null,
      afterScore: null,
      appliedChanges: null
    };
    this.performanceOptimizations.set(id, newOptimization);
    return newOptimization;
  }
  
  async updatePerformanceOptimizationStatus(id: number, status: string): Promise<PerformanceOptimization | undefined> {
    const optimization = this.performanceOptimizations.get(id);
    if (!optimization) return undefined;
    
    const updatedOptimization: PerformanceOptimization = {
      ...optimization,
      status: status as any // Type cast to avoid enum issues
    };
    this.performanceOptimizations.set(id, updatedOptimization);
    return updatedOptimization;
  }
  
  async completePerformanceOptimization(id: number, results: any, afterScore: number, appliedChanges: any): Promise<PerformanceOptimization | undefined> {
    const optimization = this.performanceOptimizations.get(id);
    if (!optimization) return undefined;
    
    const updatedOptimization: PerformanceOptimization = {
      ...optimization,
      status: 'completed' as any, // Type cast to avoid enum issues
      completedAt: new Date(),
      results,
      afterScore,
      appliedChanges
    };
    this.performanceOptimizations.set(id, updatedOptimization);
    return updatedOptimization;
  }
}

// DatabaseStorage implements the same interface but uses PostgreSQL via Drizzle ORM
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    // Use PostgreSQL session store when using a database
    const PostgresSessionStore = connectPg(session);
    
    this.sessionStore = new PostgresSessionStore({
      conObject: {
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
      },
      createTableIfMissing: true
    });
  }
  
  // Projects
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }
  
  // Security Scans
  async getSecurityScans(projectId?: number): Promise<SecurityScan[]> {
    if (projectId) {
      return await db.select().from(securityScans).where(eq(securityScans.projectId, projectId));
    }
    return await db.select().from(securityScans);
  }

  async getSecurityScan(id: number): Promise<SecurityScan | undefined> {
    const [scan] = await db.select().from(securityScans).where(eq(securityScans.id, id));
    return scan || undefined;
  }

  async createSecurityScan(scan: InsertSecurityScan): Promise<SecurityScan> {
    const [newScan] = await db.insert(securityScans).values(scan).returning();
    return newScan;
  }
  
  // Vulnerabilities
  async getVulnerabilities(scanId: number): Promise<Vulnerability[]> {
    return await db.select().from(vulnerabilities).where(eq(vulnerabilities.scanId, scanId));
  }

  async getVulnerability(id: number): Promise<Vulnerability | undefined> {
    const [vulnerability] = await db.select().from(vulnerabilities).where(eq(vulnerabilities.id, id));
    return vulnerability || undefined;
  }

  async createVulnerability(vulnerability: InsertVulnerability): Promise<Vulnerability> {
    const [newVulnerability] = await db.insert(vulnerabilities).values(vulnerability).returning();
    return newVulnerability;
  }

  async updateVulnerability(id: number, fixed: boolean): Promise<Vulnerability | undefined> {
    const [updatedVulnerability] = await db
      .update(vulnerabilities)
      .set({ fixed })
      .where(eq(vulnerabilities.id, id))
      .returning();
    return updatedVulnerability || undefined;
  }
  
  // Deployments
  async getDeployments(projectId?: number): Promise<Deployment[]> {
    if (projectId) {
      return await db.select().from(deployments).where(eq(deployments.projectId, projectId));
    }
    return await db.select().from(deployments);
  }

  async getDeployment(id: number): Promise<Deployment | undefined> {
    const [deployment] = await db.select().from(deployments).where(eq(deployments.id, id));
    return deployment || undefined;
  }

  async createDeployment(deployment: InsertDeployment): Promise<Deployment> {
    const [newDeployment] = await db.insert(deployments).values(deployment).returning();
    return newDeployment;
  }
  
  // SEO Analyses
  async getSEOAnalyses(): Promise<SEOAnalysis[]> {
    return await db.select().from(seoAnalyses);
  }

  async getSEOAnalysis(id: number): Promise<SEOAnalysis | undefined> {
    const [analysis] = await db.select().from(seoAnalyses).where(eq(seoAnalyses.id, id));
    return analysis || undefined;
  }

  async createSEOAnalysis(analysis: InsertSEOAnalysis): Promise<SEOAnalysis> {
    const [newAnalysis] = await db.insert(seoAnalyses).values(analysis).returning();
    return newAnalysis;
  }
  
  // Pen Tests
  async getPenTests(): Promise<PenTest[]> {
    return await db.select().from(penTests);
  }

  async getPenTest(id: number): Promise<PenTest | undefined> {
    const [test] = await db.select().from(penTests).where(eq(penTests.id, id));
    return test || undefined;
  }

  async createPenTest(test: InsertPenTest): Promise<PenTest> {
    const [newTest] = await db.insert(penTests).values(test).returning();
    return newTest;
  }

  // Tasks
  async getTasks(projectId?: number): Promise<Task[]> {
    if (projectId) {
      return await db.select().from(tasks).where(eq(tasks.projectId, projectId));
    }
    return await db.select().from(tasks);
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTaskProgress(id: number, progress: number, status?: string): Promise<Task | undefined> {
    const updateData: any = { progress };
    if (status) {
      updateData.status = status;
    }
    
    const [updatedTask] = await db
      .update(tasks)
      .set(updateData)
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask || undefined;
  }
  
  // Traffic Boosts
  async getTrafficBoosts(): Promise<TrafficBoost[]> {
    return await db.select().from(trafficBoosts);
  }

  async getTrafficBoost(id: number): Promise<TrafficBoost | undefined> {
    const [boost] = await db.select().from(trafficBoosts).where(eq(trafficBoosts.id, id));
    return boost || undefined;
  }

  async createTrafficBoost(boost: InsertTrafficBoost): Promise<TrafficBoost> {
    const [newBoost] = await db.insert(trafficBoosts).values(boost).returning();
    return newBoost;
  }

  async updateTrafficBoostStatus(id: number, status: string, endDate?: Date): Promise<TrafficBoost | undefined> {
    const updateData: any = { status };
    if (endDate) {
      updateData.endDate = endDate;
    }
    
    const [updatedBoost] = await db
      .update(trafficBoosts)
      .set(updateData)
      .where(eq(trafficBoosts.id, id))
      .returning();
    return updatedBoost || undefined;
  }
  
  // Page Speed Analyses
  async getPageSpeedAnalyses(): Promise<PageSpeedAnalysis[]> {
    return await db.select().from(pageSpeedAnalyses);
  }

  async getPageSpeedAnalysis(id: number): Promise<PageSpeedAnalysis | undefined> {
    const [analysis] = await db.select().from(pageSpeedAnalyses).where(eq(pageSpeedAnalyses.id, id));
    return analysis || undefined;
  }

  async createPageSpeedAnalysis(analysis: InsertPageSpeedAnalysis): Promise<PageSpeedAnalysis> {
    const [newAnalysis] = await db.insert(pageSpeedAnalyses).values(analysis).returning();
    return newAnalysis;
  }
  
  // URL Scans
  async getUrlScans(): Promise<UrlScan[]> {
    return await db.select().from(urlScans);
  }

  async getUrlScan(id: number): Promise<UrlScan | undefined> {
    const [scan] = await db.select().from(urlScans).where(eq(urlScans.id, id));
    return scan || undefined;
  }

  async createUrlScan(scan: InsertUrlScan): Promise<UrlScan> {
    const [newScan] = await db.insert(urlScans).values(scan).returning();
    return newScan;
  }
  
  // Users
  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }
  
  async updateUserStatus(id: number, status: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ status: status as any })
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }
  
  async updateUserLastLogin(id: number): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ lastLogin: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    // First check if the user exists
    const user = await this.getUser(id);
    if (!user) return false;
    
    const result = await db.delete(users).where(eq(users.id, id));
    return result?.rowCount > 0;
  }
  
  async updateUserRole(id: number, role: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ role: role as any }) // Type assertion to fit enum
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }
  
  async updateUserPassword(id: number, passwordHash: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ passwordHash })
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }
  
  // Two-Factor Authentication
  async getTwoFactorAuth(userId: number): Promise<TwoFactorAuth | undefined> {
    const [tfaRecord] = await db
      .select()
      .from(tfaTable)
      .where(eq(tfaTable.userId, userId));
    return tfaRecord || undefined;
  }
  
  async createTwoFactorAuth(twoFactorData: InsertTwoFactorAuth): Promise<TwoFactorAuth> {
    const [newTwoFactorAuth] = await db
      .insert(tfaTable)
      .values(twoFactorData)
      .returning();
    return newTwoFactorAuth;
  }
  
  async updateTwoFactorAuth(userId: number, verified: boolean): Promise<TwoFactorAuth | undefined> {
    const [updatedTwoFactorAuth] = await db
      .update(tfaTable)
      .set({ verified })
      .where(eq(tfaTable.userId, userId))
      .returning();
    return updatedTwoFactorAuth || undefined;
  }
  
  async deleteTwoFactorAuth(userId: number): Promise<boolean> {
    // First check if the record exists
    const twoFactorAuth = await this.getTwoFactorAuth(userId);
    if (!twoFactorAuth) return false;
    
    // Then delete it
    const result = await db.delete(tfaTable).where(eq(tfaTable.userId, userId));
    return result?.rowCount > 0;
  }
  
  // API Configurations
  async getApiConfigurations(): Promise<ApiConfiguration[]> {
    return await db.select().from(apiConfigurations);
  }
  
  async getApiConfiguration(id: number): Promise<ApiConfiguration | undefined> {
    const [config] = await db.select().from(apiConfigurations).where(eq(apiConfigurations.id, id));
    return config || undefined;
  }
  
  async getApiConfigurationByProvider(provider: string): Promise<ApiConfiguration | undefined> {
    const [config] = await db
      .select()
      .from(apiConfigurations)
      .where(and(
        eq(apiConfigurations.provider, provider),
        eq(apiConfigurations.isActive, true)
      ));
    return config || undefined;
  }
  
  async createApiConfiguration(config: InsertApiConfiguration): Promise<ApiConfiguration> {
    const [newConfig] = await db.insert(apiConfigurations).values(config).returning();
    return newConfig;
  }
  
  async updateApiConfiguration(id: number, config: Partial<InsertApiConfiguration>): Promise<ApiConfiguration | undefined> {
    const updateData = { 
      ...config, 
      updatedAt: new Date() 
    };
    
    const [updatedConfig] = await db
      .update(apiConfigurations)
      .set(updateData)
      .where(eq(apiConfigurations.id, id))
      .returning();
    return updatedConfig || undefined;
  }
  
  async deleteApiConfiguration(id: number): Promise<boolean> {
    // First check if the config exists
    const config = await this.getApiConfiguration(id);
    if (!config) return false;
    
    const result = await db.delete(apiConfigurations).where(eq(apiConfigurations.id, id));
    return result?.rowCount > 0;
  }
  
  // Deployment Providers
  async getDeploymentProviders(): Promise<DeploymentProvider[]> {
    return await db.select().from(deploymentProviders);
  }
  
  async getDeploymentProvider(id: number): Promise<DeploymentProvider | undefined> {
    const [provider] = await db.select().from(deploymentProviders).where(eq(deploymentProviders.id, id));
    return provider || undefined;
  }
  
  async getActiveDeploymentProviders(): Promise<DeploymentProvider[]> {
    return await db
      .select()
      .from(deploymentProviders)
      .where(eq(deploymentProviders.isActive, true));
  }
  
  async createDeploymentProvider(provider: InsertDeploymentProvider): Promise<DeploymentProvider> {
    const [newProvider] = await db.insert(deploymentProviders).values(provider).returning();
    return newProvider;
  }
  
  async updateDeploymentProvider(id: number, provider: Partial<InsertDeploymentProvider>): Promise<DeploymentProvider | undefined> {
    const [updatedProvider] = await db
      .update(deploymentProviders)
      .set(provider)
      .where(eq(deploymentProviders.id, id))
      .returning();
    return updatedProvider || undefined;
  }
  
  async deleteDeploymentProvider(id: number): Promise<boolean> {
    // First check if the provider exists
    const provider = await this.getDeploymentProvider(id);
    if (!provider) return false;
    
    const result = await db.delete(deploymentProviders).where(eq(deploymentProviders.id, id));
    return result?.rowCount > 0;
  }
  
  // Notifications
  async getNotifications(userId: number, read?: boolean): Promise<Notification[]> {
    if (read !== undefined) {
      return await db.select()
        .from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.read, read)
        ));
    }
    
    return await db.select()
      .from(notifications)
      .where(eq(notifications.userId, userId));
  }
  
  async getNotification(id: number): Promise<Notification | undefined> {
    const [notification] = await db.select()
      .from(notifications)
      .where(eq(notifications.id, id));
    return notification || undefined;
  }
  
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const [updatedNotification] = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    return updatedNotification || undefined;
  }
  
  async deleteNotification(id: number): Promise<boolean> {
    // First check if the notification exists
    const notification = await this.getNotification(id);
    if (!notification) return false;
    
    const result = await db.delete(notifications).where(eq(notifications.id, id));
    return result?.rowCount > 0;
  }
  
  // Subscriptions
  async getSubscriptions(userId?: number): Promise<Subscription[]> {
    if (userId) {
      return await db.select()
        .from(subscriptions)
        .where(eq(subscriptions.userId, userId));
    }
    return await db.select().from(subscriptions);
  }
  
  async getSubscription(id: number): Promise<Subscription | undefined> {
    const [subscription] = await db.select()
      .from(subscriptions)
      .where(eq(subscriptions.id, id));
    return subscription || undefined;
  }
  
  async getUserActiveSubscription(userId: number): Promise<Subscription | undefined> {
    const [subscription] = await db.select()
      .from(subscriptions)
      .where(and(
        eq(subscriptions.userId, userId),
        eq(subscriptions.status, 'active')
      ));
    return subscription || undefined;
  }
  
  async getActiveSubscriptionByUserId(userId: number): Promise<Subscription | undefined> {
    // This is essentially the same as getUserActiveSubscription but kept for interface compatibility
    const [subscription] = await db.select()
      .from(subscriptions)
      .where(and(
        eq(subscriptions.userId, userId),
        eq(subscriptions.status, 'active')
      ));
    return subscription || undefined;
  }
  
  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const [newSubscription] = await db.insert(subscriptions)
      .values(subscription)
      .returning();
    return newSubscription;
  }
  
  async createOrUpdateSubscription(subscription: InsertSubscription): Promise<Subscription> {
    // Find if user already has a subscription
    const existingSubscription = await this.getUserActiveSubscription(subscription.userId);
    
    if (existingSubscription) {
      // Update existing subscription
      const updateData = {
        ...subscription,
        updatedAt: new Date()
      };
      
      const [updatedSubscription] = await db.update(subscriptions)
        .set(updateData)
        .where(eq(subscriptions.id, existingSubscription.id))
        .returning();
      return updatedSubscription;
    } else {
      // Create new subscription
      return this.createSubscription(subscription);
    }
  }
  
  async updateSubscription(id: number, status: string, endDate?: Date): Promise<Subscription | undefined> {
    const updateData: any = { 
      status,
      updatedAt: new Date()
    };
    
    if (endDate) {
      updateData.endDate = endDate;
    }
    
    const [updatedSubscription] = await db.update(subscriptions)
      .set(updateData)
      .where(eq(subscriptions.id, id))
      .returning();
    return updatedSubscription || undefined;
  }
  
  async updateSubscriptionStatus(id: number, status: string): Promise<Subscription | undefined> {
    const [updatedSubscription] = await db.update(subscriptions)
      .set({ 
        status,
        updatedAt: new Date()
      })
      .where(eq(subscriptions.id, id))
      .returning();
    return updatedSubscription || undefined;
  }
  
  // Transactions
  async getTransactions(userId?: number): Promise<Transaction[]> {
    if (userId) {
      return await db.select()
        .from(transactions)
        .where(eq(transactions.userId, userId));
    }
    return await db.select().from(transactions);
  }
  
  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db.select()
      .from(transactions)
      .where(eq(transactions.id, id));
    return transaction || undefined;
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions)
      .values(transaction)
      .returning();
    return newTransaction;
  }
  
  async updateTransactionStatus(id: number, status: string): Promise<Transaction | undefined> {
    const [updatedTransaction] = await db.update(transactions)
      .set({ status })
      .where(eq(transactions.id, id))
      .returning();
    return updatedTransaction || undefined;
  }
  
  // Performance Optimizations
  async getPerformanceOptimizations(projectId?: number): Promise<PerformanceOptimization[]> {
    if (projectId) {
      return await db.select().from(performanceOptimizations).where(eq(performanceOptimizations.projectId, projectId));
    }
    return await db.select().from(performanceOptimizations);
  }
  
  async getPerformanceOptimization(id: number): Promise<PerformanceOptimization | undefined> {
    const [optimization] = await db.select().from(performanceOptimizations).where(eq(performanceOptimizations.id, id));
    return optimization || undefined;
  }
  
  async createPerformanceOptimization(optimization: InsertPerformanceOptimization): Promise<PerformanceOptimization> {
    const [newOptimization] = await db.insert(performanceOptimizations).values(optimization).returning();
    return newOptimization;
  }
  
  async updatePerformanceOptimizationStatus(id: number, status: string): Promise<PerformanceOptimization | undefined> {
    const [updatedOptimization] = await db.update(performanceOptimizations)
      .set({ 
        status: status as any // Type cast to handle enum issues
      })
      .where(eq(performanceOptimizations.id, id))
      .returning();
    return updatedOptimization || undefined;
  }
  
  async completePerformanceOptimization(
    id: number, 
    results: any, 
    afterScore: number, 
    appliedChanges: any
  ): Promise<PerformanceOptimization | undefined> {
    const [updatedOptimization] = await db.update(performanceOptimizations)
      .set({ 
        status: 'completed' as any, // Type cast to handle enum issues
        completedAt: new Date(),
        results,
        afterScore,
        appliedChanges
      })
      .where(eq(performanceOptimizations.id, id))
      .returning();
    return updatedOptimization || undefined;
  }

  // ==================== ADVANCED FEATURES ====================

  // 1. AI-POWERED CODE GENERATION
  async getCodeGenerations(projectId?: number, userId?: number): Promise<CodeGeneration[]> {
    let query = db.select().from(codeGenerations);
    
    if (projectId && userId) {
      query = query.where(and(
        eq(codeGenerations.projectId, projectId),
        eq(codeGenerations.userId, userId)
      ));
    } else if (projectId) {
      query = query.where(eq(codeGenerations.projectId, projectId));
    } else if (userId) {
      query = query.where(eq(codeGenerations.userId, userId));
    }
    
    return query.orderBy(codeGenerations.createdAt);
  }
  
  async getCodeGeneration(id: number): Promise<CodeGeneration | undefined> {
    const [codeGen] = await db
      .select()
      .from(codeGenerations)
      .where(eq(codeGenerations.id, id));
    return codeGen || undefined;
  }
  
  async createCodeGeneration(codeGen: InsertCodeGeneration): Promise<CodeGeneration> {
    const [result] = await db
      .insert(codeGenerations)
      .values(codeGen)
      .returning();
    return result;
  }
  
  async updateCodeGenerationResult(id: number, result: string): Promise<CodeGeneration | undefined> {
    const [updatedCodeGen] = await db
      .update(codeGenerations)
      .set({ result })
      .where(eq(codeGenerations.id, id))
      .returning();
    return updatedCodeGen || undefined;
  }
  
  async updateCodeGenerationRating(id: number, rating: number): Promise<CodeGeneration | undefined> {
    const [updatedCodeGen] = await db
      .update(codeGenerations)
      .set({ rating })
      .where(eq(codeGenerations.id, id))
      .returning();
    return updatedCodeGen || undefined;
  }
  
  async updateCodeGenerationUsage(id: number, used: boolean): Promise<CodeGeneration | undefined> {
    const [updatedCodeGen] = await db
      .update(codeGenerations)
      .set({ usedInProject: used })
      .where(eq(codeGenerations.id, id))
      .returning();
    return updatedCodeGen || undefined;
  }
  
  async updateCodeGenerationMetadata(id: number, metadata: any): Promise<CodeGeneration | undefined> {
    const [updatedCodeGen] = await db
      .update(codeGenerations)
      .set({ metadata })
      .where(eq(codeGenerations.id, id))
      .returning();
    return updatedCodeGen || undefined;
  }
  
  // 2. REAL-TIME COLLABORATION
  async getCollaborationSessions(projectId?: number): Promise<CollaborationSession[]> {
    if (projectId) {
      return db
        .select()
        .from(collaborationSessions)
        .where(eq(collaborationSessions.projectId, projectId))
        .orderBy(collaborationSessions.startTime);
    }
    return db.select().from(collaborationSessions).orderBy(collaborationSessions.startTime);
  }
  
  async getCollaborationSession(id: number): Promise<CollaborationSession | undefined> {
    const [session] = await db
      .select()
      .from(collaborationSessions)
      .where(eq(collaborationSessions.id, id));
    return session || undefined;
  }
  
  async createCollaborationSession(session: InsertCollaborationSession): Promise<CollaborationSession> {
    const [result] = await db
      .insert(collaborationSessions)
      .values(session)
      .returning();
    return result;
  }
  
  async updateCollaborationSessionStatus(id: number, status: string): Promise<CollaborationSession | undefined> {
    const [updatedSession] = await db
      .update(collaborationSessions)
      .set({ status: status as any })
      .where(eq(collaborationSessions.id, id))
      .returning();
    return updatedSession || undefined;
  }
  
  async endCollaborationSession(id: number): Promise<CollaborationSession | undefined> {
    const [updatedSession] = await db
      .update(collaborationSessions)
      .set({
        status: 'completed',
        endTime: new Date()
      })
      .where(eq(collaborationSessions.id, id))
      .returning();
    return updatedSession || undefined;
  }
  
  async getCollaborationParticipants(sessionId: number): Promise<CollaborationParticipant[]> {
    return db
      .select()
      .from(collaborationParticipants)
      .where(eq(collaborationParticipants.sessionId, sessionId));
  }
  
  async getCollaborationParticipant(id: number): Promise<CollaborationParticipant | undefined> {
    const [participant] = await db
      .select()
      .from(collaborationParticipants)
      .where(eq(collaborationParticipants.id, id));
    return participant || undefined;
  }
  
  async createCollaborationParticipant(participant: InsertCollaborationParticipant): Promise<CollaborationParticipant> {
    const [result] = await db
      .insert(collaborationParticipants)
      .values(participant)
      .returning();
    return result;
  }
  
  async updateCollaborationParticipantRole(id: number, role: string): Promise<CollaborationParticipant | undefined> {
    const [updatedParticipant] = await db
      .update(collaborationParticipants)
      .set({ role })
      .where(eq(collaborationParticipants.id, id))
      .returning();
    return updatedParticipant || undefined;
  }
  
  async removeCollaborationParticipant(id: number): Promise<boolean> {
    const [participant] = await db
      .update(collaborationParticipants)
      .set({
        active: false,
        leaveTime: new Date()
      })
      .where(eq(collaborationParticipants.id, id))
      .returning();
    return !!participant;
  }
  
  async getCollaborationMessages(sessionId: number): Promise<CollaborationMessage[]> {
    return db
      .select()
      .from(collaborationMessages)
      .where(eq(collaborationMessages.sessionId, sessionId))
      .orderBy(collaborationMessages.timestamp);
  }
  
  async createCollaborationMessage(message: InsertCollaborationMessage): Promise<CollaborationMessage> {
    const [result] = await db
      .insert(collaborationMessages)
      .values(message)
      .returning();
    return result;
  }

  // 3. DEPLOYMENT ROLLBACK & VERSION CONTROL
  async getDeploymentVersions(deploymentId: number): Promise<DeploymentVersion[]> {
    return db
      .select()
      .from(deploymentVersions)
      .where(eq(deploymentVersions.deploymentId, deploymentId))
      .orderBy(deploymentVersions.timestamp);
  }
  
  async getDeploymentVersion(id: number): Promise<DeploymentVersion | undefined> {
    const [version] = await db
      .select()
      .from(deploymentVersions)
      .where(eq(deploymentVersions.id, id));
    return version || undefined;
  }
  
  async createDeploymentVersion(version: InsertDeploymentVersion): Promise<DeploymentVersion> {
    const [result] = await db
      .insert(deploymentVersions)
      .values(version)
      .returning();
    return result;
  }
  
  async updateDeploymentVersionStatus(id: number, status: string): Promise<DeploymentVersion | undefined> {
    const [updatedVersion] = await db
      .update(deploymentVersions)
      .set({ status })
      .where(eq(deploymentVersions.id, id))
      .returning();
    return updatedVersion || undefined;
  }
  
  async getRollbacks(deploymentId: number): Promise<Rollback[]> {
    return db
      .select()
      .from(rollbacks)
      .where(eq(rollbacks.deploymentId, deploymentId))
      .orderBy(rollbacks.timestamp);
  }
  
  async getRollback(id: number): Promise<Rollback | undefined> {
    const [rollback] = await db
      .select()
      .from(rollbacks)
      .where(eq(rollbacks.id, id));
    return rollback || undefined;
  }
  
  async createRollback(rollback: InsertRollback): Promise<Rollback> {
    const [result] = await db
      .insert(rollbacks)
      .values(rollback)
      .returning();
    return result;
  }
  
  async updateRollbackStatus(id: number, status: string, logs?: string): Promise<Rollback | undefined> {
    const updateData: Record<string, any> = { status };
    if (logs) {
      updateData.logs = logs;
    }
    
    const [updatedRollback] = await db
      .update(rollbacks)
      .set(updateData)
      .where(eq(rollbacks.id, id))
      .returning();
    return updatedRollback || undefined;
  }
  
  // Template Settings
  async getTemplateSettings(type?: string): Promise<TemplateSettings[]> {
    let query = db.select().from(templateSettings);
    if (type) {
      query = query.where(eq(templateSettings.type, type));
    }
    return await query;
  }
  
  async getTemplateSettingById(id: number): Promise<TemplateSettings | undefined> {
    const [setting] = await db.select().from(templateSettings).where(eq(templateSettings.id, id));
    return setting || undefined;
  }
  
  async getDefaultTemplateSettingByType(type: string): Promise<TemplateSettings | undefined> {
    const [setting] = await db.select().from(templateSettings)
      .where(
        and(
          eq(templateSettings.type, type),
          eq(templateSettings.isDefault, true)
        )
      );
    return setting || undefined;
  }
  
  async createTemplateSetting(templateSetting: InsertTemplateSettings): Promise<TemplateSettings> {
    // If this is a default setting, update any existing defaults of the same type
    if (templateSetting.isDefault) {
      await db.update(templateSettings)
        .set({ isDefault: false })
        .where(
          and(
            eq(templateSettings.type, templateSetting.type),
            eq(templateSettings.isDefault, true)
          )
        );
    }
    
    const [setting] = await db
      .insert(templateSettings)
      .values({
        ...templateSetting,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    
    return setting;
  }
  
  async updateTemplateSetting(id: number, templateSetting: Partial<InsertTemplateSettings>): Promise<TemplateSettings | undefined> {
    // If we're setting this as default, update other settings of the same type
    if (templateSetting.isDefault) {
      const [existingSetting] = await db.select()
        .from(templateSettings)
        .where(eq(templateSettings.id, id));
      
      if (existingSetting) {
        await db.update(templateSettings)
          .set({ isDefault: false })
          .where(
            and(
              eq(templateSettings.type, existingSetting.type),
              eq(templateSettings.isDefault, true),
              ne(templateSettings.id, id)
            )
          );
      }
    }
    
    const [setting] = await db.update(templateSettings)
      .set({
        ...templateSetting,
        updatedAt: new Date()
      })
      .where(eq(templateSettings.id, id))
      .returning();
    
    return setting || undefined;
  }
  
  async setDefaultTemplateSetting(id: number, type: string): Promise<TemplateSettings | undefined> {
    // First verify the setting exists and is of the correct type
    const [existingSetting] = await db.select()
      .from(templateSettings)
      .where(
        and(
          eq(templateSettings.id, id),
          eq(templateSettings.type, type)
        )
      );
    
    if (!existingSetting) {
      return undefined;
    }
    
    // Update all settings of this type to not be default
    await db.update(templateSettings)
      .set({ 
        isDefault: false,
        updatedAt: new Date()
      })
      .where(eq(templateSettings.type, type));
    
    // Set the target setting as default
    const [setting] = await db.update(templateSettings)
      .set({ 
        isDefault: true,
        updatedAt: new Date()
      })
      .where(eq(templateSettings.id, id))
      .returning();
    
    return setting || undefined;
  }
  
  async deleteTemplateSetting(id: number): Promise<boolean> {
    // Don't allow deletion of default settings
    const [existingSetting] = await db.select()
      .from(templateSettings)
      .where(eq(templateSettings.id, id));
    
    if (!existingSetting || existingSetting.isDefault) {
      return false;
    }
    
    const result = await db.delete(templateSettings)
      .where(eq(templateSettings.id, id));
    
    return result.rowCount > 0;
  }

  // AWS Credentials
  async getAwsCredentials(userId: number): Promise<AwsCredentials[]> {
    return await db.select()
      .from(awsCredentials)
      .where(eq(awsCredentials.userId, userId));
  }

  async getAwsCredential(id: number): Promise<AwsCredentials | undefined> {
    const [credential] = await db.select()
      .from(awsCredentials)
      .where(eq(awsCredentials.id, id));
    
    return credential || undefined;
  }

  async createAwsCredential(credential: InsertAwsCredentials): Promise<AwsCredentials> {
    const [newCredential] = await db.insert(awsCredentials)
      .values({
        ...credential,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    
    return newCredential;
  }

  async updateAwsCredential(id: number, credential: Partial<InsertAwsCredentials>): Promise<AwsCredentials | undefined> {
    const [updatedCredential] = await db.update(awsCredentials)
      .set({
        ...credential,
        updatedAt: new Date()
      })
      .where(eq(awsCredentials.id, id))
      .returning();
    
    return updatedCredential || undefined;
  }

  async deleteAwsCredential(id: number): Promise<boolean> {
    const result = await db.delete(awsCredentials)
      .where(eq(awsCredentials.id, id));
    
    return result.rowCount > 0;
  }

  async verifyAwsCredential(id: number, password: string): Promise<AwsCredentials | undefined> {
    // Fetch the credential
    const [credential] = await db.select()
      .from(awsCredentials)
      .where(eq(awsCredentials.id, id));
    
    if (!credential) {
      return undefined;
    }
    
    // In a real implementation, we'd need to:
    // 1. Decrypt the secretAccessKey using the password
    // 2. If decryption succeeds, the password is correct
    
    // For this demo implementation, we'll use a simple validation approach
    // We'll check if the password meets a minimum length requirement
    // This is just for demonstration - in production, proper cryptographic methods should be used
    
    if (password.length < 8) {
      console.warn("Password verification failed: password too short");
      return undefined;
    }
    
    // For enhanced security in a production environment:
    // - Store a hash of the password alongside the credentials
    // - Use the password to decrypt the encrypted AWS credentials
    // - Implement proper key derivation and encryption/decryption
    
    // For now, our simple implementation just validates the password length and returns the credentials
    
    return credential;
  }

  async updateAwsCredentialLastUsed(id: number): Promise<AwsCredentials | undefined> {
    const [updatedCredential] = await db.update(awsCredentials)
      .set({
        lastUsed: new Date(),
        updatedAt: new Date()
      })
      .where(eq(awsCredentials.id, id))
      .returning();
    
    return updatedCredential || undefined;
  }
  
  // Cloud Credentials Implementation
  async getCloudCredentials(userId: number): Promise<CloudCredential[]> {
    return await db.select()
      .from(cloudCredentials)
      .where(eq(cloudCredentials.userId, userId));
  }

  async getCloudCredential(id: number): Promise<CloudCredential | undefined> {
    const [credential] = await db.select()
      .from(cloudCredentials)
      .where(eq(cloudCredentials.id, id));
    
    return credential || undefined;
  }

  async createCloudCredential(credential: InsertCloudCredential): Promise<CloudCredential> {
    // Hash the password if provided
    let passwordHash = null;
    if (credential.password) {
      passwordHash = await bcrypt.hash(credential.password, 10);
    }
    
    // Extract password from the credential object to avoid storing it directly
    const { password, ...credentialWithoutPassword } = credential;
    
    const [newCredential] = await db.insert(cloudCredentials)
      .values({
        ...credentialWithoutPassword,
        passwordHash,
      })
      .returning();
    
    return newCredential;
  }

  async updateCloudCredential(id: number, credential: Partial<InsertCloudCredential>): Promise<CloudCredential | undefined> {
    // Extract password from the credential object to avoid storing it directly
    const { password, ...credentialWithoutPassword } = credential;
    
    // Hash the new password if provided
    let passwordHash = undefined;
    if (password) {
      passwordHash = await bcrypt.hash(password, 10);
    }
    
    const [updatedCredential] = await db.update(cloudCredentials)
      .set({
        ...credentialWithoutPassword,
        ...(passwordHash ? { passwordHash } : {}),
      })
      .where(eq(cloudCredentials.id, id))
      .returning();
    
    return updatedCredential || undefined;
  }

  async deleteCloudCredential(id: number): Promise<boolean> {
    const result = await db.delete(cloudCredentials)
      .where(eq(cloudCredentials.id, id));
    
    return result.rowCount > 0;
  }

  async verifyCloudCredential(id: number, password: string): Promise<CloudCredential | undefined> {
    const [credential] = await db.select()
      .from(cloudCredentials)
      .where(eq(cloudCredentials.id, id));
    
    if (!credential) {
      return undefined;
    }
    
    // In a real implementation we would:
    // - Verify the password against a hashed value stored in the database
    // - Use the password to decrypt the encrypted cloud credentials
    // - Implement proper key derivation and encryption/decryption
    
    // For now, our simple implementation just validates the password matches what's stored and returns the credentials
    if (credential.passwordHash && !await comparePasswords(password, credential.passwordHash)) {
      return undefined;
    }
    
    return credential;
  }

  // ===============================
  // Interactive Learning Tutorials
  // ===============================

  // Tutorials
  async getTutorials(filterPublished?: boolean): Promise<Tutorial[]> {
    let tutorials = Array.from(this.tutorials.values());
    
    if (filterPublished) {
      tutorials = tutorials.filter(tutorial => tutorial.published);
    }
    
    return tutorials;
  }

  async getTutorialsByLanguage(language: string): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values())
      .filter(tutorial => tutorial.language === language);
  }

  async getTutorialsByDifficulty(difficulty: string): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values())
      .filter(tutorial => tutorial.difficulty === difficulty);
  }

  async getTutorialById(id: number): Promise<Tutorial | undefined> {
    return this.tutorials.get(id);
  }

  async createTutorial(tutorial: InsertTutorial): Promise<Tutorial> {
    const id = this.tutorialsId++;
    const newTutorial: Tutorial = {
      ...tutorial,
      id,
      createdAt: new Date(),
      published: false,
      totalSteps: 0
    };
    this.tutorials.set(id, newTutorial);
    return newTutorial;
  }

  async updateTutorial(id: number, tutorial: Partial<InsertTutorial>): Promise<Tutorial | undefined> {
    const existingTutorial = this.tutorials.get(id);
    if (!existingTutorial) return undefined;

    const updatedTutorial: Tutorial = {
      ...existingTutorial,
      ...tutorial
    };
    
    this.tutorials.set(id, updatedTutorial);
    return updatedTutorial;
  }

  async updateTutorialPublishStatus(id: number, published: boolean): Promise<Tutorial | undefined> {
    const tutorial = this.tutorials.get(id);
    if (!tutorial) return undefined;

    const updatedTutorial: Tutorial = {
      ...tutorial,
      published
    };
    
    this.tutorials.set(id, updatedTutorial);
    return updatedTutorial;
  }

  async updateTutorialTotalSteps(id: number, totalSteps: number): Promise<Tutorial | undefined> {
    const tutorial = this.tutorials.get(id);
    if (!tutorial) return undefined;

    const updatedTutorial: Tutorial = {
      ...tutorial,
      totalSteps
    };
    
    this.tutorials.set(id, updatedTutorial);
    return updatedTutorial;
  }

  async deleteTutorial(id: number): Promise<boolean> {
    if (!this.tutorials.has(id)) return false;
    return this.tutorials.delete(id);
  }

  // Tutorial Steps
  async getTutorialSteps(tutorialId: number): Promise<TutorialStep[]> {
    return Array.from(this.tutorialSteps.values())
      .filter(step => step.tutorialId === tutorialId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getTutorialStepById(id: number): Promise<TutorialStep | undefined> {
    return this.tutorialSteps.get(id);
  }

  async createTutorialStep(step: InsertTutorialStep): Promise<TutorialStep> {
    const id = this.tutorialStepsId++;
    const newStep: TutorialStep = {
      ...step,
      id,
      createdAt: new Date()
    };
    this.tutorialSteps.set(id, newStep);
    
    // Update the tutorial's total steps count
    const tutorial = await this.getTutorialById(step.tutorialId);
    if (tutorial) {
      await this.updateTutorialTotalSteps(tutorial.id, tutorial.totalSteps + 1);
    }
    
    return newStep;
  }

  async updateTutorialStep(id: number, step: Partial<InsertTutorialStep>): Promise<TutorialStep | undefined> {
    const existingStep = this.tutorialSteps.get(id);
    if (!existingStep) return undefined;

    const updatedStep: TutorialStep = {
      ...existingStep,
      ...step
    };
    
    this.tutorialSteps.set(id, updatedStep);
    return updatedStep;
  }

  async deleteTutorialStep(id: number): Promise<boolean> {
    const step = this.tutorialSteps.get(id);
    if (!step) return false;
    
    const success = this.tutorialSteps.delete(id);
    
    // Update the tutorial's total steps count if the step was deleted successfully
    if (success) {
      const tutorial = await this.getTutorialById(step.tutorialId);
      if (tutorial && tutorial.totalSteps > 0) {
        await this.updateTutorialTotalSteps(tutorial.id, tutorial.totalSteps - 1);
      }
    }
    
    return success;
  }

  // User Tutorial Progress
  async getUserTutorialProgress(userId: number, tutorialId?: number): Promise<UserTutorialProgress[]> {
    let progress = Array.from(this.userTutorialProgress.values())
      .filter(p => p.userId === userId);
    
    if (tutorialId) {
      progress = progress.filter(p => p.tutorialId === tutorialId);
    }
    
    return progress;
  }

  async getUserTutorialProgressById(id: number): Promise<UserTutorialProgress | undefined> {
    return this.userTutorialProgress.get(id);
  }

  async createUserTutorialProgress(progress: InsertUserTutorialProgress): Promise<UserTutorialProgress> {
    const id = this.userTutorialProgressId++;
    const now = new Date();
    const newProgress: UserTutorialProgress = {
      ...progress,
      id,
      startedAt: now,
      lastAccessedAt: now,
      completedAt: null,
      currentStep: progress.currentStep || 1,
      completedSteps: progress.completedSteps || [],
      isCompleted: progress.isCompleted || false
    };
    this.userTutorialProgress.set(id, newProgress);
    return newProgress;
  }

  async updateUserTutorialCurrentStep(id: number, currentStep: number): Promise<UserTutorialProgress | undefined> {
    const progress = this.userTutorialProgress.get(id);
    if (!progress) return undefined;

    const updatedProgress: UserTutorialProgress = {
      ...progress,
      currentStep,
      lastAccessedAt: new Date()
    };
    
    this.userTutorialProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  async updateUserTutorialCompletedSteps(id: number, completedSteps: number[]): Promise<UserTutorialProgress | undefined> {
    const progress = this.userTutorialProgress.get(id);
    if (!progress) return undefined;

    const updatedProgress: UserTutorialProgress = {
      ...progress,
      completedSteps,
      lastAccessedAt: new Date()
    };
    
    this.userTutorialProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  async markTutorialComplete(id: number): Promise<UserTutorialProgress | undefined> {
    const progress = this.userTutorialProgress.get(id);
    if (!progress) return undefined;

    const now = new Date();
    const updatedProgress: UserTutorialProgress = {
      ...progress,
      isCompleted: true,
      completedAt: now,
      lastAccessedAt: now
    };
    
    this.userTutorialProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  async updateUserTutorialProgress(id: number, progress: Partial<InsertUserTutorialProgress>): Promise<UserTutorialProgress | undefined> {
    const existingProgress = this.userTutorialProgress.get(id);
    if (!existingProgress) return undefined;

    const updatedProgress: UserTutorialProgress = {
      ...existingProgress,
      ...progress,
      lastAccessedAt: new Date()
    };
    
    this.userTutorialProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  // User Step Submissions
  async getUserStepSubmissions(progressId: number): Promise<UserStepSubmission[]> {
    return Array.from(this.userStepSubmissions.values())
      .filter(submission => submission.progressId === progressId);
  }

  async getUserStepSubmission(id: number): Promise<UserStepSubmission | undefined> {
    return this.userStepSubmissions.get(id);
  }

  async getUserStepSubmissionByStepId(progressId: number, stepId: number): Promise<UserStepSubmission | undefined> {
    return Array.from(this.userStepSubmissions.values())
      .find(submission => submission.progressId === progressId && submission.stepId === stepId);
  }

  async createUserStepSubmission(submission: InsertUserStepSubmission): Promise<UserStepSubmission> {
    const id = this.userStepSubmissionsId++;
    const newSubmission: UserStepSubmission = {
      ...submission,
      id,
      createdAt: new Date(),
      isCorrect: submission.isCorrect || false,
      feedback: submission.feedback || null,
      output: submission.output || null,
      hintsUsed: submission.hintsUsed || 0,
      attemptNumber: submission.attemptNumber || 1
    };
    this.userStepSubmissions.set(id, newSubmission);
    return newSubmission;
  }

  async updateUserStepSubmissionFeedback(id: number, isCorrect: boolean, feedback: string): Promise<UserStepSubmission | undefined> {
    const submission = this.userStepSubmissions.get(id);
    if (!submission) return undefined;

    const updatedSubmission: UserStepSubmission = {
      ...submission,
      isCorrect,
      feedback
    };
    
    this.userStepSubmissions.set(id, updatedSubmission);
    
    // If the submission is correct, update the user's progress to include this completed step
    if (isCorrect) {
      const progress = await this.getUserTutorialProgressById(submission.progressId);
      if (progress) {
        const completedSteps = progress.completedSteps || [];
        if (!completedSteps.includes(submission.stepId)) {
          const updatedSteps = [...completedSteps, submission.stepId];
          await this.updateUserTutorialCompletedSteps(progress.id, updatedSteps);
          
          // Get the tutorial to check if all steps are completed
          const tutorial = await this.getTutorialById(progress.tutorialId);
          if (tutorial && updatedSteps.length >= tutorial.totalSteps) {
            await this.markTutorialComplete(progress.id);
          }
        }
      }
    }
    
    return updatedSubmission;
  }

  async updateUserStepSubmission(id: number, submission: Partial<InsertUserStepSubmission>): Promise<UserStepSubmission | undefined> {
    const existingSubmission = this.userStepSubmissions.get(id);
    if (!existingSubmission) return undefined;

    const updatedSubmission: UserStepSubmission = {
      ...existingSubmission,
      ...submission
    };
    
    this.userStepSubmissions.set(id, updatedSubmission);
    return updatedSubmission;
  }
}

// Now using the database implementation instead of memory storage
export const storage = new DatabaseStorage();
