import fs from 'fs';
import path from 'path';
import { promisify } from 'util';

const readdir = promisify(fs.readdir);
const stat = promisify(fs.stat);
const readFile = promisify(fs.readFile);
const writeFile = promisify(fs.writeFile);
const mkdir = promisify(fs.mkdir);
const unlink = promisify(fs.unlink);
const rmdir = promisify(fs.rmdir);

export interface FileEntry {
  name: string;
  type: 'file' | 'directory';
  size: number;
  lastModified: string;
  permissions: string;
  extension?: string;
}

/**
 * Get files and directories from a specific path
 */
export async function getFilesFromPath(dirPath: string): Promise<FileEntry[]> {
  try {
    const items = await readdir(dirPath);
    const itemDetails = await Promise.all(
      items.map(async (item) => {
        const itemPath = path.join(dirPath, item);
        try {
          const stats = await stat(itemPath);
          const extension = path.extname(item).slice(1);
          
          // Get permissions in Unix-like format (e.g., "rwxr-xr-x")
          const permissions = getPermissionsString(stats.mode);
          
          return {
            name: item,
            type: stats.isDirectory() ? 'directory' : 'file',
            size: stats.size,
            lastModified: stats.mtime.toISOString(),
            permissions,
            ...(extension ? { extension } : {}),
          };
        } catch (err) {
          console.error(`Error getting stats for ${itemPath}:`, err);
          return null;
        }
      })
    );
    
    return itemDetails.filter((item): item is FileEntry => item !== null);
  } catch (err) {
    console.error(`Error reading directory ${dirPath}:`, err);
    throw err;
  }
}

/**
 * Get the content of a file
 */
export async function getFileContent(filePath: string): Promise<string> {
  try {
    const data = await readFile(filePath, 'utf8');
    return data;
  } catch (err) {
    console.error(`Error reading file ${filePath}:`, err);
    throw err;
  }
}

/**
 * Save content to a file
 */
export async function saveFileContent(filePath: string, content: string): Promise<void> {
  try {
    await writeFile(filePath, content, 'utf8');
  } catch (err) {
    console.error(`Error writing to file ${filePath}:`, err);
    throw err;
  }
}

/**
 * Create a new file or directory
 */
export async function createFileOrDirectory(
  filePath: string, 
  type: 'file' | 'directory', 
  content: string = ''
): Promise<void> {
  try {
    if (type === 'directory') {
      await mkdir(filePath, { recursive: true });
    } else {
      // Ensure parent directory exists
      const parentDir = path.dirname(filePath);
      try {
        await stat(parentDir);
      } catch (err) {
        await mkdir(parentDir, { recursive: true });
      }
      
      await writeFile(filePath, content, 'utf8');
    }
  } catch (err) {
    console.error(`Error creating ${type} at ${filePath}:`, err);
    throw err;
  }
}

/**
 * Delete a file or directory
 */
export async function deleteFileOrDirectory(
  filePath: string, 
  type: 'file' | 'directory'
): Promise<void> {
  try {
    if (type === 'directory') {
      await rmdir(filePath, { recursive: true });
    } else {
      await unlink(filePath);
    }
  } catch (err) {
    console.error(`Error deleting ${type} at ${filePath}:`, err);
    throw err;
  }
}

/**
 * Helper function to convert file mode to permissions string (e.g., "rwxr-xr-x")
 */
function getPermissionsString(mode: number): string {
  const perms = [
    (mode & 0o400) ? 'r' : '-',
    (mode & 0o200) ? 'w' : '-',
    (mode & 0o100) ? 'x' : '-',
    (mode & 0o040) ? 'r' : '-',
    (mode & 0o020) ? 'w' : '-',
    (mode & 0o010) ? 'x' : '-',
    (mode & 0o004) ? 'r' : '-',
    (mode & 0o002) ? 'w' : '-',
    (mode & 0o001) ? 'x' : '-',
  ];
  
  return perms.join('');
}

/**
 * Check if a path exists and return its type
 */
export async function pathExists(filePath: string): Promise<{ exists: boolean; type?: 'file' | 'directory' }> {
  try {
    const stats = await stat(filePath);
    return {
      exists: true,
      type: stats.isDirectory() ? 'directory' : 'file',
    };
  } catch (err) {
    return { exists: false };
  }
}

/**
 * Safely join paths to prevent path traversal attacks
 */
export function securePath(basePath: string, requestedPath: string): string {
  // Normalize the paths to handle '..' and '.' segments
  const normalizedBase = path.normalize(basePath);
  const normalizedRequested = path.normalize(path.resolve(normalizedBase, requestedPath));
  
  // Check if the normalized requested path starts with the normalized base path
  if (!normalizedRequested.startsWith(normalizedBase)) {
    throw new Error('Path traversal attempt detected');
  }
  
  return normalizedRequested;
}