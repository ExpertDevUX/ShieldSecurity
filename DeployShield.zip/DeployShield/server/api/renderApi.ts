/**
 * Render API Integration
 * 
 * This module provides server-side functionality for interacting with the Render API
 * Documentation: https://api-docs.render.com/reference/
 */

import axios from 'axios';
import { storage } from '../storage';

// Render API Types
export interface RenderServiceConfig {
  name: string;
  type: string;
  ownerId?: string;
  repo?: string;
  branch?: string;
  rootDir?: string;
  buildCommand?: string;
  startCommand?: string;
  envVars?: Array<{ key: string; value: string; isSecret?: boolean }>;
  region?: string;
  plan?: string;
  autoDeploy?: boolean;
  numInstances?: number;
}

export interface RenderService {
  id: string;
  name: string;
  type: string;
  autoDeploy: boolean;
  branch: string;
  repo: string;
  slug: string;
  status: string;
  suspenders: string[];
  url: string;
  createdAt: string;
  updatedAt: string;
  env: string;
  region: string;
}

export interface RenderDeployment {
  id: string;
  commit?: string;
  status: string;
  finishedAt?: string;
  createdAt: string;
  updatedAt: string;
  serviceId: string;
}

/**
 * Client for interacting with the Render API
 */
export class RenderApiClient {
  private apiKey: string;
  private baseUrl: string;
  
  constructor(apiKey: string, baseUrl: string = 'https://api.render.com/v1') {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
  }
  
  /**
   * Make a request to the Render API
   */
  private async request<T>(
    method: 'GET' | 'POST' | 'PUT' | 'DELETE', 
    path: string, 
    data?: any
  ): Promise<T> {
    try {
      const url = `${this.baseUrl}${path}`;
      
      const response = await axios({
        method,
        url,
        data,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        }
      });
      
      return response.data as T;
    } catch (error) {
      console.error(`Render API Error: ${error.message}`);
      
      if (error.response) {
        throw new Error(`Render API Error (${error.response.status}): ${JSON.stringify(error.response.data)}`);
      }
      
      throw error;
    }
  }
  
  /**
   * List all services
   */
  async listServices(): Promise<RenderService[]> {
    return this.request<RenderService[]>('GET', '/services');
  }
  
  /**
   * Get a service by ID
   */
  async getService(serviceId: string): Promise<RenderService> {
    return this.request<RenderService>('GET', `/services/${serviceId}`);
  }
  
  /**
   * Create a new service
   */
  async createService(config: RenderServiceConfig): Promise<RenderService> {
    return this.request<RenderService>('POST', '/services', config);
  }
  
  /**
   * List deployments for a service
   */
  async listDeployments(serviceId: string): Promise<RenderDeployment[]> {
    return this.request<RenderDeployment[]>('GET', `/services/${serviceId}/deploys`);
  }
  
  /**
   * Get a deployment by ID
   */
  async getDeployment(deploymentId: string): Promise<RenderDeployment> {
    return this.request<RenderDeployment>('GET', `/deploys/${deploymentId}`);
  }
  
  /**
   * Trigger a manual deployment
   */
  async triggerDeploy(serviceId: string, clearCache: boolean = false): Promise<RenderDeployment> {
    return this.request<RenderDeployment>('POST', `/services/${serviceId}/deploys`, { clearCache });
  }
  
  /**
   * Update an existing service
   */
  async updateService(serviceId: string, config: Partial<RenderServiceConfig>): Promise<RenderService> {
    return this.request<RenderService>('PATCH', `/services/${serviceId}`, config);
  }
  
  /**
   * Delete a service
   */
  async deleteService(serviceId: string): Promise<void> {
    return this.request<void>('DELETE', `/services/${serviceId}`);
  }
  
  /**
   * Test the Render API connection
   */
  async testConnection(): Promise<boolean> {
    try {
      await this.listServices();
      return true;
    } catch (error) {
      return false;
    }
  }
}

/**
 * Get the Render API client
 * This tries to load the API key from storage and returns a configured client
 */
export async function getRenderApiClient(): Promise<RenderApiClient | null> {
  try {
    const config = await storage.getApiConfigurationByProvider('render');
    
    if (!config || !config.apiKey || !config.isActive) {
      console.log('Render API configuration not found or not active');
      return null;
    }
    
    return new RenderApiClient(
      config.apiKey, 
      config.baseUrl || 'https://api.render.com/v1'
    );
  } catch (error) {
    console.error(`Error creating Render API client: ${error.message}`);
    return null;
  }
}

/**
 * Deploy to Render
 */
export async function deployToRender(
  projectId: number,
  deploymentConfig: {
    name: string;
    type: string;
    repo: string;
    branch: string;
    buildCommand?: string;
    startCommand?: string;
    envVars?: Array<{ key: string; value: string; isSecret?: boolean }>;
  }
): Promise<{
  success: boolean;
  serviceId?: string;
  url?: string;
  message?: string;
  error?: string;
}> {
  try {
    const renderClient = await getRenderApiClient();
    
    if (!renderClient) {
      return {
        success: false,
        error: 'Render API client could not be initialized. Check API configuration.'
      };
    }
    
    // Create the service
    const service = await renderClient.createService({
      name: deploymentConfig.name,
      type: deploymentConfig.type,
      repo: deploymentConfig.repo,
      branch: deploymentConfig.branch || 'main',
      buildCommand: deploymentConfig.buildCommand,
      startCommand: deploymentConfig.startCommand,
      envVars: deploymentConfig.envVars || [],
      autoDeploy: true
    });
    
    // Record the deployment in our database
    const deployment = await storage.createDeployment({
      projectId,
      target: 'render',
      status: 'in_progress',
      logs: JSON.stringify({
        serviceId: service.id,
        url: service.url,
        createdAt: service.createdAt
      })
    });
    
    return {
      success: true,
      serviceId: service.id,
      url: service.url,
      message: 'Deployment to Render initiated successfully'
    };
  } catch (error) {
    console.error(`Error deploying to Render: ${error.message}`);
    
    return {
      success: false,
      error: `Failed to deploy to Render: ${error.message}`
    };
  }
}

/**
 * Check deployment status
 */
export async function checkRenderDeploymentStatus(serviceId: string): Promise<{
  status: string;
  url?: string;
  deployId?: string;
  logs?: string[];
}> {
  try {
    const renderClient = await getRenderApiClient();
    
    if (!renderClient) {
      return {
        status: 'error',
        logs: ['Render API client could not be initialized']
      };
    }
    
    // Get the service status
    const service = await renderClient.getService(serviceId);
    
    // Get latest deployment
    const deployments = await renderClient.listDeployments(serviceId);
    const latestDeployment = deployments.length > 0 ? deployments[0] : null;
    
    return {
      status: latestDeployment ? latestDeployment.status : service.status,
      url: service.url,
      deployId: latestDeployment ? latestDeployment.id : undefined,
      logs: [`Service status: ${service.status}`, latestDeployment ? `Deployment status: ${latestDeployment.status}` : 'No deployments found']
    };
  } catch (error) {
    console.error(`Error checking Render deployment status: ${error.message}`);
    
    return {
      status: 'error',
      logs: [`Error checking deployment status: ${error.message}`]
    };
  }
}