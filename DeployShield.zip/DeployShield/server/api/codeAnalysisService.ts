import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize the API with your API key
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

interface CodeAnalysisOptions {
  languageHint?: string;
  includeSuggestions?: boolean;
  includeExamples?: boolean;
  securityFocus?: boolean;
  performanceFocus?: boolean;
  bestPracticesFocus?: boolean;
}

interface CodeIssue {
  id: string;
  description: string;
  severity: "high" | "medium" | "low";
  suggestion?: string;
  code?: string;
}

interface CodeAnalysisResult {
  issues: CodeIssue[];
  score?: number;
  summary?: string;
}

const generateSystemPrompt = (options: CodeAnalysisOptions) => {
  const language = options.languageHint ? options.languageHint : "unspecified";
  const securityFocus = options.securityFocus ? "high" : "normal";
  const performanceFocus = options.performanceFocus ? "high" : "normal";
  const bestPracticesFocus = options.bestPracticesFocus ? "high" : "normal";

  return `
    You are an expert code analyzer and reviewer. Analyze the provided ${language} code for issues and provide constructive feedback.
    
    Focus areas:
    - Security concerns: ${securityFocus} priority
    - Performance optimizations: ${performanceFocus} priority
    - Best practices: ${bestPracticesFocus} priority
    
    For each issue found:
    1. Provide a clear description of the problem
    2. Rate the severity as "high", "medium", or "low"
    3. Give a specific suggestion on how to fix it
    4. When appropriate, provide a code example showing the fix
    
    Also provide:
    - An overall quality score from 0-100
    - A brief summary of the code quality and main improvement areas
    
    Format your response as structured JSON with the following schema:
    {
      "issues": [
        {
          "id": "unique-id",
          "description": "Description of the issue",
          "severity": "high|medium|low",
          "suggestion": "How to fix it",
          "code": "Example code for the fix (optional)"
        }
      ],
      "score": 75,
      "summary": "Brief overall assessment"
    }
  `;
};

export const analyzeCodeWithGemini = async (
  code: string,
  options: CodeAnalysisOptions = {}
): Promise<CodeAnalysisResult> => {
  // Default fallback for testing
  if (!process.env.GEMINI_API_KEY) {
    console.warn("GEMINI_API_KEY not provided, using mock analysis");
    return generateMockAnalysis(code, options);
  }

  try {
    // For generative models, we'll use gemini-pro
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    
    const systemPrompt = generateSystemPrompt(options);
    
    const prompt = `
      ${systemPrompt}
      
      Here's the code to analyze:
      \`\`\`${options.languageHint || ''}
      ${code}
      \`\`\`
    `;
    
    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();
    
    // Parse the JSON response
    try {
      // Extract JSON from the response (it might be wrapped in markdown code blocks)
      const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/) || 
                        text.match(/```\s*([\s\S]*?)\s*```/) ||
                        [null, text];
                        
      const jsonText = jsonMatch[1] || text;
      const parsedResult = JSON.parse(jsonText);
      
      return {
        issues: parsedResult.issues || [],
        score: parsedResult.score,
        summary: parsedResult.summary
      };
    } catch (parseError) {
      console.error("Failed to parse Gemini response:", parseError);
      console.log("Raw response:", text);
      throw new Error("Invalid response format from AI service");
    }
  } catch (error) {
    console.error("Error analyzing code with Gemini:", error);
    throw error;
  }
};

// Fallback for when APIs are not available or for testing
export const generateMockAnalysis = (
  code: string,
  options: CodeAnalysisOptions
): CodeAnalysisResult => {
  // Determine the language from code and options
  const language = options.languageHint || detectLanguageFromCode(code);
  
  // Generate a different length analysis based on code length
  const codeLength = code.length;
  const issueCount = Math.min(5, Math.max(1, Math.floor(codeLength / 100)));
  
  const issues: CodeIssue[] = [];
  
  // Common issues across languages
  const commonIssues = [
    {
      description: "Missing error handling",
      severity: "high" as const,
      suggestion: "Add try/catch blocks to handle potential errors",
      code: language === "javascript" ? 
        "try {\n  // Your code here\n} catch (error) {\n  console.error('Operation failed:', error);\n}" : 
        "try:\n    # Your code here\nexcept Exception as e:\n    print(f'Operation failed: {e}')"
    },
    {
      description: "Hard-coded credentials",
      severity: "high" as const,
      suggestion: "Move sensitive data to environment variables or a secure vault",
      code: language === "javascript" ? 
        "// Bad\nconst apiKey = '1234567890';\n\n// Good\nconst apiKey = process.env.API_KEY;" : 
        "# Bad\napi_key = '1234567890'\n\n# Good\nimport os\napi_key = os.environ.get('API_KEY')"
    },
    {
      description: "Inefficient loop",
      severity: "medium" as const,
      suggestion: "Consider using more efficient iteration methods",
      code: language === "javascript" ? 
        "// Instead of\nfor (let i = 0; i < array.length; i++) {\n  // ...\n}\n\n// Consider\narray.forEach(item => {\n  // ...\n});" : 
        "# Instead of\nfor i in range(len(items)):\n    item = items[i]\n    # ...\n\n# Consider\nfor item in items:\n    # ..."
    },
    {
      description: "Inconsistent naming convention",
      severity: "low" as const,
      suggestion: "Use consistent naming conventions throughout your code",
      code: language === "javascript" ? 
        "// Inconsistent\nconst UserName = 'John';\nconst user_age = 30;\n\n// Consistent (camelCase)\nconst userName = 'John';\nconst userAge = 30;" : 
        "# Inconsistent\nUserName = 'John'\nuser_age = 30\n\n# Consistent (snake_case for Python)\nuser_name = 'John'\nuser_age = 30"
    },
    {
      description: "Magic numbers",
      severity: "low" as const,
      suggestion: "Replace magic numbers with named constants",
      code: language === "javascript" ? 
        "// Bad\nif (status === 200) {\n  // ...\n}\n\n// Good\nconst HTTP_OK = 200;\nif (status === HTTP_OK) {\n  // ...\n}" : 
        "# Bad\nif status == 200:\n    # ...\n\n# Good\nHTTP_OK = 200\nif status == HTTP_OK:\n    # ..."
    }
  ];
  
  // Language-specific issues
  const languageSpecificIssues: Record<string, CodeIssue[]> = {
    javascript: [
      {
        description: "Using var instead of let/const",
        severity: "medium" as const,
        suggestion: "Use let for variables that change and const for variables that don't",
        code: "// Instead of\nvar name = 'John';\n\n// Use\nconst name = 'John';"
      },
      {
        description: "Not handling Promise rejections",
        severity: "high" as const,
        suggestion: "Always handle Promise rejections with catch or use try/await/catch",
        code: "// Bad\nfetch('/api/data').then(res => res.json());\n\n// Good\nfetch('/api/data')\n  .then(res => res.json())\n  .catch(err => console.error(err));"
      }
    ],
    python: [
      {
        description: "Not using context manager for file operations",
        severity: "medium" as const,
        suggestion: "Use 'with' statement for file operations to ensure proper cleanup",
        code: "# Bad\nf = open('file.txt', 'r')\ncontent = f.read()\nf.close()\n\n# Good\nwith open('file.txt', 'r') as f:\n    content = f.read()"
      },
      {
        description: "Using wildcard imports",
        severity: "low" as const,
        suggestion: "Import only what you need instead of using wildcard imports",
        code: "# Bad\nfrom module import *\n\n# Good\nfrom module import specific_function, AnotherFunction"
      }
    ]
  };
  
  // Add some common issues
  for (let i = 0; i < issueCount; i++) {
    if (i < commonIssues.length) {
      issues.push({
        id: `issue-${i+1}`,
        ...commonIssues[i]
      });
    }
  }
  
  // Add language-specific issues if available
  if (languageSpecificIssues[language] && issues.length < 5) {
    const specificIssues = languageSpecificIssues[language];
    for (let i = 0; i < Math.min(specificIssues.length, 5 - issues.length); i++) {
      issues.push({
        id: `lang-issue-${i+1}`,
        ...specificIssues[i]
      });
    }
  }
  
  // Calculate a mock score based on code length and issue count
  const baseScore = 70; // Start with a base score
  const lengthPenalty = Math.min(20, codeLength > 500 ? 0 : (500 - codeLength) / 25);
  const issuePenalty = issues.reduce((total, issue) => {
    switch (issue.severity) {
      case 'high': return total + 5;
      case 'medium': return total + 3;
      case 'low': return total + 1;
      default: return total;
    }
  }, 0);
  
  const score = Math.max(0, Math.min(100, baseScore - lengthPenalty - issuePenalty));
  
  return {
    issues,
    score: Math.round(score),
    summary: `This ${language} code has ${issues.length} issues identified. The overall quality score is ${Math.round(score)}/100. ${
      score < 50 ? 'Significant improvements needed.' :
      score < 70 ? 'Several areas need attention.' :
      score < 85 ? 'Generally good with some improvements possible.' :
      'Excellent code quality with minor improvements possible.'
    }`
  };
};

// Helper function to detect language from code
function detectLanguageFromCode(code: string): string {
  if (code.includes('function') || code.includes('const ') || code.includes('let ') || code.includes('var ')) {
    return 'javascript';
  } else if (code.includes('def ') || code.includes('import ') || code.includes('class ') && code.includes(':')) {
    return 'python';
  } else if (code.includes('public class') || code.includes('private ') || code.includes('void ')) {
    return 'java';
  } else if (code.includes('<?php')) {
    return 'php';
  } else if (code.includes('<html>') || code.includes('<!DOCTYPE')) {
    return 'html';
  } else if (code.includes('SELECT') || code.includes('FROM') || code.includes('WHERE')) {
    return 'sql';
  }
  return 'unknown';
}