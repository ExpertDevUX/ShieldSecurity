import { GoogleGenerativeAI } from "@google/generative-ai";
import OpenAI from "openai";
import { log } from "../vite";

// AI providers
export type AIProvider = "openai" | "gemini" | "claude" | "cohere" | "mock";

// Response type for code generation
export interface CodeGenerationResponse {
  generatedCode: string;
  explanation?: string;
  suggestedUsage?: string;
  importStatements?: string[];
  dependencies?: string[];
}

// Create a code generation prompt based on input parameters
export function createCodeGenerationPrompt(
  prompt: string, 
  language: string, 
  type: string
): string {
  return `
You are an expert software developer. Generate ${language} code for the following request:
Type of code to generate: ${type}
Programming language: ${language}

Request: ${prompt}

Please provide:
1. The complete, working ${language} code implementation
2. A brief explanation of how the code works
3. Dependencies or packages required to run the code (if any)
4. Any import statements needed
5. Suggestions for how to use/integrate this code

Format your response as JSON with the following structure:
{
  "generatedCode": "// Your generated code here",
  "explanation": "Brief explanation of the code",
  "suggestedUsage": "How to use/integrate this code",
  "importStatements": ["import statement 1", "import statement 2"],
  "dependencies": ["dependency1", "dependency2"]
}
`;
}

// Generate code with OpenAI
export async function generateCodeWithOpenAI(
  prompt: string,
  language: string,
  type: string,
  apiKey: string
): Promise<CodeGenerationResponse> {
  try {
    const openai = new OpenAI({ apiKey });
    
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: createCodeGenerationPrompt(prompt, language, type) }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }
    
    return JSON.parse(content) as CodeGenerationResponse;
  } catch (error: any) {
    log(`OpenAI code generation error: ${error.message}`, "ai-service");
    throw new Error(`OpenAI API error: ${error.message || String(error)}`);
  }
}

// Generate code with Google Gemini
export async function generateCodeWithGemini(
  prompt: string,
  language: string,
  type: string,
  apiKey: string
): Promise<CodeGenerationResponse> {
  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    
    const result = await model.generateContent(createCodeGenerationPrompt(prompt, language, type));
    const response = await result.response;
    const content = response.text();
    
    // Extract JSON from the response
    const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || 
                      content.match(/```([\s\S]*?)```/) || 
                      content.match(/{[\s\S]*}/);
    
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[1] || jsonMatch[0]) as CodeGenerationResponse;
      } catch (parseError) {
        throw new Error("Failed to parse Gemini response as JSON");
      }
    }
    
    // If we can't extract JSON, try to structure it manually
    const codeBlock = content.match(/```[\w]*\n([\s\S]*?)\n```/);
    return {
      generatedCode: codeBlock ? codeBlock[1] : content,
      explanation: "Generated using Gemini AI",
    };
  } catch (error: any) {
    log(`Gemini code generation error: ${error.message}`, "ai-service");
    throw new Error(`Gemini API error: ${error.message || String(error)}`);
  }
}

// Mock code generation for testing or when no API keys are available
export function generateMockCode(
  prompt: string,
  language: string,
  type: string
): CodeGenerationResponse {
  let mockCode = "";
  let explanation = "This is a mock implementation generated without using an AI service.";
  let dependencies: string[] = [];
  let importStatements: string[] = [];
  
  // Generate appropriate mock code based on language and type
  switch (language) {
    case "javascript":
    case "typescript":
      if (type === "function") {
        mockCode = `
// ${prompt}
function processData(input) {
  // TODO: Implement actual logic based on the prompt
  console.log("Processing:", input);
  return {
    result: "Processed " + input,
    timestamp: new Date().toISOString()
  };
}

// Example usage
// const result = processData("sample data");
// console.log(result);
`;
      } else if (type === "component") {
        importStatements = ["import React from 'react'"];
        dependencies = ["react"];
        mockCode = `
import React from 'react';

// ${prompt}
function CustomComponent({ title, data = [] }) {
  return (
    <div className="custom-component">
      <h2>{title}</h2>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default CustomComponent;
`;
      }
      break;
      
    case "python":
      mockCode = `
# ${prompt}
def process_data(input_data):
    """
    Process the input data and return results.
    
    Args:
        input_data: The data to process
        
    Returns:
        Processed data result
    """
    print(f"Processing: {input_data}")
    return {
        "result": f"Processed {input_data}",
        "timestamp": import_datetime.now().isoformat()
    }

# Example usage
# result = process_data("sample data")
# print(result)
`;
      importStatements = ["import datetime as import_datetime"];
      break;
      
    default:
      mockCode = `
// Mock ${language} code for: ${prompt}
// This is a placeholder. Replace with actual implementation.
`;
  }
  
  return {
    generatedCode: mockCode,
    explanation,
    suggestedUsage: "Replace this mock implementation with your actual code",
    importStatements,
    dependencies
  };
}

// Process AI code generation request based on provider
export async function generateCode(
  prompt: string,
  language: string,
  type: string,
  provider: AIProvider = "mock",
  apiKey?: string
): Promise<CodeGenerationResponse> {
  try {
    switch (provider) {
      case "openai":
        if (!apiKey) {
          throw new Error("OpenAI API key is required");
        }
        return await generateCodeWithOpenAI(prompt, language, type, apiKey);
        
      case "gemini":
        if (!apiKey) {
          throw new Error("Gemini API key is required");
        }
        return await generateCodeWithGemini(prompt, language, type, apiKey);
        
      case "claude":
      case "cohere":
        // Placeholder for future implementation
        throw new Error(`${provider} integration is not implemented yet`);
        
      case "mock":
      default:
        return generateMockCode(prompt, language, type);
    }
  } catch (error: any) {
    log(`Code generation error with ${provider}: ${error.message}`, "ai-service");
    // Fall back to mock if all else fails
    return generateMockCode(prompt, language, type);
  }
}