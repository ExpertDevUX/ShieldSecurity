import { Request, Response } from "express";
import { storage } from "../storage";
import { z } from "zod";
import bcrypt from "bcryptjs";

// Schemas for validation
const createUserSchema = z.object({
  username: z.string().min(3),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["admin", "user", "developer"]),
});

const updateRoleSchema = z.object({
  role: z.enum(["admin", "user", "developer"]),
});

const updateStatusSchema = z.object({
  status: z.enum(["active", "inactive", "banned"]),
});

const resetPasswordSchema = z.object({
  password: z.string().min(6),
});

// Get all users (admin only)
export async function getAllUsers(req: Request, res: Response) {
  try {
    // Check if requester is admin
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied. Admin privileges required." });
    }

    const users = await storage.getUsers();
    res.status(200).json(users);
  } catch (error) {
    console.error("Error getting users:", error);
    res.status(500).json({ message: "Failed to retrieve users" });
  }
}

// Create a new user (admin only)
export async function createUser(req: Request, res: Response) {
  try {
    // Check if requester is admin
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied. Admin privileges required." });
    }

    // Validate request body
    const validationResult = createUserSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation error",
        errors: validationResult.error.errors,
      });
    }

    const { username, email, password, role } = validationResult.data;

    // Check if username or email already exists
    const existingUser = await storage.getUserByUsername(username);
    if (existingUser) {
      return res.status(400).json({ message: "Username already exists" });
    }

    const existingEmail = await storage.getUserByEmail(email);
    if (existingEmail) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Create user
    const newUser = await storage.createUser({
      username,
      email,
      passwordHash,
      role,
      status: "active", // Default status
    });

    res.status(201).json(newUser);
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ message: "Failed to create user" });
  }
}

// Update user role (admin only)
export async function updateUserRole(req: Request, res: Response) {
  try {
    // Check if requester is admin
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied. Admin privileges required." });
    }

    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    // Validate request body
    const validationResult = updateRoleSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation error",
        errors: validationResult.error.errors,
      });
    }

    const { role } = validationResult.data;

    // Check if user exists
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Update role
    const updatedUser = await storage.updateUserRole(userId, role);
    if (!updatedUser) {
      return res.status(500).json({ message: "Failed to update user role" });
    }

    res.status(200).json(updatedUser);
  } catch (error) {
    console.error("Error updating user role:", error);
    res.status(500).json({ message: "Failed to update user role" });
  }
}

// Update user status (admin only)
export async function updateUserStatus(req: Request, res: Response) {
  try {
    // Check if requester is admin
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied. Admin privileges required." });
    }

    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    // Validate request body
    const validationResult = updateStatusSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation error",
        errors: validationResult.error.errors,
      });
    }

    const { status } = validationResult.data;

    // Check if user exists
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Update status
    const updatedUser = await storage.updateUserStatus(userId, status);
    if (!updatedUser) {
      return res.status(500).json({ message: "Failed to update user status" });
    }

    res.status(200).json(updatedUser);
  } catch (error) {
    console.error("Error updating user status:", error);
    res.status(500).json({ message: "Failed to update user status" });
  }
}

// Reset user password (admin only)
export async function resetUserPassword(req: Request, res: Response) {
  try {
    // Check if requester is admin
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied. Admin privileges required." });
    }

    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    // Validate request body
    const validationResult = resetPasswordSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation error",
        errors: validationResult.error.errors,
      });
    }

    const { password } = validationResult.data;

    // Check if user exists
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Hash new password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Update password
    const updatedUser = await storage.updateUserPassword(userId, passwordHash);
    if (!updatedUser) {
      return res.status(500).json({ message: "Failed to reset user password" });
    }

    res.status(200).json({ message: "Password reset successfully" });
  } catch (error) {
    console.error("Error resetting user password:", error);
    res.status(500).json({ message: "Failed to reset user password" });
  }
}