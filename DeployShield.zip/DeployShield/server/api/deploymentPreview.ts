import * as fs from 'fs';
import * as path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { log } from '../vite';

const execAsync = promisify(exec);

// Base directory for preview deployments
const PREVIEW_BASE_DIR = path.join(__dirname, '../../server_files/preview_deployments');

// Ensure the preview directory exists
function ensurePreviewDirectoryExists() {
  if (!fs.existsSync(PREVIEW_BASE_DIR)) {
    fs.mkdirSync(PREVIEW_BASE_DIR, { recursive: true });
  }
}

// Create a unique directory for each preview deployment
export async function createPreviewDirectory(deploymentId: number, userId: number): Promise<string> {
  ensurePreviewDirectoryExists();
  const previewDir = path.join(PREVIEW_BASE_DIR, `preview_${deploymentId}_${userId}_${Date.now()}`);
  fs.mkdirSync(previewDir, { recursive: true });
  return previewDir;
}

// Write generated code to the preview directory
export async function writeCodeToPreviewDirectory(
  previewDir: string, 
  code: string, 
  filename: string
): Promise<string> {
  const filePath = path.join(previewDir, filename);
  fs.writeFileSync(filePath, code);
  return filePath;
}

// Determine the appropriate file extension for a language
export function getFileExtension(language: string): string {
  switch (language.toLowerCase()) {
    case 'javascript':
      return '.js';
    case 'typescript':
      return '.ts';
    case 'python':
      return '.py';
    case 'java':
      return '.java';
    case 'c#':
    case 'csharp':
      return '.cs';
    case 'php':
      return '.php';
    case 'ruby':
      return '.rb';
    case 'go':
      return '.go';
    case 'rust':
      return '.rs';
    case 'swift':
      return '.swift';
    case 'kotlin':
      return '.kt';
    case 'html':
      return '.html';
    case 'css':
      return '.css';
    default:
      return '.txt';
  }
}

// Prepare HTML wrapper for code preview
export function prepareHtmlPreview(
  code: string, 
  language: string, 
  title: string = 'Code Preview'
): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/github-dark.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
  <script>hljs.highlightAll();</script>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 1200px;
      margin: 0 auto;
      padding: 1rem;
      background-color: #f8f9fa;
    }
    h1 {
      color: #2d3748;
      margin-bottom: 2rem;
      border-bottom: 2px solid #e2e8f0;
      padding-bottom: 0.5rem;
    }
    pre {
      margin: 0;
      border-radius: 6px;
      overflow: auto;
    }
    code {
      font-family: 'JetBrains Mono', 'Fira Code', 'Courier New', Courier, monospace;
      padding: 1.5rem !important;
      border-radius: 6px;
      display: block;
    }
    .preview-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    .preview-info {
      padding: 1rem;
      background-color: #f1f5f9;
      border-radius: 6px;
      margin-bottom: 1rem;
      border-left: 4px solid #3182ce;
    }
    .language-label {
      font-size: 0.85rem;
      color: #718096;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .preview-container {
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
      padding: 1.5rem;
      margin-bottom: 2rem;
    }
    .info-box {
      padding: 1rem;
      background-color: #ebf8ff;
      border-left: 4px solid #4299e1;
      margin-bottom: 1rem;
      border-radius: 4px;
    }
  </style>
</head>
<body>
  <h1>${title}</h1>
  
  <div class="preview-info">
    <p>This is a preview of generated code. Review it carefully before using in your project.</p>
    <p><span class="language-label">Language:</span> ${language}</p>
  </div>
  
  <div class="preview-container">
    <div class="preview-header">
      <h2>Source Code</h2>
    </div>
    <pre><code class="language-${language.toLowerCase()}">${code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</code></pre>
  </div>
</body>
</html>`;
}

// Prepare HTML wrapper for interactive web code preview (HTML/CSS/JS)
export function prepareInteractiveHtmlPreview(
  code: string, 
  title: string = 'Interactive Preview'
): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
      line-height: 1.6;
      margin: 0;
      padding: 0;
    }
    .preview-header {
      background-color: #f1f5f9;
      padding: 0.5rem 1rem;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .preview-header h1 {
      font-size: 1.2rem;
      margin: 0;
    }
    .preview-content {
      padding: 0;
      height: calc(100vh - 50px);
    }
    iframe {
      width: 100%;
      height: 100%;
      border: none;
    }
  </style>
</head>
<body>
  <div class="preview-header">
    <h1>${title}</h1>
  </div>
  <div class="preview-content">
    <iframe id="preview-frame" sandbox="allow-scripts"></iframe>
  </div>
  <script>
    // Inject HTML content into the iframe
    window.onload = function() {
      const iframe = document.getElementById('preview-frame');
      const code = ${JSON.stringify(code)};
      
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      iframeDoc.open();
      iframeDoc.write(code);
      iframeDoc.close();
    };
  </script>
</body>
</html>`;
}

// Check if code is interactive front-end code (HTML with optional CSS/JS)
export function isInteractiveCode(code: string, language: string): boolean {
  if (language.toLowerCase() === 'html') {
    return true;
  }
  
  // Check if it appears to be a complete HTML document
  if (code.includes('<!DOCTYPE html>') || 
      (code.includes('<html') && code.includes('<body'))) {
    return true;
  }
  
  return false;
}

// Create a preview URL and file for the code
export async function createCodePreview(
  code: string,
  language: string,
  deploymentId: number,
  userId: number,
  type: string
): Promise<{ previewUrl: string; previewPath: string }> {
  try {
    const previewDir = await createPreviewDirectory(deploymentId, userId);
    const baseFilename = `preview_${type}`;
    
    // Determine if this should be an interactive preview
    const isInteractive = isInteractiveCode(code, language);
    
    // Create the appropriate preview file
    let previewPath: string;
    let previewUrl: string;
    
    if (isInteractive) {
      // For HTML content, create an interactive preview
      const previewContent = prepareInteractiveHtmlPreview(code, `${type} Preview`);
      previewPath = path.join(previewDir, `${baseFilename}_interactive.html`);
      fs.writeFileSync(previewPath, previewContent);
      previewUrl = `/api/preview/${path.basename(previewDir)}/${baseFilename}_interactive.html`;
    } else {
      // For other languages, create a syntax-highlighted view
      const fileExtension = getFileExtension(language);
      const codeFilePath = path.join(previewDir, `${baseFilename}${fileExtension}`);
      fs.writeFileSync(codeFilePath, code);
      
      // Create the HTML preview file
      const previewContent = prepareHtmlPreview(code, language, `${type} Preview`);
      previewPath = path.join(previewDir, `${baseFilename}.html`);
      fs.writeFileSync(previewPath, previewContent);
      previewUrl = `/api/preview/${path.basename(previewDir)}/${baseFilename}.html`;
    }
    
    return { previewUrl, previewPath };
  } catch (error: any) {
    log(`Error creating code preview: ${error.message}`, 'preview-service');
    throw new Error(`Failed to create preview: ${error.message}`);
  }
}