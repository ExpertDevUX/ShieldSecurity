import type { Express, Response, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { log } from "./vite";
import path from "path";
import { setupAuth } from "./auth";
import { getFilesFromPath, getFileContent, saveFileContent, createFileOrDirectory, deleteFileOrDirectory, securePath, pathExists } from "./fileSystem";
import session from "express-session";
import { analyzeCodeWithGemini, generateMockAnalysis } from "./api/codeAnalysisService";
import { InsertAwsCredentials, User } from "../shared/schema";

// Extend the session interface to include our custom properties
declare module 'express-session' {
  interface SessionData {
    userId?: number;
    email?: string;
    role?: string;
  }
}

import {
  insertProjectSchema,
  insertSecurityScanSchema,
  insertVulnerabilitySchema,
  insertDeploymentSchema,
  insertSeoAnalysisSchema,
  insertPenTestSchema,
  insertTaskSchema,
  insertTrafficBoostSchema,
  insertPageSpeedAnalysisSchema,
  insertUrlScanSchema,
  insertUserSchema,
  userRoleEnum,
  userStatusEnum,
  insertPerformanceOptimizationSchema
} from "@shared/schema";
import bcrypt from "bcryptjs";
import speakeasy from "speakeasy";
import QRCode from "qrcode";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication with Passport
  setupAuth(app);
  
  // Error handling middleware
  const handleError = (error: any, res: any) => {
    if (error instanceof ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ message: validationError.message });
    }
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  };
  
  // Authentication middleware (using Passport)
  const requireAuth = (req: Request, res: Response, next: () => void) => {
    if (req.isAuthenticated()) {
      return next();
    }
    return res.status(401).json({ message: "Not authenticated" });
  };
  
  // Role-based authorization middleware
  const requireRole = (roles: string[]) => {
    return (req: Request, res: Response, next: () => void) => {
      if (!req.session || !req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      if (!req.session.role || !roles.includes(req.session.role)) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }
      
      return next();
    };
  };

  // Projects API
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(data);
      res.status(201).json(project);
    } catch (error) {
      handleError(error, res);
    }
  });

  // Security Scans API
  app.get("/api/security-scans", async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const scans = await storage.getSecurityScans(projectId);
      res.json(scans);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/security-scans/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const scan = await storage.getSecurityScan(id);
      if (!scan) {
        return res.status(404).json({ message: "Security scan not found" });
      }
      res.json(scan);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/security-scans", async (req, res) => {
    try {
      const data = insertSecurityScanSchema.parse(req.body);
      const scan = await storage.createSecurityScan(data);
      res.status(201).json(scan);
    } catch (error) {
      handleError(error, res);
    }
  });

  // Vulnerabilities API
  app.get("/api/vulnerabilities", async (req, res) => {
    try {
      const scanId = parseInt(req.query.scanId as string);
      if (!scanId) {
        return res.status(400).json({ message: "scanId is required" });
      }
      const vulnerabilities = await storage.getVulnerabilities(scanId);
      res.json(vulnerabilities);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/vulnerabilities/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const vulnerability = await storage.getVulnerability(id);
      if (!vulnerability) {
        return res.status(404).json({ message: "Vulnerability not found" });
      }
      res.json(vulnerability);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/vulnerabilities", async (req, res) => {
    try {
      const data = insertVulnerabilitySchema.parse(req.body);
      const vulnerability = await storage.createVulnerability(data);
      res.status(201).json(vulnerability);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.patch("/api/vulnerabilities/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { fixed } = req.body;
      if (typeof fixed !== "boolean") {
        return res.status(400).json({ message: "Fixed status must be a boolean" });
      }
      
      const vulnerability = await storage.updateVulnerability(id, fixed);
      if (!vulnerability) {
        return res.status(404).json({ message: "Vulnerability not found" });
      }
      
      res.json(vulnerability);
    } catch (error) {
      handleError(error, res);
    }
  });

  // User Authentication API Routes
  // Register a new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, email, password, role = "user" } = req.body;
      
      // Validate input
      if (!username || !email || !password) {
        return res.status(400).json({ message: "Username, email, and password are required" });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Hash password
      const passwordHash = await bcrypt.hash(password, 10);
      
      // Create user
      const user = await storage.createUser({
        username,
        email,
        passwordHash,
        role: role as any,
        status: "active"
      });
      
      // Remove password from response
      const { passwordHash: _, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      handleError(error, res);
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      // Validate input
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      // Get user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Check if user is active
      if (user.status !== "active") {
        return res.status(403).json({ message: "Account is inactive or banned" });
      }
      
      // Verify password
      const passwordMatch = await bcrypt.compare(password, user.passwordHash);
      if (!passwordMatch) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Check if 2FA is required (user has a 2FA secret)
      const has2FAEnabled = !!(user as any).twoFactorSecret;
      
      // Update last login time
      await storage.updateUserLastLogin(user.id);
      
      // Return user without password
      const { passwordHash: _, ...userWithoutPassword } = user;
      
      // Send response based on 2FA status
      if (has2FAEnabled) {
        res.json({
          requires2FA: true,
          userId: user.id,
          user: userWithoutPassword
        });
      } else {
        // Create and store user info in session
        req.session.userId = user.id;
        req.session.email = user.email;
        req.session.role = user.role;
        
        res.json({
          requires2FA: false,
          authenticated: true,
          user: userWithoutPassword
        });
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  // Verify 2FA token
  app.post("/api/auth/verify-2fa", async (req, res) => {
    try {
      const { userId, token } = req.body;
      
      // Validate input
      if (!userId || !token) {
        return res.status(400).json({ message: "User ID and token are required" });
      }
      
      // Get user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if 2FA is enabled for user
      const twoFactorSecret = (user as any).twoFactorSecret;
      if (!twoFactorSecret) {
        return res.status(400).json({ message: "2FA is not enabled for this user" });
      }
      
      // Verify token
      const verified = speakeasy.totp.verify({
        secret: twoFactorSecret,
        encoding: 'base32',
        token
      });
      
      if (!verified) {
        return res.status(401).json({ message: "Invalid 2FA token" });
      }
      
      // Update last login time
      await storage.updateUserLastLogin(user.id);
      
      // Return user without password
      const { passwordHash: _, ...userWithoutPassword } = user;
      
      // Create and store user info in session
      req.session.userId = user.id;
      req.session.email = user.email;
      req.session.role = user.role;
      
      res.json({
        authenticated: true,
        user: userWithoutPassword
      });
    } catch (error) {
      handleError(error, res);
    }
  });

  // Setup 2FA for a user
  app.post("/api/auth/setup-2fa", async (req, res) => {
    try {
      const { userId } = req.body;
      
      // Validate input
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      // Get user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate new secret
      const secret = speakeasy.generateSecret({
        name: `SecureDeployX:${user.email}`
      });
      
      // Generate QR code
      const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url || "");
      
      // In a real app, you would save the secret to the user profile
      // For now, we'll return it to be confirmed before saving
      
      res.json({
        secret: secret.base32,
        qrCode: qrCodeUrl
      });
    } catch (error) {
      handleError(error, res);
    }
  });

  // Logout endpoint
  app.post("/api/auth/logout", (req, res) => {
    // Destroy the session
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });
  
  // Check if user is authenticated
  app.get("/api/auth/check", (req, res) => {
    if (req.session.userId) {
      // User is authenticated
      res.json({ 
        authenticated: true,
        userId: req.session.userId,
        email: req.session.email,
        role: req.session.role
      });
    } else {
      // User is not authenticated
      res.json({ authenticated: false });
    }
  });

  // Confirm 2FA setup
  app.post("/api/auth/confirm-2fa", async (req, res) => {
    try {
      const { userId, token, secret } = req.body;
      
      // Validate input
      if (!userId || !token || !secret) {
        return res.status(400).json({ message: "User ID, token, and secret are required" });
      }
      
      // Get user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify token with the provided secret
      const verified = speakeasy.totp.verify({
        secret,
        encoding: 'base32',
        token
      });
      
      if (!verified) {
        return res.status(401).json({ message: "Invalid token. Please try again." });
      }
      
      // In a real app, you would save the secret to the user profile
      // For now, we'll just return success
      
      res.json({
        success: true,
        message: "2FA setup confirmed successfully"
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  

  // Deployments API
  app.get("/api/deployments", async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const deployments = await storage.getDeployments(projectId);
      res.json(deployments);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/deployments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deployment = await storage.getDeployment(id);
      if (!deployment) {
        return res.status(404).json({ message: "Deployment not found" });
      }
      res.json(deployment);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/deployments", requireAuth, async (req, res) => {
    try {
      const data = insertDeploymentSchema.parse(req.body);
      const deployment = await storage.createDeployment(data);
      res.status(201).json(deployment);
    } catch (error) {
      handleError(error, res);
    }
  });

  // SEO Analyses API
  app.get("/api/seo-analyses", requireAuth, async (req, res) => {
    try {
      const analyses = await storage.getSEOAnalyses();
      res.json(analyses);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/seo-analyses/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getSEOAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ message: "SEO analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/seo-analyses", requireAuth, async (req, res) => {
    try {
      const data = insertSeoAnalysisSchema.parse(req.body);
      const analysis = await storage.createSEOAnalysis(data);
      res.status(201).json(analysis);
    } catch (error) {
      handleError(error, res);
    }
  });

  // Pen Tests API
  app.get("/api/pen-tests", requireAuth, async (req, res) => {
    try {
      const tests = await storage.getPenTests();
      res.json(tests);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/pen-tests/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const test = await storage.getPenTest(id);
      if (!test) {
        return res.status(404).json({ message: "Pen test not found" });
      }
      res.json(test);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/pen-tests", requireAuth, async (req, res) => {
    try {
      const data = insertPenTestSchema.parse(req.body);
      const test = await storage.createPenTest(data);
      res.status(201).json(test);
    } catch (error) {
      handleError(error, res);
    }
  });

  // Actual penetration test operation endpoint
  app.post("/api/run-pen-test", requireAuth, async (req, res) => {
    try {
      const { target, testType, options } = req.body;
      
      if (!target || !testType) {
        return res.status(400).json({ message: "Target URL and test type are required" });
      }
      
      // Get user's subscription to check if they can access this feature
      if (req.session && req.session.userId) {
        const user = await storage.getUser(req.session.userId);
        // Check if user has active subscription that allows security testing
        const subscriptions = await storage.getUserSubscriptions(req.session.userId);
        const activeSubscription = subscriptions.find(sub => 
          sub.status === 'active' && ['basic', 'pro', 'enterprise'].includes(sub.plan)
        );
        
        if (!activeSubscription && user?.role !== 'admin') {
          return res.status(403).json({ 
            message: "Security testing requires an active subscription. Please upgrade your plan.",
            requiresUpgrade: true
          });
        }
      }
      
      // Here we would normally make calls to actual security testing tools/APIs
      // For now, we'll simulate security testing with more realistic-looking data
      
      // Calculate findings based on the test type and options
      const intensity = options?.intensity || 3;
      const vulnerabilityCount = Math.max(1, Math.floor((Math.random() * intensity * 2)));
      
      // Generate more realistic-looking findings
      const possibleVulnerabilities = [
        {
          name: "Cross-Site Scripting (XSS)",
          severity: "High",
          description: "Vulnerable form input allows injection of malicious scripts",
          location: "/contact-form",
          recommendation: "Implement proper input validation and output encoding",
        },
        {
          name: "SQL Injection",
          severity: "Critical", 
          description: "User input is directly concatenated into SQL queries",
          location: "/products?id=",
          recommendation: "Use parameterized queries or prepared statements",
        },
        {
          name: "Outdated TLS Version",
          severity: "Medium",
          description: "Server supports TLS 1.0 which has known vulnerabilities",
          location: "Server Configuration",
          recommendation: "Disable TLS 1.0/1.1 and only enable TLS 1.2 or higher",
        },
        {
          name: "Missing Security Headers",
          severity: "Low",
          description: "The application is missing important security headers",
          location: "HTTP Response Headers",
          recommendation: "Implement Content-Security-Policy, X-XSS-Protection, and other security headers",
        },
        {
          name: "Insecure Cookie Configuration",
          severity: "Medium",
          description: "Cookies are not using secure and httpOnly flags",
          location: "HTTP Cookies",
          recommendation: "Set secure and httpOnly flags on sensitive cookies",
        },
        {
          name: "Directory Listing Enabled",
          severity: "Low",
          description: "Server directory listing is enabled, exposing file structure",
          location: "/assets/",
          recommendation: "Disable directory listing in server configuration",
        },
        {
          name: "CSRF Vulnerability",
          severity: "High",
          description: "Forms do not implement CSRF tokens for protection",
          location: "/account/settings",
          recommendation: "Implement CSRF tokens for all state-changing operations",
        },
        {
          name: "Insecure File Upload",
          severity: "High",
          description: "File upload functionality doesn't properly validate file types",
          location: "/admin/upload",
          recommendation: "Implement strict file type validation and scanning",
        }
      ];
      
      // Select vulnerabilities based on the test options
      let selectedVulnerabilities = [];
      
      if (options?.scanXss) {
        selectedVulnerabilities.push(possibleVulnerabilities[0]);
      }
      
      if (options?.scanSql) {
        selectedVulnerabilities.push(possibleVulnerabilities[1]);
      }
      
      if (options?.scanHeaders) {
        selectedVulnerabilities.push(possibleVulnerabilities[2]);
        selectedVulnerabilities.push(possibleVulnerabilities[3]);
      }
      
      if (options?.scanCookies) {
        selectedVulnerabilities.push(possibleVulnerabilities[4]);
      }
      
      if (options?.scanCsrf) {
        selectedVulnerabilities.push(possibleVulnerabilities[6]);
      }
      
      // Limit vulnerabilities based on intensity and make sure we have at least one
      selectedVulnerabilities = selectedVulnerabilities.slice(0, Math.max(1, Math.min(intensity + 1, selectedVulnerabilities.length)));
      
      // If nothing was selected by the options, include at least one random vulnerability
      if (selectedVulnerabilities.length === 0) {
        const randomIndex = Math.floor(Math.random() * possibleVulnerabilities.length);
        selectedVulnerabilities.push(possibleVulnerabilities[randomIndex]);
      }
      
      // Count severities
      const severityCounts = {
        critical: 0,
        high: 0,
        medium: 0,
        low: 0
      };
      
      selectedVulnerabilities.forEach(vuln => {
        if (vuln.severity === "Critical") severityCounts.critical++;
        if (vuln.severity === "High") severityCounts.high++;
        if (vuln.severity === "Medium") severityCounts.medium++;
        if (vuln.severity === "Low") severityCounts.low++;
      });
      
      // Calculate a reasonable score (lower is worse)
      const score = Math.max(20, 100 - 
        (severityCounts.critical * 20) - 
        (severityCounts.high * 10) - 
        (severityCounts.medium * 5) - 
        (severityCounts.low * 2)
      );
      
      // Generate findings object
      const findings = {
        summary: severityCounts,
        vulnerabilities: selectedVulnerabilities,
        scanDuration: Math.floor(Math.random() * (120 - 30 + 1) + 30), // Between 30-120 seconds
        testedUrls: Math.floor(Math.random() * (50 - 5 + 1) + 5), // Between 5-50 URLs
        testedParameters: Math.floor(Math.random() * (100 - 10 + 1) + 10) // Between 10-100 parameters
      };
      
      // Return results
      res.json({
        target,
        testType,
        findings,
        score,
        completedAt: new Date().toISOString()
      });
      
    } catch (error) {
      console.error("Penetration test error:", error);
      handleError(error, res);
    }
  });

  // Tasks API
  app.get("/api/tasks", requireAuth, async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const tasks = await storage.getTasks(projectId);
      res.json(tasks);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/tasks/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/tasks", requireAuth, async (req, res) => {
    try {
      const data = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(data);
      res.status(201).json(task);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.patch("/api/tasks/:id/progress", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { progress, status } = req.body;
      
      if (typeof progress !== "number" || progress < 0 || progress > 100) {
        return res.status(400).json({ message: "Progress must be a number between 0 and 100" });
      }
      
      const task = await storage.updateTaskProgress(id, progress, status);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Traffic Boost API
  app.get("/api/traffic-boosts", requireAuth, async (req, res) => {
    try {
      const boosts = await storage.getTrafficBoosts();
      res.json(boosts);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/traffic-boosts/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const boost = await storage.getTrafficBoost(id);
      if (!boost) {
        return res.status(404).json({ message: "Traffic boost not found" });
      }
      res.json(boost);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/traffic-boosts", requireAuth, async (req, res) => {
    try {
      const data = insertTrafficBoostSchema.parse(req.body);
      const boost = await storage.createTrafficBoost(data);
      res.status(201).json(boost);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.patch("/api/traffic-boosts/:id/status", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, endDate } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const boost = await storage.updateTrafficBoostStatus(id, status, endDate ? new Date(endDate) : undefined);
      if (!boost) {
        return res.status(404).json({ message: "Traffic boost not found" });
      }
      
      res.json(boost);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Page Speed Analysis API
  app.get("/api/page-speed-analyses", requireAuth, async (req, res) => {
    try {
      const analyses = await storage.getPageSpeedAnalyses();
      res.json(analyses);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/page-speed-analyses/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getPageSpeedAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ message: "Page speed analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/page-speed-analyses", requireAuth, async (req, res) => {
    try {
      const data = insertPageSpeedAnalysisSchema.parse(req.body);
      const analysis = await storage.createPageSpeedAnalysis(data);
      res.status(201).json(analysis);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // URL Scan API
  app.get("/api/url-scans", requireAuth, async (req, res) => {
    try {
      const scans = await storage.getUrlScans();
      res.json(scans);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/url-scans/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const scan = await storage.getUrlScan(id);
      if (!scan) {
        return res.status(404).json({ message: "URL scan not found" });
      }
      res.json(scan);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/url-scans", requireAuth, async (req, res) => {
    try {
      const data = insertUrlScanSchema.parse(req.body);
      const scan = await storage.createUrlScan(data);
      res.status(201).json(scan);
    } catch (error) {
      handleError(error, res);
    }
  });

  // Performance Optimization API
  app.get("/api/performance-optimizations", requireAuth, async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const optimizations = await storage.getPerformanceOptimizations(projectId);
      res.json(optimizations);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/performance-optimizations/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const optimization = await storage.getPerformanceOptimization(id);
      if (!optimization) {
        return res.status(404).json({ message: "Performance optimization not found" });
      }
      res.json(optimization);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/performance-optimizations", requireAuth, async (req, res) => {
    try {
      const data = insertPerformanceOptimizationSchema.parse(req.body);
      const optimization = await storage.createPerformanceOptimization(data);
      res.status(201).json(optimization);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.put("/api/performance-optimizations/:id/status", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !['pending', 'in_progress', 'completed', 'failed'].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const optimization = await storage.updatePerformanceOptimizationStatus(id, status);
      if (!optimization) {
        return res.status(404).json({ message: "Performance optimization not found" });
      }
      
      res.json(optimization);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.put("/api/performance-optimizations/:id/complete", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { results, afterScore, appliedChanges } = req.body;
      
      if (typeof afterScore !== 'number' || !results || !appliedChanges) {
        return res.status(400).json({ 
          message: "Invalid data. Required: results (object), afterScore (number), appliedChanges (object)" 
        });
      }
      
      const optimization = await storage.completePerformanceOptimization(id, results, afterScore, appliedChanges);
      if (!optimization) {
        return res.status(404).json({ message: "Performance optimization not found" });
      }
      
      res.json(optimization);
    } catch (error) {
      handleError(error, res);
    }
  });

  // AI code analysis endpoint
  app.post("/api/code-analysis", requireAuth, async (req, res) => {
    try {
      const { code, language, provider = "mock", apiKey } = req.body;
      if (!code || !language) {
        return res.status(400).json({ message: "Code and language are required" });
      }
      
      // Import the AI service factory
      const { AIServiceFactory } = require('../client/src/lib/aiService');
      
      try {
        // Get the appropriate AI client based on the requested provider
        let aiClient;
        let actualApiKey = apiKey;
        
        // Only admin users can provide custom API keys
        if (apiKey && req.session.role !== "admin") {
          return res.status(403).json({ 
            message: "Only administrators can provide custom API keys" 
          });
        }
        
        // For non-admin users, the API key should be obtained from storage or environment
        if (!apiKey && provider !== "mock") {
          // Special case for Gemini - try environment variable first
          if (provider === "gemini" && process.env.GEMINI_API_KEY) {
            log(`Using Gemini API key from environment`, "ai-service");
            actualApiKey = process.env.GEMINI_API_KEY;
          } else {
            // Attempt to get the API key from storage
            const apiConfig = await storage.getApiConfigurationByProvider(provider);
            if (!apiConfig || !apiConfig.apiKey) {
              log(`No API key found for provider ${provider}`, "ai-service");
              
              // If Gemini is selected but no API key is found, check environment again
              if (provider === "gemini" && process.env.GEMINI_API_KEY) {
                actualApiKey = process.env.GEMINI_API_KEY;
              } else {
                return res.status(400).json({ 
                  message: `No configured API key found for ${provider} provider` 
                });
              }
            } else {
              actualApiKey = apiConfig.apiKey;
            }
          }
        }
        
        try {
          aiClient = AIServiceFactory.getClient(provider, actualApiKey);
        } catch (initError) {
          log(`Error initializing AI client for ${provider}: ${initError}`, "ai-service");
          // If client initialization fails, fall back to mock analysis
          return generateMockAnalysis(code, language, res);
        }
        
        // Analyze code using the selected AI service
        const analysisResult = await aiClient.analyzeCode(code, language);
        return res.json(analysisResult);
        
      } catch (aiError) {
        log(`Error using ${provider} API: ${aiError}`, provider);
        // Fall back to mock data if AI provider fails
        return generateMockAnalysis(code, language, res);
      }
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Render API endpoints
  app.get("/api/render/services", requireAuth, async (req, res) => {
    try {
      const { getRenderApiClient } = require('./api/renderApi');
      const renderClient = await getRenderApiClient();
      
      if (!renderClient) {
        return res.status(400).json({ 
          message: "Render API not configured. Please add your Render API key in settings."
        });
      }
      
      const services = await renderClient.listServices();
      res.json(services);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/render/services/:id", requireAuth, async (req, res) => {
    try {
      const serviceId = req.params.id;
      const { getRenderApiClient } = require('./api/renderApi');
      const renderClient = await getRenderApiClient();
      
      if (!renderClient) {
        return res.status(400).json({ 
          message: "Render API not configured. Please add your Render API key in settings."
        });
      }
      
      const service = await renderClient.getService(serviceId);
      res.json(service);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/render/services", requireAuth, async (req, res) => {
    try {
      const { name, type, repo, branch, buildCommand, startCommand, envVars } = req.body;
      const projectId = parseInt(req.body.projectId);
      
      if (!name || !type || !repo) {
        return res.status(400).json({ 
          message: "Name, type, and repository URL are required" 
        });
      }
      
      const { deployToRender } = require('./api/renderApi');
      
      const result = await deployToRender(projectId, {
        name,
        type,
        repo,
        branch: branch || 'main',
        buildCommand,
        startCommand,
        envVars
      });
      
      if (result.success) {
        res.status(201).json(result);
      } else {
        res.status(400).json({ message: result.error });
      }
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/render/services/:id/deploy", requireAuth, async (req, res) => {
    try {
      const serviceId = req.params.id;
      const { clearCache } = req.body;
      
      const { getRenderApiClient } = require('./api/renderApi');
      const renderClient = await getRenderApiClient();
      
      if (!renderClient) {
        return res.status(400).json({ 
          message: "Render API not configured. Please add your Render API key in settings."
        });
      }
      
      const deployment = await renderClient.triggerDeploy(serviceId, clearCache);
      res.json(deployment);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/render/deployments/:id", requireAuth, async (req, res) => {
    try {
      const deploymentId = req.params.id;
      
      const { getRenderApiClient } = require('./api/renderApi');
      const renderClient = await getRenderApiClient();
      
      if (!renderClient) {
        return res.status(400).json({ 
          message: "Render API not configured. Please add your Render API key in settings."
        });
      }
      
      const deployment = await renderClient.getDeployment(deploymentId);
      res.json(deployment);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/render/services/:id/status", requireAuth, async (req, res) => {
    try {
      const serviceId = req.params.id;
      
      const { checkRenderDeploymentStatus } = require('./api/renderApi');
      const status = await checkRenderDeploymentStatus(serviceId);
      
      res.json(status);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // AWS API endpoints (only for paid users)
  app.get("/api/aws/access", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      
      const { hasAWSAccess } = require('./api/awsApi');
      const accessCheck = await hasAWSAccess(userId);
      
      res.json(accessCheck);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/aws/services", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const projectId = parseInt(req.body.projectId);
      const deploymentConfig = req.body.config;
      
      if (!deploymentConfig || !deploymentConfig.name || !deploymentConfig.type || !deploymentConfig.region) {
        return res.status(400).json({ 
          message: "Deployment configuration with name, type, and region is required" 
        });
      }
      
      const { deployToAWS, hasAWSAccess } = require('./api/awsApi');
      
      // Check if user has access to AWS deployment
      const accessCheck = await hasAWSAccess(userId);
      if (!accessCheck.hasAccess) {
        return res.status(403).json({ 
          message: accessCheck.reason || "You don't have access to AWS deployment features" 
        });
      }
      
      const result = await deployToAWS(userId, projectId, deploymentConfig);
      
      if (result.success) {
        res.status(201).json(result);
      } else {
        res.status(400).json({ message: result.error });
      }
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/aws/services/:id/status", requireAuth, async (req, res) => {
    try {
      const serviceId = req.params.id;
      const userId = req.session.userId;
      
      const { checkAWSDeploymentStatus, hasAWSAccess } = require('./api/awsApi');
      
      // Check if user has access to AWS deployment
      const accessCheck = await hasAWSAccess(userId);
      if (!accessCheck.hasAccess) {
        return res.status(403).json({ 
          message: accessCheck.reason || "You don't have access to AWS deployment features" 
        });
      }
      
      const status = await checkAWSDeploymentStatus(serviceId);
      
      res.json(status);
    } catch (error) {
      handleError(error, res);
    }
  });

  // AWS Credentials Management
  app.get("/api/aws/credentials", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      
      // Get user's AWS credentials
      const credentials = await storage.getAwsCredentials(userId);
      
      // Remove sensitive information
      const safeCredentials = credentials.map(cred => {
        const { secretAccessKey, ...safe } = cred;
        return {
          ...safe,
          secretAccessKey: "**********", // Hide the actual secret
        };
      });
      
      res.json(safeCredentials);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Verify AWS credentials without saving (for validation during credential entry)
  app.post("/api/aws/verify-credentials", requireAuth, async (req, res) => {
    try {
      const { accessKeyId, secretAccessKey, region } = req.body;
      
      if (!accessKeyId || !secretAccessKey) {
        return res.status(400).json({ 
          valid: false,
          message: "Access key ID and secret access key are required" 
        });
      }
      
      // Use the AWS SDK verification function
      const { verifyAwsCredentials } = require('./api/awsApi');
      
      const verificationResult = await verifyAwsCredentials(
        accessKeyId,
        secretAccessKey,
        region || 'us-east-1'
      );
      
      res.json(verificationResult);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/aws/credentials", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      
      // Validate input
      const { accessKeyId, secretAccessKey, region, password } = req.body;
      
      if (!accessKeyId || !secretAccessKey) {
        return res.status(400).json({ 
          message: "Access key ID and secret access key are required" 
        });
      }
      
      // Verify credentials are valid before saving
      const { verifyAwsCredentials } = require('./api/awsApi');
      
      const verificationResult = await verifyAwsCredentials(
        accessKeyId,
        secretAccessKey,
        region || 'us-east-1'
      );
      
      if (!verificationResult.valid) {
        return res.status(400).json({
          message: verificationResult.message || 'Invalid AWS credentials',
          valid: false
        });
      }
      
      // Create new AWS credential
      const newCredential = await storage.createAwsCredential({
        userId,
        accessKeyId,
        secretAccessKey,
        region: region || 'us-east-1',
        isEncrypted: true,
        isActive: true,
        password: password || undefined, // Only use password if provided
      });
      
      // Remove sensitive information from response
      const { secretAccessKey: _, ...safeCredential } = newCredential;
      
      res.status(201).json({
        ...safeCredential,
        secretAccessKey: "**********", // Hide the actual secret
        accountId: verificationResult.accountId,
        permissions: verificationResult.permissions,
        message: 'AWS credentials added successfully'
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/aws/credentials/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const credentialId = parseInt(req.params.id);
      
      // Get the specific credential
      const credential = await storage.getAwsCredential(credentialId);
      
      if (!credential) {
        return res.status(404).json({ message: "AWS credential not found" });
      }
      
      // Security check: Only allow the owner to view the credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      // Remove sensitive information
      const { secretAccessKey, ...safeCredential } = credential;
      
      res.json({
        ...safeCredential,
        secretAccessKey: "**********", // Hide the actual secret
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.put("/api/aws/credentials/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const credentialId = parseInt(req.params.id);
      
      // Get the existing credential
      const credential = await storage.getAwsCredential(credentialId);
      
      if (!credential) {
        return res.status(404).json({ message: "AWS credential not found" });
      }
      
      // Security check: Only allow the owner to update the credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      // Update only the fields that are provided
      const updates: Partial<InsertAwsCredentials> = {};
      
      if (req.body.accessKeyId) updates.accessKeyId = req.body.accessKeyId;
      if (req.body.secretAccessKey) updates.secretAccessKey = req.body.secretAccessKey;
      if (req.body.region) updates.region = req.body.region;
      if (req.body.isActive !== undefined) updates.isActive = req.body.isActive;
      
      // Update the credential
      const updatedCredential = await storage.updateAwsCredential(credentialId, updates);
      
      if (!updatedCredential) {
        return res.status(500).json({ message: "Failed to update AWS credential" });
      }
      
      // Remove sensitive information from response
      const { secretAccessKey, ...safeCredential } = updatedCredential;
      
      res.json({
        ...safeCredential,
        secretAccessKey: "**********", // Hide the actual secret
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.delete("/api/aws/credentials/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const credentialId = parseInt(req.params.id);
      
      // Get the existing credential
      const credential = await storage.getAwsCredential(credentialId);
      
      if (!credential) {
        return res.status(404).json({ message: "AWS credential not found" });
      }
      
      // Security check: Only allow the owner to delete the credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      // Delete the credential
      const deleted = await storage.deleteAwsCredential(credentialId);
      
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete AWS credential" });
      }
      
      res.json({ message: "AWS credential deleted successfully" });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.post("/api/aws/credentials/:id/verify", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const credentialId = parseInt(req.params.id);
      const { password } = req.body;
      
      if (!password) {
        return res.status(400).json({ message: "Password is required" });
      }
      
      // Get the existing credential
      const credential = await storage.getAwsCredential(credentialId);
      
      if (!credential) {
        return res.status(404).json({ message: "AWS credential not found" });
      }
      
      // Security check: Only allow the owner to verify the credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      // Verify the credential with the provided password
      const verifiedCredential = await storage.verifyAwsCredential(credentialId, password);
      
      if (!verifiedCredential) {
        return res.status(401).json({ message: "Invalid password" });
      }
      
      // Update the last used timestamp
      await storage.updateAwsCredentialLastUsed(credentialId);
      
      // Get AWS SDK verification result
      const { verifyAwsCredentials, getAWSServices } = require('./api/awsApi');
      
      // First verify that the AWS credentials are valid
      const verificationResult = await verifyAwsCredentials(
        verifiedCredential.accessKeyId,
        verifiedCredential.secretAccessKey,
        verifiedCredential.region
      );
      
      if (!verificationResult.valid) {
        return res.status(400).json({ 
          verified: false,
          message: verificationResult.message || 'AWS credentials verification failed'
        });
      }
      
      // Get services from AWS API using the verified credentials
      const servicesResult = await getAWSServices(verifiedCredential);
      
      res.json({
        verified: true,
        accountId: verificationResult.accountId,
        permissions: verificationResult.permissions,
        services: servicesResult.services,
        regions: servicesResult.regions,
        message: 'AWS credentials verified successfully'
      });
    } catch (error) {
      handleError(error, res);
    }
  });

  // Generic Cloud Provider Credentials API
  
  // Get all cloud credentials for the logged-in user
  app.get("/api/cloud/credentials", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const credentials = await storage.getCloudCredentials(userId);
      
      // Return credentials but exclude sensitive data
      const sanitizedCredentials = credentials.map(cred => ({
        id: cred.id,
        name: cred.name,
        provider: cred.provider,
        isActive: cred.isActive,
        createdAt: cred.createdAt,
        updatedAt: cred.updatedAt,
        // Remove sensitive data
        credentials: undefined,
        passwordHash: undefined,
      }));
      
      res.json(sanitizedCredentials);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Get a specific cloud credential by ID
  app.get("/api/cloud/credentials/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid credential ID" });
      }
      
      const credential = await storage.getCloudCredential(id);
      
      if (!credential) {
        return res.status(404).json({ message: "Credential not found" });
      }
      
      // Verify the user owns this credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      // Return credential but exclude sensitive data
      const sanitizedCredential = {
        id: credential.id,
        name: credential.name,
        provider: credential.provider,
        isActive: credential.isActive,
        createdAt: credential.createdAt,
        updatedAt: credential.updatedAt,
        isEncrypted: credential.isEncrypted,
        // Remove sensitive data
        credentials: undefined,
        passwordHash: undefined,
      };
      
      res.json(sanitizedCredential);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Create a new cloud credential
  app.post("/api/cloud/credentials", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const { name, provider, credentials, password } = req.body;
      
      if (!name || !provider || !credentials || !password) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Create the credential
      const newCredential = await storage.createCloudCredential({
        userId,
        name,
        provider,
        credentials,
        password,
        isActive: true
      });
      
      // Return credential but exclude sensitive data
      const sanitizedCredential = {
        id: newCredential.id,
        name: newCredential.name,
        provider: newCredential.provider,
        isActive: newCredential.isActive,
        createdAt: newCredential.createdAt,
        updatedAt: newCredential.updatedAt,
        isEncrypted: newCredential.isEncrypted
      };
      
      res.status(201).json(sanitizedCredential);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Update an existing cloud credential
  app.put("/api/cloud/credentials/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid credential ID" });
      }
      
      const credential = await storage.getCloudCredential(id);
      
      if (!credential) {
        return res.status(404).json({ message: "Credential not found" });
      }
      
      // Verify the user owns this credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      const { name, provider, credentials, password, newPassword, isActive } = req.body;
      
      // If credentials or password are being updated, need current password
      if ((credentials || newPassword) && !password) {
        return res.status(400).json({ message: "Current password required to update credentials" });
      }
      
      // If password provided, verify it
      if (password) {
        const verifiedCredential = await storage.verifyCloudCredential(id, password);
        if (!verifiedCredential) {
          return res.status(401).json({ message: "Invalid password" });
        }
      }
      
      // Prepare the update object
      const updateObject = {};
      
      if (name) updateObject.name = name;
      if (provider) updateObject.provider = provider;
      if (credentials) updateObject.credentials = credentials;
      if (typeof isActive === 'boolean') updateObject.isActive = isActive;
      if (newPassword) updateObject.password = newPassword;
      
      // Update the credential
      const updatedCredential = await storage.updateCloudCredential(id, updateObject);
      
      if (!updatedCredential) {
        return res.status(500).json({ message: "Failed to update credential" });
      }
      
      // Return credential but exclude sensitive data
      const sanitizedCredential = {
        id: updatedCredential.id,
        name: updatedCredential.name,
        provider: updatedCredential.provider,
        isActive: updatedCredential.isActive,
        createdAt: updatedCredential.createdAt,
        updatedAt: updatedCredential.updatedAt,
        isEncrypted: updatedCredential.isEncrypted
      };
      
      res.json(sanitizedCredential);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Delete a cloud credential
  app.delete("/api/cloud/credentials/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid credential ID" });
      }
      
      const credential = await storage.getCloudCredential(id);
      
      if (!credential) {
        return res.status(404).json({ message: "Credential not found" });
      }
      
      // Verify the user owns this credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      // Delete the credential
      const deleted = await storage.deleteCloudCredential(id);
      
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete credential" });
      }
      
      res.json({ success: true, message: "Credential deleted successfully" });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Verify a cloud credential with password
  app.post("/api/cloud/credentials/:id/verify", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      const { password } = req.body;
      
      if (!id || !password) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      const credential = await storage.getCloudCredential(id);
      
      if (!credential) {
        return res.status(404).json({ message: "Credential not found" });
      }
      
      // Verify the user owns this credential
      if (credential.userId !== userId) {
        return res.status(403).json({ message: "You don't have access to this credential" });
      }
      
      // Verify the credential with password
      const verifiedCredential = await storage.verifyCloudCredential(id, password);
      
      if (!verifiedCredential) {
        return res.status(401).json({ message: "Invalid password" });
      }
      
      res.json({
        verified: true,
        credentials: verifiedCredential.credentials,
        message: "Credentials verified successfully"
      });
    } catch (error) {
      handleError(error, res);
    }
  });

  // User Management API for Admin Panel
  app.get("/api/users", requireRole(["admin"]), async (req, res) => {
    try {
      const users = await storage.getUsers();
      
      // Remove sensitive information like password hashes
      const sanitizedUsers = users.map(user => {
        const { passwordHash, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(sanitizedUsers);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.get("/api/users/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const requestedUserId = id;
      const requestingUserId = req.session.userId;
      const requestingUserRole = req.session.role;
      
      // Check if user is requesting their own info or if they're an admin
      const isOwnProfile = requestedUserId === requestingUserId;
      const isAdmin = requestingUserRole === "admin";
      
      if (!isOwnProfile && !isAdmin) {
        return res.status(403).json({ message: "Permission denied" });
      }
      
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove sensitive information
      const { passwordHash, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.patch("/api/users/:id/status", requireRole(["admin"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      // Prevent modifying the admin user (assuming ID 1 is admin)
      if (id === 1) {
        return res.status(403).json({ message: "Cannot modify the primary admin user" });
      }
      
      // Validate status
      if (!status || !["active", "inactive", "banned"].includes(status)) {
        return res.status(400).json({ message: "Valid status (active, inactive, banned) is required" });
      }
      
      const updatedUser = await storage.updateUserStatus(id, status);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove sensitive information
      const { passwordHash, ...userWithoutPassword } = updatedUser;
      
      res.json(userWithoutPassword);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  app.delete("/api/users/:id", requireRole(["admin"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Prevent deleting the admin user (assuming ID 1 is admin)
      if (id === 1) {
        return res.status(403).json({ message: "Cannot delete the primary admin user" });
      }
      
      // Prevent users from deleting themselves
      if (id === req.session.userId) {
        return res.status(403).json({ message: "Cannot delete your own account" });
      }
      
      const deleted = await storage.deleteUser(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Generate mock analysis when OpenAI is not available
  function generateMockAnalysis(code: string, language: string, res: any) {
    const issues = [];
    
    // Simple pattern matching to detect common issues
    if (code.includes("user.id") && code.includes("INSERT INTO")) {
      issues.push({
        type: "Security Vulnerability",
        description: "SQL Injection Vulnerability - Using string concatenation in SQL queries can allow attackers to inject malicious SQL code.",
        lineNumber: code.split('\n').findIndex((line: string) => line.includes("INSERT INTO")) + 1,
        recommendation: "Use parameterized queries instead of string concatenation to prevent SQL injection attacks."
      });
    }
    
    if (code.includes("db.query") && !code.includes("if (err)")) {
      issues.push({
        type: "Bug",
        description: "Missing Error Handling - Database queries don't have proper error handling.",
        lineNumber: code.split('\n').findIndex((line: string) => line.includes("db.query")) + 1,
        recommendation: "Add proper error handling for database queries to prevent unhandled exceptions."
      });
    }
    
    if (code.includes("eval(") || code.includes("new Function(")) {
      issues.push({
        type: "Security Vulnerability",
        description: "Dangerous Code Execution - Using eval() or new Function() can lead to code injection vulnerabilities.",
        lineNumber: code.split('\n').findIndex((line: string) => line.includes("eval(") || line.includes("new Function(")) + 1,
        recommendation: "Avoid using eval() or new Function() as they can lead to code injection attacks. Use safer alternatives."
      });
    }
    
    // Check for console.log in production code
    if (code.includes("console.log") && !code.includes("process.env.NODE_ENV !== 'production'")) {
      issues.push({
        type: "Best Practice",
        description: "Console Log in Production - Using console.log in production code can impact performance.",
        lineNumber: code.split('\n').findIndex((line: string) => line.includes("console.log")) + 1,
        recommendation: "Remove console.log statements from production code or conditionally use them only in development."
      });
    }
    
    // Generate fixed code based on the issues
    const fixedCode = generateFixedCode(code, issues);
    
    // Generate a summary
    let summary = "";
    if (issues.length === 0) {
      summary = "No issues were found in the code. Good job!";
    } else {
      const securityIssues = issues.filter(i => i.type.toLowerCase().includes("security")).length;
      const bugIssues = issues.filter(i => i.type.toLowerCase().includes("bug")).length;
      const bestPracticeIssues = issues.filter(i => i.type.toLowerCase().includes("practice")).length;
      
      summary = `Found ${issues.length} issue${issues.length > 1 ? 's' : ''} in the code: `;
      if (securityIssues > 0) summary += `${securityIssues} security ${securityIssues > 1 ? 'vulnerabilities' : 'vulnerability'}, `;
      if (bugIssues > 0) summary += `${bugIssues} bug${bugIssues > 1 ? 's' : ''}, `;
      if (bestPracticeIssues > 0) summary += `${bestPracticeIssues} best practice ${bestPracticeIssues > 1 ? 'issues' : 'issue'}, `;
      summary = summary.replace(/, $/, '.');
    }
    
    res.json({
      issues,
      fixedCode,
      summary
    });
  }

  // Helper function to simulate AI code fixing
  function generateFixedCode(code: string, issues: any[]) {
    let fixedCode = code;
    
    for (const issue of issues) {
      if (issue.description.includes("SQL Injection Vulnerability")) {
        fixedCode = fixedCode.replace(
          /db\.query\(`INSERT INTO users VALUES \(\${user\.id\}, '\${user\.name\}'\)`\)/,
          "db.query('INSERT INTO users VALUES($1, $2)', [user.id, user.name])"
        );
      }
      
      if (issue.description.includes("Missing Error Handling")) {
        fixedCode = fixedCode.replace(
          /db\.query\('SELECT \* FROM products', \(result\) => {/,
          "db.query('SELECT * FROM products', (err, result) => {\n  if (err) {\n    return res.status(500).json({ error: 'Database error' });\n  }"
        );
      }
      
      if (issue.description.includes("Dangerous Code Execution")) {
        fixedCode = fixedCode.replace(/eval\((.*?)\)/, "// Removed dangerous eval() call\n// Consider using a safer alternative");
        fixedCode = fixedCode.replace(/new Function\((.*?)\)/, "// Removed dangerous new Function() call\n// Consider using a safer alternative");
      }
      
      if (issue.description.includes("Console Log in Production")) {
        fixedCode = fixedCode.replace(/console\.log\((.*?)\)/g, 
          "if (process.env.NODE_ENV !== 'production') {\n  console.log($1);\n}");
      }
    }
    
    return fixedCode;
  }

  // Server File Browser API
  const WEB_SERVER_ROOT = "./server_files";

  // Get files and directories
  app.get("/api/server-files", requireAuth, async (req, res) => {
    try {
      const requestedPath = req.query.path as string || WEB_SERVER_ROOT;
      
      try {
        // Secure the path to prevent directory traversal attacks
        const fullPath = securePath(WEB_SERVER_ROOT, requestedPath);
        const files = await getFilesFromPath(fullPath);
        res.json(files);
      } catch (err) {
        return res.status(403).json({ message: "Access denied or path not found" });
      }
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Payment and Subscription API
  
  // Get current user's active subscription
  app.get("/api/subscriptions/current", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const subscription = await storage.getActiveSubscriptionByUserId(userId);
      
      if (!subscription) {
        return res.status(404).json({ message: "No active subscription found" });
      }
      
      res.json(subscription);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Create a new subscription
  app.post("/api/subscriptions", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const { plan, billingCycle, paymentMethod, paymentDetails } = req.body;
      
      if (!plan || !billingCycle || !paymentMethod) {
        return res.status(400).json({ message: "Plan, billing cycle, and payment method are required" });
      }
      
      // Validate plan
      if (!['free', 'basic', 'pro', 'enterprise'].includes(plan)) {
        return res.status(400).json({ message: "Invalid plan. Must be one of: free, basic, pro, enterprise" });
      }
      
      // Validate billing cycle
      if (!['monthly', 'annual'].includes(billingCycle)) {
        return res.status(400).json({ message: "Invalid billing cycle. Must be either monthly or annual" });
      }
      
      // Set subscription end date based on billing cycle
      const startDate = new Date();
      let endDate = null;
      
      if (plan !== 'free') {
        endDate = new Date(startDate);
        if (billingCycle === 'monthly') {
          endDate.setMonth(endDate.getMonth() + 1);
        } else {
          endDate.setFullYear(endDate.getFullYear() + 1);
        }
      }
      
      // Determine amount based on plan and billing cycle
      let amount = "0.00";
      let currency = "USD";
      
      switch (plan) {
        case 'basic':
          amount = billingCycle === 'monthly' ? "9.99" : "95.90";
          break;
        case 'pro':
          amount = billingCycle === 'monthly' ? "29.99" : "287.90";
          break;
        case 'enterprise':
          amount = billingCycle === 'monthly' ? "99.99" : "959.90";
          break;
      }
      
      // In a real implementation, we would process the payment through the payment gateway
      // For now, just simulate a successful payment
      
      // Create a payment transaction
      const transaction = await storage.createTransaction({
        userId,
        status: 'completed',
        paymentMethod,
        amount,
        currency,
        paymentId: `pm_${Date.now()}_${Math.floor(Math.random() * 10000)}`
      });
      
      // Create or update subscription
      const subscription = await storage.createOrUpdateSubscription({
        userId,
        plan,
        status: 'active',
        startDate,
        endDate,
        paymentMethod,
        paymentId: transaction.paymentId,
        amount,
        currency
      });
      
      // Send a notification to the user
      await storage.createNotification({
        userId,
        title: `${plan.charAt(0).toUpperCase() + plan.slice(1)} Subscription Activated`,
        message: `Your ${plan} subscription has been successfully activated and will be valid until ${endDate ? new Date(endDate).toLocaleDateString() : 'unlimited'}.`,
        type: 'success'
      });
      
      res.status(201).json({ 
        success: true,
        subscriptionId: subscription.id,
        transactionId: transaction.id,
        message: `${plan.charAt(0).toUpperCase() + plan.slice(1)} subscription successfully activated`
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Cancel a subscription
  app.post("/api/subscriptions/cancel", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const { reason } = req.body;
      
      const subscription = await storage.getActiveSubscriptionByUserId(userId);
      
      if (!subscription) {
        return res.status(404).json({ message: "No active subscription found" });
      }
      
      // Update subscription status to 'canceled'
      const canceledSubscription = await storage.updateSubscriptionStatus(subscription.id, 'canceled');
      
      // Send a notification to the user
      await storage.createNotification({
        userId,
        title: "Subscription Canceled",
        message: `Your ${subscription.plan} subscription has been canceled. You'll still have access until ${new Date(subscription.endDate).toLocaleDateString()}.`,
        type: 'info'
      });
      
      res.json({ 
        success: true, 
        message: "Subscription successfully canceled" 
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Get transaction history
  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const transactions = await storage.getTransactionsByUserId(userId);
      
      res.json(transactions);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Admin Payment Settings API
  
  // Get payment providers settings
  app.get("/api/admin/payment-settings", requireRole(["admin"]), async (req, res) => {
    try {
      const paypalConfig = await storage.getApiConfigurationByProvider("paypal");
      const stripeConfig = await storage.getApiConfigurationByProvider("stripe");
      
      const providers = [];
      
      if (paypalConfig) {
        providers.push({
          id: paypalConfig.id,
          providerName: "paypal",
          isActive: paypalConfig.isActive,
          clientId: paypalConfig.apiKey, // API key stored as clientId for PayPal
          secretKey: "••••••••", // Masked for security
          mode: paypalConfig.settings?.mode || "sandbox",
          supportedCurrencies: paypalConfig.settings?.supportedCurrencies || ["USD", "EUR", "GBP"],
          settings: {
            autoCapture: paypalConfig.settings?.autoCapture !== false,
            allowGuestCheckout: paypalConfig.settings?.allowGuestCheckout !== false
          }
        });
      } else {
        // Default PayPal config if not found
        providers.push({
          id: 0,
          providerName: "paypal",
          isActive: false,
          clientId: "",
          secretKey: "",
          mode: "sandbox",
          supportedCurrencies: ["USD", "EUR", "GBP"],
          settings: {
            autoCapture: true,
            allowGuestCheckout: true
          }
        });
      }
      
      if (stripeConfig) {
        providers.push({
          id: stripeConfig.id,
          providerName: "stripe",
          isActive: stripeConfig.isActive,
          apiKey: "••••••••", // Masked for security
          webhookSecret: "••••••••", // Masked for security
          mode: stripeConfig.settings?.mode || "sandbox",
          supportedCurrencies: stripeConfig.settings?.supportedCurrencies || ["USD", "EUR", "GBP"],
          settings: {
            autoCapture: stripeConfig.settings?.autoCapture !== false,
            statementDescriptor: stripeConfig.settings?.statementDescriptor || "SecureDeployX"
          }
        });
      } else {
        // Default Stripe config if not found
        providers.push({
          id: 0,
          providerName: "stripe",
          isActive: false,
          apiKey: "",
          webhookSecret: "",
          mode: "sandbox",
          supportedCurrencies: ["USD", "EUR", "GBP"],
          settings: {
            autoCapture: true,
            statementDescriptor: "SecureDeployX"
          }
        });
      }
      
      res.json(providers);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Update payment provider settings
  app.put("/api/admin/payment-settings/:provider", requireRole(["admin"]), async (req, res) => {
    try {
      const { provider } = req.params;
      const settings = req.body;
      
      if (provider !== "paypal" && provider !== "stripe") {
        return res.status(400).json({ message: "Invalid provider. Must be either paypal or stripe" });
      }
      
      let existingConfig = await storage.getApiConfigurationByProvider(provider);
      let configId = existingConfig ? existingConfig.id : null;
      
      // Prepare configuration based on provider
      const apiConfig = {
        provider,
        apiKey: provider === "paypal" ? settings.clientId : settings.apiKey,
        baseUrl: null,
        isActive: settings.isActive,
        settings: {
          mode: settings.mode,
          supportedCurrencies: settings.supportedCurrencies,
          ...(provider === "paypal" ? {
            autoCapture: settings.settings.autoCapture,
            allowGuestCheckout: settings.settings.allowGuestCheckout
          } : {
            autoCapture: settings.settings.autoCapture,
            statementDescriptor: settings.settings.statementDescriptor
          })
        }
      };
      
      if (configId) {
        // Update existing config
        await storage.updateApiConfiguration(configId, apiConfig);
      } else {
        // Create new config
        await storage.createApiConfiguration(apiConfig);
      }
      
      res.json({ 
        success: true, 
        message: `${provider.charAt(0).toUpperCase() + provider.slice(1)} settings updated successfully` 
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Test payment provider connection
  app.post("/api/admin/payment-settings/:provider/test", requireRole(["admin"]), async (req, res) => {
    try {
      const { provider } = req.params;
      
      if (provider !== "paypal" && provider !== "stripe") {
        return res.status(400).json({ message: "Invalid provider. Must be either paypal or stripe" });
      }
      
      const apiConfig = await storage.getApiConfigurationByProvider(provider);
      
      if (!apiConfig || !apiConfig.apiKey || !apiConfig.isActive) {
        return res.json({ 
          success: false, 
          message: `${provider.charAt(0).toUpperCase() + provider.slice(1)} is not properly configured` 
        });
      }
      
      // In a real implementation, this would test the connection to the payment provider
      // For now, just return success if the API key is present
      
      res.json({ 
        success: true, 
        message: `Successfully connected to ${provider.charAt(0).toUpperCase() + provider.slice(1)}` 
      });
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Update general payment settings
  app.put("/api/admin/payment-settings/general", requireRole(["admin"]), async (req, res) => {
    try {
      const settings = req.body;
      
      // In a real implementation, this would save the settings to the database
      // For now, just return success
      
      res.json({ 
        success: true, 
        message: "General payment settings updated successfully" 
      });
    } catch (error) {
      handleError(error, res);
    }
  });

  // Get file content
  app.get("/api/server-files/content", requireAuth, async (req, res) => {
    try {
      const requestedPath = req.query.path as string;
      
      if (!requestedPath) {
        return res.status(400).json({ message: "Path parameter is required" });
      }
      
      try {
        // Secure the path to prevent directory traversal attacks
        const fullPath = securePath(WEB_SERVER_ROOT, requestedPath);
        const content = await getFileContent(fullPath);
        res.json({ content });
      } catch (err) {
        return res.status(403).json({ message: "Access denied or file not found" });
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  // Save file content
  app.post("/api/server-files/content", requireAuth, async (req, res) => {
    try {
      const { path: requestedPath, content } = req.body;
      
      if (!requestedPath || typeof content !== "string") {
        return res.status(400).json({ message: "Path and content parameters are required" });
      }
      
      try {
        // Secure the path to prevent directory traversal attacks
        const fullPath = securePath(WEB_SERVER_ROOT, requestedPath);
        await saveFileContent(fullPath, content);
        res.json({ success: true });
      } catch (err) {
        return res.status(403).json({ message: "Access denied or file not found" });
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  // Create file or directory
  app.post("/api/server-files/create", requireAuth, async (req, res) => {
    try {
      const { path: requestedPath, type, content = "" } = req.body;
      
      if (!requestedPath || !type) {
        return res.status(400).json({ message: "Path and type parameters are required" });
      }
      
      if (type !== "file" && type !== "directory") {
        return res.status(400).json({ message: "Type must be either 'file' or 'directory'" });
      }
      
      try {
        // Secure the path to prevent directory traversal attacks
        const fullPath = securePath(WEB_SERVER_ROOT, requestedPath);
        await createFileOrDirectory(fullPath, type, content);
        res.json({ success: true });
      } catch (err) {
        return res.status(403).json({ message: "Access denied or path already exists" });
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  // Delete file or directory
  app.delete("/api/server-files/delete", requireAuth, async (req, res) => {
    try {
      const { path: requestedPath, type } = req.body;
      
      if (!requestedPath || !type) {
        return res.status(400).json({ message: "Path and type parameters are required" });
      }
      
      if (type !== "file" && type !== "directory") {
        return res.status(400).json({ message: "Type must be either 'file' or 'directory'" });
      }
      
      try {
        // Secure the path to prevent directory traversal attacks
        const fullPath = securePath(WEB_SERVER_ROOT, requestedPath);
        await deleteFileOrDirectory(fullPath, type);
        res.json({ success: true });
      } catch (err) {
        return res.status(403).json({ message: "Access denied or path not found" });
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  // HTML Customization API endpoints
  // Get file content or directory listing
  app.get("/api/files", requireRole(["admin"]), async (req, res) => {
    try {
      const requestedPath = req.query.path as string;
      
      if (!requestedPath) {
        return res.status(400).json({ message: "Path parameter is required" });
      }
      
      // For security, only allow accessing files in specific directories
      const allowedPaths = ['client/public', 'client'];
      const isAllowedPath = allowedPaths.some(path => 
        requestedPath === path || requestedPath.startsWith(`${path}/`)
      );
      
      if (!isAllowedPath) {
        return res.status(403).json({ 
          message: "Access denied. Only client/ and client/public/ directories are accessible" 
        });
      }
        
      try {
        // Check if path exists and is a directory or file
        const pathInfo = await pathExists(requestedPath);
        
        if (!pathInfo.exists) {
          return res.status(404).json({ message: "Path not found" });
        }
        
        if (pathInfo.type === 'directory') {
          // Return directory listing
          const files = await getFilesFromPath(requestedPath);
          
          // Just return file names for directories
          const fileNames = files
            .filter(file => file.type === 'file')
            .map(file => file.name);
          
          return res.json({ files: fileNames });
        } else {
          // Return file content
          const content = await getFileContent(requestedPath);
          res.send(content); // Send the raw content, not JSON
        }
      } catch (err) {
        console.error('Error accessing path:', err);
        return res.status(500).json({ message: "Error accessing path" });
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  // Save HTML file content
  app.post("/api/files", requireRole(["admin"]), async (req, res) => {
    try {
      const { path: requestedPath, content } = req.body;
      
      if (!requestedPath || typeof content !== "string") {
        return res.status(400).json({ message: "Path and content parameters are required" });
      }
      
      try {
        // For security, only allow writing to files in specific directories
        const allowedPaths = ['client/public', 'client'];
        const isAllowedPath = allowedPaths.some(path => 
          requestedPath.startsWith(`${path}/`)
        );
        
        if (!isAllowedPath) {
          return res.status(403).json({ 
            message: "Access denied. Only client/ and client/public/ files can be modified" 
          });
        }
        
        await saveFileContent(requestedPath, content);
        res.json({ success: true });
      } catch (err) {
        console.error('Error writing file:', err);
        return res.status(500).json({ message: "Failed to save file" });
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  // ==================== ADVANCED FEATURES API ROUTES ====================

  // 1. AI-POWERED CODE GENERATION
  app.get("/api/code-generations", requireAuth, async (req, res) => {
    try {
      const projectId = req.query.projectId ? Number(req.query.projectId) : undefined;
      const userId = req.session.userId;
      
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const codeGenerations = await storage.getCodeGenerations(projectId, userId);
      res.json(codeGenerations);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/code-generations/:id", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const codeGeneration = await storage.getCodeGeneration(id);
      
      if (!codeGeneration) {
        return res.status(404).json({ message: "Code generation not found" });
      }
      
      // Security check - users should only access their own code generations
      if (codeGeneration.userId !== req.session.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(codeGeneration);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/code-generations", requireAuth, async (req, res) => {
    try {
      // Get userId from session
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const { projectId, prompt, language, type, aiProvider } = req.body;
      
      if (!projectId || !prompt || !language || !type) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Check if project exists and user has access
      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Create the code generation request
      const codeGeneration = await storage.createCodeGeneration({
        userId,
        projectId,
        prompt,
        language,
        type,
        aiProvider: aiProvider || 'gemini'
        // result, createdAt, usedInProject will be handled by the database defaults
      });
      
      // Return the created entry immediately, then process the AI request
      res.status(201).json(codeGeneration);
      
      // Process the code generation asynchronously
      try {
        // Import the AI code service
        const { generateCode } = require('./api/aiCodeService');
        
        // Get API key for the requested provider
        let apiKey: string | undefined;
        
        // Use environment variable for Gemini, if available
        if (aiProvider === 'gemini' && process.env.GEMINI_API_KEY) {
          apiKey = process.env.GEMINI_API_KEY;
        } 
        // For OpenAI, check environment variable
        else if (aiProvider === 'openai' && process.env.OPENAI_API_KEY) {
          apiKey = process.env.OPENAI_API_KEY;
        }
        // Otherwise, try to get from database
        else if (aiProvider !== 'mock') {
          const apiConfig = await storage.getApiConfigurationByProvider(aiProvider);
          if (apiConfig?.apiKey) {
            apiKey = apiConfig.apiKey;
          }
        }
        
        // Generate the code
        const result = await generateCode(prompt, language, type, aiProvider, apiKey);
        
        // Update the code generation with the result
        if (result && result.generatedCode) {
          await storage.updateCodeGenerationResult(codeGeneration.id, result.generatedCode);
          
          // Also store any additional metadata
          if (result.explanation || result.suggestedUsage || result.dependencies) {
            const metadata = {
              explanation: result.explanation,
              suggestedUsage: result.suggestedUsage,
              dependencies: result.dependencies,
              importStatements: result.importStatements
            };
            
            // Update metadata if storage supports it
            if (typeof storage.updateCodeGenerationMetadata === 'function') {
              await storage.updateCodeGenerationMetadata(codeGeneration.id, metadata);
            }
          }
          
          log(`Successfully generated code for request #${codeGeneration.id}`, 'code-generation');
        }
      } catch (aiError: any) {
        log(`Error generating code: ${aiError.message}`, 'code-generation');
        // Don't return this error to the client as we've already sent a response
      }
    } catch (error) {
      handleError(error, res);
    }
  });

  app.patch("/api/code-generations/:id/rate", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const { rating } = req.body;
      const userId = req.session.userId;
      
      if (typeof rating !== 'number' || rating < 1 || rating > 5) {
        return res.status(400).json({ message: "Rating must be a number between 1 and 5" });
      }
      
      const codeGeneration = await storage.getCodeGeneration(id);
      if (!codeGeneration) {
        return res.status(404).json({ message: "Code generation not found" });
      }
      
      // Security check - users should only rate their own code generations
      if (codeGeneration.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updated = await storage.updateCodeGenerationRating(id, rating);
      res.json(updated);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.patch("/api/code-generations/:id/usage", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const { used } = req.body;
      const userId = req.session.userId;
      
      if (typeof used !== 'boolean') {
        return res.status(400).json({ message: "Used parameter must be a boolean" });
      }
      
      const codeGeneration = await storage.getCodeGeneration(id);
      if (!codeGeneration) {
        return res.status(404).json({ message: "Code generation not found" });
      }
      
      // Security check - users should only update their own code generations
      if (codeGeneration.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updated = await storage.updateCodeGenerationUsage(id, used);
      res.json(updated);
    } catch (error) {
      handleError(error, res);
    }
  });

  // 2. REAL-TIME COLLABORATION SESSIONS
  app.get("/api/collaboration-sessions", requireAuth, async (req, res) => {
    try {
      const projectId = req.query.projectId ? Number(req.query.projectId) : undefined;
      const sessions = await storage.getCollaborationSessions(projectId);
      res.json(sessions);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/collaboration-sessions/:id", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const session = await storage.getCollaborationSession(id);
      
      if (!session) {
        return res.status(404).json({ message: "Collaboration session not found" });
      }
      
      res.json(session);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/collaboration-sessions", requireAuth, async (req, res) => {
    try {
      const { projectId, title, description } = req.body;
      
      if (!projectId || !title) {
        return res.status(400).json({ message: "Project ID and title are required" });
      }
      
      // Check if project exists
      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const session = await storage.createCollaborationSession({
        projectId,
        title,
        description: description || "",
        startTime: new Date(),
        endTime: null,
        status: "active",
        hostUserId: req.user!.id
      });
      
      // Add the creator as the first participant (host)
      await storage.createCollaborationParticipant({
        sessionId: session.id,
        userId: req.user!.id,
        joinTime: new Date(),
        leaveTime: null,
        role: "host",
        active: true
      });
      
      res.status(201).json(session);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.patch("/api/collaboration-sessions/:id/status", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const { status } = req.body;
      
      if (!status || !["active", "paused", "completed"].includes(status)) {
        return res.status(400).json({ message: "Valid status is required (active, paused, or completed)" });
      }
      
      const session = await storage.getCollaborationSession(id);
      if (!session) {
        return res.status(404).json({ message: "Collaboration session not found" });
      }
      
      // Only the host can change the session status
      if (session.hostUserId !== req.user?.id) {
        return res.status(403).json({ message: "Only the host can update the session status" });
      }
      
      let updatedSession;
      if (status === "completed") {
        updatedSession = await storage.endCollaborationSession(id);
      } else {
        updatedSession = await storage.updateCollaborationSessionStatus(id, status);
      }
      
      res.json(updatedSession);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/collaboration-sessions/:sessionId/participants", requireAuth, async (req, res) => {
    try {
      const sessionId = Number(req.params.sessionId);
      
      // Verify session exists
      const session = await storage.getCollaborationSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Collaboration session not found" });
      }
      
      const participants = await storage.getCollaborationParticipants(sessionId);
      res.json(participants);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/collaboration-sessions/:sessionId/participants", requireAuth, async (req, res) => {
    try {
      const sessionId = Number(req.params.sessionId);
      const { userId, role } = req.body;
      
      if (!userId || !role) {
        return res.status(400).json({ message: "User ID and role are required" });
      }
      
      // Verify session exists
      const session = await storage.getCollaborationSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Collaboration session not found" });
      }
      
      // Only the host can add participants
      if (session.hostUserId !== req.user?.id) {
        return res.status(403).json({ message: "Only the host can add participants" });
      }
      
      // Verify user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if user is already a participant
      const participants = await storage.getCollaborationParticipants(sessionId);
      const existingParticipant = participants.find(p => p.userId === userId && p.active);
      
      if (existingParticipant) {
        return res.status(400).json({ message: "User is already a participant in this session" });
      }
      
      const participant = await storage.createCollaborationParticipant({
        sessionId,
        userId,
        joinTime: new Date(),
        leaveTime: null,
        role,
        active: true
      });
      
      res.status(201).json(participant);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.delete("/api/collaboration-sessions/:sessionId/participants/:id", requireAuth, async (req, res) => {
    try {
      const sessionId = Number(req.params.sessionId);
      const participantId = Number(req.params.id);
      
      // Verify session exists
      const session = await storage.getCollaborationSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Collaboration session not found" });
      }
      
      // Only the host can remove participants
      if (session.hostUserId !== req.user?.id) {
        return res.status(403).json({ message: "Only the host can remove participants" });
      }
      
      const success = await storage.removeCollaborationParticipant(participantId);
      
      if (!success) {
        return res.status(404).json({ message: "Participant not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/collaboration-sessions/:sessionId/messages", requireAuth, async (req, res) => {
    try {
      const sessionId = Number(req.params.sessionId);
      
      // Verify session exists
      const session = await storage.getCollaborationSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Collaboration session not found" });
      }
      
      // Verify user is a participant
      const participants = await storage.getCollaborationParticipants(sessionId);
      const isParticipant = participants.some(p => p.userId === req.user?.id && p.active);
      
      if (!isParticipant && session.hostUserId !== req.user?.id) {
        return res.status(403).json({ message: "Access denied - you are not a participant in this session" });
      }
      
      const messages = await storage.getCollaborationMessages(sessionId);
      res.json(messages);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/collaboration-sessions/:sessionId/messages", requireAuth, async (req, res) => {
    try {
      const sessionId = Number(req.params.sessionId);
      const { content, type } = req.body;
      
      if (!content) {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      // Verify session exists and is active
      const session = await storage.getCollaborationSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Collaboration session not found" });
      }
      
      if (session.status !== "active") {
        return res.status(400).json({ message: "Cannot send messages to an inactive session" });
      }
      
      // Verify user is a participant
      const participants = await storage.getCollaborationParticipants(sessionId);
      const isParticipant = participants.some(p => p.userId === req.user?.id && p.active);
      
      if (!isParticipant && session.hostUserId !== req.user?.id) {
        return res.status(403).json({ message: "Access denied - you are not a participant in this session" });
      }
      
      const message = await storage.createCollaborationMessage({
        sessionId,
        userId: req.user!.id,
        content,
        type: type || "text",
        timestamp: new Date()
      });
      
      res.status(201).json(message);
    } catch (error) {
      handleError(error, res);
    }
  });

  // 3. DEPLOYMENT ROLLBACK & VERSION CONTROL
  app.get("/api/deployments/:deploymentId/versions", requireAuth, async (req, res) => {
    try {
      const deploymentId = Number(req.params.deploymentId);
      
      // Verify deployment exists
      const deployment = await storage.getDeployment(deploymentId);
      if (!deployment) {
        return res.status(404).json({ message: "Deployment not found" });
      }
      
      // Get project to check permissions
      const project = await storage.getProject(deployment.projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const versions = await storage.getDeploymentVersions(deploymentId);
      res.json(versions);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/deployments/:deploymentId/versions", requireAuth, async (req, res) => {
    try {
      const deploymentId = Number(req.params.deploymentId);
      const { version, notes, artifacts } = req.body;
      
      if (!version) {
        return res.status(400).json({ message: "Version is required" });
      }
      
      // Verify deployment exists
      const deployment = await storage.getDeployment(deploymentId);
      if (!deployment) {
        return res.status(404).json({ message: "Deployment not found" });
      }
      
      // Get project to check permissions
      const project = await storage.getProject(deployment.projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const deploymentVersion = await storage.createDeploymentVersion({
        deploymentId,
        version,
        notes: notes || "",
        timestamp: new Date(),
        status: "active",
        artifacts: artifacts || {}
      });
      
      res.status(201).json(deploymentVersion);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/deployments/:deploymentId/rollbacks", requireAuth, async (req, res) => {
    try {
      const deploymentId = Number(req.params.deploymentId);
      
      // Verify deployment exists
      const deployment = await storage.getDeployment(deploymentId);
      if (!deployment) {
        return res.status(404).json({ message: "Deployment not found" });
      }
      
      // Get project to check permissions
      const project = await storage.getProject(deployment.projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const rollbacks = await storage.getRollbacks(deploymentId);
      res.json(rollbacks);
    } catch (error) {
      handleError(error, res);
    }
  });

  app.post("/api/deployments/:deploymentId/rollbacks", requireAuth, async (req, res) => {
    try {
      const deploymentId = Number(req.params.deploymentId);
      const { fromVersionId, toVersionId, reason } = req.body;
      
      if (!fromVersionId || !toVersionId) {
        return res.status(400).json({ message: "From and to version IDs are required" });
      }
      
      // Verify deployment exists
      const deployment = await storage.getDeployment(deploymentId);
      if (!deployment) {
        return res.status(404).json({ message: "Deployment not found" });
      }
      
      // Verify the versions exist
      const fromVersion = await storage.getDeploymentVersion(fromVersionId);
      const toVersion = await storage.getDeploymentVersion(toVersionId);
      
      if (!fromVersion || !toVersion) {
        return res.status(404).json({ message: "One or both versions not found" });
      }
      
      if (fromVersion.deploymentId !== deploymentId || toVersion.deploymentId !== deploymentId) {
        return res.status(400).json({ message: "Versions must belong to the specified deployment" });
      }
      
      // Create rollback record
      const rollback = await storage.createRollback({
        deploymentId,
        fromVersionId,
        toVersionId,
        timestamp: new Date(),
        status: "in_progress",
        reason: reason || "",
        logs: "",
        initiatedBy: req.user!.id
      });
      
      // In a real implementation, you'd trigger the actual rollback process here
      
      res.status(201).json(rollback);
      
      // After this point, you'd have some mechanism to update the rollback status
      // once the actual rollback process completes
    } catch (error) {
      handleError(error, res);
    }
  });

  app.get("/api/rollbacks/:id", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const rollback = await storage.getRollback(id);
      
      if (!rollback) {
        return res.status(404).json({ message: "Rollback not found" });
      }
      
      res.json(rollback);
    } catch (error) {
      handleError(error, res);
    }
  });

  // DEPLOYMENT PREVIEW API ENDPOINTS
  app.post("/api/code-preview", requireAuth, async (req, res) => {
    try {
      const { code, language, deploymentId, type } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ message: "Code and language are required" });
      }
      
      // Import the deployment preview service
      const { createCodePreview } = require('./api/deploymentPreview');
      
      // Generate a deployment ID if not provided
      const previewDeploymentId = deploymentId || Math.floor(Math.random() * 100000);
      const userId = req.session.userId || 0;
      
      // Create the preview
      const preview = await createCodePreview(
        code,
        language,
        previewDeploymentId,
        userId,
        type || 'code'
      );
      
      res.json(preview);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // Serve preview files
  app.get("/api/preview/:previewDirName/:filename", async (req, res) => {
    try {
      const { previewDirName, filename } = req.params;
      
      // Import path module
      const path = require('path');
      const fs = require('fs');
      
      // Construct the path to the preview file
      const previewDir = path.join(__dirname, '../server_files/preview_deployments', previewDirName);
      const filePath = path.join(previewDir, filename);
      
      // Check if file exists
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "Preview file not found" });
      }
      
      // Determine content type based on file extension
      let contentType = 'text/plain';
      
      if (filename.endsWith('.html')) {
        contentType = 'text/html';
      } else if (filename.endsWith('.css')) {
        contentType = 'text/css';
      } else if (filename.endsWith('.js')) {
        contentType = 'application/javascript';
      } else if (filename.endsWith('.json')) {
        contentType = 'application/json';
      } else if (filename.endsWith('.svg')) {
        contentType = 'image/svg+xml';
      }
      
      res.setHeader('Content-Type', contentType);
      res.sendFile(filePath);
    } catch (error) {
      handleError(error, res);
    }
  });
  
  // New AI code analysis endpoint - works with and without authentication
  app.post("/api/ai/analyze-code", async (req, res) => {
    try {
      const { code, provider = "gemini", options = {} } = req.body;
      
      if (!code) {
        return res.status(400).json({ message: "Code is required" });
      }
      
      // Check if user is authenticated
      const isAuthenticated = req.session && req.session.userId;
      
      // If user is not authenticated, return 401 - the client will handle this and use mock data
      if (!isAuthenticated) {
        console.log("User not authenticated for code analysis, returning 401");
        return res.status(401).json({ 
          message: "Authentication required. Please log in to use this feature." 
        });
      }
      
      if (provider === "gemini") {
        // Use the Gemini API for code analysis
        const result = await analyzeCodeWithGemini(code, options);
        return res.json(result);
      } else if (provider === "mock") {
        // Use mock analysis for testing
        const result = generateMockAnalysis(code, options);
        return res.json(result);
      } else {
        return res.status(400).json({ message: `Unsupported provider: ${provider}` });
      }
    } catch (error) {
      console.error("Error analyzing code:", error);
      handleError(error, res);
    }
  });

  // Tutorial API endpoints
  app.get("/api/tutorials", async (req, res) => {
    try {
      const tutorials = await storage.getTutorials();
      res.json(tutorials);
    } catch (error) {
      console.error("Error getting tutorials:", error);
      handleError(error, res);
    }
  });

  app.get("/api/tutorials/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tutorial = await storage.getTutorialById(id);
      
      if (!tutorial) {
        return res.status(404).json({ message: "Tutorial not found" });
      }
      
      res.json(tutorial);
    } catch (error) {
      console.error(`Error getting tutorial ${req.params.id}:`, error);
      handleError(error, res);
    }
  });

  app.get("/api/tutorials/:id/steps", async (req, res) => {
    try {
      const tutorialId = parseInt(req.params.id);
      const tutorial = await storage.getTutorialById(tutorialId);
      
      if (!tutorial) {
        return res.status(404).json({ message: "Tutorial not found" });
      }
      
      const steps = await storage.getTutorialSteps(tutorialId);
      res.json(steps);
    } catch (error) {
      console.error(`Error getting steps for tutorial ${req.params.id}:`, error);
      handleError(error, res);
    }
  });

  app.get("/api/tutorial-steps/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const step = await storage.getTutorialStepById(id);
      
      if (!step) {
        return res.status(404).json({ message: "Tutorial step not found" });
      }
      
      res.json(step);
    } catch (error) {
      console.error(`Error getting tutorial step ${req.params.id}:`, error);
      handleError(error, res);
    }
  });

  // User tutorial progress endpoints (requires authentication)
  app.get("/api/user/tutorial-progress", async (req, res) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const tutorialId = req.query.tutorialId ? parseInt(req.query.tutorialId as string) : undefined;
      const progress = await storage.getUserTutorialProgress(userId, tutorialId);
      res.json(progress);
    } catch (error) {
      console.error("Error getting user tutorial progress:", error);
      handleError(error, res);
    }
  });

  app.post("/api/user/tutorial-progress", async (req, res) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const { tutorialId } = req.body;
      if (!tutorialId) {
        return res.status(400).json({ message: "tutorialId is required" });
      }
      
      // Check if tutorial exists
      const tutorial = await storage.getTutorialById(parseInt(tutorialId));
      if (!tutorial) {
        return res.status(404).json({ message: "Tutorial not found" });
      }
      
      // Check if progress already exists
      const existingProgress = await storage.getUserTutorialProgress(userId, parseInt(tutorialId));
      if (existingProgress && existingProgress.length > 0) {
        return res.json(existingProgress[0]);
      }
      
      // Create new progress
      const progress = await storage.createUserTutorialProgress({
        userId,
        tutorialId: parseInt(tutorialId)
      });
      
      res.status(201).json(progress);
    } catch (error) {
      console.error("Error creating user tutorial progress:", error);
      handleError(error, res);
    }
  });

  app.put("/api/user/tutorial-progress/:id/current-step", async (req, res) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      const { currentStep } = req.body;
      
      if (currentStep === undefined || currentStep < 1) {
        return res.status(400).json({ message: "Valid currentStep is required" });
      }
      
      // Check if progress exists
      const progress = await storage.getUserTutorialProgressById(id);
      if (!progress) {
        return res.status(404).json({ message: "Progress not found" });
      }
      
      // Check if user owns this progress
      if (progress.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedProgress = await storage.updateUserTutorialCurrentStep(id, currentStep);
      res.json(updatedProgress);
    } catch (error) {
      console.error(`Error updating current step for progress ${req.params.id}:`, error);
      handleError(error, res);
    }
  });

  app.post("/api/user/step-submissions", async (req, res) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const { progressId, stepId, submittedCode, output, hintsUsed, attemptNumber } = req.body;
      
      if (!progressId || !stepId || !submittedCode) {
        return res.status(400).json({ message: "progressId, stepId, and submittedCode are required" });
      }
      
      // Check if progress exists and belongs to user
      const progress = await storage.getUserTutorialProgressById(parseInt(progressId));
      if (!progress) {
        return res.status(404).json({ message: "Progress not found" });
      }
      
      if (progress.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Check if step exists
      const step = await storage.getTutorialStepById(parseInt(stepId));
      if (!step) {
        return res.status(404).json({ message: "Step not found" });
      }
      
      // Create submission
      const submission = await storage.createUserStepSubmission({
        userId,
        progressId: parseInt(progressId),
        stepId: parseInt(stepId),
        tutorialId: progress.tutorialId,
        submittedCode,
        output: output || null,
        hintsUsed: hintsUsed || 0,
        attemptNumber: attemptNumber || 1
      });
      
      res.status(201).json(submission);
    } catch (error) {
      console.error("Error creating step submission:", error);
      handleError(error, res);
    }
  });

  app.get("/api/user/step-submissions/:progressId", async (req, res) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const progressId = parseInt(req.params.progressId);
      
      // Check if progress exists and belongs to user
      const progress = await storage.getUserTutorialProgressById(progressId);
      if (!progress) {
        return res.status(404).json({ message: "Progress not found" });
      }
      
      if (progress.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const submissions = await storage.getUserStepSubmissions(progressId);
      res.json(submissions);
    } catch (error) {
      console.error(`Error getting step submissions for progress ${req.params.progressId}:`, error);
      handleError(error, res);
    }
  });

  app.put("/api/user/step-submissions/:id/feedback", async (req, res) => {
    try {
      // Check if user is authenticated and is an admin
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // In a real application, we would check if the user is an admin here
      // For now, we'll allow any authenticated user to provide feedback (for demo purposes)
      
      const id = parseInt(req.params.id);
      const { isCorrect, feedback } = req.body;
      
      if (isCorrect === undefined || !feedback) {
        return res.status(400).json({ message: "isCorrect and feedback are required" });
      }
      
      // Check if submission exists
      const submission = await storage.getUserStepSubmission(id);
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      
      const updatedSubmission = await storage.updateUserStepSubmissionFeedback(
        id, 
        Boolean(isCorrect), 
        feedback
      );
      
      res.json(updatedSubmission);
    } catch (error) {
      console.error(`Error updating feedback for submission ${req.params.id}:`, error);
      handleError(error, res);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
