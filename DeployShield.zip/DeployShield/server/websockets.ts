import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import url from 'url';
import { v4 as uuidv4 } from 'uuid';
import { storage } from './storage';

// Type definitions for our WebSocket messages
interface WebSocketMessage {
  type: string;
  payload: any;
  sessionId: string;
  userId?: number;
  timestamp: number;
}

interface CollaborativeClient {
  id: string;
  ws: WebSocket;
  userId?: number;
  username?: string;
  sessionId: string;
  isAlive: boolean;
  lastActivity: number;
}

// Map to store active sessions and their connected clients
const sessions = new Map<string, Set<CollaborativeClient>>();

// Setup the WebSocket server
export function setupWebSocketServer(server: Server) {
  const wss = new WebSocketServer({ server, path: '/ws/collaboration' });
  
  console.log('WebSocket server initialized on path: /ws/collaboration');

  // Ping clients every 30 seconds to keep connections alive
  const pingInterval = setInterval(() => {
    wss.clients.forEach((ws: any) => {
      const client = ws as CollaborativeClient;
      if (client.isAlive === false) {
        // Client didn't respond to ping, terminate connection
        return ws.terminate();
      }
      
      // Set isAlive to false, it will be reset to true when pong is received
      client.isAlive = false;
      ws.ping();
      
      // Check for inactive clients (10 minutes of inactivity)
      const tenMinutesAgo = Date.now() - 10 * 60 * 1000;
      if (client.lastActivity < tenMinutesAgo) {
        console.log(`Terminating inactive client: ${client.id}`);
        return ws.terminate();
      }
    });
  }, 30000);
  
  wss.on('close', () => {
    clearInterval(pingInterval);
  });

  wss.on('connection', (ws: WebSocket, req) => {
    // Parse URL to get sessionId
    const parsedUrl = url.parse(req.url || '', true);
    const sessionId = parsedUrl.query.sessionId as string;
    const userId = parseInt(parsedUrl.query.userId as string) || undefined;
    const username = parsedUrl.query.username as string || 'Anonymous';
    
    if (!sessionId) {
      console.error('WebSocket connection attempt without sessionId');
      ws.close(1008, 'Session ID is required');
      return;
    }

    // Create client object
    const client: CollaborativeClient = {
      id: uuidv4(),
      ws,
      userId,
      username,
      sessionId,
      isAlive: true,
      lastActivity: Date.now()
    };
    
    // Add client to the session
    if (!sessions.has(sessionId)) {
      sessions.set(sessionId, new Set());
    }
    sessions.get(sessionId)?.add(client);
    
    // Send welcome message
    const welcomeMsg: WebSocketMessage = {
      type: 'system',
      payload: {
        message: `Welcome to collaboration session ${sessionId}`,
        activeUsers: Array.from(sessions.get(sessionId) || []).map(c => ({
          id: c.id,
          userId: c.userId,
          username: c.username
        }))
      },
      sessionId,
      timestamp: Date.now()
    };
    ws.send(JSON.stringify(welcomeMsg));
    
    // Broadcast join message to other clients in the session
    broadcastToSession(sessionId, {
      type: 'user_joined',
      payload: {
        userId: client.userId,
        username: client.username,
        clientId: client.id
      },
      sessionId,
      timestamp: Date.now()
    }, client.id);
    
    // Handle messages
    ws.on('message', async (message: string) => {
      try {
        client.lastActivity = Date.now();
        client.isAlive = true;
        
        const parsedMessage: WebSocketMessage = JSON.parse(message);
        
        if (!parsedMessage.sessionId || parsedMessage.sessionId !== sessionId) {
          console.error('Invalid session ID in message');
          return;
        }
        
        // Add server timestamp
        parsedMessage.timestamp = Date.now();
        
        // Handle different message types
        switch (parsedMessage.type) {
          case 'code_update':
            // Broadcast code update to all other clients in the session
            broadcastToSession(sessionId, parsedMessage, client.id);
            
            // Optionally save code to database
            if (parsedMessage.payload?.code && client.userId) {
              try {
                // Save the code to your database here if needed
                // This is a placeholder for actual database operations
                console.log(`Saving code update from user ${client.userId} in session ${sessionId}`);
              } catch (error) {
                console.error('Error saving code update:', error);
              }
            }
            break;
            
          case 'cursor_update':
            // Broadcast cursor position to all other clients
            broadcastToSession(sessionId, parsedMessage, client.id);
            break;
            
          case 'chat_message':
            // Save chat message to database and broadcast
            if (parsedMessage.payload?.message && client.userId) {
              try {
                await storage.createCollaborationMessage({
                  sessionId: parseInt(sessionId),
                  userId: client.userId,
                  message: parsedMessage.payload.message,
                  type: 'chat',
                  metadata: { clientId: client.id }
                });
              } catch (error) {
                console.error('Error saving chat message:', error);
              }
            }
            
            // Add sender info to the message payload
            parsedMessage.payload.sender = {
              id: client.id,
              userId: client.userId,
              username: client.username
            };
            
            // Broadcast to all clients including sender
            broadcastToSession(sessionId, parsedMessage);
            break;
            
          case 'ping':
            // Respond to ping with pong
            ws.send(JSON.stringify({
              type: 'pong',
              payload: { time: Date.now() },
              sessionId,
              timestamp: Date.now()
            }));
            break;
            
          default:
            console.log(`Received unknown message type: ${parsedMessage.type}`);
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    // Handle WebSocket errors
    ws.on('error', (error) => {
      console.error(`WebSocket error for client ${client.id}:`, error);
    });
    
    // Handle pong responses (keep-alive)
    ws.on('pong', () => {
      client.isAlive = true;
      client.lastActivity = Date.now();
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      // Remove client from the session
      sessions.get(sessionId)?.delete(client);
      
      // If session is empty, remove it
      if (sessions.get(sessionId)?.size === 0) {
        sessions.delete(sessionId);
      }
      
      // Broadcast user left message
      broadcastToSession(sessionId, {
        type: 'user_left',
        payload: {
          userId: client.userId,
          username: client.username,
          clientId: client.id
        },
        sessionId,
        timestamp: Date.now()
      });
      
      console.log(`Client ${client.id} disconnected from session ${sessionId}`);
    });
    
    console.log(`Client ${client.id} connected to session ${sessionId}`);
  });
  
  return wss;
}

// Helper function to broadcast message to all clients in a session
function broadcastToSession(
  sessionId: string, 
  message: WebSocketMessage, 
  excludeClientId?: string
) {
  const sessionClients = sessions.get(sessionId);
  if (!sessionClients) return;
  
  const messageStr = JSON.stringify(message);
  
  sessionClients.forEach(client => {
    if (excludeClientId && client.id === excludeClientId) return;
    
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(messageStr);
    }
  });
}

// Get active sessions info for monitoring
export function getActiveSessionsInfo() {
  const info = Array.from(sessions.entries()).map(([sessionId, clients]) => ({
    sessionId,
    clientCount: clients.size,
    clients: Array.from(clients).map(c => ({
      id: c.id,
      userId: c.userId,
      username: c.username,
      lastActivity: new Date(c.lastActivity).toISOString(),
    }))
  }));
  
  return {
    totalSessions: sessions.size,
    totalClients: Array.from(sessions.values()).reduce((acc, clients) => acc + clients.size, 0),
    sessions: info
  };
}