import { watch } from 'chokidar';
import { spawn, ChildProcess } from 'child_process';
import fs from 'fs';
import { log } from './vite';

interface CompilerConfig {
  sourceDir: string;
  outputDir: string;
  includePattern: RegExp;
  excludePattern?: RegExp;
  compiler: 'typescript' | 'sass' | 'babel';
}

interface CompilerProcess {
  process: ChildProcess | null;
  isRunning: boolean;
}

type CompileResult = {
  success: boolean;
  output?: string;
  error?: string;
};

/**
 * Auto compiler service that watches source files and compiles them on change
 */
export class AutoCompiler {
  private watchers: any[] = [];
  private compilerProcesses: Map<string, CompilerProcess> = new Map();
  private configs: CompilerConfig[] = [];
  private isInitialized: boolean = false;
  private compileQueue: Array<{filePath: string, config: CompilerConfig}> = [];
  private isProcessingQueue: boolean = false;
  private concurrentCompilations: number = 0;
  private maxConcurrentCompilations: number = 2; // Limit concurrent compilations

  constructor() {
    // Default configurations - be more conservative
    this.configs = [
      {
        sourceDir: './client/src',
        outputDir: './dist',
        includePattern: /\.(ts|tsx)$/,
        excludePattern: /node_modules|dist|\.git/,
        compiler: 'typescript'
      },
      // Only enable SASS if really needed
      // {
      //   sourceDir: './client/src/styles',
      //   outputDir: './dist/css',
      //   includePattern: /\.scss$/,
      //   compiler: 'sass'
      // }
    ];
  }

  /**
   * Initialize the compiler service
   */
  public async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    for (const config of this.configs) {
      await this.setupWatcher(config);
    }

    // Start the queue processor
    this.processQueue();

    this.isInitialized = true;
    log('Auto compiler initialized', 'compiler');
  }

  /**
   * Start watching for file changes
   */
  private async setupWatcher(config: CompilerConfig): Promise<void> {
    // Ensure output directory exists
    if (!fs.existsSync(config.outputDir)) {
      fs.mkdirSync(config.outputDir, { recursive: true });
    }

    // Setup watcher for this config - use a more conservative approach
    const watcher = watch(config.sourceDir, {
      ignored: config.excludePattern,
      persistent: true,
      ignoreInitial: true, // Don't compile on startup
      awaitWriteFinish: {
        stabilityThreshold: 1000, // Wait until file is stable for 1s
        pollInterval: 100
      }
    });

    // Add event listeners - only track changes, not additions
    watcher.on('change', (filePath) => this.handleFileChange(filePath, config));

    this.watchers.push(watcher);
    log(`Watching ${config.sourceDir} for changes (${config.compiler})`, 'compiler');
  }

  /**
   * Handle file changes by adding to the queue
   */
  private async handleFileChange(filePath: string, config: CompilerConfig): Promise<void> {
    // Check if the file matches our include pattern
    if (!config.includePattern.test(filePath)) {
      return;
    }

    // Add to queue instead of compiling immediately
    this.compileQueue.push({filePath, config});
    log(`File queued for compilation: ${filePath}`, 'compiler');
  }

  /**
   * Process the compilation queue with rate limiting
   */
  private async processQueue(): Promise<void> {
    if (this.isProcessingQueue) return;
    
    this.isProcessingQueue = true;
    
    while (this.compileQueue.length > 0 && this.concurrentCompilations < this.maxConcurrentCompilations) {
      const { filePath, config } = this.compileQueue.shift()!;
      
      // Start compilation without awaiting
      this.concurrentCompilations++;
      this.compileFile(filePath, config).finally(() => {
        this.concurrentCompilations--;
      });
      
      // Small delay between starting compilations
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    this.isProcessingQueue = false;
    
    // If there are still items in the queue, schedule another run
    if (this.compileQueue.length > 0) {
      setTimeout(() => this.processQueue(), 1000);
    }
  }

  /**
   * Compile a single file
   */
  private async compileFile(filePath: string, config: CompilerConfig): Promise<CompileResult> {
    const compilerKey = `${config.compiler}-${filePath}`;
    
    // Check if a compilation is already running for this file
    const existingProcess = this.compilerProcesses.get(compilerKey);
    if (existingProcess && existingProcess.isRunning) {
      log(`Compilation already in progress for ${filePath}`, 'compiler');
      return { success: false, error: 'Compilation already in progress' };
    }

    // Setup the compiler process
    let cmd: string;
    let args: string[];

    switch (config.compiler) {
      case 'typescript':
        cmd = 'npx';
        args = ['tsc', filePath, '--outDir', config.outputDir];
        break;
      case 'sass':
        cmd = 'npx';
        args = ['node-sass', filePath, '--output', config.outputDir];
        break;
      default:
        return { success: false, error: `Unsupported compiler: ${config.compiler}` };
    }

    // Track this process
    this.compilerProcesses.set(compilerKey, { process: null, isRunning: true });

    return new Promise((resolve) => {
      log(`Compiling ${filePath} with ${config.compiler}`, 'compiler');
      
      const process = spawn(cmd, args);
      const compilerProcess = this.compilerProcesses.get(compilerKey);
      if (compilerProcess) {
        compilerProcess.process = process;
      }

      let stdoutData = '';
      let stderrData = '';

      process.stdout.on('data', (data) => {
        stdoutData += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderrData += data.toString();
      });

      process.on('close', (code) => {
        const success = code === 0;
        
        if (success) {
          log(`Successfully compiled ${filePath}`, 'compiler');
        } else {
          log(`Failed to compile ${filePath}: ${stderrData}`, 'compiler');
        }

        // Mark this process as completed
        if (compilerProcess) {
          compilerProcess.isRunning = false;
          compilerProcess.process = null;
        }

        // Process the next item in the queue
        this.processQueue();

        resolve({
          success,
          output: stdoutData,
          error: stderrData
        });
      });
    });
  }

  /**
   * Add a new compiler configuration
   */
  public addConfig(config: CompilerConfig): void {
    this.configs.push(config);
    
    if (this.isInitialized) {
      this.setupWatcher(config);
    }
  }

  /**
   * Stop all watchers
   */
  public dispose(): void {
    for (const watcher of this.watchers) {
      watcher.close();
    }
    
    // Kill any running compiler processes
    this.compilerProcesses.forEach(compilerProcess => {
      if (compilerProcess.process) {
        compilerProcess.process.kill();
      }
    });

    this.watchers = [];
    this.compilerProcesses.clear();
    this.isInitialized = false;
    
    log('Auto compiler stopped', 'compiler');
  }
}

export const autoCompiler = new AutoCompiler();

// Expose compiler API
export const getAutoCompiler = () => autoCompiler;