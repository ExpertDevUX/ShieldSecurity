import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, BorderStyle, WidthType } from 'docx';
import { saveAs } from './utils';

// Add autotable to jsPDF
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

/**
 * Generate a PDF report from security/code analysis data
 */
export async function exportToPdf(
  type: 'security' | 'code-analysis' | 'seo' | 'pen-test' | 'traffic-boost' | 'page-speed' | 'url-scan',
  data: Record<string, any>,
  filename: string = `${type}-report.pdf`
): Promise<void> {
  // Create title from type
  const title = type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') + ' Report';
  // Create new PDF document
  const doc = new jsPDF();
  
  // Add title
  doc.setFontSize(20);
  doc.text(title, 14, 22);
  
  // Add date
  doc.setFontSize(10);
  doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 30);
  
  // Add horizontal line
  doc.setLineWidth(0.5);
  doc.line(14, 35, 196, 35);
  
  let yPosition = 45;
  
  // Generate different reports based on type
  switch (type) {
    case 'security':
      generateSecurityPdf(doc, data, yPosition);
      break;
    case 'code-analysis':
      generateCodeAnalysisPdf(doc, data, yPosition);
      break;
    case 'seo':
      generateSEOPdf(doc, data, yPosition);
      break;
    case 'pen-test':
      generatePenTestPdf(doc, data, yPosition);
      break;
  }
  
  // Save the PDF file
  doc.save(`${title.toLowerCase().replace(/\s+/g, '-')}-report.pdf`);
}

function generateSecurityPdf(doc: jsPDF, data: any, yPosition: number): void {
  // Add summary section
  doc.setFontSize(16);
  doc.text('Security Scan Summary', 14, yPosition);
  
  yPosition += 10;
  doc.setFontSize(12);
  
  // Add severity counts
  const tableData = [
    ['High Severity', data.highSeverity || 0],
    ['Medium Severity', data.mediumSeverity || 0],
    ['Low Severity', data.lowSeverity || 0],
    ['Total Vulnerabilities', (data.highSeverity || 0) + (data.mediumSeverity || 0) + (data.lowSeverity || 0)]
  ];
  
  doc.autoTable({
    startY: yPosition,
    head: [['Severity', 'Count']],
    body: tableData,
    theme: 'striped',
    headStyles: { fillColor: [66, 135, 245] }
  });
  
  yPosition = (doc as any).lastAutoTable.finalY + 15;
  
  // Add vulnerabilities table if available
  if (data.vulnerabilities && data.vulnerabilities.length > 0) {
    doc.setFontSize(16);
    doc.text('Vulnerabilities', 14, yPosition);
    
    yPosition += 10;
    
    const vulnRows = data.vulnerabilities.map((v: any) => [
      v.severity,
      v.description,
      v.fixed ? 'Yes' : 'No'
    ]);
    
    doc.autoTable({
      startY: yPosition,
      head: [['Severity', 'Description', 'Fixed']],
      body: vulnRows,
      theme: 'striped',
      headStyles: { fillColor: [66, 135, 245] }
    });
  }
}

function generateCodeAnalysisPdf(doc: jsPDF, data: any, yPosition: number): void {
  // Add summary
  doc.setFontSize(16);
  doc.text('Code Analysis Summary', 14, yPosition);
  
  yPosition += 10;
  doc.setFontSize(12);
  doc.text(data.summary || 'No issues found.', 14, yPosition);
  
  yPosition += 15;
  
  // Add language and provider info
  doc.autoTable({
    startY: yPosition,
    head: [['Property', 'Value']],
    body: [
      ['Language', data.language || 'Unknown'],
      ['Analysis Provider', data.provider || 'Unknown']
    ],
    theme: 'striped',
    headStyles: { fillColor: [66, 135, 245] }
  });
  
  yPosition = (doc as any).lastAutoTable.finalY + 15;
  
  // Add issues if available
  if (data.issues && data.issues.length > 0) {
    doc.setFontSize(16);
    doc.text('Identified Issues', 14, yPosition);
    
    yPosition += 10;
    
    const issueRows = data.issues.map((issue: any) => [
      issue.type,
      issue.description,
      issue.lineNumber,
      issue.recommendation
    ]);
    
    doc.autoTable({
      startY: yPosition,
      head: [['Type', 'Description', 'Line', 'Recommendation']],
      body: issueRows,
      theme: 'striped',
      headStyles: { fillColor: [66, 135, 245] },
      columnStyles: {
        0: { cellWidth: 30 },
        1: { cellWidth: 70 },
        2: { cellWidth: 15 },
        3: { cellWidth: 70 }
      }
    });
  }
}

function generateSEOPdf(doc: jsPDF, data: any, yPosition: number): void {
  // Add summary
  doc.setFontSize(16);
  doc.text('SEO Analysis', 14, yPosition);
  
  yPosition += 10;
  doc.setFontSize(12);
  
  // Add URL and score
  doc.autoTable({
    startY: yPosition,
    head: [['Property', 'Value']],
    body: [
      ['URL', data.url || 'Unknown'],
      ['Score', data.score || 'N/A'],
      ['Analysis Date', new Date(data.analysisDate).toLocaleString()]
    ],
    theme: 'striped',
    headStyles: { fillColor: [66, 135, 245] }
  });
  
  yPosition = (doc as any).lastAutoTable.finalY + 15;
  
  // Add findings if available
  if (data.report && data.report.findings && data.report.findings.length > 0) {
    doc.setFontSize(16);
    doc.text('Findings', 14, yPosition);
    
    yPosition += 10;
    
    const findingRows = data.report.findings.map((finding: any) => [
      finding.category,
      finding.description,
      finding.impact,
      finding.recommendation
    ]);
    
    doc.autoTable({
      startY: yPosition,
      head: [['Category', 'Description', 'Impact', 'Recommendation']],
      body: findingRows,
      theme: 'striped',
      headStyles: { fillColor: [66, 135, 245] }
    });
  }
}

function generatePenTestPdf(doc: jsPDF, data: any, yPosition: number): void {
  // Add summary
  doc.setFontSize(16);
  doc.text('Penetration Test Report', 14, yPosition);
  
  yPosition += 10;
  doc.setFontSize(12);
  
  // Add target and score
  doc.autoTable({
    startY: yPosition,
    head: [['Property', 'Value']],
    body: [
      ['Target', data.target || 'Unknown'],
      ['Security Score', data.score || 'N/A'],
      ['Test Date', new Date(data.testDate).toLocaleString()]
    ],
    theme: 'striped',
    headStyles: { fillColor: [66, 135, 245] }
  });
  
  yPosition = (doc as any).lastAutoTable.finalY + 15;
  
  // Add findings if available
  if (data.findings && data.findings.vulnerabilities && data.findings.vulnerabilities.length > 0) {
    doc.setFontSize(16);
    doc.text('Vulnerabilities', 14, yPosition);
    
    yPosition += 10;
    
    const vulnRows = data.findings.vulnerabilities.map((vuln: any) => [
      vuln.severity,
      vuln.name,
      vuln.description,
      vuln.mitigation
    ]);
    
    doc.autoTable({
      startY: yPosition,
      head: [['Severity', 'Name', 'Description', 'Mitigation']],
      body: vulnRows,
      theme: 'striped',
      headStyles: { fillColor: [66, 135, 245] }
    });
  }
}

/**
 * Export data to a Word document
 */
export async function exportToWord(
  type: 'security' | 'code-analysis' | 'seo' | 'pen-test' | 'traffic-boost' | 'page-speed' | 'url-scan',
  data: Record<string, any>,
  filename: string = `${type}-report.docx`
): Promise<void> {
  // Create title from type
  const title = type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') + ' Report';
  // Create new document
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        new Paragraph({
          text: title,
          heading: HeadingLevel.HEADING_1,
        }),
        new Paragraph({
          text: `Generated: ${new Date().toLocaleString()}`,
          style: "aside",
        }),
      ],
    }],
  });
  
  // Generate different reports based on type
  switch (type) {
    case 'security':
      generateSecurityWord(doc, data);
      break;
    case 'code-analysis':
      generateCodeAnalysisWord(doc, data);
      break;
    case 'seo':
      generateSEOWord(doc, data);
      break;
    case 'pen-test':
      generatePenTestWord(doc, data);
      break;
    case 'traffic-boost':
    case 'page-speed':
    case 'url-scan':
      // For now, handle these types with the SEO report format since they're similar
      generateSEOWord(doc, data);
      break;
  }
  
  // Generate the document as a blob
  const buffer = await Packer.toBuffer(doc);
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  
  // Save the file
  saveAs(blob, filename);
}

function generateSecurityWord(doc: Document, data: any): void {
  // Add summary section
  doc.addSection({
    children: [
      new Paragraph({
        text: "Security Scan Summary",
        heading: HeadingLevel.HEADING_2,
      }),
      
      // Create table for summary data
      new Table({
        width: {
          size: 100,
          type: WidthType.PERCENTAGE,
        },
        rows: [
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Severity")],
                width: {
                  size: 50,
                  type: WidthType.PERCENTAGE,
                },
              }),
              new TableCell({
                children: [new Paragraph("Count")],
                width: {
                  size: 50,
                  type: WidthType.PERCENTAGE,
                },
              }),
            ],
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("High Severity")],
              }),
              new TableCell({
                children: [new Paragraph(`${data.highSeverity || 0}`)],
              }),
            ],
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Medium Severity")],
              }),
              new TableCell({
                children: [new Paragraph(`${data.mediumSeverity || 0}`)],
              }),
            ],
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Low Severity")],
              }),
              new TableCell({
                children: [new Paragraph(`${data.lowSeverity || 0}`)],
              }),
            ],
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Total Vulnerabilities")],
              }),
              new TableCell({
                children: [
                  new Paragraph(
                    `${(data.highSeverity || 0) + (data.mediumSeverity || 0) + (data.lowSeverity || 0)}`
                  ),
                ],
              }),
            ],
          }),
        ],
      }),
      
      // Add vulnerabilities if available
      ...(data.vulnerabilities && data.vulnerabilities.length > 0
        ? [
            new Paragraph({
              text: "Vulnerabilities",
              heading: HeadingLevel.HEADING_2,
              spacing: {
                before: 400,
              },
            }),
            createVulnerabilitiesTable(data.vulnerabilities),
          ]
        : []),
    ],
  });
}

function createVulnerabilitiesTable(vulnerabilities: any[]): Table {
  // Create table header row
  const rows = [
    new TableRow({
      children: [
        new TableCell({ children: [new Paragraph("Severity")] }),
        new TableCell({ children: [new Paragraph("Description")] }),
        new TableCell({ children: [new Paragraph("Fixed")] }),
      ],
    }),
  ];
  
  // Add vulnerability rows
  vulnerabilities.forEach((v) => {
    rows.push(
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph(v.severity)] }),
          new TableCell({ children: [new Paragraph(v.description)] }),
          new TableCell({ children: [new Paragraph(v.fixed ? "Yes" : "No")] }),
        ],
      })
    );
  });
  
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows,
  });
}

function generateCodeAnalysisWord(doc: Document, data: any): void {
  const children = [
    new Paragraph({
      text: "Code Analysis Summary",
      heading: HeadingLevel.HEADING_2,
    }),
    new Paragraph(data.summary || "No issues found."),
    
    // Language and provider info
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: [
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Property")] }),
            new TableCell({ children: [new Paragraph("Value")] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Language")] }),
            new TableCell({ children: [new Paragraph(data.language || "Unknown")] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Analysis Provider")] }),
            new TableCell({ children: [new Paragraph(data.provider || "Unknown")] }),
          ],
        }),
      ],
    }),
  ];
  
  // Add issues if available
  if (data.issues && data.issues.length > 0) {
    children.push(
      new Paragraph({
        text: "Identified Issues",
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 400 },
      })
    );
    
    // Create table for issues
    const issueRows = [
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Type")] }),
          new TableCell({ children: [new Paragraph("Description")] }),
          new TableCell({ children: [new Paragraph("Line")] }),
          new TableCell({ children: [new Paragraph("Recommendation")] }),
        ],
      }),
    ];
    
    data.issues.forEach((issue: any) => {
      issueRows.push(
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph(issue.type)] }),
            new TableCell({ children: [new Paragraph(issue.description)] }),
            new TableCell({ children: [new Paragraph(`${issue.lineNumber}`)] }),
            new TableCell({ children: [new Paragraph(issue.recommendation)] }),
          ],
        })
      );
    });
    
    children.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: issueRows,
    }));
    
    // Add code snippet if available
    if (data.code) {
      children.push(
        new Paragraph({
          text: "Original Code",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 400 },
        }),
        new Paragraph({
          text: data.code,
          style: "Code",
        })
      );
    }
    
    if (data.fixedCode) {
      children.push(
        new Paragraph({
          text: "Fixed Code",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 400 },
        }),
        new Paragraph({
          text: data.fixedCode,
          style: "Code",
        })
      );
    }
  }
  
  doc.addSection({ children });
}

function generateSEOWord(doc: Document, data: any): void {
  const children = [
    new Paragraph({
      text: "SEO Analysis",
      heading: HeadingLevel.HEADING_2,
    }),
    
    // URL and score
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: [
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Property")] }),
            new TableCell({ children: [new Paragraph("Value")] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("URL")] }),
            new TableCell({ children: [new Paragraph(data.url || "Unknown")] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Score")] }),
            new TableCell({ children: [new Paragraph(`${data.score || "N/A"}`)] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Analysis Date")] }),
            new TableCell({ 
              children: [new Paragraph(new Date(data.analysisDate).toLocaleString())] 
            }),
          ],
        }),
      ],
    }),
  ];
  
  // Add findings if available
  if (data.report && data.report.findings && data.report.findings.length > 0) {
    children.push(
      new Paragraph({
        text: "Findings",
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 400 },
      })
    );
    
    // Create table for findings
    const findingRows = [
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Category")] }),
          new TableCell({ children: [new Paragraph("Description")] }),
          new TableCell({ children: [new Paragraph("Impact")] }),
          new TableCell({ children: [new Paragraph("Recommendation")] }),
        ],
      }),
    ];
    
    data.report.findings.forEach((finding: any) => {
      findingRows.push(
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph(finding.category)] }),
            new TableCell({ children: [new Paragraph(finding.description)] }),
            new TableCell({ children: [new Paragraph(finding.impact)] }),
            new TableCell({ children: [new Paragraph(finding.recommendation)] }),
          ],
        })
      );
    });
    
    children.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: findingRows,
    }));
  }
  
  doc.addSection({ children });
}

function generatePenTestWord(doc: Document, data: any): void {
  const children = [
    new Paragraph({
      text: "Penetration Test Report",
      heading: HeadingLevel.HEADING_2,
    }),
    
    // Target and score
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: [
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Property")] }),
            new TableCell({ children: [new Paragraph("Value")] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Target")] }),
            new TableCell({ children: [new Paragraph(data.target || "Unknown")] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Security Score")] }),
            new TableCell({ children: [new Paragraph(`${data.score || "N/A"}`)] }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph("Test Date")] }),
            new TableCell({ 
              children: [new Paragraph(new Date(data.testDate).toLocaleString())] 
            }),
          ],
        }),
      ],
    }),
  ];
  
  // Add vulnerabilities if available
  if (data.findings && data.findings.vulnerabilities && data.findings.vulnerabilities.length > 0) {
    children.push(
      new Paragraph({
        text: "Vulnerabilities",
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 400 },
      })
    );
    
    // Create table for vulnerabilities
    const vulnRows = [
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Severity")] }),
          new TableCell({ children: [new Paragraph("Name")] }),
          new TableCell({ children: [new Paragraph("Description")] }),
          new TableCell({ children: [new Paragraph("Mitigation")] }),
        ],
      }),
    ];
    
    data.findings.vulnerabilities.forEach((vuln: any) => {
      vulnRows.push(
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph(vuln.severity)] }),
            new TableCell({ children: [new Paragraph(vuln.name)] }),
            new TableCell({ children: [new Paragraph(vuln.description)] }),
            new TableCell({ children: [new Paragraph(vuln.mitigation)] }),
          ],
        })
      );
    });
    
    children.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: vulnRows,
    }));
  }
  
  doc.addSection({ children });
}