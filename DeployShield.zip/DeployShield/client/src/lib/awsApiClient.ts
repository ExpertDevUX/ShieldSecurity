/**
 * AWS API Client
 * 
 * This module provides a client for interacting with AWS services
 * through our server-side API proxy for deployment purposes.
 */

import { apiRequest } from "./queryClient";

// AWS Service Types
export type AWSServiceType = 'ec2' | 's3' | 'lambda' | 'ecs' | 'elasticbeanstalk';

// AWS Region
export type AWSRegion = 'us-east-1' | 'us-east-2' | 'us-west-1' | 'us-west-2' | 'eu-west-1' | 'eu-central-1' | 'ap-south-1' | 'ap-northeast-1' | 'ap-southeast-1';

// AWS Environment Variable
export interface AWSEnvVar {
  key: string;
  value: string;
}

// AWS Service Configuration
export interface AWSServiceConfig {
  name: string;
  type: AWSServiceType;
  region: AWSRegion;
  envVars?: AWSEnvVar[];
  instanceType?: string;
  storageSize?: number;
  handler?: string;
  runtime?: string;
  memorySize?: number;
  timeout?: number;
  bucketName?: string;
  ecsCluster?: string;
  containerPort?: number;
  cpu?: number;
  memory?: number;
}

// AWS Deployment
export interface AWSDeployment {
  id: string;
  status: 'pending' | 'in_progress' | 'succeeded' | 'failed';
  createdAt: string;
  updatedAt: string;
  serviceId: string;
  region: string;
  logs?: string;
}

// AWS Service
export interface AWSService {
  id: string;
  name: string;
  type: AWSServiceType;
  region: AWSRegion;
  status: 'creating' | 'running' | 'failed' | 'stopping' | 'stopped' | 'terminating' | 'terminated';
  endpoint?: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * AWSAPI class for interacting with AWS services through our API proxy
 * This is a restricted API only available to paid users
 */
class AWSAPI {
  private baseUrl: string = '/api/aws'; // Proxy through our backend

  /**
   * Make an authenticated request to the AWS API proxy
   */
  private async request<T>(
    path: string, 
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
    data?: any
  ): Promise<T> {
    try {
      const response = await apiRequest<T>({
        url: `${this.baseUrl}${path}`,
        method,
        data: data || undefined,
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      return response;
    } catch (error) {
      console.error('AWS API request failed:', error);
      throw error;
    }
  }

  /**
   * Check if the current user has access to AWS deployment features
   */
  async checkAccess(): Promise<{ hasAccess: boolean; reason?: string }> {
    return this.request<{ hasAccess: boolean; reason?: string }>('/access');
  }

  /**
   * List all AWS services
   */
  async listServices(): Promise<AWSService[]> {
    return this.request<AWSService[]>('/services');
  }

  /**
   * Get a service by ID
   */
  async getService(serviceId: string): Promise<AWSService> {
    return this.request<AWSService>(`/services/${serviceId}`);
  }

  /**
   * Create a new AWS service
   */
  async createService(config: AWSServiceConfig): Promise<AWSService> {
    return this.request<AWSService>('/services', 'POST', config);
  }

  /**
   * List deployments for a service
   */
  async listDeployments(serviceId: string): Promise<AWSDeployment[]> {
    return this.request<AWSDeployment[]>(`/services/${serviceId}/deployments`);
  }

  /**
   * Get a deployment by ID
   */
  async getDeployment(deploymentId: string): Promise<AWSDeployment> {
    return this.request<AWSDeployment>(`/deployments/${deploymentId}`);
  }

  /**
   * Trigger a new deployment for a service
   */
  async triggerDeploy(serviceId: string, options?: { version?: string, commitHash?: string }): Promise<AWSDeployment> {
    return this.request<AWSDeployment>(`/services/${serviceId}/deploy`, 'POST', options);
  }

  /**
   * Update an existing service
   */
  async updateService(serviceId: string, config: Partial<AWSServiceConfig>): Promise<AWSService> {
    return this.request<AWSService>(`/services/${serviceId}`, 'PUT', config);
  }

  /**
   * Delete a service
   */
  async deleteService(serviceId: string): Promise<void> {
    return this.request<void>(`/services/${serviceId}`, 'DELETE');
  }

  /**
   * Get the estimated cost for a service configuration
   */
  async estimateCost(config: AWSServiceConfig): Promise<{ monthlyCost: number; currency: string }> {
    return this.request<{ monthlyCost: number; currency: string }>('/estimate-cost', 'POST', config);
  }

  /**
   * Get AWS regions
   */
  async getRegions(): Promise<{ id: string; name: string }[]> {
    return this.request<{ id: string; name: string }[]>('/regions');
  }

  /**
   * Get available instance types for a region and service type
   */
  async getInstanceTypes(region: string, serviceType: AWSServiceType): Promise<{ id: string; name: string; specs: string }[]> {
    return this.request<{ id: string; name: string; specs: string }[]>(`/instance-types?region=${region}&type=${serviceType}`);
  }
}

// Export a singleton instance
export const awsApi = new AWSAPI();

// Also export the class for consumers who need to create their own instance
export default AWSAPI;