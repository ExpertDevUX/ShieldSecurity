import OpenAI from "openai";
import { GoogleGenerativeAI } from "@google/generative-ai";

export type AIProvider = "openai" | "gemini" | "mock";

export const AI_PROVIDERS = [
  { id: "openai", name: "OpenAI GPT-4o" },
  { id: "gemini", name: "Google Gemini" },
  { id: "mock", name: "Demo Mode" }
] as const;

export type CodeAnalysisResponse = {
  issues: Array<{
    type: string;
    description: string;
    lineNumber: number;
    recommendation: string;
  }>;
  fixedCode: string;
  summary: string;
};

/**
 * Analyze code using the selected AI provider
 */
export async function analyzeCode(
  code: string,
  language: string,
  provider: AIProvider = "mock",
  apiKey?: string
): Promise<CodeAnalysisResponse> {
  // Use the factory to get the appropriate client
  const aiService = AIServiceFactory.getClient(provider, apiKey);
  
  try {
    return await aiService.analyzeCode(code, language);
  } catch (error: any) {
    console.error("Error analyzing code:", error);
    throw new Error(`Failed to analyze code with ${provider}: ${error.message || String(error)}`);
  }
}

export class AIServiceFactory {
  static getClient(provider: AIProvider, apiKey?: string) {
    switch (provider) {
      case "openai":
        if (!apiKey) {
          throw new Error("OpenAI API key is required");
        }
        return new OpenAIService(apiKey);
      case "gemini":
        if (!apiKey) {
          // In browser environments, try to use the VITE_ prefixed environment variable
          const envKey = import.meta.env.VITE_GEMINI_API_KEY;
          
          // If no key is found and we're in the client, we'll make a request without an API key
          // The server will attempt to use its own key from environment variables or database
          if (!envKey && typeof window !== 'undefined') {
            console.log("No Gemini API key provided on client, will rely on server-side key");
            apiKey = "use_server_key";
          } else if (!envKey) {
            // If we're in a Node.js environment (server-side)
            throw new Error("Gemini API key is required");
          } else {
            apiKey = envKey || "";
          }
        }
        return new GeminiService(apiKey);
      case "mock":
      default:
        return new MockAIService();
    }
  }
}

export abstract class AIService {
  abstract analyzeCode(code: string, language: string): Promise<CodeAnalysisResponse>;
}

class OpenAIService extends AIService {
  private client: OpenAI;

  constructor(apiKey: string) {
    super();
    this.client = new OpenAI({ apiKey });
  }

  async analyzeCode(code: string, language: string): Promise<CodeAnalysisResponse> {
    const prompt = `
      Analyze the following ${language} code for:
      1. Security vulnerabilities
      2. Performance issues
      3. Best practices violations
      4. Common bugs or logic errors
      
      For each issue found, provide:
      - The type of issue (security, performance, best practice, etc.)
      - A short description
      - The line number where the issue occurs
      - A specific recommendation to fix it
      
      Also provide an improved version of the code with all issues fixed, and a summary of the changes made.
      
      Respond in JSON format with the following structure:
      {
        "issues": [
          {
            "type": "string", // Type of issue (security, performance, best practice, etc.)
            "description": "string", // Short description of the issue
            "lineNumber": number, // Line number where the issue occurs
            "recommendation": "string" // Specific recommendation to fix the issue
          }
        ],
        "fixedCode": "string", // The improved version of the code with all issues fixed
        "summary": "string" // A summary of the analysis and changes made
      }
      
      Here's the code to analyze:
      
      \`\`\`${language}
      ${code}
      \`\`\`
    `;

    try {
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await this.client.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" }
      });

      const content = response.choices[0].message.content;
      
      if (!content) {
        throw new Error("Empty response from OpenAI");
      }
      
      return JSON.parse(content) as CodeAnalysisResponse;
    } catch (error: any) {
      console.error("OpenAI API error:", error);
      throw new Error(`OpenAI API error: ${error.message || String(error)}`);
    }
  }
}

class GeminiService extends AIService {
  private client: GoogleGenerativeAI | null;
  private useServerKey: boolean;

  constructor(apiKey: string) {
    super();
    
    // Special case for when we want to rely on the server's API key
    if (apiKey === "use_server_key") {
      this.client = null;
      this.useServerKey = true;
    } else {
      this.client = new GoogleGenerativeAI(apiKey);
      this.useServerKey = false;
    }
  }

  async analyzeCode(code: string, language: string): Promise<CodeAnalysisResponse> {
    // If we're using the server key, we need to make a fetch request instead of using the client directly
    if (this.useServerKey) {
      try {
        const response = await fetch('/api/code-analysis', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            code,
            language,
            provider: 'gemini'
          }),
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Error analyzing code with server Gemini API');
        }
        
        return await response.json();
      } catch (error: any) {
        console.error("Server Gemini API error:", error);
        throw new Error(`Server Gemini API error: ${error.message || String(error)}`);
      }
    }
    
    // Otherwise, use the client directly
    const model = this.client!.getGenerativeModel({ model: "gemini-pro" });
    
    const prompt = `
      Analyze the following ${language} code for:
      1. Security vulnerabilities
      2. Performance issues
      3. Best practices violations
      4. Common bugs or logic errors
      
      For each issue found, provide:
      - The type of issue (security, performance, best practice, etc.)
      - A short description
      - The line number where the issue occurs
      - A specific recommendation to fix it
      
      Also provide an improved version of the code with all issues fixed, and a summary of the changes made.
      
      Respond in JSON format with the following structure:
      {
        "issues": [
          {
            "type": "string", // Type of issue (security, performance, best practice, etc.)
            "description": "string", // Short description of the issue
            "lineNumber": number, // Line number where the issue occurs
            "recommendation": "string" // Specific recommendation to fix the issue
          }
        ],
        "fixedCode": "string", // The improved version of the code with all issues fixed
        "summary": "string" // A summary of the analysis and changes made
      }
      
      Here's the code to analyze:
      
      \`\`\`${language}
      ${code}
      \`\`\`
    `;

    try {
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const content = response.text();
      
      // Extract JSON from the response
      const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || 
                        content.match(/```([\s\S]*?)```/) || 
                        content.match(/{[\s\S]*}/);
      
      if (jsonMatch) {
        try {
          return JSON.parse(jsonMatch[1] || jsonMatch[0]) as CodeAnalysisResponse;
        } catch (parseError) {
          console.error("Error parsing Gemini JSON response:", parseError);
          throw new Error("Failed to parse Gemini response. Try using OpenAI instead.");
        }
      }
      
      // If we can't parse as JSON, try to structure it manually
      // This is a fallback for when the model doesn't return proper JSON
      return {
        issues: [{
          type: "warning",
          description: "Failed to parse AI response as JSON. Raw content displayed.",
          lineNumber: 1,
          recommendation: "Try with OpenAI provider instead."
        }],
        fixedCode: code,
        summary: content.substring(0, 500) + "... (content truncated)"
      };
    } catch (error: any) {
      console.error("Gemini API error:", error);
      throw new Error(`Gemini API error: ${error.message || String(error)}`);
    }
  }
}

class MockAIService extends AIService {
  async analyzeCode(code: string, language: string): Promise<CodeAnalysisResponse> {
    // Simple pattern matching to demonstrate functionality without API
    const issues = [];
    const lines = code.split('\n');
    
    // Simple patterns to look for in various languages
    const patterns = {
      // Security issues
      security: [
        { regex: /exec\s*\(.*user/i, description: "Potential command injection vulnerability", recommendation: "Use parameterized inputs and sanitize user data" },
        { regex: /eval\s*\(/i, description: "Dangerous use of eval()", recommendation: "Avoid eval(); use safer alternatives" },
        { regex: /select\s+.*\s+from\s+.*\s+where\s+.*=[^=]/i, description: "Potential SQL injection vulnerability", recommendation: "Use parameterized queries instead of string concatenation" },
        { regex: /document\.write\(/i, description: "DOM-based XSS vulnerability", recommendation: "Use safer DOM methods like textContent or createElement" }
      ],
      // Performance issues
      performance: [
        { regex: /for\s*\(\s*let\s+i.*\.length/i, description: "Inefficient loop - length computed each iteration", recommendation: "Cache the array length outside the loop" },
        { regex: /\+\s*".*"\s*\+/i, description: "String concatenation in loop", recommendation: "Use template literals or string interpolation" }
      ],
      // Best practices
      bestPractice: [
        { regex: /console\.log/i, description: "Debug code left in production", recommendation: "Remove console.log statements before production" },
        { regex: /var\s+[a-z]/i, description: "Using 'var' instead of 'let' or 'const'", recommendation: "Use 'const' for unchanging variables, 'let' for others" },
        { regex: /catch\s*\(\s*e\s*\)\s*{\s*\}/i, description: "Empty catch block", recommendation: "Handle errors properly instead of silently catching them" },
        { regex: /===\s*undefined/i, description: "Explicit undefined check", recommendation: "Consider using optional chaining (?.) or nullish coalescing (??)" }
      ]
    };
    
    // Scan the code line by line
    lines.forEach((line, index) => {
      // Check each category of patterns
      for (const [type, patternList] of Object.entries(patterns)) {
        for (const pattern of patternList) {
          if (pattern.regex.test(line)) {
            issues.push({
              type,
              description: pattern.description,
              lineNumber: index + 1,
              recommendation: pattern.recommendation
            });
          }
        }
      }
    });
    
    // If no issues found, add a generic best practice recommendation
    if (issues.length === 0) {
      issues.push({
        type: "bestPractice",
        description: "No specific issues detected with our pattern matching",
        lineNumber: 1,
        recommendation: "Consider adding proper documentation and comments"
      });
    }
    
    // Create a simple "fixed" version - just for demo purposes
    let fixedCode = code;
    let summary = "";
    
    if (issues.length > 0) {
      summary = `Identified ${issues.length} potential issues in your code. The most common issues were related to ${issues[0].type}.`;
      
      // Make some simple fixes based on identified issues
      if (issues.some(i => /var\s+/.test(i.description))) {
        fixedCode = fixedCode.replace(/var\s+/g, 'const ');
      }
      if (issues.some(i => /console\.log/.test(i.description))) {
        fixedCode = fixedCode.replace(/console\.log\([^)]*\);?/g, '');
      }
    } else {
      summary = "No issues were detected in the code. However, this is a simple pattern-matching demo and not a comprehensive analysis.";
    }
    
    return {
      issues,
      fixedCode,
      summary
    };
  }
}