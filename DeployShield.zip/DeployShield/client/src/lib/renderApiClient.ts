/**
 * Render API Client
 * 
 * This module provides a client for interacting with the Render API
 * for deploying and managing services on the Render platform.
 * 
 * Documentation: https://api-docs.render.com/reference/
 */

import { apiRequest } from "./queryClient";

// Service Types
export type RenderServiceType = 'web' | 'static' | 'private' | 'background';

// Service Environment Variable
export interface RenderEnvVar {
  key: string;
  value: string;
  isSecret?: boolean;
}

// Render Service Configuration
export interface RenderServiceConfig {
  name: string;
  type: RenderServiceType;
  repo?: string;
  branch?: string;
  rootDir?: string;
  buildCommand?: string;
  startCommand?: string;
  envVars?: RenderEnvVar[];
  region?: string;
  plan?: string;
  autoDeploy?: boolean;
  numInstances?: number;
}

// Render Deployment
export interface RenderDeployment {
  id: string;
  commit?: string;
  status: 'created' | 'build_in_progress' | 'build_failed' | 'build_successful' | 'deployment_started' | 'deployment_successful' | 'deployment_failed';
  finishedAt?: string;
  createdAt: string;
  updatedAt: string;
  serviceId: string;
}

// Render Service
export interface RenderService {
  id: string;
  name: string;
  type: RenderServiceType;
  autoDeploy: boolean;
  branch: string;
  repo: string;
  slug: string;
  status: 'live' | 'build_failed' | 'creating' | 'suspended';
  suspenders: string[];
  url: string;
  createdAt: string;
  updatedAt: string;
  env: string;
  region: string;
}

/**
 * RenderAPI class for interacting with the Render API
 */
class RenderAPI {
  private apiKey: string | null = null;
  private baseUrl: string = '/api/render'; // Proxy through our backend

  constructor(apiKey?: string) {
    if (apiKey) {
      this.apiKey = apiKey;
    }
  }

  /**
   * Set the API key
   */
  setApiKey(apiKey: string): void {
    this.apiKey = apiKey;
  }

  /**
   * Make an authenticated request to the Render API
   */
  private async request<T>(
    path: string, 
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
    data?: any
  ): Promise<T> {
    try {
      const response = await apiRequest<T>({
        url: `${this.baseUrl}${path}`,
        method,
        data: data || undefined,
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      return response;
    } catch (error) {
      console.error('Render API request failed:', error);
      throw error;
    }
  }

  /**
   * List all services
   */
  async listServices(): Promise<RenderService[]> {
    return this.request<RenderService[]>('/services');
  }

  /**
   * Get a service by ID
   */
  async getService(serviceId: string): Promise<RenderService> {
    return this.request<RenderService>(`/services/${serviceId}`);
  }

  /**
   * Create a new service
   */
  async createService(config: RenderServiceConfig): Promise<RenderService> {
    return this.request<RenderService>('/services', 'POST', config);
  }

  /**
   * List deployments for a service
   */
  async listDeployments(serviceId: string): Promise<RenderDeployment[]> {
    return this.request<RenderDeployment[]>(`/services/${serviceId}/deployments`);
  }

  /**
   * Get a deployment by ID
   */
  async getDeployment(deploymentId: string): Promise<RenderDeployment> {
    return this.request<RenderDeployment>(`/deployments/${deploymentId}`);
  }

  /**
   * Trigger a manual deployment for a service
   */
  async triggerDeploy(serviceId: string, clearCache: boolean = false): Promise<RenderDeployment> {
    return this.request<RenderDeployment>(`/services/${serviceId}/deploys`, 'POST', { clearCache });
  }

  /**
   * Update an existing service
   */
  async updateService(serviceId: string, config: Partial<RenderServiceConfig>): Promise<RenderService> {
    return this.request<RenderService>(`/services/${serviceId}`, 'PUT', config);
  }

  /**
   * Delete a service
   */
  async deleteService(serviceId: string): Promise<void> {
    return this.request<void>(`/services/${serviceId}`, 'DELETE');
  }

  /**
   * Get the status of a service
   */
  async getServiceStatus(serviceId: string): Promise<string> {
    const service = await this.getService(serviceId);
    return service.status;
  }
}

// Export a singleton instance
export const renderApi = new RenderAPI();

// Also export the class for consumers who need to create their own instance
export default RenderAPI;