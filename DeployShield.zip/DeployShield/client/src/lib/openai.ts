import OpenAI from "openai";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
export const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export type CodeAnalysisResponse = {
  issues: Array<{
    type: string;
    description: string;
    lineNumber: number;
    recommendation: string;
  }>;
  fixedCode: string;
  summary: string;
};

/**
 * Analyze code for security vulnerabilities and best practices
 */
export async function analyzeCode(code: string, language: string): Promise<CodeAnalysisResponse> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert code reviewer focused on identifying security vulnerabilities, bugs, and best practices issues. 
          Analyze the provided ${language} code carefully. For each issue found, provide:
          1. Type (e.g., "Security Vulnerability", "Bug", "Performance Issue", "Best Practice")
          2. Detailed description of the issue
          3. The line number where the issue occurs
          4. A specific recommendation to fix the issue
          
          Also provide a fixed version of the entire code and a brief summary of all issues found.
          Response should be in JSON format as follows:
          {
            "issues": [
              {
                "type": "string",
                "description": "string",
                "lineNumber": number,
                "recommendation": "string"
              }
            ],
            "fixedCode": "string",
            "summary": "string"
          }`
        },
        {
          role: "user",
          content: code
        }
      ],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content) as CodeAnalysisResponse;
  } catch (error) {
    console.error("Error analyzing code:", error);
    throw new Error("Failed to analyze code. Please try again later.");
  }
}

/**
 * Analyze image for security testing purposes
 */
export async function analyzeImageSecurity(base64Image: string): Promise<{
  vulnerabilities: Array<{
    type: string;
    description: string;
    severity: string;
    recommendation: string;
  }>;
  summary: string;
}> {
  try {
    const visionResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a security expert analyzing screenshots or images of user interfaces for security vulnerabilities, privacy issues, and UX security problems. Provide detailed analysis in JSON format."
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this screenshot for security vulnerabilities, privacy issues, exposed credentials, UX security problems, and anything else related to security. Return the analysis in JSON format with vulnerabilities array and summary."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" }
    });

    return JSON.parse(visionResponse.choices[0].message.content);
  } catch (error) {
    console.error("Error analyzing image:", error);
    throw new Error("Failed to analyze image. Please try again later.");
  }
}

/**
 * Generate suggestions for improving security based on scanning results
 */
export async function generateSecuritySuggestions(vulnerabilities: Array<{
  description: string;
  severity: string;
  fixed: boolean;
}>): Promise<Array<{
  title: string;
  description: string;
  implementation: string;
  priority: string;
}>> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a cybersecurity expert. Based on the vulnerabilities provided, generate actionable security improvement suggestions.
          Response should be in JSON format as an array of suggestions with title, description, implementation steps, and priority.`
        },
        {
          role: "user",
          content: JSON.stringify(vulnerabilities)
        }
      ],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content).suggestions;
  } catch (error) {
    console.error("Error generating security suggestions:", error);
    throw new Error("Failed to generate security suggestions. Please try again later.");
  }
}