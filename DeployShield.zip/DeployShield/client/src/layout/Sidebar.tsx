import { Link } from "wouter";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Shield, LayoutDashboard, Code, Terminal, Upload, BarChart, Settings, Zap, Globe, Gauge, Server, FileEdit, Users, Share2 } from "lucide-react";

export default function Sidebar({ isSidebarOpen, closeSidebar }: { isSidebarOpen: boolean; closeSidebar: () => void }) {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  const navItems = [
    { path: "/", icon: <LayoutDashboard className="w-5 h-5" />, label: "Dashboard" },
    { path: "/deployment", icon: <Upload className="w-5 h-5" />, label: "Deploy App/Website" },
    { path: "/security-scan", icon: <Shield className="w-5 h-5" />, label: "Security Scan" },
    { path: "/pen-testing", icon: <Terminal className="w-5 h-5" />, label: "Pen Testing" },
    { path: "/traffic-boosting", icon: <Zap className="w-5 h-5" />, label: "Traffic Boosting" },
    { path: "/seo-analysis", icon: <BarChart className="w-5 h-5" />, label: "SEO Analysis" },
    { path: "/performance-optimization", icon: <Gauge className="w-5 h-5" />, label: "Performance Wizard" },
    { path: "/server-browser", icon: <Server className="w-5 h-5" />, label: "Server File Browser" },
    { path: "/html-customization", icon: <FileEdit className="w-5 h-5" />, label: "HTML Customization" },
    { path: "/collaboration", icon: <Share2 className="w-5 h-5" />, label: "Collaboration" },
    { path: "/user-management", icon: <Users className="w-5 h-5" />, label: "User Management" },
    { path: "/settings", icon: <Settings className="w-5 h-5" />, label: "Settings" },
  ];

  return (
    <>
      {/* Backdrop for mobile */}
      <div
        className={cn(
          "fixed inset-0 z-20 transition-opacity bg-black opacity-50 lg:hidden",
          isSidebarOpen ? "block" : "hidden"
        )}
        onClick={closeSidebar}
      />

      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-30 w-64 overflow-y-auto transition duration-300 transform bg-gray-900 lg:translate-x-0 lg:static lg:inset-0",
          isSidebarOpen ? "translate-x-0 ease-out" : "-translate-x-full ease-in"
        )}
      >
        <div className="flex items-center justify-center mt-8">
          <div className="flex items-center">
            <Shield className="w-10 h-10 text-blue-500" />
            <span className="mx-2 text-2xl font-semibold text-white">SecureDeployX</span>
          </div>
        </div>

        <nav className="mt-10">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <div
                className={cn(
                  "flex items-center px-6 py-3 mt-1 cursor-pointer",
                  isActive(item.path)
                    ? "text-gray-100 bg-gray-700 bg-opacity-25"
                    : "text-gray-300 hover:bg-gray-700 hover:bg-opacity-25 hover:text-gray-100"
                )}
                onClick={closeSidebar}
              >
                {item.icon}
                <span className="mx-3">{item.label}</span>
              </div>
            </Link>
          ))}
        </nav>
      </div>
    </>
  );
}
