import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Layout from "./layout/Layout";
import Dashboard from "@/pages/dashboard";
import SecurityScan from "@/pages/security-scan";
import PenTesting from "@/pages/pen-testing";
import SeoAnalysis from "@/pages/seo-analysis";
import Settings from "@/pages/settings";
import TrafficBoosting from "./pages/traffic-boosting";
import Deployment from "./pages/deployment";
import PerformanceOptimization from "./pages/performance-optimization";
import ServerBrowser from "./pages/server-browser";
import HtmlCustomization from "./pages/html-customization";
import UserManagement from "@/pages/user-management";
import Collaboration from "@/pages/collaboration";
import CodePreviewDemo from "@/pages/code-preview-demo";
import AuthPage from "@/pages/auth";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./components/auth/ProtectedRoute";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      
      <Route path="/">
        <ProtectedRoute>
          <Layout>
            <Dashboard />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/deployment">
        <ProtectedRoute>
          <Layout>
            <Deployment />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/security-scan">
        <ProtectedRoute>
          <Layout>
            <SecurityScan />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/pen-testing">
        <ProtectedRoute>
          <Layout>
            <PenTesting />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/traffic-boosting">
        <ProtectedRoute>
          <Layout>
            <TrafficBoosting />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/seo-analysis">
        <ProtectedRoute>
          <Layout>
            <SeoAnalysis />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/performance-optimization">
        <ProtectedRoute>
          <Layout>
            <PerformanceOptimization />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/server-browser">
        <ProtectedRoute>
          <Layout>
            <ServerBrowser />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/html-customization">
        <ProtectedRoute>
          <Layout>
            <HtmlCustomization />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/user-management">
        <ProtectedRoute>
          <Layout>
            <UserManagement />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/collaboration">
        <ProtectedRoute>
          <Layout>
            <Collaboration />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/collaboration/:sessionId">
        <ProtectedRoute>
          <Layout>
            <Collaboration />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/code-preview-demo">
        <ProtectedRoute>
          <Layout>
            <CodePreviewDemo />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route path="/settings">
        <ProtectedRoute>
          <Layout>
            <Settings />
          </Layout>
        </ProtectedRoute>
      </Route>
      
      <Route>
        <Layout>
          <NotFound />
        </Layout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
