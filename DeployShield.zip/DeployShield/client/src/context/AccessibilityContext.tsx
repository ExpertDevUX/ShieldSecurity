import React, { createContext, useState, useContext, useEffect } from "react";

type AccessibilityOptions = {
  highContrast: boolean;
  largeText: boolean;
  reducedMotion: boolean;
  screenReaderMode: boolean;
  announcements: string[];
};

interface AccessibilityContextType {
  options: AccessibilityOptions;
  toggleHighContrast: () => void;
  toggleLargeText: () => void;
  toggleReducedMotion: () => void;
  toggleScreenReaderMode: () => void;
  announce: (message: string) => void;
  clearAnnouncements: () => void;
}

const defaultOptions: AccessibilityOptions = {
  highContrast: false,
  largeText: false,
  reducedMotion: false,
  screenReaderMode: false,
  announcements: [],
};

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [options, setOptions] = useState<AccessibilityOptions>(() => {
    // Try to load from localStorage if available
    const savedOptions = localStorage.getItem('accessibility-options');
    if (savedOptions) {
      try {
        const parsed = JSON.parse(savedOptions);
        return {
          ...defaultOptions,
          ...parsed,
          // Always reset announcements on load
          announcements: []
        };
      } catch (e) {
        console.error('Failed to parse saved accessibility options:', e);
      }
    }
    return defaultOptions;
  });

  // Save options to localStorage when they change
  useEffect(() => {
    const { announcements, ...optionsToSave } = options;
    localStorage.setItem('accessibility-options', JSON.stringify(optionsToSave));
  }, [options]);

  // Apply global CSS classes based on accessibility options
  useEffect(() => {
    const html = document.documentElement;
    
    // High Contrast Mode
    if (options.highContrast) {
      html.classList.add('high-contrast-mode');
    } else {
      html.classList.remove('high-contrast-mode');
    }
    
    // Large Text Mode
    if (options.largeText) {
      html.classList.add('large-text-mode');
    } else {
      html.classList.remove('large-text-mode');
    }
    
    // Reduced Motion
    if (options.reducedMotion) {
      html.classList.add('reduced-motion');
    } else {
      html.classList.remove('reduced-motion');
    }
    
    // Screen Reader Mode
    if (options.screenReaderMode) {
      html.classList.add('screen-reader-mode');
    } else {
      html.classList.remove('screen-reader-mode');
    }
  }, [options]);

  // Check for system preferences for reduced motion
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    
    const handleChange = (e: MediaQueryListEvent) => {
      setOptions(prev => ({ ...prev, reducedMotion: e.matches }));
    };
    
    // Set initial value
    if (mediaQuery.matches && !options.reducedMotion) {
      setOptions(prev => ({ ...prev, reducedMotion: true }));
    }
    
    // Add listener for changes
    mediaQuery.addEventListener('change', handleChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleChange);
    };
  }, []);

  const toggleHighContrast = () => {
    setOptions(prev => ({ ...prev, highContrast: !prev.highContrast }));
  };

  const toggleLargeText = () => {
    setOptions(prev => ({ ...prev, largeText: !prev.largeText }));
  };

  const toggleReducedMotion = () => {
    setOptions(prev => ({ ...prev, reducedMotion: !prev.reducedMotion }));
  };

  const toggleScreenReaderMode = () => {
    setOptions(prev => ({ ...prev, screenReaderMode: !prev.screenReaderMode }));
  };

  const announce = (message: string) => {
    setOptions(prev => ({
      ...prev,
      announcements: [...prev.announcements, message]
    }));
  };

  const clearAnnouncements = () => {
    setOptions(prev => ({
      ...prev,
      announcements: []
    }));
  };

  return (
    <AccessibilityContext.Provider
      value={{
        options,
        toggleHighContrast,
        toggleLargeText,
        toggleReducedMotion,
        toggleScreenReaderMode,
        announce,
        clearAnnouncements
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (context === undefined) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
}