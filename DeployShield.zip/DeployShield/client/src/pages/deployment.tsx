import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Rocket, Globe, Server, ArrowRight, Code, Database, 
  FileCode, Box, GripVertical, ShieldCheck, Languages
} from "lucide-react";
import AutoDeployTemplate from "@/components/deployment/AutoDeployPreview";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CodeAnalysisButton } from "@/components/code-analysis/CodeAnalysisButton";

export default function DeploymentPage() {
  const { toast } = useToast();
  const [deployingApp, setDeployingApp] = useState(false);
  const [deployingWebsite, setDeployingWebsite] = useState(false);
  const [deployingPython, setDeployingPython] = useState(false);
  const [deployingWordPress, setDeployingWordPress] = useState(false);
  const [deployingPHP, setDeployingPHP] = useState(false);
  const [deployingASPNET, setDeployingASPNET] = useState(false);
  
  // Environment options
  const [deploymentRegion, setDeploymentRegion] = useState("us-east-1");
  const [pythonVersion, setPythonVersion] = useState("3.11");
  const [phpVersion, setPhpVersion] = useState("8.2");
  const [wordpressType, setWordpressType] = useState("standard");
  const [aspnetVersion, setAspnetVersion] = useState("7.0");
  const [deploymentUrl, setDeploymentUrl] = useState("");
  
  // Code Analysis options
  const [codeLanguage, setCodeLanguage] = useState("javascript");
  const [aiProvider, setAiProvider] = useState("gemini");
  const [analysisType, setAnalysisType] = useState("security");
  const [analyzingCode, setAnalyzingCode] = useState(false);
  
  const handleDeployApp = async () => {
    setDeployingApp(true);
    
    try {
      // Create a deployment record
      const deployment = await apiRequest('/api/deployments', 
        {
          target: "Server Application",
          status: "In Progress",
          projectId: 1, // Use the first project for demo
          logs: "Initializing deployment process...\nPreparing build environment...\nInstalling dependencies..."
        }, 
        { method: 'POST' }
      );
      
      // Invalidate the deployments query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/deployments"] });
      
      toast({
        title: "App Deployment Initiated",
        description: "Your application is being deployed. You'll be notified when it's complete.",
      });
    } catch (error) {
      toast({
        title: "Deployment Failed",
        description: "There was an error starting the deployment. Please try again.",
        variant: "destructive",
      });
      console.error("Deployment error:", error);
    } finally {
      setDeployingApp(false);
    }
  };
  
  const handleDeployWebsite = async () => {
    setDeployingWebsite(true);
    
    try {
      // Create a deployment record
      const deployment = await apiRequest('/api/deployments', 
        {
          target: "Static Website",
          status: "In Progress",
          projectId: 1, // Use the first project for demo
          logs: "Initializing deployment process...\nPreparing static assets...\nOptimizing for CDN delivery..."
        },
        { method: 'POST' }
      );
      
      // Invalidate the deployments query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/deployments"] });
      
      toast({
        title: "Website Deployment Initiated",
        description: "Your website is being deployed. You'll be notified when it's complete.",
      });
    } catch (error) {
      toast({
        title: "Deployment Failed",
        description: "There was an error starting the deployment. Please try again.",
        variant: "destructive",
      });
      console.error("Deployment error:", error);
    } finally {
      setDeployingWebsite(false);
    }
  };

  const handleDeployPython = async () => {
    setDeployingPython(true);
    
    try {
      // Create a deployment record
      const deployment = await apiRequest('/api/deployments', 
        {
          target: `Python ${pythonVersion} Application`,
          status: "In Progress",
          projectId: 1, 
          region: deploymentRegion,
          logs: `Initializing Python ${pythonVersion} deployment...\nSetting up virtual environment...\nInstalling dependencies...\nConfiguring WSGI server...`
        },
        { method: 'POST' }
      );
      
      // Invalidate the deployments query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/deployments"] });
      
      toast({
        title: "Python Deployment Initiated",
        description: `Your Python ${pythonVersion} application is being deployed. You'll be notified when it's complete.`,
      });
    } catch (error) {
      toast({
        title: "Python Deployment Failed",
        description: "There was an error starting the deployment. Please try again.",
        variant: "destructive",
      });
      console.error("Deployment error:", error);
    } finally {
      setDeployingPython(false);
    }
  };

  const handleDeployWordPress = async () => {
    setDeployingWordPress(true);
    
    try {
      // Create a deployment record
      const deployment = await apiRequest('/api/deployments', 
        {
          target: "WordPress",
          status: "In Progress",
          projectId: 1,
          region: deploymentRegion,
          logs: "Setting up WordPress environment...\nConfiguring database...\nInstalling WordPress core...\nSetting up themes and plugins..."
        },
        { method: 'POST' }
      );
      
      // Invalidate the deployments query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/deployments"] });
      
      toast({
        title: "WordPress Deployment Initiated",
        description: "Your WordPress site is being deployed. You'll be notified when it's complete.",
      });
    } catch (error) {
      toast({
        title: "WordPress Deployment Failed",
        description: "There was an error starting the deployment. Please try again.",
        variant: "destructive",
      });
      console.error("Deployment error:", error);
    } finally {
      setDeployingWordPress(false);
    }
  };

  const handleDeployPHP = async () => {
    setDeployingPHP(true);
    
    try {
      // Create a deployment record
      const deployment = await apiRequest('/api/deployments', 
        {
          target: `PHP ${phpVersion} Application`,
          status: "In Progress",
          projectId: 1,
          region: deploymentRegion,
          logs: `Setting up PHP ${phpVersion} environment...\nConfiguring web server...\nInstalling Composer dependencies...`
        },
        { method: 'POST' }
      );
      
      // Invalidate the deployments query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/deployments"] });
      
      toast({
        title: "PHP Deployment Initiated",
        description: `Your PHP ${phpVersion} application is being deployed. You'll be notified when it's complete.`,
      });
    } catch (error) {
      toast({
        title: "PHP Deployment Failed",
        description: "There was an error starting the deployment. Please try again.",
        variant: "destructive",
      });
      console.error("Deployment error:", error);
    } finally {
      setDeployingPHP(false);
    }
  };

  const handleDeployASPNET = async () => {
    setDeployingASPNET(true);
    
    try {
      // Create a deployment record
      const deployment = await apiRequest('/api/deployments', 
        {
          target: `ASP.NET ${aspnetVersion}`,
          status: "In Progress",
          projectId: 1,
          region: deploymentRegion,
          logs: `Setting up .NET ${aspnetVersion} environment...\nRestoring packages...\nBuilding application...\nSetting up IIS...`
        },
        { method: 'POST' }
      );
      
      // Invalidate the deployments query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/deployments"] });
      
      toast({
        title: "ASP.NET Deployment Initiated",
        description: `Your ASP.NET ${aspnetVersion} application is being deployed. You'll be notified when it's complete.`,
      });
    } catch (error) {
      toast({
        title: "ASP.NET Deployment Failed",
        description: "There was an error starting the deployment. Please try again.",
        variant: "destructive",
      });
      console.error("Deployment error:", error);
    } finally {
      setDeployingASPNET(false);
    }
  };
  
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Rocket className="h-8 w-8 text-primary" />
          Deploy Application
        </h1>
        <p className="text-muted-foreground">
          Deploy your application quickly and easily with our Replit-style deployment engine
        </p>
      </div>
      
      {/* Deployment Platform Tabs */}
      <Tabs defaultValue="quickDeploy" className="w-full">
        <TabsList className="grid grid-cols-3 w-full mb-6">
          <TabsTrigger value="quickDeploy">
            <Rocket className="mr-2 h-4 w-4" />
            Quick Deploy
          </TabsTrigger>
          <TabsTrigger value="advancedDeploy">
            <Server className="mr-2 h-4 w-4" />
            Advanced Options
          </TabsTrigger>
          <TabsTrigger value="codeAnalysis">
            <Code className="mr-2 h-4 w-4" />
            AI Code Analysis
          </TabsTrigger>
        </TabsList>

        {/* Quick Deploy Tab Content */}
        <TabsContent value="quickDeploy">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gradient-to-br from-blue-100/30 to-blue-50/30 dark:from-blue-900/20 dark:to-blue-800/10 border-blue-200 dark:border-blue-900/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  Deploy App
                </CardTitle>
                <CardDescription>
                  Deploy a full-stack application with backend services
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Deploy complete applications with server-side logic, APIs, and database connections. 
                  Includes support for Node.js, Python, and Ruby applications.
                </p>
                <Button 
                  size="lg" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={handleDeployApp}
                  disabled={deployingApp}
                >
                  {deployingApp ? (
                    <>
                      <span className="animate-pulse">Deploying...</span>
                    </>
                  ) : (
                    <>
                      Deploy App
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-green-100/30 to-green-50/30 dark:from-green-900/20 dark:to-green-800/10 border-green-200 dark:border-green-900/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-green-600 dark:text-green-400" />
                  Deploy Website
                </CardTitle>
                <CardDescription>
                  Deploy static websites and single-page applications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Deploy static websites and SPAs with optimized delivery, CDN integration, and 
                  automatic HTTPS. Perfect for React, Vue, and other frontend frameworks.
                </p>
                <Button 
                  size="lg" 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={handleDeployWebsite}
                  disabled={deployingWebsite}
                >
                  {deployingWebsite ? (
                    <>
                      <span className="animate-pulse">Deploying...</span>
                    </>
                  ) : (
                    <>
                      Deploy Website
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Advanced Deploy Tab Content */}
        <TabsContent value="advancedDeploy">
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="w-full md:w-1/3">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Deployment Settings</CardTitle>
                    <CardDescription>Configure global deployment options</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="deploymentRegion">Region</Label>
                      <Select value={deploymentRegion} onValueChange={setDeploymentRegion}>
                        <SelectTrigger id="deploymentRegion">
                          <SelectValue placeholder="Select region" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="us-east-1">US East (N. Virginia)</SelectItem>
                          <SelectItem value="us-west-2">US West (Oregon)</SelectItem>
                          <SelectItem value="eu-west-1">EU (Ireland)</SelectItem>
                          <SelectItem value="ap-southeast-1">Asia Pacific (Singapore)</SelectItem>
                          <SelectItem value="ap-northeast-1">Asia Pacific (Tokyo)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="deploymentUrl">Custom Domain (Optional)</Label>
                      <Input 
                        id="deploymentUrl" 
                        placeholder="your-site.com" 
                        value={deploymentUrl}
                        onChange={(e) => setDeploymentUrl(e.target.value)}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="w-full md:w-2/3">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Advanced Deployment Options</CardTitle>
                    <CardDescription>Deploy your application with specialized configurations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {/* Python Deployment Option */}
                      <Card className="border-blue-200 dark:border-blue-800">
                        <CardHeader className="py-3">
                          <CardTitle className="text-base flex items-center">
                            <FileCode className="h-4 w-4 mr-2 text-blue-600" />
                            Python Application
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="py-2 space-y-2">
                          <div className="flex justify-between items-center">
                            <Label htmlFor="pythonVersion" className="text-sm">Version:</Label>
                            <Select 
                              value={pythonVersion} 
                              onValueChange={setPythonVersion}
                            >
                              <SelectTrigger id="pythonVersion" className="h-7 text-xs">
                                <SelectValue placeholder="Version" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="3.11">3.11</SelectItem>
                                <SelectItem value="3.10">3.10</SelectItem>
                                <SelectItem value="3.9">3.9</SelectItem>
                                <SelectItem value="3.8">3.8</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button 
                            size="sm" 
                            className="w-full"
                            onClick={handleDeployPython}
                            disabled={deployingPython}
                          >
                            {deployingPython ? "Deploying..." : "Deploy Python"}
                          </Button>
                        </CardContent>
                      </Card>

                      {/* WordPress Deployment Option */}
                      <Card className="border-orange-200 dark:border-orange-800">
                        <CardHeader className="py-3">
                          <CardTitle className="text-base flex items-center">
                            <Box className="h-4 w-4 mr-2 text-orange-600" />
                            WordPress
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="py-2 space-y-2">
                          <div className="flex justify-between items-center">
                            <Label htmlFor="wordpressType" className="text-sm">Type:</Label>
                            <Select 
                              value={wordpressType} 
                              onValueChange={setWordpressType}
                            >
                              <SelectTrigger id="wordpressType" className="h-7 text-xs">
                                <SelectValue placeholder="Type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="standard">Standard</SelectItem>
                                <SelectItem value="woocommerce">WooCommerce</SelectItem>
                                <SelectItem value="multisite">Multisite</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button 
                            size="sm" 
                            className="w-full"
                            onClick={handleDeployWordPress}
                            disabled={deployingWordPress}
                          >
                            {deployingWordPress ? "Deploying..." : "Deploy WordPress"}
                          </Button>
                        </CardContent>
                      </Card>

                      {/* PHP Deployment Option */}
                      <Card className="border-purple-200 dark:border-purple-800">
                        <CardHeader className="py-3">
                          <CardTitle className="text-base flex items-center">
                            <Code className="h-4 w-4 mr-2 text-purple-600" />
                            PHP Application
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="py-2 space-y-2">
                          <div className="flex justify-between items-center">
                            <Label htmlFor="phpVersion" className="text-sm">Version:</Label>
                            <Select 
                              value={phpVersion} 
                              onValueChange={setPhpVersion}
                            >
                              <SelectTrigger id="phpVersion" className="h-7 text-xs">
                                <SelectValue placeholder="Version" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="8.2">8.2</SelectItem>
                                <SelectItem value="8.1">8.1</SelectItem>
                                <SelectItem value="8.0">8.0</SelectItem>
                                <SelectItem value="7.4">7.4</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button 
                            size="sm" 
                            className="w-full"
                            onClick={handleDeployPHP}
                            disabled={deployingPHP}
                          >
                            {deployingPHP ? "Deploying..." : "Deploy PHP"}
                          </Button>
                        </CardContent>
                      </Card>

                      {/* ASP.NET Deployment Option */}
                      <Card className="border-indigo-200 dark:border-indigo-800">
                        <CardHeader className="py-3">
                          <CardTitle className="text-base flex items-center">
                            <GripVertical className="h-4 w-4 mr-2 text-indigo-600" />
                            ASP.NET
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="py-2 space-y-2">
                          <div className="flex justify-between items-center">
                            <Label htmlFor="aspnetVersion" className="text-sm">Version:</Label>
                            <Select 
                              value={aspnetVersion} 
                              onValueChange={setAspnetVersion}
                            >
                              <SelectTrigger id="aspnetVersion" className="h-7 text-xs">
                                <SelectValue placeholder="Version" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="7.0">7.0</SelectItem>
                                <SelectItem value="6.0">6.0</SelectItem>
                                <SelectItem value="5.0">5.0</SelectItem>
                                <SelectItem value="3.1">3.1</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button 
                            size="sm" 
                            className="w-full"
                            onClick={handleDeployASPNET}
                            disabled={deployingASPNET}
                          >
                            {deployingASPNET ? "Deploying..." : "Deploy ASP.NET"}
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* AI Code Analysis Tab Content */}
        <TabsContent value="codeAnalysis">
          <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-100/30 to-purple-50/30 dark:from-purple-900/20 dark:to-purple-800/10 border-purple-200 dark:border-purple-900/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                  Pre-Deployment Code Analysis
                </CardTitle>
                <CardDescription>
                  Analyze your code for security issues, performance optimizations, and best practices before deployment
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Code Analysis Options */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="codeLanguage">Select Language</Label>
                      <Select defaultValue="javascript">
                        <SelectTrigger id="codeLanguage">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="javascript">JavaScript/TypeScript</SelectItem>
                          <SelectItem value="python">Python</SelectItem>
                          <SelectItem value="java">Java</SelectItem>
                          <SelectItem value="csharp">C#</SelectItem>
                          <SelectItem value="php">PHP</SelectItem>
                          <SelectItem value="go">Go</SelectItem>
                          <SelectItem value="ruby">Ruby</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="aiProvider">AI Provider</Label>
                      <Select defaultValue="gemini">
                        <SelectTrigger id="aiProvider">
                          <SelectValue placeholder="Select AI provider" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="gemini">Google Gemini</SelectItem>
                          <SelectItem value="openai">OpenAI</SelectItem>
                          <SelectItem value="mock">Mock Service</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="analysisType">Analysis Type</Label>
                      <Select defaultValue="security">
                        <SelectTrigger id="analysisType">
                          <SelectValue placeholder="Select analysis type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="security">Security Analysis</SelectItem>
                          <SelectItem value="performance">Performance Optimization</SelectItem>
                          <SelectItem value="bestpractices">Best Practices</SelectItem>
                          <SelectItem value="comprehensive">Comprehensive Analysis</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="pt-2">
                      <CodeAnalysisButton 
                        className="w-full bg-purple-600 hover:bg-purple-700"
                        label="Analyze Code with Whisper"
                      />
                    </div>
                  </div>
                  
                  {/* Code Analysis Results */}
                  <div className="bg-slate-50 dark:bg-slate-900 rounded-lg p-4 border border-slate-200 dark:border-slate-800">
                    <h3 className="text-lg font-medium mb-2">Analysis Results</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Upload your code or connect your repository to get AI-powered analysis and recommendations before deployment.
                    </p>
                    <div className="bg-slate-100 dark:bg-slate-800 rounded p-3 text-xs font-mono">
                      <div className="flex items-center text-green-600 dark:text-green-400 mb-2">
                        <span className="mr-2">●</span>
                        <span>Waiting for code analysis to begin...</span>
                      </div>
                      <div className="text-slate-500 dark:text-slate-400">
                        # AI-powered code analysis will help you:
                        <br />
                        # - Identify security vulnerabilities
                        <br />
                        # - Suggest performance optimizations
                        <br />
                        # - Ensure best practices are followed
                        <br />
                        # - Fix potential bugs before deployment
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Recent Analysis History */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Analysis History</CardTitle>
                <CardDescription>View your recent code analysis results</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  No recent analysis found. Run your first code analysis to see results here.
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Rocket className="h-5 w-5" />
            Replit-Style Build Preview
          </CardTitle>
          <CardDescription>
            Select a template, configure options, and preview your application with real-time build logs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-primary/5">
                <CardHeader>
                  <CardTitle>How It Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border bg-background">
                        <span className="text-sm font-bold">1</span>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">Select a Template</p>
                        <p className="text-sm text-muted-foreground">
                          Choose from Next.js, React SPA, Express API, or MERN stack templates
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border bg-background">
                        <span className="text-sm font-bold">2</span>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">Configure Options</p>
                        <p className="text-sm text-muted-foreground">
                          Customize your deployment with database, authentication, and CMS options
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border bg-background">
                        <span className="text-sm font-bold">3</span>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">Build & Preview</p>
                        <p className="text-sm text-muted-foreground">
                          Watch your application build in real-time with interactive logs and statistics
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-primary/5">
                <CardHeader>
                  <CardTitle>Features</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Code className="h-4 w-4 text-primary" />
                      <span className="text-sm">Real-time build logs with colored formatting</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Server className="h-4 w-4 text-primary" />
                      <span className="text-sm">Interactive preview with hot reloading</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Database className="h-4 w-4 text-primary" />
                      <span className="text-sm">Auto-configured database connections</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-primary" />
                      <span className="text-sm">One-click deployment to production</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Rocket className="h-4 w-4 text-primary" />
                      <span className="text-sm">Performance metrics and optimization suggestions</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
            
            <AutoDeployTemplate />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}