import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { 
  CreditCard, 
  DollarSign, 
  Settings, 
  Save, 
  UserPlus,
  AlertCircle,
  CheckCircle,
  RefreshCw
} from "lucide-react";

interface PaymentProviderSettings {
  id: number;
  providerName: string;
  isActive: boolean;
  merchantId?: string;
  apiKey?: string;
  clientId?: string;
  secretKey?: string;
  webhookSecret?: string;
  mode: 'live' | 'sandbox';
  supportedCurrencies: string[];
  settings: Record<string, any>;
}

interface PaymentProviderFormData {
  isActive: boolean;
  merchantId?: string;
  apiKey?: string;
  clientId?: string;
  secretKey?: string;
  webhookSecret?: string;
  mode: 'live' | 'sandbox';
  supportedCurrencies: string[];
  settings: Record<string, any>;
}

export default function PaymentSettingsPage() {
  const [activeTab, setActiveTab] = useState('paypal');
  const [isSaving, setIsSaving] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);
  const { toast } = useToast();
  
  // PayPal Settings form
  const [paypalSettings, setPaypalSettings] = useState<PaymentProviderFormData>({
    isActive: false,
    clientId: '',
    secretKey: '',
    mode: 'sandbox',
    supportedCurrencies: ['USD', 'EUR', 'GBP'],
    settings: {
      autoCapture: true,
      allowGuestCheckout: true
    }
  });
  
  // Stripe Settings form
  const [stripeSettings, setStripeSettings] = useState<PaymentProviderFormData>({
    isActive: false,
    apiKey: '',
    webhookSecret: '',
    mode: 'sandbox',
    supportedCurrencies: ['USD', 'EUR', 'GBP'],
    settings: {
      autoCapture: true,
      statementDescriptor: 'SecureDeployX'
    }
  });
  
  // General payment settings
  const [generalSettings, setGeneralSettings] = useState({
    enableAutomaticRenewal: true,
    sendPaymentReminders: true,
    reminderDaysBefore: 7,
    allowCancellations: true,
    requireBillingAddress: false,
    defaultCurrency: 'USD',
    taxPercentage: 0,
    enablePromoCode: true
  });
  
  // Load payment provider settings
  const { data: paymentProviders, isLoading } = useQuery({
    queryKey: ['/api/admin/payment-settings'],
    queryFn: async () => {
      try {
        const result = await apiRequest<PaymentProviderSettings[]>({
          url: '/api/admin/payment-settings',
          method: 'GET'
        });
        return result;
      } catch (error) {
        console.error('Failed to load payment settings:', error);
        return [];
      }
    }
  });
  
  // Update payment settings mutation
  const updateSettings = useMutation({
    mutationFn: async (data: {
      provider: string;
      settings: PaymentProviderFormData;
    }) => {
      return apiRequest({
        url: `/api/admin/payment-settings/${data.provider}`,
        method: 'PUT',
        data: data.settings
      });
    },
    onSuccess: () => {
      toast({
        title: "Payment settings updated",
        description: "Your changes have been saved successfully.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/payment-settings'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update settings",
        description: "An error occurred while saving. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Update general settings mutation
  const updateGeneralSettings = useMutation({
    mutationFn: async (data: typeof generalSettings) => {
      return apiRequest({
        url: '/api/admin/payment-settings/general',
        method: 'PUT',
        data
      });
    },
    onSuccess: () => {
      toast({
        title: "General settings updated",
        description: "Your changes have been saved successfully.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update settings",
        description: "An error occurred while saving. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Test connection mutation
  const testConnection = useMutation({
    mutationFn: async (data: {
      provider: string;
    }) => {
      return apiRequest<{ success: boolean; message: string }>({
        url: `/api/admin/payment-settings/${data.provider}/test`,
        method: 'POST'
      });
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Connection successful",
          description: data.message || "Successfully connected to the payment provider.",
          variant: "default",
        });
      } else {
        toast({
          title: "Connection failed",
          description: data.message || "Failed to connect to the payment provider.",
          variant: "destructive",
        });
      }
    },
    onError: () => {
      toast({
        title: "Connection test failed",
        description: "Could not test the connection. Please check your settings.",
        variant: "destructive",
      });
    }
  });
  
  // Initialize form data when API data is loaded
  useEffect(() => {
    if (paymentProviders && paymentProviders.length > 0) {
      const paypal = paymentProviders.find(p => p.providerName === 'paypal');
      const stripe = paymentProviders.find(p => p.providerName === 'stripe');
      
      if (paypal) {
        setPaypalSettings({
          isActive: paypal.isActive,
          clientId: paypal.clientId || '',
          secretKey: paypal.secretKey || '',
          mode: paypal.mode,
          supportedCurrencies: paypal.supportedCurrencies,
          settings: paypal.settings
        });
      }
      
      if (stripe) {
        setStripeSettings({
          isActive: stripe.isActive,
          apiKey: stripe.apiKey || '',
          webhookSecret: stripe.webhookSecret || '',
          mode: stripe.mode,
          supportedCurrencies: stripe.supportedCurrencies,
          settings: stripe.settings
        });
      }
    }
  }, [paymentProviders]);
  
  // Handle PayPal settings form submission
  const handlePayPalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      await updateSettings.mutateAsync({
        provider: 'paypal',
        settings: paypalSettings
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  // Handle Stripe settings form submission
  const handleStripeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      await updateSettings.mutateAsync({
        provider: 'stripe',
        settings: stripeSettings
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  // Handle general settings form submission
  const handleGeneralSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      await updateGeneralSettings.mutateAsync(generalSettings);
    } finally {
      setIsSaving(false);
    }
  };
  
  // Test connection with payment provider
  const handleTestConnection = async (provider: string) => {
    setTestingConnection(true);
    
    try {
      await testConnection.mutateAsync({ provider });
    } finally {
      setTestingConnection(false);
    }
  };
  
  return (
    <div className="container mx-auto py-10 space-y-8">
      <div className="flex flex-col">
        <h1 className="text-3xl font-bold tracking-tight mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Payment Settings
        </h1>
        <p className="text-muted-foreground">
          Configure payment providers and manage subscription settings
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 w-full mb-8">
          <TabsTrigger value="paypal">
            <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
              <path d="M7.996 0H19.26c0.012 0 0.025 0 0.039 0 2.203 0 3.994 1.791 3.994 3.994 0 0.514-0.098 1.006-0.276 1.458l0.010-0.027c-1.222 5.264-5.397 9.061-10.283 10.318l-0.096 0.022c-0.609 0.176-1.309 0.277-2.033 0.277-0.401 0-0.797-0.031-1.183-0.092l0.044 0.006c-1.355-0.228-2.547-0.802-3.543-1.614L5.92 14.334c-0.863-0.715-1.508-1.667-1.85-2.758l-0.013-0.047c-0.18-0.485-0.284-1.046-0.284-1.632 0-0.019 0-0.038 0-0.057l-0 0.003c0.013-2.188 1.792-3.962 3.981-3.962 0.010 0 0.019 0 0.029 0L7.996 0z" />
            </svg>
            PayPal
          </TabsTrigger>
          <TabsTrigger value="stripe">
            <CreditCard className="h-4 w-4 mr-2" />
            Stripe
          </TabsTrigger>
          <TabsTrigger value="general">
            <Settings className="h-4 w-4 mr-2" />
            General Settings
          </TabsTrigger>
        </TabsList>
        
        {/* PayPal Settings Tab */}
        <TabsContent value="paypal">
          <Card>
            <form onSubmit={handlePayPalSubmit}>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-xl flex items-center">
                      <svg className="h-5 w-5 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M7.996 0H19.26c0.012 0 0.025 0 0.039 0 2.203 0 3.994 1.791 3.994 3.994 0 0.514-0.098 1.006-0.276 1.458l0.010-0.027c-1.222 5.264-5.397 9.061-10.283 10.318l-0.096 0.022c-0.609 0.176-1.309 0.277-2.033 0.277-0.401 0-0.797-0.031-1.183-0.092l0.044 0.006c-1.355-0.228-2.547-0.802-3.543-1.614L5.92 14.334c-0.863-0.715-1.508-1.667-1.85-2.758l-0.013-0.047c-0.18-0.485-0.284-1.046-0.284-1.632 0-0.019 0-0.038 0-0.057l-0 0.003c0.013-2.188 1.792-3.962 3.981-3.962 0.010 0 0.019 0 0.029 0L7.996 0z" />
                      </svg>
                      PayPal Configuration
                    </CardTitle>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="paypal-active" className="cursor-pointer">Active</Label>
                    <Switch 
                      id="paypal-active" 
                      checked={paypalSettings.isActive}
                      onCheckedChange={(checked) => 
                        setPaypalSettings(prev => ({ ...prev, isActive: checked }))
                      }
                    />
                  </div>
                </div>
                <CardDescription>
                  Configure PayPal integration for accepting payments
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="paypal-client-id">Client ID</Label>
                  <Input 
                    id="paypal-client-id" 
                    placeholder="PayPal Client ID"
                    value={paypalSettings.clientId}
                    onChange={(e) => 
                      setPaypalSettings(prev => ({ ...prev, clientId: e.target.value }))
                    }
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    Your PayPal Client ID from the PayPal Developer Dashboard
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="paypal-secret-key">Secret Key</Label>
                  <Input 
                    id="paypal-secret-key" 
                    type="password"
                    placeholder="PayPal Secret Key"
                    value={paypalSettings.secretKey}
                    onChange={(e) => 
                      setPaypalSettings(prev => ({ ...prev, secretKey: e.target.value }))
                    }
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    Your PayPal Secret Key from the PayPal Developer Dashboard
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label>Mode</Label>
                  <div className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="paypal-sandbox" 
                        name="paypal-mode"
                        value="sandbox"
                        checked={paypalSettings.mode === 'sandbox'}
                        onChange={() => 
                          setPaypalSettings(prev => ({ ...prev, mode: 'sandbox' }))
                        }
                        className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                      />
                      <Label htmlFor="paypal-sandbox" className="text-sm font-normal cursor-pointer">
                        Sandbox (Testing)
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="paypal-live" 
                        name="paypal-mode"
                        value="live"
                        checked={paypalSettings.mode === 'live'}
                        onChange={() => 
                          setPaypalSettings(prev => ({ ...prev, mode: 'live' }))
                        }
                        className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                      />
                      <Label htmlFor="paypal-live" className="text-sm font-normal cursor-pointer">
                        Live (Production)
                      </Label>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Advanced Settings</Label>
                  <div className="bg-muted rounded-md p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="paypal-auto-capture" className="text-sm cursor-pointer">
                        Auto-capture payments
                      </Label>
                      <Switch 
                        id="paypal-auto-capture" 
                        checked={paypalSettings.settings.autoCapture}
                        onCheckedChange={(checked) => 
                          setPaypalSettings(prev => ({
                            ...prev,
                            settings: { ...prev.settings, autoCapture: checked }
                          }))
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="paypal-guest-checkout" className="text-sm cursor-pointer">
                        Allow guest checkout
                      </Label>
                      <Switch 
                        id="paypal-guest-checkout" 
                        checked={paypalSettings.settings.allowGuestCheckout}
                        onCheckedChange={(checked) => 
                          setPaypalSettings(prev => ({
                            ...prev,
                            settings: { ...prev.settings, allowGuestCheckout: checked }
                          }))
                        }
                      />
                    </div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button 
                    type="button"
                    variant="outline"
                    size="sm"
                    disabled={!paypalSettings.clientId || !paypalSettings.secretKey || testingConnection}
                    onClick={() => handleTestConnection('paypal')}
                    className="flex items-center"
                  >
                    {testingConnection ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Testing Connection...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Test Connection
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Reset form to initial values
                    if (paymentProviders) {
                      const paypal = paymentProviders.find(p => p.providerName === 'paypal');
                      if (paypal) {
                        setPaypalSettings({
                          isActive: paypal.isActive,
                          clientId: paypal.clientId || '',
                          secretKey: paypal.secretKey || '',
                          mode: paypal.mode,
                          supportedCurrencies: paypal.supportedCurrencies,
                          settings: paypal.settings
                        });
                      }
                    }
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={isSaving || updateSettings.isPending}
                >
                  {isSaving || updateSettings.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Configuration
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
        
        {/* Stripe Settings Tab */}
        <TabsContent value="stripe">
          <Card>
            <form onSubmit={handleStripeSubmit}>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-xl flex items-center">
                      <CreditCard className="h-5 w-5 mr-2" />
                      Stripe Configuration
                    </CardTitle>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="stripe-active" className="cursor-pointer">Active</Label>
                    <Switch 
                      id="stripe-active" 
                      checked={stripeSettings.isActive}
                      onCheckedChange={(checked) => 
                        setStripeSettings(prev => ({ ...prev, isActive: checked }))
                      }
                    />
                  </div>
                </div>
                <CardDescription>
                  Configure Stripe integration for accepting payments
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="stripe-api-key">API Key</Label>
                  <Input 
                    id="stripe-api-key" 
                    placeholder="Stripe API Key"
                    value={stripeSettings.apiKey}
                    onChange={(e) => 
                      setStripeSettings(prev => ({ ...prev, apiKey: e.target.value }))
                    }
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    Your Stripe API Key from the Stripe Dashboard
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="stripe-webhook-secret">Webhook Secret</Label>
                  <Input 
                    id="stripe-webhook-secret" 
                    type="password"
                    placeholder="Stripe Webhook Secret"
                    value={stripeSettings.webhookSecret}
                    onChange={(e) => 
                      setStripeSettings(prev => ({ ...prev, webhookSecret: e.target.value }))
                    }
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    Your Stripe Webhook Secret for handling events
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label>Mode</Label>
                  <div className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="stripe-sandbox" 
                        name="stripe-mode"
                        value="sandbox"
                        checked={stripeSettings.mode === 'sandbox'}
                        onChange={() => 
                          setStripeSettings(prev => ({ ...prev, mode: 'sandbox' }))
                        }
                        className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                      />
                      <Label htmlFor="stripe-sandbox" className="text-sm font-normal cursor-pointer">
                        Test Mode
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="stripe-live" 
                        name="stripe-mode"
                        value="live"
                        checked={stripeSettings.mode === 'live'}
                        onChange={() => 
                          setStripeSettings(prev => ({ ...prev, mode: 'live' }))
                        }
                        className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                      />
                      <Label htmlFor="stripe-live" className="text-sm font-normal cursor-pointer">
                        Live Mode
                      </Label>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Advanced Settings</Label>
                  <div className="bg-muted rounded-md p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="stripe-auto-capture" className="text-sm cursor-pointer">
                        Auto-capture payments
                      </Label>
                      <Switch 
                        id="stripe-auto-capture" 
                        checked={stripeSettings.settings.autoCapture}
                        onCheckedChange={(checked) => 
                          setStripeSettings(prev => ({
                            ...prev,
                            settings: { ...prev.settings, autoCapture: checked }
                          }))
                        }
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="stripe-statement-descriptor" className="text-sm">
                        Statement Descriptor
                      </Label>
                      <Input 
                        id="stripe-statement-descriptor" 
                        value={stripeSettings.settings.statementDescriptor || ''}
                        onChange={(e) => 
                          setStripeSettings(prev => ({
                            ...prev,
                            settings: { ...prev.settings, statementDescriptor: e.target.value }
                          }))
                        }
                        maxLength={22}
                        placeholder="Company name (max 22 chars)"
                      />
                      <p className="text-xs text-muted-foreground">
                        This will appear on your customer's credit card statement
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button 
                    type="button"
                    variant="outline"
                    size="sm"
                    disabled={!stripeSettings.apiKey || !stripeSettings.webhookSecret || testingConnection}
                    onClick={() => handleTestConnection('stripe')}
                    className="flex items-center"
                  >
                    {testingConnection ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Testing Connection...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Test Connection
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Reset form to initial values
                    if (paymentProviders) {
                      const stripe = paymentProviders.find(p => p.providerName === 'stripe');
                      if (stripe) {
                        setStripeSettings({
                          isActive: stripe.isActive,
                          apiKey: stripe.apiKey || '',
                          webhookSecret: stripe.webhookSecret || '',
                          mode: stripe.mode,
                          supportedCurrencies: stripe.supportedCurrencies,
                          settings: stripe.settings
                        });
                      }
                    }
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={isSaving || updateSettings.isPending}
                >
                  {isSaving || updateSettings.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Configuration
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
        
        {/* General Settings Tab */}
        <TabsContent value="general">
          <Card>
            <form onSubmit={handleGeneralSettingsSubmit}>
              <CardHeader>
                <CardTitle className="text-xl flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  General Payment Settings
                </CardTitle>
                <CardDescription>
                  Configure global settings for payments and subscriptions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium">Subscription Settings</h3>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-renewal" className="cursor-pointer">
                      Enable automatic renewal
                    </Label>
                    <Switch 
                      id="auto-renewal" 
                      checked={generalSettings.enableAutomaticRenewal}
                      onCheckedChange={(checked) => 
                        setGeneralSettings(prev => ({ ...prev, enableAutomaticRenewal: checked }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="payment-reminders" className="cursor-pointer">
                      Send payment reminders
                    </Label>
                    <Switch 
                      id="payment-reminders" 
                      checked={generalSettings.sendPaymentReminders}
                      onCheckedChange={(checked) => 
                        setGeneralSettings(prev => ({ ...prev, sendPaymentReminders: checked }))
                      }
                    />
                  </div>
                  
                  {generalSettings.sendPaymentReminders && (
                    <div className="space-y-2">
                      <Label htmlFor="reminder-days">Days before expiration to send reminder</Label>
                      <Input 
                        id="reminder-days" 
                        type="number"
                        min={1}
                        max={30}
                        value={generalSettings.reminderDaysBefore}
                        onChange={(e) => 
                          setGeneralSettings(prev => ({ 
                            ...prev, 
                            reminderDaysBefore: parseInt(e.target.value) || 7
                          }))
                        }
                      />
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="allow-cancellations" className="cursor-pointer">
                      Allow subscription cancellations
                    </Label>
                    <Switch 
                      id="allow-cancellations" 
                      checked={generalSettings.allowCancellations}
                      onCheckedChange={(checked) => 
                        setGeneralSettings(prev => ({ ...prev, allowCancellations: checked }))
                      }
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="font-medium">Payment Settings</h3>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="billing-address" className="cursor-pointer">
                      Require billing address
                    </Label>
                    <Switch 
                      id="billing-address" 
                      checked={generalSettings.requireBillingAddress}
                      onCheckedChange={(checked) => 
                        setGeneralSettings(prev => ({ ...prev, requireBillingAddress: checked }))
                      }
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="default-currency">Default Currency</Label>
                    <select
                      id="default-currency"
                      value={generalSettings.defaultCurrency}
                      onChange={(e) => 
                        setGeneralSettings(prev => ({ ...prev, defaultCurrency: e.target.value }))
                      }
                      className="w-full p-2 rounded-md border border-input bg-background"
                    >
                      <option value="USD">USD - US Dollar</option>
                      <option value="EUR">EUR - Euro</option>
                      <option value="GBP">GBP - British Pound</option>
                      <option value="CAD">CAD - Canadian Dollar</option>
                      <option value="AUD">AUD - Australian Dollar</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tax-percentage">Tax Percentage</Label>
                    <Input 
                      id="tax-percentage" 
                      type="number"
                      min={0}
                      max={100}
                      step={0.01}
                      value={generalSettings.taxPercentage}
                      onChange={(e) => 
                        setGeneralSettings(prev => ({ 
                          ...prev, 
                          taxPercentage: parseFloat(e.target.value) || 0
                        }))
                      }
                    />
                    <p className="text-sm text-muted-foreground">
                      Enter 0 for no tax, or the applicable tax rate percentage
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="promo-codes" className="cursor-pointer">
                      Enable promotional codes
                    </Label>
                    <Switch 
                      id="promo-codes" 
                      checked={generalSettings.enablePromoCode}
                      onCheckedChange={(checked) => 
                        setGeneralSettings(prev => ({ ...prev, enablePromoCode: checked }))
                      }
                    />
                  </div>
                </div>
                
                <div className="px-4 py-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-md">
                  <div className="flex">
                    <AlertCircle className="h-5 w-5 text-amber-600 mr-2 flex-shrink-0" />
                    <div className="text-sm text-amber-800 dark:text-amber-300">
                      <p className="font-medium">Important Note</p>
                      <p>Changes to payment settings may affect active subscriptions and billing cycles. Please review carefully before saving.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button 
                  type="submit"
                  disabled={isSaving || updateGeneralSettings.isPending}
                >
                  {isSaving || updateGeneralSettings.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Settings
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}