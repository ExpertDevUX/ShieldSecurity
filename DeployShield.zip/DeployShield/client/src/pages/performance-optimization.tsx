import { useState } from "react";
import { 
  Zap, 
  Globe, 
  Database, 
  Code, 
  Image, 
  FileJson, 
  GripVertical,
  Check,
  FileSearch,
  ArrowRight,
  RefreshCcw,
  Lightbulb,
  Settings,
  Copy,
  Download,
  Save,
  Share2,
  Terminal,
  BookOpen,
  LayoutGrid
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import OnlineIDE from "@/components/code-optimization/OnlineIDE";

type OptimizationArea = {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  status: "idle" | "analyzing" | "optimizing" | "complete";
  score?: number;
  issues?: Array<{
    id: string;
    description: string;
    severity: "high" | "medium" | "low";
    suggestion: string;
    code?: string;
  }>;
};

export default function PerformanceOptimizationPage() {
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState<"idle" | "analyzing" | "optimizing" | "complete">("idle");
  const [activeTab, setActiveTab] = useState("configure");
  const [selectedDevice, setSelectedDevice] = useState("mobile");
  const [optimizationSettings, setOptimizationSettings] = useState({
    bundleSize: true,
    imageCompression: true,
    codeOptimization: true,
    fontOptimization: true,
    apiOptimization: true,
    databaseIndexing: true,
  });
  
  // Fetch existing page speed analyses to display history
  const { data: pageSpeedData = [] } = useQuery<any[]>({
    queryKey: ["/api/page-speed-analyses"],
    enabled: activeTab === "history"
  });
  
  const [optimizationAreas, setOptimizationAreas] = useState<OptimizationArea[]>([
    {
      id: "frontend",
      title: "Frontend Assets",
      description: "Optimize images, JavaScript, and CSS files",
      icon: <Globe className="h-6 w-6" />,
      status: "idle",
    },
    {
      id: "database",
      title: "Database Queries",
      description: "Analyze and optimize slow database queries",
      icon: <Database className="h-6 w-6" />,
      status: "idle",
    },
    {
      id: "code",
      title: "Code Performance",
      description: "Identify and fix performance bottlenecks in code",
      icon: <Code className="h-6 w-6" />,
      status: "idle",
    },
    {
      id: "images",
      title: "Image Optimization",
      description: "Compress and optimize image assets",
      icon: <Image className="h-6 w-6" />,
      status: "idle",
    },
    {
      id: "api",
      title: "API Response Time",
      description: "Improve API response time and caching",
      icon: <FileJson className="h-6 w-6" />,
      status: "idle",
    },
  ]);

  const startOptimization = async () => {
    setIsRunning(true);
    setStep("analyzing");
    setProgress(0);
    
    // Reset all optimization areas
    setOptimizationAreas(prev => 
      prev.map(area => ({
        ...area,
        status: "idle",
        issues: undefined,
        score: undefined
      }))
    );

    let currentProgress = 0;
    const progressIntervalId = setInterval(() => {
      if (currentProgress < 100) {
        currentProgress += 1;
        setProgress(currentProgress);
      } else {
        clearInterval(progressIntervalId);
      }
    }, 100);

    try {
      // Filter areas to optimize based on user settings
      const areasToOptimize = optimizationAreas.filter(area => {
        // Apply filter based on settings
        if (area.id === "frontend" && !optimizationSettings.bundleSize) return false;
        if (area.id === "images" && !optimizationSettings.imageCompression) return false;
        if (area.id === "code" && !optimizationSettings.codeOptimization) return false;
        if (area.id === "api" && !optimizationSettings.apiOptimization) return false;
        if (area.id === "database" && !optimizationSettings.databaseIndexing) return false;
        return true;
      });

      if (areasToOptimize.length === 0) {
        toast({
          title: "No Areas Selected",
          description: "Please enable at least one optimization area in the configuration.",
          variant: "destructive",
        });
        clearInterval(progressIntervalId);
        setProgress(100);
        setIsRunning(false);
        return;
      }
      
      // Fetch projects data properly
      let projectId = 1; // Default to 1 if no projects available
      try {
        const projects = await queryClient.fetchQuery({ 
          queryKey: ["/api/projects"]
        });
        
        // Get the project ID (use the first one if available, or default to 1)
        if (projects && Array.isArray(projects) && projects.length > 0) {
          projectId = projects[0].id;
        }
      } catch (error) {
        console.error("Failed to fetch projects:", error);
      }
      
      // Build the optimization types array based on selected settings
      const optimizationTypes: string[] = [];
      if (optimizationSettings.bundleSize) optimizationTypes.push("javascript");
      if (optimizationSettings.imageCompression) optimizationTypes.push("image");
      if (optimizationSettings.codeOptimization) optimizationTypes.push("compression");
      if (optimizationSettings.apiOptimization) optimizationTypes.push("caching");
      if (optimizationSettings.databaseIndexing) optimizationTypes.push("database");
      
      // Create an initial performance optimization record
      const response = await apiRequest('/api/performance-optimizations', 
        JSON.stringify({
          projectId,
          optimizationTypes,
          status: "in_progress",
          beforeScore: 0, // Initial score (will be updated as we analyze)
        }),
        { method: 'POST' }
      );
      
      const optimizationId = response.id;
      
      // Create an analysis task for the current settings (still maintain this for history)
      await apiRequest('/api/page-speed-analyses', 
        JSON.stringify({
          url: "https://example.com/optimization-wizard",
          score: 0, // Will be updated after analysis
          deviceType: selectedDevice,
          metrics: {
            analysisStart: new Date().toISOString(),
            selectedOptions: optimizationTypes,
            device: selectedDevice
          }
        }),
        { method: 'POST' }
      );
      
      // If history tab is active, invalidate queries to refresh the data
      if (activeTab === "history") {
        queryClient.invalidateQueries({ queryKey: ["/api/page-speed-analyses"] });
      }
      
      // Analysis results object to collect all results
      const allResults: Record<string, any> = {};
      let totalBeforeScore = 0;
      
      // Analyze each optimization area one by one
      for (let i = 0; i < areasToOptimize.length; i++) {
        const area = areasToOptimize[i];
        
        // Update status to analyzing
        setOptimizationAreas(prev => 
          prev.map(a => a.id === area.id ? { ...a, status: "analyzing" } : a)
        );
        
        // Update the optimization status to in_progress
        await apiRequest(`/api/performance-optimizations/${optimizationId}/status`, 
          JSON.stringify({ status: "in_progress" }),
          { method: 'PUT' }
        );
        
        // Use realistic time for analysis
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Generate analysis results
        const analysisResults = await generateMockAnalysis(area.id);
        allResults[area.id] = analysisResults;
        totalBeforeScore += analysisResults.score;
        
        // Update with analysis results
        setOptimizationAreas(prev => 
          prev.map(a => a.id === area.id ? { 
            ...a, 
            status: "optimizing",
            score: analysisResults.score,
            issues: analysisResults.issues
          } : a)
        );
        
        // Simulate optimization process
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mark as complete
        setOptimizationAreas(prev => 
          prev.map(a => a.id === area.id ? { ...a, status: "complete" } : a)
        );
      }
      
      // Calculate average before score
      const averageBeforeScore = Math.round(totalBeforeScore / areasToOptimize.length);
      
      // Calculate after score (simulate improvement)
      const afterScore = Math.min(100, Math.round(averageBeforeScore * (1 + Math.random() * 0.3)));
      
      // Generate recommendations and applied changes summary
      const recommendations = areasToOptimize.flatMap(area => 
        (allResults[area.id]?.issues || []).map((issue: any) => ({
          area: area.id,
          description: issue.suggestion,
          priority: issue.severity
        }))
      );
      
      // Applied changes summary
      const appliedChanges = {
        summary: `Optimized ${areasToOptimize.length} areas with ${recommendations.length} improvements`,
        timestamp: new Date().toISOString(),
        device: selectedDevice,
        scoreImprovement: afterScore - averageBeforeScore,
        areas: areasToOptimize.map(area => ({
          id: area.id,
          title: area.title,
          changesApplied: (allResults[area.id]?.issues || []).length
        }))
      };
      
      // Complete the performance optimization
      await apiRequest(`/api/performance-optimizations/${optimizationId}/complete`, 
        JSON.stringify({
          results: allResults,
          afterScore,
          appliedChanges
        }),
        { method: 'PUT' }
      );
      
      // All areas completed
      setStep("complete");
      
      toast({
        title: "Optimization Complete",
        description: `Score improved from ${averageBeforeScore} to ${afterScore} for ${selectedDevice} device.`,
      });
      
      // Switch to history tab to show results
      setActiveTab("history");
      
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/page-speed-analyses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/performance-optimizations"] });
      
    } catch (error) {
      console.error("Optimization error:", error);
      toast({
        title: "Optimization Failed",
        description: "There was an error during the optimization process.",
        variant: "destructive",
      });
    } finally {
      clearInterval(progressIntervalId);
      setProgress(100);
      setIsRunning(false);
    }
  };

  // Function to generate analysis results - in real app, this would call an API
  const generateMockAnalysis = async (areaId: string) => {
    try {
      // In a production app, we'd make a real API request here
      // For now, simulate a server call by creating a page speed analysis
      
      let sampleUrl = "";
      let deviceType = "mobile";
      
      switch (areaId) {
        case "frontend":
          sampleUrl = "https://example.com/home";
          break;
        case "database":
          sampleUrl = "https://example.com/api/data";
          deviceType = "desktop";
          break;
        case "code":
          sampleUrl = "https://example.com/app";
          break;
        case "images":
          sampleUrl = "https://example.com/gallery";
          break;
        case "api":
          sampleUrl = "https://example.com/api/endpoint";
          deviceType = "desktop";
          break;
        default:
          sampleUrl = "https://example.com";
      }
      
      // Generate random score between 60-100
      const score = Math.floor(Math.random() * 40) + 60;
      
      // Create sample metrics based on the area
      const getMetrics = () => {
        const baseMetrics = {
          firstContentfulPaint: Math.random() * 2 + 0.5,
          largestContentfulPaint: Math.random() * 3 + 0.8,
          cumulativeLayoutShift: Math.random() * 0.2,
          totalBlockingTime: Math.random() * 300,
          speedIndex: Math.random() * 4 + 1
        };
        
        return baseMetrics;
      };
      
      // Create a page speed analysis record
      await apiRequest('/api/page-speed-analyses', 
        JSON.stringify({
          url: sampleUrl,
          score: score,
          deviceType: deviceType,
          metrics: getMetrics()
        }),
        { method: 'POST' }
      );
      
      // Generate mock issues based on the area
      const mockIssues = {
        frontend: [
          {
            id: "f1",
            description: "Large uncompressed JavaScript bundles",
            severity: "high" as const,
            suggestion: "Implement code splitting and enable compression",
            code: "// Before\nimport { entireLibrary } from 'large-lib';\n\n// After\nimport { onlyNeededFunction } from 'large-lib/function';",
          },
          {
            id: "f2",
            description: "Render-blocking CSS",
            severity: "medium" as const,
            suggestion: "Use critical CSS and defer non-critical styles",
          },
        ],
        database: [
          {
            id: "d1",
            description: "Missing index on frequently queried column",
            severity: "high" as const,
            suggestion: "Add index to improve query performance",
            code: "CREATE INDEX idx_user_email ON users(email);",
          },
          {
            id: "d2",
            description: "N+1 query problem in user relationships",
            severity: "high" as const,
            suggestion: "Use eager loading with JOIN clauses",
            code: "// Before\nconst users = await User.findAll();\nfor (const user of users) {\n  await user.getPosts();\n}\n\n// After\nconst users = await User.findAll({\n  include: [{ model: Post }]\n});",
          },
        ],
        code: [
          {
            id: "c1",
            description: "Inefficient list rendering with nested loops",
            severity: "medium" as const,
            suggestion: "Use memoization and virtualized lists for large datasets",
            code: "// Before\n{items.map(item => (\n  <div key={item.id}>\n    {item.subItems.map(subItem => (\n      <SubItem key={subItem.id} data={subItem} />\n    ))}\n  </div>\n))}\n\n// After\n{items.map(item => (\n  <MemoizedItem key={item.id} item={item} />\n))}",
          },
        ],
        images: [
          {
            id: "i1",
            description: "Large unoptimized image files",
            severity: "high" as const,
            suggestion: "Compress images and use responsive image sizing",
          },
          {
            id: "i2",
            description: "Images without width/height attributes",
            severity: "low" as const,
            suggestion: "Add explicit width and height to prevent layout shifts",
            code: '<img src="image.jpg" width="800" height="600" loading="lazy" />',
          },
        ],
        api: [
          {
            id: "a1",
            description: "API responses not being cached",
            severity: "medium" as const,
            suggestion: "Implement proper cache headers and client-side caching",
            code: "// Server-side\nres.setHeader('Cache-Control', 'max-age=3600');\n\n// Client-side\nconst { data } = useQuery(['key'], fetcher, {\n  staleTime: 60 * 60 * 1000, // 1 hour\n});",
          },
        ],
      };

      return {
        score: score,
        issues: mockIssues[areaId as keyof typeof mockIssues] || [],
      };
    } catch (error) {
      console.error("Error generating analysis:", error);
      // Fallback to random score if API call fails
      return {
        score: Math.floor(Math.random() * 40) + 60,
        issues: [],
      };
    }
  };

  const getOverallScore = () => {
    const completedAreas = optimizationAreas.filter(area => area.score !== undefined);
    if (completedAreas.length === 0) return 0;
    
    const totalScore = completedAreas.reduce((sum, area) => sum + (area.score || 0), 0);
    return Math.round(totalScore / completedAreas.length);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
      case "medium": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
      case "low": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "analyzing": return <FileSearch className="animate-pulse h-5 w-5 text-blue-500" />;
      case "optimizing": return <RefreshCcw className="animate-spin h-5 w-5 text-amber-500" />;
      case "complete": return <Check className="h-5 w-5 text-green-500" />;
      default: return <GripVertical className="h-5 w-5 text-gray-400" />;
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Zap className="h-8 w-8 text-amber-500" />
          Performance Optimization Wizard
        </h1>
        <p className="text-muted-foreground">
          Automatically analyze and optimize your application's performance with one click
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Analysis</CardTitle>
              <CardDescription>
                Select areas to analyze and optimize for better performance
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {optimizationAreas.map((area) => (
                <div key={area.id} className="flex items-start gap-4 p-4 border rounded-lg">
                  <div className="mt-1 p-2 bg-primary/10 rounded-lg flex-shrink-0">
                    {area.icon}
                  </div>
                  <div className="flex-grow space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">{area.title}</h3>
                      <div className="flex items-center gap-2">
                        {area.score !== undefined && (
                          <Badge variant={area.score > 80 ? "default" : area.score > 60 ? "outline" : "destructive"}>
                            Score: {area.score}
                          </Badge>
                        )}
                        {getStatusIcon(area.status)}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{area.description}</p>
                    
                    {area.issues && area.issues.length > 0 && (
                      <div className="mt-3 space-y-3">
                        <Separator />
                        <h4 className="text-sm font-medium">Issues Found:</h4>
                        <div className="space-y-2">
                          {area.issues.map(issue => (
                            <div key={issue.id} className="space-y-2">
                              <div className="flex gap-2 items-start">
                                <Badge className={getSeverityColor(issue.severity)}>
                                  {issue.severity}
                                </Badge>
                                <p className="text-sm">{issue.description}</p>
                              </div>
                              <p className="text-sm flex items-center gap-1 text-muted-foreground">
                                <Lightbulb className="h-4 w-4" />
                                <span>{issue.suggestion}</span>
                              </p>
                              {issue.code && (
                                <pre className="text-xs bg-slate-100 dark:bg-slate-800 p-2 rounded overflow-x-auto">
                                  {issue.code}
                                </pre>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
            <CardFooter>
              <Button 
                size="lg" 
                className="w-full"
                onClick={startOptimization}
                disabled={isRunning}
              >
                {isRunning ? (
                  <>
                    <RefreshCcw className="mr-2 h-4 w-4 animate-spin" />
                    {step === "analyzing" ? "Analyzing..." : step === "optimizing" ? "Optimizing..." : "Processing..."}
                  </>
                ) : (
                  <>
                    Run One-Click Optimization
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <Terminal className="h-6 w-6 text-blue-500" />
                  Code Optimization IDE
                </h2>
                <p className="text-muted-foreground">
                  Edit, analyze, and optimize your code with performance-focused tools
                </p>
              </div>
              <div>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  Export Optimized Code
                </Button>
              </div>
            </div>
            
            <OnlineIDE />
          </div>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuration</CardTitle>
              <CardDescription>
                Configure optimization settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="configure">Setup</TabsTrigger>
                  <TabsTrigger value="device">Device</TabsTrigger>
                  <TabsTrigger value="history">History</TabsTrigger>
                </TabsList>
                <TabsContent value="configure" className="space-y-4 pt-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="bundle-size">JS Bundle Size</Label>
                        <p className="text-xs text-muted-foreground">
                          Reduce JavaScript bundle size
                        </p>
                      </div>
                      <Switch 
                        id="bundle-size" 
                        checked={optimizationSettings.bundleSize}
                        onCheckedChange={(checked) => 
                          setOptimizationSettings(prev => ({ ...prev, bundleSize: checked }))
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="image-compression">Image Compression</Label>
                        <p className="text-xs text-muted-foreground">
                          Optimize and compress images
                        </p>
                      </div>
                      <Switch 
                        id="image-compression" 
                        checked={optimizationSettings.imageCompression}
                        onCheckedChange={(checked) => 
                          setOptimizationSettings(prev => ({ ...prev, imageCompression: checked }))
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="code-optimization">Code Optimization</Label>
                        <p className="text-xs text-muted-foreground">
                          Identify and fix code performance issues
                        </p>
                      </div>
                      <Switch 
                        id="code-optimization" 
                        checked={optimizationSettings.codeOptimization}
                        onCheckedChange={(checked) => 
                          setOptimizationSettings(prev => ({ ...prev, codeOptimization: checked }))
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="font-optimization">Font Optimization</Label>
                        <p className="text-xs text-muted-foreground">
                          Optimize web fonts loading
                        </p>
                      </div>
                      <Switch 
                        id="font-optimization" 
                        checked={optimizationSettings.fontOptimization}
                        onCheckedChange={(checked) => 
                          setOptimizationSettings(prev => ({ ...prev, fontOptimization: checked }))
                        }
                      />
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="device" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button 
                      variant={selectedDevice === "mobile" ? "default" : "outline"}
                      className="flex items-center gap-2"
                      onClick={() => setSelectedDevice("mobile")}
                    >
                      <Globe className="h-4 w-4" />
                      Mobile
                    </Button>
                    <Button 
                      variant={selectedDevice === "desktop" ? "default" : "outline"}
                      className="flex items-center gap-2"
                      onClick={() => setSelectedDevice("desktop")}
                    >
                      <Globe className="h-4 w-4" />
                      Desktop
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground pt-2">
                    Select which device to optimize for. This affects how performance is measured and optimized.
                  </p>
                </TabsContent>
                
                <TabsContent value="history" className="space-y-4 pt-4">
                  <div className="space-y-4">
                    {pageSpeedData && pageSpeedData.length > 0 ? (
                      <div className="space-y-3">
                        {pageSpeedData.slice(0, 5).map((analysis: any) => (
                          <div key={analysis.id} className="flex items-center justify-between border p-2 rounded-md">
                            <div>
                              <div className="font-medium text-sm">{analysis.url}</div>
                              <div className="text-xs text-muted-foreground">
                                {new Date(analysis.analysisDate).toLocaleString()}
                              </div>
                            </div>
                            <Badge variant={analysis.score > 80 ? "default" : "outline"}>
                              Score: {analysis.score}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 text-muted-foreground">
                        <p>No previous analyses found</p>
                        <p className="text-xs">Run an optimization to start building history</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Optimization Progress</CardTitle>
              <CardDescription>
                Current progress of optimization process
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} />
              </div>
              
              <div className="mt-4 space-y-2">
                <h3 className="text-sm font-medium">Current Step</h3>
                <div className="grid grid-cols-3 gap-2">
                  <div className={`text-center p-2 rounded-lg border ${step === "analyzing" ? "bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-900" : ""}`}>
                    <span className="text-xs block">Analysis</span>
                    {step === "analyzing" && <span className="text-xs text-blue-500">In Progress</span>}
                    {step === "optimizing" || step === "complete" ? <Check className="mx-auto h-4 w-4 text-green-500 mt-1" /> : null}
                  </div>
                  <div className={`text-center p-2 rounded-lg border ${step === "optimizing" ? "bg-amber-50 border-amber-200 dark:bg-amber-900/20 dark:border-amber-900" : ""}`}>
                    <span className="text-xs block">Optimization</span>
                    {step === "optimizing" && <span className="text-xs text-amber-500">In Progress</span>}
                    {step === "complete" && <Check className="mx-auto h-4 w-4 text-green-500 mt-1" />}
                  </div>
                  <div className={`text-center p-2 rounded-lg border ${step === "complete" ? "bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900" : ""}`}>
                    <span className="text-xs block">Complete</span>
                    {step === "complete" && <span className="text-xs text-green-500">Finished</span>}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Performance Score</CardTitle>
              <CardDescription>
                Overall score after optimization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-6">
                <div className="relative w-32 h-32">
                  <svg className="w-full h-full" viewBox="0 0 100 100">
                    <circle
                      className="text-gray-200 dark:text-gray-700"
                      strokeWidth="10"
                      stroke="currentColor"
                      fill="transparent"
                      r="40"
                      cx="50"
                      cy="50"
                    />
                    <circle
                      className={`
                        ${getOverallScore() > 80 ? 'text-green-500' : getOverallScore() > 60 ? 'text-amber-500' : 'text-red-500'}
                      `}
                      strokeWidth="10"
                      strokeDasharray={`${getOverallScore() * 2.51} 251.2`}
                      strokeLinecap="round"
                      stroke="currentColor"
                      fill="transparent"
                      r="40"
                      cx="50"
                      cy="50"
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-3xl font-bold">{getOverallScore()}</span>
                  </div>
                </div>
                <p className="mt-4 text-sm text-center text-muted-foreground">
                  {getOverallScore() > 80 
                    ? "Excellent! Your application is well optimized." 
                    : getOverallScore() > 60 
                    ? "Good, but there's room for improvement."
                    : "Needs significant performance improvements."}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>
                  Key metrics from the last analysis
                </CardDescription>
              </div>
              <Download className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {step === "complete" ? (
                  <>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <span className="h-2 w-2 rounded-full bg-blue-500 mr-2"></span>
                          <span>First Contentful Paint</span>
                        </div>
                        <span className="font-medium">1.2s</span>
                      </div>
                      <Progress value={70} className="h-1.5" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                          <span>Largest Contentful Paint</span>
                        </div>
                        <span className="font-medium">2.1s</span>
                      </div>
                      <Progress value={65} className="h-1.5" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <span className="h-2 w-2 rounded-full bg-amber-500 mr-2"></span>
                          <span>Cumulative Layout Shift</span>
                        </div>
                        <span className="font-medium">0.08</span>
                      </div>
                      <Progress value={85} className="h-1.5" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <span className="h-2 w-2 rounded-full bg-red-500 mr-2"></span>
                          <span>Total Blocking Time</span>
                        </div>
                        <span className="font-medium">180ms</span>
                      </div>
                      <Progress value={60} className="h-1.5" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <span className="h-2 w-2 rounded-full bg-purple-500 mr-2"></span>
                          <span>Speed Index</span>
                        </div>
                        <span className="font-medium">2.8s</span>
                      </div>
                      <Progress value={75} className="h-1.5" />
                    </div>
                    
                    <div className="pt-2">
                      <Button variant="outline" size="sm" className="w-full mt-2">
                        <Save className="mr-2 h-4 w-4" />
                        Export Report
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-6 text-center">
                    <div className="text-muted-foreground mb-2">
                      <FileSearch className="h-10 w-10 mx-auto mb-2 opacity-50" />
                      <p>Run an optimization to see detailed metrics</p>
                    </div>
                    <p className="text-xs text-muted-foreground max-w-[200px] mx-auto mt-1">
                      Metrics will appear here after analysis is complete
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}