import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "../lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Cpu,
  Code,
  Wand2,
  Star,
  Clock,
  CheckCircle,
  XCircle,
  Copy,
  Save,
  ThumbsUp,
  ThumbsDown,
  RefreshCw,
  ExternalLink
} from "lucide-react";

const codeGenerationSchema = z.object({
  prompt: z.string().min(10, "Prompt must be at least 10 characters"),
  language: z.string().min(1, "Please select a programming language"),
  type: z.enum([
    "function",
    "component",
    "api",
    "schema",
    "test",
    "refactor",
    "optimization",
    "custom"
  ]),
  projectId: z.number().optional(),
  aiProvider: z.string().default("gemini"),
});

const CODE_TYPES = [
  { value: "function", label: "Function" },
  { value: "component", label: "UI Component" },
  { value: "api", label: "API Endpoint" },
  { value: "schema", label: "Database Schema" },
  { value: "test", label: "Unit Test" },
  { value: "refactor", label: "Code Refactoring" },
  { value: "optimization", label: "Optimization" },
  { value: "custom", label: "Custom" },
];

const LANGUAGES = [
  { value: "javascript", label: "JavaScript" },
  { value: "typescript", label: "TypeScript" },
  { value: "python", label: "Python" },
  { value: "java", label: "Java" },
  { value: "csharp", label: "C#" },
  { value: "php", label: "PHP" },
  { value: "go", label: "Go" },
  { value: "ruby", label: "Ruby" },
  { value: "rust", label: "Rust" },
  { value: "swift", label: "Swift" },
  { value: "kotlin", label: "Kotlin" },
];

const AI_PROVIDERS = [
  { value: "gemini", label: "Google Gemini" },
  { value: "openai", label: "OpenAI" },
  { value: "mock", label: "Mock Service" }, 
];

const CodeGeneration = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("generate");
  const [selectedGeneration, setSelectedGeneration] = useState<any>(null);

  // Form for creating new code generation
  const form = useForm<z.infer<typeof codeGenerationSchema>>({
    resolver: zodResolver(codeGenerationSchema),
    defaultValues: {
      prompt: "",
      language: "typescript",
      type: "function",
      aiProvider: "gemini",
    },
  });

  // Fetch projects for the project selector
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<any[]>({
    queryKey: ["/api/projects"],
    enabled: true,
  });

  // Fetch existing code generations
  const { data: codeGenerations = [], isLoading: isLoadingGenerations } = useQuery<any[]>({
    queryKey: ["/api/code-generations"],
    enabled: true,
  });

  // Create a new code generation
  const createCodeGenerationMutation = useMutation({
    mutationFn: async (formData: z.infer<typeof codeGenerationSchema>) => {
      return apiRequest("/api/code-generations", {
        method: "POST",
        data: {
          ...formData,
          projectId: formData.projectId || 1, // Default to first project if none selected
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Code Generation Request Submitted",
        description: "Your code is being generated. Please wait a moment.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/code-generations"] });
      form.reset({
        prompt: "",
        language: "typescript",
        type: "function",
        aiProvider: "gemini",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to generate code",
        description: error?.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });

  // Mark a code generation as used in project
  const markAsUsedMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/code-generations/${id}/usage`, {
        method: "PATCH",
        data: { used: true }
      });
    },
    onSuccess: () => {
      toast({
        title: "Marked as used",
        description: "This code generation has been marked as used in your project",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/code-generations"] });
    },
  });

  // Rate a code generation
  const rateCodeGenerationMutation = useMutation({
    mutationFn: async ({ id, rating }: { id: number; rating: number }) => {
      return apiRequest(`/api/code-generations/${id}/rate`, {
        method: "PATCH",
        data: { rating },
      });
    },
    onSuccess: () => {
      toast({
        title: "Rating Submitted",
        description: "Thank you for rating this code generation",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/code-generations"] });
    },
  });

  // Handle form submission
  const onSubmit = (values: z.infer<typeof codeGenerationSchema>) => {
    createCodeGenerationMutation.mutate(values);
  };

  // Handle copy to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The code has been copied to your clipboard",
    });
  };

  return (
    <div className="container px-4 py-6 mx-auto max-w-7xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">AI Code Generation</h1>
          <p className="text-muted-foreground">
            Generate code snippets, components, and more using AI
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setActiveTab("generate")}>
            <Wand2 className="w-4 h-4 mr-2" /> New Generation
          </Button>
          <Button variant="outline" onClick={() => setActiveTab("history")}>
            <Clock className="w-4 h-4 mr-2" /> History
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="generate">Generate New Code</TabsTrigger>
          <TabsTrigger value="history">Generation History</TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="mt-4">
          <Card className="border-t-4 border-t-blue-500">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Cpu className="w-5 h-5 mr-2 text-blue-500" />
                Generate Code with AI
              </CardTitle>
              <CardDescription>
                Describe what you want to create and our AI will generate the code for you.
                Be specific with your prompt for better results.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="prompt"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Prompt</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe the code you want to generate in detail. For example: 'Create a React component that displays a responsive image gallery with thumbnails and modal preview.'"
                            className="min-h-[150px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          The more detailed your prompt, the better the generated code will be.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Type of Code</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {CODE_TYPES.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="language"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Programming Language</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select language" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {LANGUAGES.map((lang) => (
                                <SelectItem key={lang.value} value={lang.value}>
                                  {lang.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="aiProvider"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>AI Provider</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select AI provider" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {AI_PROVIDERS.map((provider) => (
                                <SelectItem key={provider.value} value={provider.value}>
                                  {provider.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="projectId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project (Optional)</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          defaultValue={field.value?.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a project (optional)" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {isLoadingProjects ? (
                              <SelectItem value="loading" disabled>
                                Loading projects...
                              </SelectItem>
                            ) : (
                              projects?.map((project: any) => (
                                <SelectItem key={project.id} value={project.id.toString()}>
                                  {project.name}
                                </SelectItem>
                              ))
                            )}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Link this generation to a specific project
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={createCodeGenerationMutation.isPending}
                  >
                    {createCodeGenerationMutation.isPending ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-4 h-4 mr-2" />
                        Generate Code
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <div className="grid grid-cols-1 gap-6">
            {isLoadingGenerations ? (
              // Loading skeleton
              Array.from({ length: 3 }).map((_, i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-8 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-28 w-full" />
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-10 w-full" />
                  </CardFooter>
                </Card>
              ))
            ) : codeGenerations && codeGenerations.length > 0 ? (
              // Actual code generations
              codeGenerations.map((generation: any) => (
                <Card key={generation.id} className={`${generation.result ? 'border-l-4 border-l-green-500' : 'border-l-4 border-l-amber-500'}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl">
                        {CODE_TYPES.find(type => type.value === generation.type)?.label || generation.type}
                        <span className="ml-2">
                          <Badge variant={generation.result ? "default" : "outline"}>
                            {generation.result ? "Completed" : "Processing"}
                          </Badge>
                        </span>
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">
                          {LANGUAGES.find(lang => lang.value === generation.language)?.label || generation.language}
                        </Badge>
                        <Badge variant="secondary">
                          {AI_PROVIDERS.find(provider => provider.value === generation.aiProvider)?.label || generation.aiProvider}
                        </Badge>
                        {generation.rating && (
                          <Badge variant="outline" className="bg-yellow-100">
                            <Star className="w-3 h-3 mr-1 text-yellow-500" fill="currentColor" />
                            {generation.rating}/5
                          </Badge>
                        )}
                        {generation.usedInProject && (
                          <Badge variant="outline" className="bg-green-100 text-green-800">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Used
                          </Badge>
                        )}
                      </div>
                    </div>
                    <CardDescription>
                      <strong>Prompt:</strong> {generation.prompt}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {generation.result ? (
                      <div className="relative">
                        <pre className="p-4 overflow-x-auto text-sm bg-gray-100 rounded-md dark:bg-gray-800">
                          <code>{generation.result}</code>
                        </pre>
                        <div className="absolute top-2 right-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(generation.result)}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center p-6 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <RefreshCw className="w-6 h-6 mr-2 animate-spin text-muted-foreground" />
                        <span className="text-muted-foreground">Generating code...</span>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <div className="text-sm text-muted-foreground">
                      Created: {new Date(generation.createdAt).toLocaleString()}
                    </div>
                    <div className="flex gap-2">
                      {generation.result && !generation.usedInProject && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => markAsUsedMutation.mutate(generation.id)}
                        >
                          <Save className="w-4 h-4 mr-1" />
                          Mark as Used
                        </Button>
                      )}
                      {generation.result && !generation.rating && (
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => rateCodeGenerationMutation.mutate({ id: generation.id, rating: 5 })}
                          >
                            <ThumbsUp className="w-4 h-4 mr-1" />
                            Good
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => rateCodeGenerationMutation.mutate({ id: generation.id, rating: 2 })}
                          >
                            <ThumbsDown className="w-4 h-4 mr-1" />
                            Needs Work
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardFooter>
                </Card>
              ))
            ) : (
              // No results
              <Card className="p-8 text-center">
                <div className="mb-4">
                  <Code className="w-12 h-12 mx-auto text-gray-400" />
                </div>
                <CardTitle className="mb-2">No code generations yet</CardTitle>
                <CardDescription>
                  Start by creating your first code generation in the 'Generate New Code' tab.
                </CardDescription>
                <Button 
                  className="mt-4" 
                  onClick={() => setActiveTab('generate')}
                >
                  Create Your First Generation
                </Button>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CodeGeneration;