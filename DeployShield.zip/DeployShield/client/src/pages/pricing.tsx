import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function PricingPage() {
  const { toast } = useToast();

  const handlePlanSelection = (plan: string) => {
    toast({
      title: "Plan Selected",
      description: `You've selected the ${plan} plan. This feature will be available soon.`,
      duration: 5000,
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold tracking-tight mb-4">
          Choose the Right <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-blue-500">Plan</span> for Your Needs
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          From individual developers to large enterprises, we have a pricing option that suits your security and deployment requirements.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {/* Free Tier */}
        <Card className="border-2 border-border">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Free</CardTitle>
            <div className="mt-4 mb-2">
              <span className="text-4xl font-bold">$0</span>
              <span className="text-muted-foreground ml-1">/month</span>
            </div>
            <CardDescription>Perfect for personal projects and small websites</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Basic security scanning</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Single-platform deployment</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Basic SEO analysis</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Performance recommendations</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>3 projects limit</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={() => handlePlanSelection("Free")}>
              Get Started
            </Button>
          </CardFooter>
        </Card>
        
        {/* Pro Tier */}
        <Card className="border-2 border-primary relative">
          <div className="absolute -top-3 left-0 right-0 flex justify-center">
            <Badge variant="default" className="bg-primary hover:bg-primary">Most Popular</Badge>
          </div>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Professional</CardTitle>
            <div className="mt-4 mb-2">
              <span className="text-4xl font-bold">$29</span>
              <span className="text-muted-foreground ml-1">/month</span>
            </div>
            <CardDescription>Ideal for developers and small businesses</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>Advanced security scanning</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>Multi-platform deployment</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>WordPress vulnerability scanner</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>Comprehensive SEO analysis</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>Performance optimization</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>Traffic boosting tools</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>15 projects limit</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>PDF & Word exports</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full" variant="default" onClick={() => handlePlanSelection("Professional")}>
              Subscribe Now
            </Button>
          </CardFooter>
        </Card>
        
        {/* Enterprise Tier */}
        <Card className="border-2 border-border">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Enterprise</CardTitle>
            <div className="mt-4 mb-2">
              <span className="text-4xl font-bold">$99</span>
              <span className="text-muted-foreground ml-1">/month</span>
            </div>
            <CardDescription>Full-featured solution for larger organizations</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Everything in Professional</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Unlimited projects</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Custom AI code analysis</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Advanced penetration testing</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Custom deployment options</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Priority support</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Dedicated account manager</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>Custom API integrations</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full" variant="outline" onClick={() => handlePlanSelection("Enterprise")}>
              Contact Sales
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      <div className="mt-20">
        <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div>
            <h3 className="text-xl font-semibold mb-2">Can I switch plans later?</h3>
            <p className="text-muted-foreground">
              Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">How does billing work?</h3>
            <p className="text-muted-foreground">
              We offer monthly and annual billing options. Annual plans come with a 20% discount compared to monthly billing.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">What payment methods do you accept?</h3>
            <p className="text-muted-foreground">
              We accept all major credit cards, PayPal, and for Enterprise customers, we can arrange invoicing.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Is there a free trial?</h3>
            <p className="text-muted-foreground">
              Yes, all paid plans come with a 14-day free trial. No credit card required to start your trial.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Do you offer refunds?</h3>
            <p className="text-muted-foreground">
              We offer a 30-day money-back guarantee for all new subscriptions if you're not satisfied with our service.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Do you offer discounts?</h3>
            <p className="text-muted-foreground">
              We offer discounts for educational institutions, non-profits, and startups. Contact our sales team for details.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-20 text-center bg-gradient-to-r from-indigo-50 to-blue-50 dark:from-indigo-950/30 dark:to-blue-950/30 py-12 px-4 rounded-xl">
        <h2 className="text-3xl font-bold mb-4">Still have questions?</h2>
        <p className="text-lg mb-8 max-w-2xl mx-auto">
          Contact our support team and we'll get back to you as soon as possible.
        </p>
        <div className="flex justify-center space-x-4">
          <Button variant="default" onClick={() => toast({
            title: "Contact form",
            description: "Contact form will be available soon.",
            duration: 3000,
          })}>
            Contact Support
          </Button>
          <Button variant="outline" onClick={() => toast({
            title: "Documentation",
            description: "Documentation will be available soon.",
            duration: 3000,
          })}>
            Read Documentation
          </Button>
        </div>
      </div>
    </div>
  );
}