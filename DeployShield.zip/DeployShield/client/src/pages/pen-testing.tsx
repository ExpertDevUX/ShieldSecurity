import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import TestForm from "@/components/pen-testing/TestForm";
import TestResult from "@/components/pen-testing/TestResult";
import { PenTest } from "@shared/schema";

export default function PenTesting() {
  const [selectedTestId, setSelectedTestId] = useState<number | null>(null);
  
  const { data: penTests, isLoading } = useQuery<PenTest[]>({
    queryKey: ["/api/pen-tests"],
  });
  
  const selectedTest = penTests?.find((test) => test.id === selectedTestId);
  
  const handleTestCompleted = (testId: number) => {
    setSelectedTestId(testId);
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-700 mb-4">Penetration Testing</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <TestForm onTestCompleted={handleTestCompleted} />
        </div>
        
        <div className="md:col-span-2">
          <TestResult 
            test={selectedTest} 
            isLoading={isLoading} 
          />
        </div>
      </div>
    </div>
  );
}
