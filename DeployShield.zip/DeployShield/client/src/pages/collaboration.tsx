import React, { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { apiRequest } from '@/lib/queryClient';
import { Tabs, TabsList, TabsContent, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Share2, Plus, Users, Clock, RefreshCw } from 'lucide-react';
import CollaborativeSession from '@/components/collaboration/CollaborativeSession';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import type { CollaborationSession } from '@shared/schema';

interface CreateSessionFormData {
  projectId: number | null;
  name: string;
  description: string;
  language: string;
  isPublic: boolean;
}

const CollaborationPage: React.FC = () => {
  const [, setLocation] = useLocation();
  const params = useParams();
  const sessionId = params.sessionId;
  const { toast } = useToast();
  const [isCreatingSession, setIsCreatingSession] = useState(false);
  const [formData, setFormData] = useState<CreateSessionFormData>({
    projectId: null,
    name: '',
    description: '',
    language: 'javascript',
    isPublic: true,
  });

  // Query to fetch sessions
  const { data: sessions, isLoading: isLoadingSessions, error: sessionsError, refetch: refetchSessions } = useQuery({
    queryKey: ['/api/collaboration-sessions'],
    queryFn: async () => {
      try {
        const response = await apiRequest<CollaborationSession[]>('/api/collaboration-sessions');
        return response.data;
      } catch (error) {
        console.error('Failed to fetch collaboration sessions:', error);
        // In a real implementation, we would handle the error and not return mock data
        // This is just for demonstration purposes
        // In a production app, throw the error or return an appropriate response
        return [];
      }
    },
  });

  // Query to fetch projects for dropdown
  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ['/api/projects'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/projects');
        return response.data;
      } catch (error) {
        console.error('Failed to fetch projects:', error);
        return [];
      }
    },
  });

  // Query to fetch session detail if sessionId is provided
  const { data: sessionDetail, isLoading: isLoadingSessionDetail } = useQuery({
    queryKey: ['/api/collaboration-sessions', sessionId],
    queryFn: async () => {
      if (!sessionId) return null;
      try {
        const response = await apiRequest(`/api/collaboration-sessions/${sessionId}`);
        return response.data;
      } catch (error) {
        console.error(`Failed to fetch session details for ${sessionId}:`, error);
        toast({
          title: 'Session Not Found',
          description: 'The requested collaboration session could not be found.',
          variant: 'destructive',
        });
        // Redirect to main collaboration page after a delay
        setTimeout(() => setLocation('/collaboration'), 3000);
        return null;
      }
    },
    enabled: !!sessionId,
  });

  // Mutation to create a new session
  const createSessionMutation = useMutation({
    mutationFn: async (data: CreateSessionFormData) => {
      return await apiRequest('/api/collaboration-sessions', {
        method: 'POST',
        data,
      });
    },
    onSuccess: (response) => {
      toast({
        title: 'Session Created',
        description: 'Your collaborative session has been created successfully.',
      });
      setIsCreatingSession(false);
      refetchSessions();
      const newSessionId = response.data?.id;
      if (newSessionId) {
        setLocation(`/collaboration/${newSessionId}`);
      }
    },
    onError: (error) => {
      console.error('Failed to create session:', error);
      toast({
        title: 'Failed to Create Session',
        description: 'There was an error creating your session. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const handleCreateSession = () => {
    if (!formData.name) {
      toast({
        title: 'Missing Information',
        description: 'Please provide a name for your session.',
        variant: 'destructive',
      });
      return;
    }

    createSessionMutation.mutate(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleProjectChange = (value: string) => {
    setFormData(prev => ({ ...prev, projectId: value ? parseInt(value, 10) : null }));
  };

  const renderCreateSessionForm = () => (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="projectId">Project (Optional)</Label>
        <Select value={formData.projectId?.toString() || ''} onValueChange={handleProjectChange}>
          <SelectTrigger id="projectId">
            <SelectValue placeholder="Select a project" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">None</SelectItem>
            {projects?.map(project => (
              <SelectItem key={project.id} value={project.id.toString()}>
                {project.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="name">Session Name*</Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
          placeholder="e.g., Bug fix collaboration"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Input
          id="description"
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          placeholder="Brief description of this session"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="language">Primary Language</Label>
        <Select value={formData.language} onValueChange={(value) => handleSelectChange('language', value)}>
          <SelectTrigger id="language">
            <SelectValue placeholder="Select a language" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="javascript">JavaScript</SelectItem>
            <SelectItem value="typescript">TypeScript</SelectItem>
            <SelectItem value="python">Python</SelectItem>
            <SelectItem value="java">Java</SelectItem>
            <SelectItem value="csharp">C#</SelectItem>
            <SelectItem value="html">HTML</SelectItem>
            <SelectItem value="css">CSS</SelectItem>
            <SelectItem value="php">PHP</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="isPublic">Visibility</Label>
        <Select 
          value={formData.isPublic ? 'public' : 'private'} 
          onValueChange={(value) => handleSelectChange('isPublic', value === 'public' ? 'true' : 'false')}
        >
          <SelectTrigger id="isPublic">
            <SelectValue placeholder="Select visibility" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="public">Public (Anyone with the link can join)</SelectItem>
            <SelectItem value="private">Private (Invite only)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button 
        onClick={handleCreateSession}
        disabled={createSessionMutation.isPending}
        className="w-full"
      >
        {createSessionMutation.isPending ? 'Creating...' : 'Create Session'}
      </Button>
    </div>
  );

  const renderSessionList = () => {
    if (isLoadingSessions) {
      return (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="border rounded-lg p-4 space-y-2">
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <div className="flex justify-between items-center mt-4">
                <Skeleton className="h-8 w-20" />
                <Skeleton className="h-8 w-20" />
              </div>
            </div>
          ))}
        </div>
      );
    }

    if (sessionsError) {
      return (
        <Alert variant="destructive">
          <AlertDescription>
            Failed to load collaboration sessions. Please try again later.
          </AlertDescription>
        </Alert>
      );
    }

    if (!sessions || sessions.length === 0) {
      return (
        <div className="text-center py-8">
          <CardDescription>No active collaboration sessions found.</CardDescription>
          <Button onClick={() => setIsCreatingSession(true)} className="mt-4">
            <Plus className="h-4 w-4 mr-2" />
            Create Your First Session
          </Button>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">Active Sessions</CardTitle>
          <Button variant="outline" size="sm" onClick={() => refetchSessions()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
        {sessions.map((session) => (
          <div key={session.id} className="border rounded-lg p-4 hover:border-primary transition-colors">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{session.name}</h3>
                {session.description && (
                  <p className="text-muted-foreground text-sm">{session.description}</p>
                )}
                <div className="flex items-center mt-2 space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {new Date(session.createdAt).toLocaleDateString()}
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    {session.activeParticipants || 1} active
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const shareUrl = `${window.location.origin}/collaboration/${session.id}`;
                    navigator.clipboard.writeText(shareUrl);
                    toast({
                      title: 'Link Copied',
                      description: 'Collaboration link copied to clipboard.',
                    });
                  }}
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => setLocation(`/collaboration/${session.id}`)}
                >
                  Join
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  // If we have a sessionId, render the CollaborativeSession component
  if (sessionId) {
    if (isLoadingSessionDetail) {
      return (
        <div className="container py-8 space-y-8">
          <div className="flex items-center space-x-4">
            <Skeleton className="h-8 w-3/4" />
          </div>
          <Skeleton className="h-[600px] w-full" />
        </div>
      );
    }

    if (!sessionDetail) {
      return (
        <div className="container py-8">
          <Alert variant="destructive">
            <AlertDescription>
              Session not found or you don't have permission to access it. Redirecting...
            </AlertDescription>
          </Alert>
        </div>
      );
    }

    return (
      <div className="container py-8">
        <div className="mb-4">
          <Button variant="outline" onClick={() => setLocation('/collaboration')}>
            Back to Sessions
          </Button>
        </div>
        <CollaborativeSession
          sessionId={sessionId}
          projectId={sessionDetail.projectId}
          initialCode={sessionDetail.initialCode || '// Collaborative code editing\n// Start typing to code together'}
          language={sessionDetail.language || 'javascript'}
          previewUrl={sessionDetail.previewUrl || ''}
          isOwner={sessionDetail.isOwner}
        />
      </div>
    );
  }

  // Otherwise, render the sessions list and creation form
  return (
    <div className="container py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Collaboration</h1>
          <p className="text-muted-foreground mt-1">
            Work together in real-time with code editing and live preview
          </p>
        </div>
        <Dialog open={isCreatingSession} onOpenChange={setIsCreatingSession}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Session
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Collaborative Session</DialogTitle>
            </DialogHeader>
            {renderCreateSessionForm()}
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="w-full max-w-md grid grid-cols-2">
          <TabsTrigger value="active">Active Sessions</TabsTrigger>
          <TabsTrigger value="recent">Recent Sessions</TabsTrigger>
        </TabsList>
        <TabsContent value="active" className="mt-6">
          {renderSessionList()}
        </TabsContent>
        <TabsContent value="recent" className="mt-6">
          <div className="text-center py-8">
            <CardDescription>Your recently closed sessions will appear here.</CardDescription>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Wrap the CollaborationPage component with ProtectedRoute
const ProtectedCollaborationPage: React.FC = () => (
  <ProtectedRoute>
    <CollaborationPage />
  </ProtectedRoute>
);

export default ProtectedCollaborationPage;