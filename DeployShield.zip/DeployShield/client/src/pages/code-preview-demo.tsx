import React from "react";
import { HoverCodePreview } from "@/components/ui/code-preview";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Info, ExternalLink, Code, FileText } from "lucide-react";

export default function CodePreviewDemo() {
  // Sample code snippets for demos
  const jsCodeExample = `// Example JavaScript code
function calculateTotalPrice(items) {
  return items.reduce((total, item) => {
    return total + (item.price * item.quantity);
  }, 0);
}

// Example usage
const cart = [
  { id: 1, name: 'Widget', price: 9.99, quantity: 2 },
  { id: 2, name: 'Gadget', price: 15.99, quantity: 1 },
  { id: 3, name: 'Tool', price: 24.99, quantity: 3 }
];

const total = calculateTotalPrice(cart);
console.log(\`Total cart price: \${total.toFixed(2)}\`);`;

  const reactComponentCode = `import React, { useState, useEffect } from 'react';

function DataFetcher({ endpoint, render }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const response = await fetch(\`https://api.example.com/\${endpoint}\`);
        if (!response.ok) {
          throw new Error(\`HTTP error! status: \${response.status}\`);
        }
        const result = await response.json();
        setData(result);
        setError(null);
      } catch (e) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [endpoint]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  return render(data);
}

export default DataFetcher;`;

  const cssExample = `.card {
  position: relative;
  border-radius: 8px;
  background-color: #ffffff;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 1.5rem;
  transition: all 0.3s ease;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
}

.card-title {
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 0.75rem;
  color: #333333;
}

.card-content {
  font-size: 0.875rem;
  color: #666666;
  line-height: 1.5;
}

@media (max-width: 768px) {
  .card {
    padding: 1rem;
  }
}`;

  const pythonExample = `import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load dataset
def load_and_prepare_data(filepath):
    data = pd.read_csv(filepath)
    # Handle missing values
    data.fillna(data.mean(), inplace=True)
    return data

# Feature engineering
def engineer_features(df):
    # Create new features
    df['age_group'] = pd.cut(df['age'], bins=[0, 18, 35, 50, 65, 100], 
                          labels=['Child', 'Young Adult', 'Adult', 'Middle Age', 'Senior'])
    # One-hot encode categorical variables
    df = pd.get_dummies(df, columns=['age_group', 'gender'], drop_first=True)
    return df

# Main function
def train_model(data_path):
    # Load and prepare data
    df = load_and_prepare_data(data_path)
    df = engineer_features(df)
    
    # Split features and target
    X = df.drop('target', axis=1)
    y = df['target']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Evaluate
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    report = classification_report(y_test, predictions)
    
    return model, accuracy, report`;

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold mb-2">Animated Code Preview Demo</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Hover over the code references below to see the animated code preview in action. The preview shows a mini-context window with syntax highlighting.
          </p>
        </div>

        <Tabs defaultValue="examples" className="w-full max-w-4xl mx-auto">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="examples">Usage Examples</TabsTrigger>
            <TabsTrigger value="customize">Customization Options</TabsTrigger>
          </TabsList>

          <TabsContent value="examples" className="pt-4">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Link Previews</CardTitle>
                  <CardDescription>
                    Hover over links to quickly preview code without navigating
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-4 text-sm">
                    When reviewing code in documentation or knowledge bases, use 
                    <HoverCodePreview 
                      code={jsCodeExample} 
                      language="javascript" 
                      fileName="calculate-prices.js"
                    >
                      <span className="text-primary font-medium underline decoration-dotted mx-1 cursor-pointer">
                        price calculation functions
                      </span>
                    </HoverCodePreview> to understand the logic without opening a new file.
                  </p>
                  <div className="flex items-center gap-2 mt-6">
                    <Badge variant="outline">Documentation</Badge>
                    <Badge variant="outline">Knowledge sharing</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Reference Popups</CardTitle>
                  <CardDescription>
                    Buttons and UI elements with contextual code preview
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col gap-4">
                    <p className="text-sm">
                      Click buttons to perform actions, or preview the implementation:
                    </p>
                    <div className="flex gap-2">
                      <Button size="sm">Regular Button</Button>
                      <HoverCodePreview 
                        code={reactComponentCode} 
                        language="jsx" 
                        fileName="DataFetcher.jsx"
                        position="bottom"
                      >
                        <Button size="sm" variant="outline" className="gap-1">
                          <Info className="h-4 w-4" />
                          Code Preview
                        </Button>
                      </HoverCodePreview>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Language Support</CardTitle>
                  <CardDescription>
                    Preview different programming languages
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 flex items-center justify-center">
                        <span className="text-yellow-500 font-bold">JS</span>
                      </div>
                      <HoverCodePreview 
                        code={jsCodeExample} 
                        language="javascript" 
                        fileName="example.js"
                        position="right"
                      >
                        <span className="cursor-pointer text-sm text-blue-500 hover:underline">
                          JavaScript Example
                        </span>
                      </HoverCodePreview>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 flex items-center justify-center">
                        <span className="text-blue-500 font-bold">Py</span>
                      </div>
                      <HoverCodePreview 
                        code={pythonExample} 
                        language="python" 
                        fileName="ml_pipeline.py"
                        position="right"
                      >
                        <span className="cursor-pointer text-sm text-blue-500 hover:underline">
                          Python ML Pipeline
                        </span>
                      </HoverCodePreview>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 flex items-center justify-center">
                        <span className="text-pink-500 font-bold">CSS</span>
                      </div>
                      <HoverCodePreview 
                        code={cssExample} 
                        language="css" 
                        fileName="card.css"
                        position="right"
                      >
                        <span className="cursor-pointer text-sm text-blue-500 hover:underline">
                          CSS Styling
                        </span>
                      </HoverCodePreview>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Icon Integration</CardTitle>
                  <CardDescription>
                    Use with icons for a polished interface
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4">
                    <HoverCodePreview 
                      code={jsCodeExample} 
                      language="javascript" 
                      fileName="function.js"
                    >
                      <div className="flex items-center gap-1 border rounded-md px-3 py-1.5 text-sm cursor-pointer hover:bg-muted">
                        <Code className="h-4 w-4" />
                        <span>View Code</span>
                      </div>
                    </HoverCodePreview>

                    <HoverCodePreview 
                      code={cssExample} 
                      language="css" 
                      fileName="styles.css"
                    >
                      <div className="flex items-center gap-1 border rounded-md px-3 py-1.5 text-sm cursor-pointer hover:bg-muted">
                        <FileText className="h-4 w-4" />
                        <span>CSS Example</span>
                      </div>
                    </HoverCodePreview>

                    <HoverCodePreview 
                      code={reactComponentCode} 
                      language="jsx" 
                      fileName="Component.jsx"
                    >
                      <div className="flex items-center gap-1 border rounded-md px-3 py-1.5 text-sm cursor-pointer hover:bg-muted">
                        <ExternalLink className="h-4 w-4" />
                        <span>React Component</span>
                      </div>
                    </HoverCodePreview>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="customize" className="pt-4">
            <Card>
              <CardHeader>
                <CardTitle>Customization Options</CardTitle>
                <CardDescription>
                  The component supports various customization props for different use cases
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Position Variants</h3>
                    <div className="space-y-3">
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          position="top"
                          previewHeight="150px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            Position: Top
                          </Button>
                        </HoverCodePreview>
                      </div>
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          position="right"
                          previewHeight="150px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            Position: Right
                          </Button>
                        </HoverCodePreview>
                      </div>
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          position="bottom"
                          previewHeight="150px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            Position: Bottom (default)
                          </Button>
                        </HoverCodePreview>
                      </div>
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          position="left"
                          previewHeight="150px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            Position: Left
                          </Button>
                        </HoverCodePreview>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium mb-2">Appearance Options</h3>
                    <div className="space-y-3">
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          previewHeight="100px"
                          previewWidth="400px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            Custom Size (height: 100px, width: 400px)
                          </Button>
                        </HoverCodePreview>
                      </div>
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          theme="light"
                          previewHeight="150px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            Light Theme
                          </Button>
                        </HoverCodePreview>
                      </div>
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          delay={500}
                          previewHeight="150px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            Longer Delay (500ms)
                          </Button>
                        </HoverCodePreview>
                      </div>
                      <div>
                        <HoverCodePreview 
                          code={jsCodeExample.slice(0, 150)} 
                          language="javascript" 
                          showLineNumbers={false}
                          previewHeight="150px"
                        >
                          <Button size="sm" variant="outline" className="w-full justify-start">
                            No Line Numbers
                          </Button>
                        </HoverCodePreview>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-6">
                <p className="text-sm text-muted-foreground">
                  The component can be easily customized with theme props, different languages, 
                  delay timing, position variations, and size adjustments to fit your specific use case.
                </p>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-2">
            This component uses Monaco Editor for syntax highlighting and Framer Motion for animations.
          </p>
        </div>
      </div>
  );
}