import React, { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { FileDown, FileUp, Save, RefreshCw, Globe, FileEdit } from "lucide-react";
import { apiRequest } from '@/lib/queryClient';
import DragDropEditor from "@/components/html-customization/DragDropEditor";
import SectionEditor from "@/components/html-customization/SectionEditor";

export default function HTMLCustomizationPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [fileList, setFileList] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<string>("");
  const [fileContent, setFileContent] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [editMode, setEditMode] = useState<"section" | "visual">("section");
  const [section, setSection] = useState<string>("full");
  const [previewUrl, setPreviewUrl] = useState<string>("");

  // Fetch list of HTML files
  useEffect(() => {
    fetchFileList();
  }, []);

  const fetchFileList = async () => {
    try {
      setIsLoading(true);
      // Default to client/public directory for HTML files
      const clientPublicDir = "client/public";
      
      // First check if the directory exists
      const dirResponse = await fetch(`/api/files?path=${clientPublicDir}`).then(res => res.json());
      
      // If we get a successful response, filter for HTML files
      if (dirResponse.files && Array.isArray(dirResponse.files)) {
        const htmlFiles = dirResponse.files.filter((file: string) => file.toLowerCase().endsWith('.html'));
        setFileList(htmlFiles.map((file: string) => `${clientPublicDir}/${file}`));
      } else {
        // If client/public doesn't exist or has issues, try client directory
        const clientDirResponse = await fetch(`/api/files?path=client`).then(res => res.json());
        if (clientDirResponse.files && Array.isArray(clientDirResponse.files)) {
          const htmlFiles = clientDirResponse.files.filter((file: string) => file.toLowerCase().endsWith('.html'));
          setFileList(htmlFiles.map((file: string) => `client/${file}`));
        }
      }
    } catch (error) {
      console.error("Error fetching files:", error);
      toast({
        title: "Error",
        description: "Failed to fetch HTML files list",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch file content when a file is selected
  useEffect(() => {
    if (selectedFile) {
      fetchFileContent(selectedFile);
    }
  }, [selectedFile]);

  const fetchFileContent = async (filename: string) => {
    try {
      setIsLoading(true);
      
      // Simple text response, not JSON
      const response = await fetch(`/api/files?path=${filename}`, { method: "GET" });
      
      // Check if response is OK before processing
      if (response.ok) {
        const content = await response.text();
        setFileContent(content);
        setPreviewUrl(`/${filename.split('/').pop()}`);
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch file content",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error fetching file content:", error);
      toast({
        title: "Error",
        description: "Failed to fetch file content",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveFile = async () => {
    if (!selectedFile || !fileContent) return;

    try {
      setIsSaving(true);
      const response = await fetch("/api/files", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          path: selectedFile,
          content: fileContent,
        }),
      }).then(res => res.json());

      if (response.success) {
        toast({
          title: "Success",
          description: "File saved successfully",
        });
      } else {
        toast({
          title: "Error",
          description: response.message || "Failed to save file",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error saving file:", error);
      toast({
        title: "Error",
        description: "Failed to save file",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleContentChange = (newContent: string) => {
    setFileContent(newContent);
  };

  return (
    <div className="container py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold mb-2">HTML Customization</h1>
          <p className="text-muted-foreground">
            Edit your HTML pages with visual tools or direct code editing
          </p>
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={fetchFileList}
          disabled={isLoading}
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Select HTML File</CardTitle>
            <CardDescription>
              Choose an HTML file to edit from your project
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="flex items-end gap-4">
                <div className="grid w-full gap-2">
                  <Label htmlFor="file-selector">HTML File</Label>
                  <Select
                    value={selectedFile}
                    onValueChange={setSelectedFile}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a file" />
                    </SelectTrigger>
                    <SelectContent>
                      {fileList.map((file) => (
                        <SelectItem key={file} value={file}>
                          {file.split('/').pop()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedFile && (
                  <Button 
                    variant="outline" 
                    onClick={() => window.open(previewUrl, '_blank')}
                  >
                    <Globe className="h-4 w-4 mr-2" />
                    Preview
                  </Button>
                )}
                <Button 
                  onClick={handleSaveFile} 
                  disabled={isSaving || !selectedFile}
                >
                  <Save className={`h-4 w-4 mr-2 ${isSaving ? "animate-spin" : ""}`} />
                  Save
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {selectedFile && (
          <Card>
            <CardHeader>
              <CardTitle>Edit Content</CardTitle>
              <CardDescription>
                Choose an editing mode and make changes to your HTML file
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="section" onValueChange={(value) => setEditMode(value as "section" | "visual")}>
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="section">
                    <FileEdit className="h-4 w-4 mr-2" />
                    Section Editing
                  </TabsTrigger>
                  <TabsTrigger value="visual">
                    <FileEdit className="h-4 w-4 mr-2" />
                    Visual Editing
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="section">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="section-selector">Choose Section</Label>
                      <Select
                        value={section}
                        onValueChange={setSection}
                      >
                        <SelectTrigger id="section-selector">
                          <SelectValue placeholder="Select a section" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="full">Full Document</SelectItem>
                          <SelectItem value="header">Header</SelectItem>
                          <SelectItem value="main">Main Content</SelectItem>
                          <SelectItem value="footer">Footer</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <SectionEditor 
                      content={fileContent} 
                      onChange={handleContentChange} 
                      section={section} 
                    />
                  </div>
                </TabsContent>

                <TabsContent value="visual">
                  <DragDropEditor 
                    content={fileContent} 
                    onChange={handleContentChange} 
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}