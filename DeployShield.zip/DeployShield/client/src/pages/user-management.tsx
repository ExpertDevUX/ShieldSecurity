import { UserManagement } from "@/components/user-management/UserManagement";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TwoFactorSetup } from "@/components/user-management/TwoFactorSetup";
import { UsersIcon, ShieldAlert, KeyRound } from "lucide-react";

export default function UserManagementPage() {
  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Admin Panel</h1>
        <p className="text-muted-foreground">User account management and security settings</p>
      </div>

      <Tabs defaultValue="users" className="space-y-6">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <UsersIcon className="h-4 w-4" />
              <span>Users</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <ShieldAlert className="h-4 w-4" />
              <span>Security</span>
            </TabsTrigger>
            <TabsTrigger value="2fa" className="flex items-center gap-2">
              <KeyRound className="h-4 w-4" />
              <span>Two-Factor Authentication</span>
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="users" className="space-y-6">
          <UserManagement />
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Manage security settings and policies for the platform
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Password Policy</h3>
                <div className="grid gap-4">
                  <div className="flex items-center justify-between border-b pb-3">
                    <div>
                      <div className="font-medium">Minimum password length</div>
                      <div className="text-sm text-muted-foreground">
                        Require at least this many characters
                      </div>
                    </div>
                    <div>8 characters</div>
                  </div>
                  <div className="flex items-center justify-between border-b pb-3">
                    <div>
                      <div className="font-medium">Password complexity</div>
                      <div className="text-sm text-muted-foreground">
                        Require at least one uppercase, lowercase, number and special character
                      </div>
                    </div>
                    <div>
                      <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs">
                        Enabled
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between border-b pb-3">
                    <div>
                      <div className="font-medium">Password expiration</div>
                      <div className="text-sm text-muted-foreground">
                        Require users to change password periodically
                      </div>
                    </div>
                    <div>
                      <span className="px-2 py-1 rounded-full bg-red-100 text-red-800 text-xs">
                        Disabled
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Login attempt limit</div>
                      <div className="text-sm text-muted-foreground">
                        Maximum number of failed login attempts before account lockout
                      </div>
                    </div>
                    <div>
                      5 attempts
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Session Management</h3>
                <div className="grid gap-4">
                  <div className="flex items-center justify-between border-b pb-3">
                    <div>
                      <div className="font-medium">Session timeout</div>
                      <div className="text-sm text-muted-foreground">
                        Automatically log users out after a period of inactivity
                      </div>
                    </div>
                    <div>30 minutes</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Concurrent sessions</div>
                      <div className="text-sm text-muted-foreground">
                        Maximum number of active sessions per user
                      </div>
                    </div>
                    <div>3 sessions</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="2fa" className="space-y-6">
          <TwoFactorSetup userId={1} />
        </TabsContent>
      </Tabs>
    </div>
  );
}