import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import SEOForm from "@/components/seo/SEOForm";
import SEOReport from "@/components/seo/SEOReport";
import SEOAdvancedSuggestions from "@/components/seo/SEOAdvancedSuggestions";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SEOAnalysis } from "@shared/schema";
import { Separator } from "@/components/ui/separator";

export default function SeoAnalysis() {
  const [selectedAnalysisId, setSelectedAnalysisId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<string>("report");
  
  const { data: seoAnalyses, isLoading } = useQuery<SEOAnalysis[]>({
    queryKey: ["/api/seo-analyses"],
  });
  
  const selectedAnalysis = seoAnalyses?.find((analysis) => analysis.id === selectedAnalysisId);
  
  const handleAnalysisCompleted = (analysisId: number) => {
    setSelectedAnalysisId(analysisId);
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-700 mb-4">SEO Analysis</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <SEOForm onAnalysisCompleted={handleAnalysisCompleted} />
        </div>
        
        <div className="md:col-span-2">
          {selectedAnalysis ? (
            <>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
                <TabsList className="grid grid-cols-2">
                  <TabsTrigger value="report">Analysis Report</TabsTrigger>
                  <TabsTrigger value="suggestions">Advanced Suggestions</TabsTrigger>
                </TabsList>
                
                <TabsContent value="report" className="mt-4">
                  <SEOReport 
                    analysis={selectedAnalysis} 
                    isLoading={isLoading}
                  />
                </TabsContent>
                
                <TabsContent value="suggestions" className="mt-4">
                  <SEOAdvancedSuggestions 
                    analysisReport={selectedAnalysis.report as Record<string, any>} 
                    url={selectedAnalysis.url}
                  />
                </TabsContent>
              </Tabs>
            </>
          ) : (
            <SEOReport 
              analysis={selectedAnalysis} 
              isLoading={isLoading}
            />
          )}
        </div>
      </div>
      
      {seoAnalyses && seoAnalyses.length > 0 && !selectedAnalysisId && (
        <div className="mt-6">
          <h3 className="text-lg font-semibold text-gray-700 mb-3">Previous Analyses</h3>
          <div className="bg-white shadow rounded-md overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">URL</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Score</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {seoAnalyses.map((analysis) => (
                  <tr key={analysis.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{analysis.url}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{analysis.score || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(analysis.analysisDate).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button 
                        onClick={() => setSelectedAnalysisId(analysis.id)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
