import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { AlertCircle, Home, ArrowLeft } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function NotFound() {
  const [location] = useLocation();
  
  return (
    <div className="w-full flex items-center justify-center py-16">
      <Card className="w-full max-w-md mx-4 border-2 shadow-lg">
        <CardContent className="pt-6 text-center">
          <div className="flex flex-col items-center mb-6">
            <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
            <h1 className="text-3xl font-bold">404 Page Not Found</h1>
          </div>

          <p className="mt-4 text-muted-foreground text-lg">
            The page <span className="font-semibold text-foreground">{location}</span> could not be found.
          </p>
          
          <p className="mt-4 text-muted-foreground">
            The page you're looking for doesn't exist or may have been moved.
          </p>
        </CardContent>
        <CardFooter className="flex justify-center gap-4 pt-4">
          <Button variant="outline" asChild>
            <Link href="/" className="inline-flex items-center gap-2">
              <Home className="h-4 w-4" />
              Back to Home
            </Link>
          </Button>
          <Button asChild>
            <a onClick={() => window.history.back()} className="inline-flex items-center gap-2 cursor-pointer">
              <ArrowLeft className="h-4 w-4" />
              Go Back
            </a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
