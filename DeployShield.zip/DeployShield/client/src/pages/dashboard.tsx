import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import StatsSummary from "@/components/dashboard/StatsSummary";
import SecurityTable from "@/components/dashboard/SecurityTable";
import CodeAnalysis from "@/components/dashboard/CodeAnalysis";
import DeploymentPanel from "@/components/dashboard/DeploymentPanel";
import ToolsPanel from "@/components/dashboard/ToolsPanel";
import ProgressTracker from "@/components/dashboard/ProgressTracker";
import { apiRequest } from "@/lib/queryClient";
import { type Project, type SecurityScan, type Task } from "@shared/schema";

export default function Dashboard() {
  const { data: projects, isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: securityScans, isLoading: isLoadingScans } = useQuery<SecurityScan[]>({
    queryKey: ["/api/security-scans"],
  });

  const { data: deployments, isLoading: isLoadingDeployments } = useQuery({
    queryKey: ["/api/deployments"],
  });

  const { data: tasks, isLoading: isLoadingTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const stats = {
    projectsSecured: projects?.length || 0,
    securityAlerts: securityScans?.filter(scan => scan.status === "Needs Attention").length || 0,
    issuesFixed: 23, // This would come from a real API in production
    deployments: deployments?.length || 0
  };

  const runNewScan = async () => {
    try {
      if (!projects || projects.length === 0) return;
      
      // Select first project for demo purposes
      const project = projects[0];
      
      await apiRequest("POST", "/api/security-scans", {
        projectId: project.id,
        highSeverity: Math.floor(Math.random() * 3),
        mediumSeverity: Math.floor(Math.random() * 4),
        lowSeverity: Math.floor(Math.random() * 6),
        status: "In Progress"
      });
      
      // Invalidate security scans query to refresh data
      window.location.reload();
    } catch (error) {
      console.error("Error running new scan:", error);
    }
  };

  return (
    <>
      <h2 className="text-2xl font-semibold text-gray-700 mb-4">Dashboard</h2>
      
      <StatsSummary stats={stats} isLoading={isLoadingProjects || isLoadingScans || isLoadingDeployments} />
      
      <div className="mt-8">
        <div className="flex flex-wrap -mx-3">
          <div className="w-full px-3 mb-6">
            <div className="bg-white rounded-md shadow-sm">
              <div className="flex items-center justify-between px-5 py-4 border-b">
                <h3 className="text-lg font-semibold text-gray-700">Recent Security Scans</h3>
                <Button 
                  onClick={runNewScan}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:outline-none"
                >
                  New Scan
                </Button>
              </div>
              
              <SecurityTable scans={securityScans || []} projects={projects || []} isLoading={isLoadingScans || isLoadingProjects} />
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex flex-wrap -mx-3">
        <div className="w-full xl:w-8/12 px-3 mb-6">
          <CodeAnalysis projects={projects || []} />
        </div>
        
        <div className="w-full xl:w-4/12 px-3 mb-6">
          <DeploymentPanel projects={projects || []} />
        </div>
      </div>
      
      <div className="mt-8">
        <div className="flex flex-wrap -mx-3">
          <div className="w-full px-3 mb-6">
            <div className="bg-white rounded-md shadow-sm">
              <div className="flex items-center justify-between px-5 py-4 border-b">
                <h3 className="text-lg font-semibold text-gray-700">Progress Tracking</h3>
              </div>
              {tasks && !isLoadingTasks ? (
                <ProgressTracker tasks={tasks} />
              ) : (
                <div className="p-6 text-center">
                  <p>Loading tasks...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <ToolsPanel />
    </>
  );
}
