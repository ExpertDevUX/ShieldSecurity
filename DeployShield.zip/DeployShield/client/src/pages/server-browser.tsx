import ServerFileBrowser from "@/components/server-browser/ServerFileBrowser";
import { Server } from "lucide-react";

export default function ServerBrowserPage() {
  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-6">
        <Server className="h-8 w-8 text-primary mr-3" />
        <div>
          <h1 className="text-3xl font-bold">Server File Browser</h1>
          <p className="text-muted-foreground">
            Browse and manage files in your web server's root directory
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        <ServerFileBrowser rootPath="./server_files" />
      </div>
    </div>
  );
}