import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import ScanForm from "@/components/security/ScanForm";
import SecurityResult from "@/components/security/SecurityResult";
import { Project, SecurityScan, Vulnerability } from "@shared/schema";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { 
  ShieldAlert, ShieldCheck, Globe, Code, AlertTriangle, 
  Lock, Server, Database, Check, X, FileWarning, 
  RefreshCw, FileCode, Table 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";

// XSS Scanner Types
interface XSSScanResult {
  url: string;
  vulnerableParameters: {
    name: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    location: string;
    fixed: boolean;
  }[];
  scanDate: string;
  scanDuration: number;
  testedUrls: number;
  testedParams: number;
  vulnerableUrls: number;
}

// WordPress Scanner Types
interface WPScanResult {
  url: string;
  wpVersion: string;
  isOutdated: boolean;
  themes: {
    name: string;
    version: string;
    isOutdated: boolean;
    vulnerabilities: {
      title: string;
      severity: 'low' | 'medium' | 'high' | 'critical';
      fixedIn: string;
    }[];
  }[];
  plugins: {
    name: string;
    version: string;
    isOutdated: boolean;
    vulnerabilities: {
      title: string;
      severity: 'low' | 'medium' | 'high' | 'critical';
      fixedIn: string;
    }[];
  }[];
  scanDate: string;
  scanDuration: number;
  securityHeaders: {
    name: string;
    value: string;
    status: 'good' | 'warning' | 'bad';
  }[];
}

export default function SecurityScanPage() {
  const { toast } = useToast();
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const scanId = searchParams.get('id');
  const [selectedScanId, setSelectedScanId] = useState<number | null>(scanId ? parseInt(scanId) : null);
  const [activeTab, setActiveTab] = useState('general');
  
  // XSS scanner states
  const [xssUrl, setXssUrl] = useState('');
  const [xssDepth, setXssDepth] = useState(2);
  const [scanningXss, setScanningXss] = useState(false);
  const [xssScanProgress, setXssScanProgress] = useState(0);
  const [xssScanResult, setXssScanResult] = useState<XSSScanResult | null>(null);
  const [xssAdvancedOptions, setXssAdvancedOptions] = useState({
    cookies: '',
    headers: '',
    testForms: true,
    testJsonInputs: true,
    testHeaders: false
  });
  
  // WordPress scanner states
  const [wpUrl, setWpUrl] = useState('');
  const [scanningWp, setScanningWp] = useState(false);
  const [wpScanProgress, setWpScanProgress] = useState(0);
  const [wpScanResult, setWpScanResult] = useState<WPScanResult | null>(null);
  const [wpAdvancedOptions, setWpAdvancedOptions] = useState({
    enumPlugins: true,
    enumThemes: true,
    enumUsers: false,
    checkVulnerabilities: true,
    scanInStealthMode: false
  });
  
  const { data: projects, isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: scans, isLoading: isLoadingScans } = useQuery<SecurityScan[]>({
    queryKey: ["/api/security-scans"],
  });
  
  const { data: vulnerabilities, isLoading: isLoadingVulnerabilities } = useQuery<Vulnerability[]>({
    queryKey: [`/api/vulnerabilities?scanId=${selectedScanId}`],
    enabled: !!selectedScanId,
  });

  const handleScanComplete = (newScanId: number) => {
    setSelectedScanId(newScanId);
  };

  // XSS scanning functionality
  const handleXssScan = () => {
    if (!xssUrl) {
      toast({
        title: "URL is required",
        description: "Please enter a URL to scan for XSS vulnerabilities",
        variant: "destructive"
      });
      return;
    }
    
    // Start scanning
    setScanningXss(true);
    setXssScanProgress(0);
    
    // Simulate scanning process
    const scanInterval = setInterval(() => {
      setXssScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(scanInterval);
          
          // Simulate scan result with random data (in a real app, this would come from an actual scan)
          const vulnerableParameters = [];
          const paramCount = Math.floor(Math.random() * 5) + 1;
          
          for (let i = 0; i < paramCount; i++) {
            const paramTypes = ['id', 'search', 'q', 'query', 'username', 'comment', 'input', 'text', 'data'];
            const descriptions = [
              'Reflected XSS vulnerability allows injection of arbitrary JavaScript',
              'Unescaped user input is directly rendered in HTML context',
              'Missing sanitization allows script tag injection',
              'DOM-based XSS vulnerability in parameter processing',
              'Stored XSS vulnerability in user input field'
            ];
            const locations = [
              'Query parameter',
              'URL path',
              'Form field',
              'HTTP header',
              'JSON payload'
            ];
            const severities: ('low' | 'medium' | 'high' | 'critical')[] = ['low', 'medium', 'high', 'critical'];
            
            vulnerableParameters.push({
              name: paramTypes[Math.floor(Math.random() * paramTypes.length)],
              severity: severities[Math.floor(Math.random() * severities.length)],
              description: descriptions[Math.floor(Math.random() * descriptions.length)],
              location: locations[Math.floor(Math.random() * locations.length)],
              fixed: false
            });
          }
          
          setXssScanResult({
            url: xssUrl,
            vulnerableParameters,
            scanDate: new Date().toISOString(),
            scanDuration: Math.floor(Math.random() * 180) + 20,
            testedUrls: Math.floor(Math.random() * 50) + 10,
            testedParams: Math.floor(Math.random() * 200) + 20,
            vulnerableUrls: vulnerableParameters.length > 0 ? Math.min(Math.floor(Math.random() * 5) + 1, 5) : 0
          });
          
          setScanningXss(false);
          
          toast({
            title: "XSS Scan Completed",
            description: `Found ${vulnerableParameters.length} potential XSS vulnerabilities`,
            variant: vulnerableParameters.length > 0 ? "destructive" : "default"
          });
          
          return 100;
        }
        return prev + Math.floor(Math.random() * 10) + 1;
      });
    }, 200);
  };

  // WordPress scanning functionality
  const handleWpScan = () => {
    if (!wpUrl) {
      toast({
        title: "WordPress URL is required",
        description: "Please enter a WordPress site URL to scan",
        variant: "destructive"
      });
      return;
    }
    
    // Start scanning
    setScanningWp(true);
    setWpScanProgress(0);
    
    // Simulate scanning process
    const scanInterval = setInterval(() => {
      setWpScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(scanInterval);
          
          // Simulate WordPress scan result with realistic data
          const plugins = [];
          const themes = [];
          
          // Generate plugins
          const pluginCount = Math.floor(Math.random() * 8) + 5;
          const pluginNames = [
            'contact-form-7', 'woocommerce', 'elementor', 'wordfence', 
            'yoast-seo', 'jetpack', 'akismet', 'wp-super-cache', 
            'all-in-one-seo-pack', 'beaver-builder', 'updraftplus', 
            'ninja-forms', 'wp-mail-smtp', 'redirection'
          ];
          
          for (let i = 0; i < pluginCount; i++) {
            const isOutdated = Math.random() > 0.7;
            const hasVulnerabilities = Math.random() > 0.8;
            const vulnCount = hasVulnerabilities ? Math.floor(Math.random() * 3) + 1 : 0;
            const vulnerabilities = [];
            
            for (let j = 0; j < vulnCount; j++) {
              const severities: ('low' | 'medium' | 'high' | 'critical')[] = ['low', 'medium', 'high', 'critical'];
              const vuln = {
                title: [
                  'SQL Injection vulnerability',
                  'Cross-Site Scripting (XSS) vulnerability',
                  'Authentication Bypass vulnerability',
                  'Privilege Escalation vulnerability',
                  'Remote Code Execution vulnerability'
                ][Math.floor(Math.random() * 5)],
                severity: severities[Math.floor(Math.random() * severities.length)],
                fixedIn: `${Math.floor(Math.random() * 5) + 1}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`
              };
              vulnerabilities.push(vuln);
            }
            
            plugins.push({
              name: pluginNames[Math.floor(Math.random() * pluginNames.length)],
              version: `${Math.floor(Math.random() * 5) + 1}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`,
              isOutdated,
              vulnerabilities
            });
          }
          
          // Generate themes
          const themeCount = Math.floor(Math.random() * 3) + 1;
          const themeNames = [
            'astra', 'divi', 'avada', 'twenty-twenty-one', 
            'generatepress', 'oceanwp', 'sydney', 'hello-elementor'
          ];
          
          for (let i = 0; i < themeCount; i++) {
            const isOutdated = Math.random() > 0.7;
            const hasVulnerabilities = Math.random() > 0.9;
            const vulnCount = hasVulnerabilities ? Math.floor(Math.random() * 2) + 1 : 0;
            const vulnerabilities = [];
            
            for (let j = 0; j < vulnCount; j++) {
              const severities: ('low' | 'medium' | 'high' | 'critical')[] = ['low', 'medium', 'high', 'critical'];
              const vuln = {
                title: [
                  'Cross-Site Scripting (XSS) vulnerability in theme template',
                  'Remote Code Execution in theme functions',
                  'Local File Inclusion vulnerability',
                  'Path Traversal vulnerability'
                ][Math.floor(Math.random() * 4)],
                severity: severities[Math.floor(Math.random() * severities.length)],
                fixedIn: `${Math.floor(Math.random() * 3) + 1}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`
              };
              vulnerabilities.push(vuln);
            }
            
            themes.push({
              name: themeNames[Math.floor(Math.random() * themeNames.length)],
              version: `${Math.floor(Math.random() * 3) + 1}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`,
              isOutdated,
              vulnerabilities
            });
          }
          
          // Security headers
          const headers = [
            { name: 'X-Frame-Options', value: Math.random() > 0.5 ? 'DENY' : '', status: Math.random() > 0.5 ? 'good' : 'bad' },
            { name: 'X-XSS-Protection', value: Math.random() > 0.5 ? '1; mode=block' : '', status: Math.random() > 0.5 ? 'good' : 'bad' },
            { name: 'X-Content-Type-Options', value: Math.random() > 0.5 ? 'nosniff' : '', status: Math.random() > 0.5 ? 'good' : 'bad' },
            { name: 'Content-Security-Policy', value: Math.random() > 0.7 ? 'default-src \'self\'' : '', status: Math.random() > 0.7 ? 'good' : 'warning' },
            { name: 'Strict-Transport-Security', value: Math.random() > 0.6 ? 'max-age=31536000' : '', status: Math.random() > 0.6 ? 'good' : 'warning' }
          ];
          
          const result: WPScanResult = {
            url: wpUrl,
            wpVersion: `${Math.floor(Math.random() * 2) + 5}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`,
            isOutdated: Math.random() > 0.7,
            themes,
            plugins,
            scanDate: new Date().toISOString(),
            scanDuration: Math.floor(Math.random() * 240) + 60,
            securityHeaders: headers
          };
          
          setWpScanResult(result);
          setScanningWp(false);
          
          // Count vulnerabilities
          const pluginVulns = plugins.reduce((sum, plugin) => sum + plugin.vulnerabilities.length, 0);
          const themeVulns = themes.reduce((sum, theme) => sum + theme.vulnerabilities.length, 0);
          const totalVulns = pluginVulns + themeVulns + (result.isOutdated ? 1 : 0);
          
          toast({
            title: "WordPress Scan Completed",
            description: `Found ${totalVulns} vulnerabilities across core, plugins, and themes`,
            variant: totalVulns > 0 ? "destructive" : "default"
          });
          
          return 100;
        }
        return prev + Math.floor(Math.random() * 5) + 1;
      });
    }, 300);
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <ShieldAlert className="h-8 w-8 text-primary" />
          Security Scanner
        </h1>
        <p className="text-muted-foreground">
          Scan your websites and applications for security vulnerabilities
        </p>
      </div>
      
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="general">
            <ShieldCheck className="mr-2 h-4 w-4" />
            General Security
          </TabsTrigger>
          <TabsTrigger value="xss">
            <Code className="mr-2 h-4 w-4" />
            XSS Scanner
          </TabsTrigger>
          <TabsTrigger value="wordpress">
            <Globe className="mr-2 h-4 w-4" />
            WordPress Scanner
          </TabsTrigger>
        </TabsList>
        
        {/* General Security Tab Content */}
        <TabsContent value="general">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <ScanForm 
                projects={projects || []} 
                isLoading={isLoadingProjects}
                onScanComplete={handleScanComplete}
              />
            </div>
            
            <div className="md:col-span-2">
              <SecurityResult 
                scan={scans?.find(s => s.id === selectedScanId)}
                vulnerabilities={vulnerabilities || []}
                projects={projects || []}
                isLoading={isLoadingScans || isLoadingVulnerabilities}
              />
            </div>
          </div>
        </TabsContent>
        
        {/* XSS Scanner Tab Content */}
        <TabsContent value="xss">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-5">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-5 w-5 text-red-500" />
                    XSS Vulnerability Scanner
                  </CardTitle>
                  <CardDescription>
                    Scan websites for Cross-Site Scripting (XSS) vulnerabilities
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="xssUrl">Website URL</Label>
                    <Input 
                      id="xssUrl" 
                      placeholder="https://example.com" 
                      value={xssUrl}
                      onChange={(e) => setXssUrl(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="xssDepth">Scan Depth: {xssDepth}</Label>
                    </div>
                    <Select value={xssDepth.toString()} onValueChange={(value) => setXssDepth(parseInt(value))}>
                      <SelectTrigger id="xssDepth">
                        <SelectValue placeholder="Select scan depth" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Quick Scan</SelectItem>
                        <SelectItem value="2">2 - Standard Scan</SelectItem>
                        <SelectItem value="3">3 - Deep Scan</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="xssAdvanced" className="flex items-center justify-between">
                      <span>Advanced Options</span>
                      <Button variant="link" className="p-0 h-auto" onClick={() => setXssAdvancedOptions({
                        cookies: '',
                        headers: '',
                        testForms: true,
                        testJsonInputs: true,
                        testHeaders: false
                      })}>Reset</Button>
                    </Label>
                    
                    <div className="space-y-4 rounded-md border p-4">
                      <div className="space-y-2">
                        <Label htmlFor="xssCookies" className="text-sm">Cookies (Optional)</Label>
                        <Textarea 
                          id="xssCookies" 
                          placeholder="name=value; name2=value2" 
                          value={xssAdvancedOptions.cookies}
                          onChange={(e) => setXssAdvancedOptions({...xssAdvancedOptions, cookies: e.target.value})}
                          rows={2}
                          className="resize-none"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="xssHeaders" className="text-sm">Custom Headers (Optional)</Label>
                        <Textarea 
                          id="xssHeaders" 
                          placeholder="X-CustomHeader: value" 
                          value={xssAdvancedOptions.headers}
                          onChange={(e) => setXssAdvancedOptions({...xssAdvancedOptions, headers: e.target.value})}
                          rows={2}
                          className="resize-none"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="testForms" className="text-sm cursor-pointer">Test Form Inputs</Label>
                        <Switch 
                          id="testForms" 
                          checked={xssAdvancedOptions.testForms}
                          onCheckedChange={(checked) => setXssAdvancedOptions({...xssAdvancedOptions, testForms: checked})}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="testJsonInputs" className="text-sm cursor-pointer">Test JSON Inputs</Label>
                        <Switch 
                          id="testJsonInputs" 
                          checked={xssAdvancedOptions.testJsonInputs}
                          onCheckedChange={(checked) => setXssAdvancedOptions({...xssAdvancedOptions, testJsonInputs: checked})}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="testHeaders" className="text-sm cursor-pointer">Test HTTP Headers</Label>
                        <Switch 
                          id="testHeaders" 
                          checked={xssAdvancedOptions.testHeaders}
                          onCheckedChange={(checked) => setXssAdvancedOptions({...xssAdvancedOptions, testHeaders: checked})}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline">Reset</Button>
                  <Button 
                    onClick={handleXssScan}
                    disabled={scanningXss || !xssUrl}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    {scanningXss ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Scanning... {Math.floor(xssScanProgress)}%
                      </>
                    ) : (
                      <>
                        <ShieldAlert className="mr-2 h-4 w-4" />
                        Start XSS Scan
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </div>
            
            <div className="md:col-span-7">
              <Card>
                <CardHeader>
                  <CardTitle>XSS Scan Results</CardTitle>
                  <CardDescription>
                    {xssScanResult ? (
                      `Scan completed for ${xssScanResult.url}`
                    ) : (
                      "Run a scan to see vulnerability results"
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {scanningXss ? (
                    <div className="space-y-6 py-10">
                      <div className="flex flex-col items-center justify-center">
                        <RefreshCw className="h-12 w-12 animate-spin text-muted-foreground mb-4" />
                        <h3 className="text-xl font-medium mb-2">Scanning for XSS Vulnerabilities</h3>
                        <p className="text-sm text-muted-foreground mb-6">
                          Testing inputs, forms, and parameters for potential XSS issues...
                        </p>
                        <div className="w-full max-w-md mb-2">
                          <Progress value={xssScanProgress} className="h-2" />
                        </div>
                        <p className="text-sm text-muted-foreground">{Math.floor(xssScanProgress)}% complete</p>
                      </div>
                    </div>
                  ) : xssScanResult ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <Card className="bg-primary/5">
                          <CardContent className="p-6">
                            <div className="flex flex-col items-center justify-center text-center">
                              <div className="text-3xl font-bold mb-1">{xssScanResult.testedUrls}</div>
                              <p className="text-sm text-muted-foreground">URLs Tested</p>
                            </div>
                          </CardContent>
                        </Card>
                        <Card className="bg-primary/5">
                          <CardContent className="p-6">
                            <div className="flex flex-col items-center justify-center text-center">
                              <div className="text-3xl font-bold mb-1">{xssScanResult.testedParams}</div>
                              <p className="text-sm text-muted-foreground">Parameters Tested</p>
                            </div>
                          </CardContent>
                        </Card>
                        <Card className={`${xssScanResult.vulnerableUrls > 0 ? 'bg-red-50 dark:bg-red-900/20' : 'bg-green-50 dark:bg-green-900/20'}`}>
                          <CardContent className="p-6">
                            <div className="flex flex-col items-center justify-center text-center">
                              <div className={`text-3xl font-bold mb-1 ${xssScanResult.vulnerableUrls > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                                {xssScanResult.vulnerableUrls}
                              </div>
                              <p className="text-sm text-muted-foreground">Vulnerable URLs</p>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-medium mb-4">Detected XSS Vulnerabilities</h3>
                        {xssScanResult.vulnerableParameters.length > 0 ? (
                          <div className="space-y-3">
                            {xssScanResult.vulnerableParameters.map((vuln, idx) => (
                              <Card key={idx} className={`border-l-4 ${
                                vuln.severity === 'critical' ? 'border-l-red-500' :
                                vuln.severity === 'high' ? 'border-l-orange-500' :
                                vuln.severity === 'medium' ? 'border-l-yellow-500' :
                                'border-l-blue-500'
                              }`}>
                                <CardContent className="py-4">
                                  <div className="grid grid-cols-12 gap-4">
                                    <div className="col-span-12 sm:col-span-8">
                                      <div className="flex items-start">
                                        <AlertTriangle className={`h-5 w-5 mt-1 mr-2 ${
                                          vuln.severity === 'critical' ? 'text-red-500' :
                                          vuln.severity === 'high' ? 'text-orange-500' :
                                          vuln.severity === 'medium' ? 'text-yellow-500' :
                                          'text-blue-500'
                                        }`} />
                                        <div>
                                          <div className="flex items-center mb-1">
                                            <h4 className="font-medium mr-2">Parameter: {vuln.name}</h4>
                                            <Badge variant={
                                              vuln.severity === 'critical' ? 'destructive' :
                                              vuln.severity === 'high' ? 'destructive' :
                                              vuln.severity === 'medium' ? 'default' :
                                              'outline'
                                            }>
                                              {vuln.severity.toUpperCase()}
                                            </Badge>
                                          </div>
                                          <p className="text-sm text-muted-foreground mb-1">{vuln.description}</p>
                                          <p className="text-xs text-muted-foreground">Location: {vuln.location}</p>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="col-span-12 sm:col-span-4 flex justify-end items-center">
                                      <Button 
                                        size="sm" 
                                        variant="outline" 
                                        className="mr-2"
                                        onClick={() => {
                                          // Show remediation suggestions
                                          toast({
                                            title: "Remediation Guidance",
                                            description: "Use context-aware output encoding and input validation to fix this XSS vulnerability.",
                                          });
                                        }}
                                      >
                                        View Details
                                      </Button>
                                      <Button 
                                        size="sm" 
                                        variant={vuln.fixed ? "outline" : "default"}
                                        onClick={() => {
                                          // Toggle fixed status
                                          const newParams = [...xssScanResult.vulnerableParameters];
                                          newParams[idx].fixed = !newParams[idx].fixed;
                                          setXssScanResult({
                                            ...xssScanResult,
                                            vulnerableParameters: newParams
                                          });
                                        }}
                                      >
                                        {vuln.fixed ? (
                                          <>
                                            <Check className="h-4 w-4 mr-1" />
                                            Fixed
                                          </>
                                        ) : "Mark Fixed"}
                                      </Button>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-10">
                            <ShieldCheck className="h-12 w-12 text-green-500 mx-auto mb-4" />
                            <h3 className="text-xl font-medium mb-2">No XSS Vulnerabilities Detected</h3>
                            <p className="text-sm text-muted-foreground max-w-md mx-auto">
                              Great job! No Cross-Site Scripting vulnerabilities were found in the scanned website.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <Code className="h-12 w-12 text-muted-foreground opacity-20 mx-auto mb-4" />
                      <h3 className="text-xl font-medium mb-2">No XSS Scan Results</h3>
                      <p className="text-sm text-muted-foreground max-w-md mx-auto">
                        Configure the scanner and click "Start XSS Scan" to check your website for Cross-Site Scripting vulnerabilities.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        {/* WordPress Scanner Tab Content */}
        <TabsContent value="wordpress">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5 text-blue-500" />
                    WordPress Security Scanner
                  </CardTitle>
                  <CardDescription>
                    Scan WordPress sites for vulnerabilities and security issues
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="wpUrl">WordPress URL</Label>
                    <Input 
                      id="wpUrl" 
                      placeholder="https://example.com" 
                      value={wpUrl}
                      onChange={(e) => setWpUrl(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="wpAdvanced" className="flex items-center justify-between">
                      <span>Scan Options</span>
                      <Button variant="link" className="p-0 h-auto" onClick={() => setWpAdvancedOptions({
                        enumPlugins: true,
                        enumThemes: true,
                        enumUsers: false,
                        checkVulnerabilities: true,
                        scanInStealthMode: false
                      })}>Reset</Button>
                    </Label>
                    
                    <div className="space-y-4 rounded-md border p-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="enumPlugins" className="text-sm cursor-pointer">Enumerate Plugins</Label>
                        <Switch 
                          id="enumPlugins" 
                          checked={wpAdvancedOptions.enumPlugins}
                          onCheckedChange={(checked) => setWpAdvancedOptions({...wpAdvancedOptions, enumPlugins: checked})}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="enumThemes" className="text-sm cursor-pointer">Enumerate Themes</Label>
                        <Switch 
                          id="enumThemes" 
                          checked={wpAdvancedOptions.enumThemes}
                          onCheckedChange={(checked) => setWpAdvancedOptions({...wpAdvancedOptions, enumThemes: checked})}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="enumUsers" className="text-sm cursor-pointer">Enumerate Users</Label>
                        <Switch 
                          id="enumUsers" 
                          checked={wpAdvancedOptions.enumUsers}
                          onCheckedChange={(checked) => setWpAdvancedOptions({...wpAdvancedOptions, enumUsers: checked})}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="checkVulnerabilities" className="text-sm cursor-pointer">Check for Known Vulnerabilities</Label>
                        <Switch 
                          id="checkVulnerabilities" 
                          checked={wpAdvancedOptions.checkVulnerabilities}
                          onCheckedChange={(checked) => setWpAdvancedOptions({...wpAdvancedOptions, checkVulnerabilities: checked})}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="scanInStealthMode" className="text-sm cursor-pointer">Stealth Mode</Label>
                        <Switch 
                          id="scanInStealthMode" 
                          checked={wpAdvancedOptions.scanInStealthMode}
                          onCheckedChange={(checked) => setWpAdvancedOptions({...wpAdvancedOptions, scanInStealthMode: checked})}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline">Reset</Button>
                  <Button 
                    onClick={handleWpScan}
                    disabled={scanningWp || !wpUrl}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {scanningWp ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Scanning... {Math.floor(wpScanProgress)}%
                      </>
                    ) : (
                      <>
                        <FileCode className="mr-2 h-4 w-4" />
                        Start WordPress Scan
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </div>
            
            <div className="md:col-span-8">
              <Card>
                <CardHeader>
                  <CardTitle>WordPress Scan Results</CardTitle>
                  <CardDescription>
                    {wpScanResult ? (
                      `Scan completed for ${wpScanResult.url}`
                    ) : (
                      "Run a scan to see WordPress security results"
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {scanningWp ? (
                    <div className="space-y-6 py-10">
                      <div className="flex flex-col items-center justify-center">
                        <RefreshCw className="h-12 w-12 animate-spin text-muted-foreground mb-4" />
                        <h3 className="text-xl font-medium mb-2">Scanning WordPress Website</h3>
                        <p className="text-sm text-muted-foreground mb-6">
                          Analyzing WordPress core, plugins, themes, and configuration...
                        </p>
                        <div className="w-full max-w-md mb-2">
                          <Progress value={wpScanProgress} className="h-2" />
                        </div>
                        <p className="text-sm text-muted-foreground">{Math.floor(wpScanProgress)}% complete</p>
                      </div>
                    </div>
                  ) : wpScanResult ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <Card className={`${wpScanResult.isOutdated ? 'bg-red-50 dark:bg-red-900/20' : 'bg-green-50 dark:bg-green-900/20'}`}>
                          <CardContent className="p-4">
                            <div className="flex flex-col items-center justify-center text-center">
                              <div className="flex items-center mb-2">
                                <Server className={`h-5 w-5 mr-2 ${wpScanResult.isOutdated ? 'text-red-500' : 'text-green-500'}`} />
                                <span className="font-medium">WordPress Core</span>
                              </div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-lg font-bold">{wpScanResult.wpVersion}</span>
                                {wpScanResult.isOutdated ? (
                                  <Badge variant="destructive">Outdated</Badge>
                                ) : (
                                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200 dark:bg-green-900 dark:text-green-300 dark:border-green-800">Up to date</Badge>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card className="bg-primary/5">
                          <CardContent className="p-4">
                            <div className="flex flex-col items-center justify-center text-center">
                              <div className="flex items-center mb-2">
                                <Box className="h-5 w-5 mr-2 text-primary" />
                                <span className="font-medium">Plugins</span>
                              </div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-lg font-bold">{wpScanResult.plugins.length}</span>
                                <Badge variant="outline" className="bg-primary/10 border-primary/20">
                                  {wpScanResult.plugins.filter(p => p.vulnerabilities.length > 0).length} vulnerable
                                </Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card className="bg-primary/5">
                          <CardContent className="p-4">
                            <div className="flex flex-col items-center justify-center text-center">
                              <div className="flex items-center mb-2">
                                <FileCode className="h-5 w-5 mr-2 text-primary" />
                                <span className="font-medium">Themes</span>
                              </div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-lg font-bold">{wpScanResult.themes.length}</span>
                                <Badge variant="outline" className="bg-primary/10 border-primary/20">
                                  {wpScanResult.themes.filter(t => t.vulnerabilities.length > 0).length} vulnerable
                                </Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card className="bg-primary/5">
                          <CardContent className="p-4">
                            <div className="flex flex-col items-center justify-center text-center">
                              <div className="flex items-center mb-2">
                                <Lock className="h-5 w-5 mr-2 text-primary" />
                                <span className="font-medium">Security Headers</span>
                              </div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-lg font-bold">
                                  {wpScanResult.securityHeaders.filter(h => h.status === 'good').length}/
                                  {wpScanResult.securityHeaders.length}
                                </span>
                                <Badge variant={
                                  wpScanResult.securityHeaders.filter(h => h.status === 'good').length === wpScanResult.securityHeaders.length
                                    ? "outline"
                                    : "default"
                                }>
                                  {wpScanResult.securityHeaders.filter(h => h.status === 'good').length === wpScanResult.securityHeaders.length ? "Good" : "Needs Improvement"}
                                </Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                      
                      <Tabs defaultValue="plugins" className="w-full">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="plugins">
                            <Box className="mr-2 h-4 w-4" />
                            Plugins ({wpScanResult.plugins.length})
                          </TabsTrigger>
                          <TabsTrigger value="themes">
                            <FileCode className="mr-2 h-4 w-4" />
                            Themes ({wpScanResult.themes.length})
                          </TabsTrigger>
                          <TabsTrigger value="headers">
                            <Lock className="mr-2 h-4 w-4" />
                            Security Headers
                          </TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="plugins" className="pt-4">
                          <div className="rounded-md border">
                            <Table>
                              <thead>
                                <tr className="border-b">
                                  <th className="p-2 text-left font-medium">Plugin</th>
                                  <th className="p-2 text-left font-medium">Version</th>
                                  <th className="p-2 text-left font-medium">Status</th>
                                  <th className="p-2 text-left font-medium">Vulnerabilities</th>
                                </tr>
                              </thead>
                              <tbody>
                                {wpScanResult.plugins.map((plugin, idx) => (
                                  <tr key={idx} className="border-b last:border-0">
                                    <td className="p-2 font-medium">{plugin.name}</td>
                                    <td className="p-2">{plugin.version}</td>
                                    <td className="p-2">
                                      {plugin.isOutdated ? (
                                        <Badge variant="destructive">Outdated</Badge>
                                      ) : (
                                        <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200 dark:bg-green-900 dark:text-green-300 dark:border-green-800">Up to date</Badge>
                                      )}
                                    </td>
                                    <td className="p-2">
                                      {plugin.vulnerabilities.length > 0 ? (
                                        <div className="space-y-1">
                                          {plugin.vulnerabilities.map((vuln, vIdx) => (
                                            <div key={vIdx} className="flex items-center gap-1">
                                              <Badge variant={
                                                vuln.severity === 'critical' ? 'destructive' :
                                                vuln.severity === 'high' ? 'destructive' :
                                                vuln.severity === 'medium' ? 'default' :
                                                'outline'
                                              } className="text-xs px-1 py-0 h-auto">
                                                {vuln.severity}
                                              </Badge>
                                              <span className="text-xs">{vuln.title}</span>
                                            </div>
                                          ))}
                                        </div>
                                      ) : (
                                        <span className="text-xs text-muted-foreground">None found</span>
                                      )}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </Table>
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="themes" className="pt-4">
                          <div className="rounded-md border">
                            <Table>
                              <thead>
                                <tr className="border-b">
                                  <th className="p-2 text-left font-medium">Theme</th>
                                  <th className="p-2 text-left font-medium">Version</th>
                                  <th className="p-2 text-left font-medium">Status</th>
                                  <th className="p-2 text-left font-medium">Vulnerabilities</th>
                                </tr>
                              </thead>
                              <tbody>
                                {wpScanResult.themes.map((theme, idx) => (
                                  <tr key={idx} className="border-b last:border-0">
                                    <td className="p-2 font-medium">{theme.name}</td>
                                    <td className="p-2">{theme.version}</td>
                                    <td className="p-2">
                                      {theme.isOutdated ? (
                                        <Badge variant="destructive">Outdated</Badge>
                                      ) : (
                                        <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200 dark:bg-green-900 dark:text-green-300 dark:border-green-800">Up to date</Badge>
                                      )}
                                    </td>
                                    <td className="p-2">
                                      {theme.vulnerabilities.length > 0 ? (
                                        <div className="space-y-1">
                                          {theme.vulnerabilities.map((vuln, vIdx) => (
                                            <div key={vIdx} className="flex items-center gap-1">
                                              <Badge variant={
                                                vuln.severity === 'critical' ? 'destructive' :
                                                vuln.severity === 'high' ? 'destructive' :
                                                vuln.severity === 'medium' ? 'default' :
                                                'outline'
                                              } className="text-xs px-1 py-0 h-auto">
                                                {vuln.severity}
                                              </Badge>
                                              <span className="text-xs">{vuln.title}</span>
                                            </div>
                                          ))}
                                        </div>
                                      ) : (
                                        <span className="text-xs text-muted-foreground">None found</span>
                                      )}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </Table>
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="headers" className="pt-4">
                          <div className="rounded-md border">
                            <Table>
                              <thead>
                                <tr className="border-b">
                                  <th className="p-2 text-left font-medium">Security Header</th>
                                  <th className="p-2 text-left font-medium">Value</th>
                                  <th className="p-2 text-left font-medium">Status</th>
                                </tr>
                              </thead>
                              <tbody>
                                {wpScanResult.securityHeaders.map((header, idx) => (
                                  <tr key={idx} className="border-b last:border-0">
                                    <td className="p-2 font-medium">{header.name}</td>
                                    <td className="p-2 font-mono text-xs">
                                      {header.value || <span className="text-muted-foreground">Not set</span>}
                                    </td>
                                    <td className="p-2">
                                      {header.status === 'good' ? (
                                        <div className="flex items-center">
                                          <Check className="h-4 w-4 text-green-500 mr-1" />
                                          <span className="text-green-600 dark:text-green-400">Good</span>
                                        </div>
                                      ) : header.status === 'warning' ? (
                                        <div className="flex items-center">
                                          <AlertTriangle className="h-4 w-4 text-yellow-500 mr-1" />
                                          <span className="text-yellow-600 dark:text-yellow-400">Warning</span>
                                        </div>
                                      ) : (
                                        <div className="flex items-center">
                                          <X className="h-4 w-4 text-red-500 mr-1" />
                                          <span className="text-red-600 dark:text-red-400">Missing</span>
                                        </div>
                                      )}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </Table>
                          </div>
                        </TabsContent>
                      </Tabs>
                      
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm text-muted-foreground">
                            Scan completed in {wpScanResult.scanDuration} seconds
                            <span className="mx-2">•</span>
                            {new Date(wpScanResult.scanDate).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="flex items-center gap-1">
                            <FileWarning className="h-4 w-4" />
                            Export Report
                          </Button>
                          <Button size="sm" className="flex items-center gap-1">
                            <ShieldCheck className="h-4 w-4" />
                            Auto-Fix Issues
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <Globe className="h-12 w-12 text-muted-foreground opacity-20 mx-auto mb-4" />
                      <h3 className="text-xl font-medium mb-2">No WordPress Scan Results</h3>
                      <p className="text-sm text-muted-foreground max-w-md mx-auto">
                        Configure the scanner and click "Start WordPress Scan" to check your WordPress site for security vulnerabilities.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
