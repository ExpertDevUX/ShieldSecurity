import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, DollarSign, CheckCircle, AlertCircle, BarChart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";

// Payment Plan types
export type PaymentPlan = 'free' | 'basic' | 'pro' | 'enterprise';

// Subscription types
interface Subscription {
  id: number;
  userId: number;
  plan: PaymentPlan;
  status: string;
  startDate: string;
  endDate: string | null;
  paymentMethod: string | null;
  paymentId: string | null;
  amount: string | null;
  currency: string | null;
  createdAt: string;
  updatedAt: string;
}

// Transaction types
interface Transaction {
  id: number;
  userId: number;
  subscriptionId: number | null;
  amount: string;
  currency: string;
  status: string;
  paymentMethod: string;
  paymentId: string | null;
  createdAt: string;
}

// Plan pricing information
const planPricing = {
  free: { monthly: 0, annual: 0 },
  basic: { monthly: 9.99, annual: 95.9 },
  pro: { monthly: 29.99, annual: 287.9 },
  enterprise: { monthly: 99.99, annual: 959.9 }
};

// Features by plan
const planFeatures = {
  free: [
    "Basic security scanning",
    "Website deployment (limited)",
    "1 project",
    "Community support"
  ],
  basic: [
    "Advanced security scanning",
    "Website deployment",
    "5 projects",
    "SEO analysis",
    "Email support",
    "Traffic boost"
  ],
  pro: [
    "All Basic features",
    "Penetration testing",
    "20 projects",
    "Priority support",
    "API access",
    "Advanced traffic simulation",
    "Performance optimization"
  ],
  enterprise: [
    "All Pro features",
    "Unlimited projects",
    "AWS deployment",
    "Custom security rules",
    "24/7 priority support",
    "Dedicated account manager",
    "Custom integrations"
  ]
};

export default function PaymentPage() {
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCVC, setCardCVC] = useState("");
  const [selectedPlan, setSelectedPlan] = useState<PaymentPlan>("pro");
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("monthly");
  const [loading, setLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Load active subscription if any
  const { data: activeSubscription, isLoading: loadingSubscription } = useQuery({
    queryKey: ['/api/subscriptions/current'],
    queryFn: async () => {
      try {
        const result = await apiRequest<Subscription>({
          url: '/api/subscriptions/current',
          method: 'GET'
        });
        return result;
      } catch (error) {
        // No active subscription
        return null;
      }
    }
  });
  
  // Load transaction history
  const { data: transactions, isLoading: loadingTransactions } = useQuery({
    queryKey: ['/api/transactions'],
    queryFn: async () => {
      try {
        const result = await apiRequest<Transaction[]>({
          url: '/api/transactions',
          method: 'GET'
        });
        return result;
      } catch (error) {
        console.error('Failed to load transaction history:', error);
        return [];
      }
    }
  });
  
  // Process payment mutation
  const processPayment = useMutation({
    mutationFn: async (paymentData: {
      plan: PaymentPlan;
      billingCycle: 'monthly' | 'annual';
      paymentMethod: string;
      paymentDetails?: any;
    }) => {
      return apiRequest<{ success: boolean; subscriptionId: number }>({
        url: '/api/subscriptions',
        method: 'POST',
        data: paymentData
      });
    },
    onSuccess: (data) => {
      setPaymentSuccess(true);
      toast({
        title: "Payment Successful",
        description: "Your subscription has been activated!",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/subscriptions/current'] });
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    },
    onError: (error) => {
      toast({
        title: "Payment Failed",
        description: "There was an issue processing your payment. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Format card number with spaces
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };
  
  // Calculate the total price based on plan and billing cycle
  const calculateTotal = () => {
    return planPricing[selectedPlan][billingCycle];
  };
  
  // Handle credit card form submission
  const handleCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Normally, you would use a secure payment processor here
    // For demo purposes, we'll simulate a successful payment
    processPayment.mutate({
      plan: selectedPlan,
      billingCycle: billingCycle,
      paymentMethod: 'credit_card',
      paymentDetails: {
        // Don't send actual card details - this would be handled by a secure payment processor
        cardName
      }
    });
  };
  
  // Handle PayPal payment
  const handlePayPalPayment = () => {
    setLoading(true);
    
    // In a real implementation, this would redirect to PayPal or process through PayPal SDK
    processPayment.mutate({
      plan: selectedPlan,
      billingCycle: billingCycle,
      paymentMethod: 'paypal'
    });
  };
  
  // Format currency for display
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  return (
    <div className="container mx-auto py-10 space-y-10">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Subscription & Payment
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl">
          Choose your plan and payment method to get started with premium features
        </p>
      </div>
      
      <Tabs defaultValue="subscription" className="max-w-4xl mx-auto">
        <TabsList className="grid grid-cols-3 w-full mb-8">
          <TabsTrigger value="subscription">
            <BarChart className="mr-2 h-4 w-4" />
            Subscription
          </TabsTrigger>
          <TabsTrigger value="payment">
            <DollarSign className="mr-2 h-4 w-4" />
            Payment Methods
          </TabsTrigger>
          <TabsTrigger value="history">
            <CreditCard className="mr-2 h-4 w-4" />
            Transaction History
          </TabsTrigger>
        </TabsList>
        
        {/* Subscription Tab */}
        <TabsContent value="subscription">
          <div className="space-y-6">
            {activeSubscription ? (
              <Card>
                <CardHeader>
                  <CardTitle>Current Subscription</CardTitle>
                  <CardDescription>Your active subscription details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-lg p-6 bg-blue-50 dark:bg-blue-900/20 flex justify-between items-center">
                    <div>
                      <h3 className="text-xl font-bold capitalize">
                        {activeSubscription.plan} Plan
                      </h3>
                      <p className="text-muted-foreground">
                        {activeSubscription.status === 'active' ? (
                          <span className="flex items-center text-green-600 dark:text-green-400">
                            <CheckCircle className="h-4 w-4 mr-1" /> Active
                          </span>
                        ) : (
                          <span className="flex items-center text-amber-600 dark:text-amber-400">
                            <AlertCircle className="h-4 w-4 mr-1" /> {activeSubscription.status}
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">
                        Started on: {formatDate(activeSubscription.startDate)}
                      </p>
                      {activeSubscription.endDate && (
                        <p className="text-sm text-muted-foreground">
                          Expires: {formatDate(activeSubscription.endDate)}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  {activeSubscription.plan !== 'enterprise' && (
                    <div className="pt-4">
                      <h3 className="font-medium mb-2">Upgrade Your Plan</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {(['basic', 'pro', 'enterprise'] as PaymentPlan[])
                          .filter(plan => plan !== activeSubscription.plan)
                          .map(plan => (
                            <Card key={plan} className={
                              plan === 'enterprise' 
                                ? 'border-purple-300 dark:border-purple-800' 
                                : plan === 'pro' 
                                  ? 'border-blue-300 dark:border-blue-800' 
                                  : ''
                            }>
                              <CardHeader className="pb-2">
                                <CardTitle className="capitalize">{plan}</CardTitle>
                              </CardHeader>
                              <CardContent className="pb-2">
                                <p className="text-2xl font-bold">
                                  {formatCurrency(planPricing[plan].monthly)}<span className="text-sm font-normal text-muted-foreground">/month</span>
                                </p>
                                <ul className="mt-2 space-y-1 text-sm">
                                  {planFeatures[plan].slice(0, 3).map((feature, i) => (
                                    <li key={i} className="flex items-center">
                                      <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                                      {feature}
                                    </li>
                                  ))}
                                </ul>
                              </CardContent>
                              <CardFooter>
                                <Button 
                                  variant={plan === 'enterprise' ? 'secondary' : 'default'}
                                  size="sm" 
                                  className="w-full"
                                  onClick={() => {
                                    setSelectedPlan(plan);
                                    const tabsElement = document.querySelector('button[value="payment"]');
                                    if (tabsElement) {
                                      (tabsElement as HTMLButtonElement).click();
                                    }
                                  }}
                                >
                                  Upgrade
                                </Button>
                              </CardFooter>
                            </Card>
                          ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Choose a Plan</CardTitle>
                  <CardDescription>Select the plan that works best for you</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center mb-6">
                    <div className="bg-muted p-1 rounded-lg flex items-center">
                      <Button
                        variant={billingCycle === 'monthly' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setBillingCycle('monthly')}
                      >
                        Monthly
                      </Button>
                      <Button
                        variant={billingCycle === 'annual' ? 'default' : 'ghost'}
                        size="sm" 
                        onClick={() => setBillingCycle('annual')}
                      >
                        Annual (Save 20%)
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {(['free', 'basic', 'pro', 'enterprise'] as PaymentPlan[]).map(plan => (
                      <Card 
                        key={plan}
                        className={`
                          ${selectedPlan === plan ? 'border-2 border-primary shadow-lg' : ''} 
                          ${plan === 'pro' ? 'border-blue-300 dark:border-blue-800' : ''}
                          ${plan === 'enterprise' ? 'border-purple-300 dark:border-purple-800' : ''}
                        `}
                      >
                        <CardHeader className="pb-2">
                          <CardTitle className="capitalize">{plan}</CardTitle>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <p className="text-2xl font-bold">
                            {formatCurrency(planPricing[plan][billingCycle])}
                            <span className="text-sm font-normal text-muted-foreground">
                              {plan !== 'free' ? `/${billingCycle === 'monthly' ? 'month' : 'year'}` : ''}
                            </span>
                          </p>
                          <ul className="mt-2 space-y-1 text-sm">
                            {planFeatures[plan].map((feature, i) => (
                              <li key={i} className="flex items-center">
                                <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            variant={selectedPlan === plan ? 'default' : 'outline'}
                            size="sm" 
                            className="w-full"
                            onClick={() => {
                              setSelectedPlan(plan);
                              if (plan !== 'free') {
                                const tabsElement = document.querySelector('button[value="payment"]');
                                if (tabsElement) {
                                  (tabsElement as HTMLButtonElement).click();
                                }
                              }
                            }}
                          >
                            {selectedPlan === plan ? 'Selected' : plan === 'free' ? 'Current Plan' : 'Select'}
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
        
        {/* Payment Methods Tab */}
        <TabsContent value="payment">
          <div className="space-y-6">
            {paymentSuccess ? (
              <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                <CardHeader>
                  <CardTitle className="flex items-center text-green-700 dark:text-green-300">
                    <CheckCircle className="h-6 w-6 mr-2" />
                    Payment Successful
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Your payment has been processed successfully. Thank you for your subscription!</p>
                  <p className="mt-2">You will be redirected to the dashboard shortly.</p>
                </CardContent>
                <CardFooter>
                  <Button onClick={() => navigate('/dashboard')}>
                    Go to Dashboard
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Summary</CardTitle>
                    <CardDescription>Review your order before payment</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center pb-4 border-b">
                        <div>
                          <h3 className="font-medium capitalize">{selectedPlan} Plan</h3>
                          <p className="text-sm text-muted-foreground capitalize">
                            {billingCycle} billing
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">
                            {formatCurrency(planPricing[selectedPlan][billingCycle])}
                          </p>
                          {billingCycle === 'annual' && (
                            <p className="text-xs text-green-600 dark:text-green-400">
                              You save 20%
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center pt-2 font-bold">
                        <p>Total Due Today</p>
                        <p>{formatCurrency(calculateTotal())}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Tabs defaultValue="credit_card" className="w-full">
                  <TabsList className="grid grid-cols-2 w-full mb-6">
                    <TabsTrigger value="credit_card">
                      <CreditCard className="mr-2 h-4 w-4" />
                      Credit Card
                    </TabsTrigger>
                    <TabsTrigger value="paypal">
                      <div className="flex items-center">
                        <svg className="h-5 w-5 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M7.996 0H19.26c0.012 0 0.025 0 0.039 0 2.203 0 3.994 1.791 3.994 3.994 0 0.514-0.098 1.006-0.276 1.458l0.010-0.027c-1.222 5.264-5.397 9.061-10.283 10.318l-0.096 0.022c-0.609 0.176-1.309 0.277-2.033 0.277-0.401 0-0.797-0.031-1.183-0.092l0.044 0.006c-1.355-0.228-2.547-0.802-3.543-1.614L5.92 14.334c-0.863-0.715-1.508-1.667-1.85-2.758l-0.013-0.047c-0.18-0.485-0.284-1.046-0.284-1.632 0-0.019 0-0.038 0-0.057l-0 0.003c0.013-2.188 1.792-3.962 3.981-3.962 0.010 0 0.019 0 0.029 0L7.996 0z" />
                          <path d="M22.282 8.164H11.964c-0.012-0-0.025-0.001-0.039-0.001-2.204 0-3.995 1.791-3.995 3.995 0 0.55 0.111 1.074 0.313 1.551l-0.010-0.026c1.208 5.275 5.389 9.086 10.284 10.341l0.096 0.021c0.61 0.176 1.31 0.278 2.035 0.278 0.403 0 0.8-0.032 1.186-0.093l-0.045 0.006c1.359-0.229 2.553-0.803 3.55-1.616l-0.012 0.010c0.864-0.717 1.509-1.67 1.85-2.761l0.013-0.048c0.18-0.475 0.284-1.025 0.284-1.601 0-0.034-0-0.068-0.001-0.102l0 0.005c-0.011-2.194-1.793-3.972-3.987-3.974l-0-0z" />
                        </svg>
                        PayPal
                      </div>
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="credit_card">
                    <Card>
                      <CardHeader>
                        <CardTitle>Credit Card Details</CardTitle>
                        <CardDescription>Enter your card information securely</CardDescription>
                      </CardHeader>
                      <form onSubmit={handleCardSubmit}>
                        <CardContent className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="cardName">Cardholder Name</Label>
                            <Input 
                              id="cardName" 
                              placeholder="John Doe"
                              value={cardName}
                              onChange={e => setCardName(e.target.value)}
                              required
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="cardNumber">Card Number</Label>
                            <Input 
                              id="cardNumber" 
                              placeholder="1234 5678 9012 3456"
                              value={cardNumber}
                              onChange={e => setCardNumber(formatCardNumber(e.target.value))}
                              maxLength={19}
                              required
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="cardExpiry">Expiry Date</Label>
                              <Input 
                                id="cardExpiry" 
                                placeholder="MM/YY"
                                value={cardExpiry}
                                onChange={e => {
                                  const value = e.target.value.replace(/[^0-9]/g, '');
                                  if (value.length <= 4) {
                                    const month = value.substring(0, 2);
                                    const year = value.substring(2, 4);
                                    if (value.length <= 2) {
                                      setCardExpiry(value);
                                    } else {
                                      setCardExpiry(`${month}/${year}`);
                                    }
                                  }
                                }}
                                maxLength={5}
                                required
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor="cardCVC">CVC/CVV</Label>
                              <Input 
                                id="cardCVC" 
                                placeholder="123"
                                value={cardCVC}
                                onChange={e => {
                                  const value = e.target.value.replace(/[^0-9]/g, '');
                                  if (value.length <= 3) {
                                    setCardCVC(value);
                                  }
                                }}
                                maxLength={3}
                                required
                              />
                            </div>
                          </div>
                          
                          <div className="bg-muted p-3 rounded-md text-sm text-muted-foreground">
                            <p className="flex items-center">
                              <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                              Your payment information is encrypted and secure
                            </p>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            type="submit" 
                            className="w-full"
                            disabled={loading || processPayment.isPending}
                          >
                            {loading || processPayment.isPending ? (
                              <span className="flex items-center">
                                <svg className="animate-spin -ml-1 mr-3 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Processing...
                              </span>
                            ) : `Pay ${formatCurrency(calculateTotal())}`}
                          </Button>
                        </CardFooter>
                      </form>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="paypal">
                    <Card>
                      <CardHeader>
                        <CardTitle>Pay with PayPal</CardTitle>
                        <CardDescription>Fast, secure payment with PayPal</CardDescription>
                      </CardHeader>
                      <CardContent className="flex flex-col items-center">
                        <div className="text-center max-w-md space-y-4">
                          <svg className="h-12 w-12 mx-auto mb-4 text-blue-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M7.996 0H19.26c0.012 0 0.025 0 0.039 0 2.203 0 3.994 1.791 3.994 3.994 0 0.514-0.098 1.006-0.276 1.458l0.010-0.027c-1.222 5.264-5.397 9.061-10.283 10.318l-0.096 0.022c-0.609 0.176-1.309 0.277-2.033 0.277-0.401 0-0.797-0.031-1.183-0.092l0.044 0.006c-1.355-0.228-2.547-0.802-3.543-1.614L5.92 14.334c-0.863-0.715-1.508-1.667-1.85-2.758l-0.013-0.047c-0.18-0.485-0.284-1.046-0.284-1.632 0-0.019 0-0.038 0-0.057l-0 0.003c0.013-2.188 1.792-3.962 3.981-3.962 0.010 0 0.019 0 0.029 0L7.996 0z" />
                            <path d="M22.282 8.164H11.964c-0.012-0-0.025-0.001-0.039-0.001-2.204 0-3.995 1.791-3.995 3.995 0 0.55 0.111 1.074 0.313 1.551l-0.010-0.026c1.208 5.275 5.389 9.086 10.284 10.341l0.096 0.021c0.61 0.176 1.31 0.278 2.035 0.278 0.403 0 0.8-0.032 1.186-0.093l-0.045 0.006c1.359-0.229 2.553-0.803 3.55-1.616l-0.012 0.010c0.864-0.717 1.509-1.67 1.85-2.761l0.013-0.048c0.18-0.475 0.284-1.025 0.284-1.601 0-0.034-0-0.068-0.001-0.102l0 0.005c-0.011-2.194-1.793-3.972-3.987-3.974l-0-0z" />
                          </svg>
                          
                          <p>Click the PayPal button below to continue to PayPal's secure payment page.</p>
                          
                          <p className="text-sm text-muted-foreground">
                            You will be charged {formatCurrency(calculateTotal())} for the {selectedPlan} plan ({billingCycle} billing).
                          </p>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-center">
                        <Button 
                          className="w-full max-w-xs bg-[#0070ba] hover:bg-[#003087]"
                          onClick={handlePayPalPayment}
                          disabled={loading || processPayment.isPending}
                        >
                          {loading || processPayment.isPending ? (
                            <span className="flex items-center">
                              <svg className="animate-spin -ml-1 mr-3 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Processing...
                            </span>
                          ) : (
                            <span className="flex items-center">
                              <svg className="h-5 w-5 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M7.996 0H19.26c0.012 0 0.025 0 0.039 0 2.203 0 3.994 1.791 3.994 3.994 0 0.514-0.098 1.006-0.276 1.458l0.010-0.027c-1.222 5.264-5.397 9.061-10.283 10.318l-0.096 0.022c-0.609 0.176-1.309 0.277-2.033 0.277-0.401 0-0.797-0.031-1.183-0.092l0.044 0.006c-1.355-0.228-2.547-0.802-3.543-1.614L5.92 14.334c-0.863-0.715-1.508-1.667-1.85-2.758l-0.013-0.047c-0.18-0.485-0.284-1.046-0.284-1.632 0-0.019 0-0.038 0-0.057l-0 0.003c0.013-2.188 1.792-3.962 3.981-3.962 0.010 0 0.019 0 0.029 0L7.996 0z" />
                              </svg>
                              Checkout with PayPal
                            </span>
                          )}
                        </Button>
                      </CardFooter>
                    </Card>
                  </TabsContent>
                </Tabs>
              </>
            )}
          </div>
        </TabsContent>
        
        {/* Transaction History Tab */}
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>Review your past payments and subscriptions</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingTransactions ? (
                <div className="py-20 text-center">
                  <svg className="animate-spin h-8 w-8 mx-auto text-muted-foreground" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </div>
              ) : transactions && transactions.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4 font-medium">Date</th>
                        <th className="text-left py-3 px-4 font-medium">Transaction ID</th>
                        <th className="text-left py-3 px-4 font-medium">Amount</th>
                        <th className="text-left py-3 px-4 font-medium">Status</th>
                        <th className="text-left py-3 px-4 font-medium">Method</th>
                      </tr>
                    </thead>
                    <tbody>
                      {transactions.map(transaction => (
                        <tr key={transaction.id} className="border-b">
                          <td className="py-3 px-4">{formatDate(transaction.createdAt)}</td>
                          <td className="py-3 px-4 font-mono text-xs">{transaction.id}</td>
                          <td className="py-3 px-4">{formatCurrency(parseFloat(transaction.amount))}</td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              transaction.status === 'completed' 
                                ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                                : transaction.status === 'pending' 
                                  ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                                  : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                            }`}>
                              {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                            </span>
                          </td>
                          <td className="py-3 px-4 capitalize">{transaction.paymentMethod.replace('_', ' ')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="py-20 text-center">
                  <p className="text-muted-foreground">No transaction history available.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}