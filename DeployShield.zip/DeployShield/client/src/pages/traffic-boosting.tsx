import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  LineChart,
  AreaChart,
  BarChart,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { AlertTriangle, ArrowUpRight, Database, Download, ExternalLink, Gauge, Globe, List, Upload, Wifi } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { apiRequest, queryClient } from '@/lib/queryClient';

import { TrafficBoost, PageSpeedAnalysis, UrlScan } from '@shared/schema';
import { Textarea } from '@/components/ui/textarea';
import { ProgressCircle } from '../components/ui/progress-circle';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { exportToPdf, exportToWord } from '@/lib/exportUtils';

interface ProxyListItem {
  ip: string;
  port: number;
  country?: string;
  type?: string;
  anonymity?: string;
  speed?: number;
}

export default function TrafficBoosting() {
  const { toast } = useToast();
  
  // State for the active tab
  const [activeTab, setActiveTab] = useState('boost');
  
  // States for traffic boost form
  const [url, setUrl] = useState('');
  const [proxyAmount, setProxyAmount] = useState(50);
  const [duration, setDuration] = useState(30);
  const [geoTargeting, setGeoTargeting] = useState<string[]>(['US', 'EU']);
  const [deviceTypes, setDeviceTypes] = useState<string[]>(['desktop', 'mobile']);
  const [referrers, setReferrers] = useState<string[]>(['google', 'facebook']);
  const [isRunning, setIsRunning] = useState(false);
  const [runningProgress, setRunningProgress] = useState(0);
  const [importedProxies, setImportedProxies] = useState<ProxyListItem[]>([]);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [proxyImportText, setProxyImportText] = useState('');
  const [proxyImportFormat, setProxyImportFormat] = useState('txt');
  const [useImportedProxies, setUseImportedProxies] = useState(false);
  const [proxyApiKey, setProxyApiKey] = useState('');
  const [proxyApiProvider, setProxyApiProvider] = useState('proxyscrape');
  const [useFreeProxies, setUseFreeProxies] = useState(true);
  const [scrapingInProgress, setScrapingInProgress] = useState(false);
  const [scrapingCount, setScrapingCount] = useState(0);
  
  // States for page speed analysis
  const [speedUrl, setSpeedUrl] = useState('');
  const [deviceType, setDeviceType] = useState('mobile');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // States for URL scan
  const [scanUrl, setScanUrl] = useState('');
  const [isScanningUrl, setIsScanningUrl] = useState(false);
  
  // Fetch active traffic boosts
  const { data: trafficBoosts } = useQuery({
    queryKey: ['/api/traffic-boosts'],
    select: (data: TrafficBoost[]) => data.sort((a, b) => 
      new Date(b.startDate).getTime() - new Date(a.startDate).getTime()
    )
  });
  
  // Fetch page speed analyses
  const { data: pageSpeedAnalyses } = useQuery({
    queryKey: ['/api/page-speed-analyses'],
    select: (data: PageSpeedAnalysis[]) => data.sort((a, b) => 
      new Date(b.analysisDate).getTime() - new Date(a.analysisDate).getTime()
    )
  });
  
  // Fetch URL scans
  const { data: urlScans } = useQuery({
    queryKey: ['/api/url-scans'],
    select: (data: UrlScan[]) => data.sort((a, b) => 
      new Date(b.scanDate).getTime() - new Date(a.scanDate).getTime()
    )
  });
  
  // Mutation for starting traffic boost
  const startBoostMutation = useMutation({
    mutationFn: (formData: any) => apiRequest('/api/traffic-boosts', 'POST', formData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/traffic-boosts'] });
      toast({
        title: 'Traffic boost started',
        description: 'Your traffic boost session has been initiated successfully',
      });
      
      // Simulate progress for demo purposes
      setIsRunning(true);
      setRunningProgress(0);
      const interval = setInterval(() => {
        setRunningProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsRunning(false);
            return 100;
          }
          return prev + (100 / (duration * 2)); // Make progress relative to duration
        });
      }, 500);
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to start traffic boost',
        description: error.message || 'An error occurred while starting the traffic boost',
        variant: 'destructive',
      });
    }
  });
  
  // Mutation for page speed analysis
  const analyzePageSpeedMutation = useMutation({
    mutationFn: (formData: any) => apiRequest('/api/page-speed-analyses', 'POST', formData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/page-speed-analyses'] });
      toast({
        title: 'Page speed analysis completed',
        description: 'The page speed analysis has been completed successfully',
      });
      setIsAnalyzing(false);
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to analyze page speed',
        description: error.message || 'An error occurred while analyzing page speed',
        variant: 'destructive',
      });
      setIsAnalyzing(false);
    }
  });
  
  // Mutation for URL scan
  const scanUrlMutation = useMutation({
    mutationFn: (formData: any) => apiRequest('/api/url-scans', 'POST', formData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/url-scans'] });
      toast({
        title: 'URL scan completed',
        description: 'The URL scan has been completed successfully',
      });
      setIsScanningUrl(false);
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to scan URL',
        description: error.message || 'An error occurred while scanning the URL',
        variant: 'destructive',
      });
      setIsScanningUrl(false);
    }
  });
  
  // Handle starting traffic boost
  const handleStartBoost = () => {
    if (!url) {
      toast({
        title: 'URL is required',
        description: 'Please enter a valid URL to boost',
        variant: 'destructive',
      });
      return;
    }
    
    startBoostMutation.mutate({
      url,
      status: 'active',
      proxyAmount,
      duration,
      settings: {
        geoTargeting,
        deviceTypes,
        referrers,
        useImportedProxies,
        useFreeProxies,
        proxyApiConfig: useImportedProxies ? null : {
          provider: proxyApiProvider,
          key: proxyApiKey
        }
      }
    });
  };
  
  // Handle analyzing page speed
  const handleAnalyzePageSpeed = () => {
    if (!speedUrl) {
      toast({
        title: 'URL is required',
        description: 'Please enter a valid URL to analyze',
        variant: 'destructive',
      });
      return;
    }
    
    setIsAnalyzing(true);
    analyzePageSpeedMutation.mutate({
      url: speedUrl,
      deviceType,
      score: Math.floor(Math.random() * 30) + 70, // For demo - replace with actual API call
      metrics: {
        fcp: Math.floor(Math.random() * 1000) + 500,
        lcp: Math.floor(Math.random() * 2000) + 1000,
        fid: Math.floor(Math.random() * 40) + 10,
        cls: (Math.random() * 0.1).toFixed(2),
        ttfb: Math.floor(Math.random() * 200) + 100
      }
    });
  };
  
  // Handle URL scan
  const handleScanUrl = () => {
    if (!scanUrl) {
      toast({
        title: 'URL is required',
        description: 'Please enter a valid URL to scan',
        variant: 'destructive',
      });
      return;
    }
    
    setIsScanningUrl(true);
    scanUrlMutation.mutate({
      url: scanUrl,
      security: {
        https: Math.random() > 0.2,
        httpStrict: Math.random() > 0.3,
        mixedContent: Math.random() > 0.7,
        securityHeaders: Math.floor(Math.random() * 10)
      },
      seo: {
        metaTitle: Math.random() > 0.1,
        metaDescription: Math.random() > 0.2,
        h1Tag: Math.random() > 0.1,
        canonicalTag: Math.random() > 0.3,
        robotsTxt: Math.random() > 0.2,
        sitemap: Math.random() > 0.4
      },
      performance: {
        resourceSize: Math.floor(Math.random() * 2000) + 500,
        requestCount: Math.floor(Math.random() * 80) + 20,
        cachePolicy: Math.random() > 0.5,
        imageOptimization: Math.random() > 0.5,
        cssMinification: Math.random() > 0.3,
        jsMinification: Math.random() > 0.4
      }
    });
  };
  
  // Import proxies from text
  const handleImportProxies = () => {
    if (!proxyImportText.trim()) {
      toast({
        title: 'No proxies to import',
        description: 'Please enter proxy data to import',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      let proxies: ProxyListItem[] = [];
      
      // Handle different import formats
      if (proxyImportFormat === 'json') {
        // JSON format: [{"ip":"127.0.0.1","port":8080,"country":"US"}, ...]
        proxies = JSON.parse(proxyImportText);
      } else if (proxyImportFormat === 'csv') {
        // CSV format: ip,port,country,type,anonymity,speed
        const lines = proxyImportText.split('\n');
        const headers = lines[0].toLowerCase().split(',');
        
        for (let i = 1; i < lines.length; i++) {
          if (!lines[i].trim()) continue;
          
          const values = lines[i].split(',');
          const proxy: ProxyListItem = {
            ip: '',
            port: 0
          };
          
          headers.forEach((header, index) => {
            if (header === 'ip') proxy.ip = values[index];
            else if (header === 'port') proxy.port = parseInt(values[index]);
            else if (header === 'country') proxy.country = values[index];
            else if (header === 'type') proxy.type = values[index];
            else if (header === 'anonymity') proxy.anonymity = values[index];
            else if (header === 'speed') proxy.speed = parseFloat(values[index]);
          });
          
          if (proxy.ip && proxy.port) {
            proxies.push(proxy);
          }
        }
      } else { 
        // TXT format: ip:port or ip:port:username:password
        const lines = proxyImportText.split('\n');
        proxies = lines.map(line => {
          const parts = line.trim().split(':');
          if (parts.length >= 2) {
            return {
              ip: parts[0],
              port: parseInt(parts[1])
            };
          }
          return null;
        }).filter(p => p !== null) as ProxyListItem[];
      }
      
      setImportedProxies(proxies);
      setUseImportedProxies(true);
      setShowImportDialog(false);
      
      toast({
        title: 'Proxies imported successfully',
        description: `Imported ${proxies.length} proxies from your data.`,
      });
    } catch (error) {
      toast({
        title: 'Failed to import proxies',
        description: 'Make sure your data is in the correct format',
        variant: 'destructive',
      });
    }
  };
  
  // Scrape free proxies
  const handleScrapeProxies = () => {
    setScrapingInProgress(true);
    setScrapingCount(0);
    
    // Simulate scraping process
    const targetCount = Math.floor(Math.random() * 100) + 50;
    const interval = setInterval(() => {
      setScrapingCount(prev => {
        if (prev >= targetCount) {
          clearInterval(interval);
          setScrapingInProgress(false);
          
          // Generate random proxies for demo
          const proxies: ProxyListItem[] = Array.from({ length: targetCount }, (_, i) => ({
            ip: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
            port: Math.floor(Math.random() * 10000) + 1000,
            country: ['US', 'UK', 'DE', 'FR', 'CA', 'JP', 'BR', 'IN'][Math.floor(Math.random() * 8)],
            type: ['http', 'https', 'socks4', 'socks5'][Math.floor(Math.random() * 4)],
            anonymity: ['transparent', 'anonymous', 'elite'][Math.floor(Math.random() * 3)],
            speed: Math.floor(Math.random() * 1000) + 100
          }));
          
          setImportedProxies(proxies);
          setUseImportedProxies(true);
          setUseFreeProxies(true);
          
          toast({
            title: 'Free proxies scraped successfully',
            description: `Found ${targetCount} free proxies from various sources.`,
          });
          
          return targetCount;
        }
        return prev + Math.floor(Math.random() * 5) + 1;
      });
    }, 200);
  };
  
  // Handle export to PDF
  const handleExportToPdf = (dataType: 'traffic-boost' | 'page-speed' | 'url-scan', data: any) => {
    exportToPdf(dataType, data, `${dataType}-report-${new Date().toISOString().split('T')[0]}.pdf`);
    
    toast({
      title: 'Report exported to PDF',
      description: 'Your report has been exported to PDF format successfully',
    });
  };
  
  // Handle export to Word
  const handleExportToWord = (dataType: 'traffic-boost' | 'page-speed' | 'url-scan', data: any) => {
    exportToWord(dataType, data, `${dataType}-report-${new Date().toISOString().split('T')[0]}.docx`);
    
    toast({
      title: 'Report exported to Word',
      description: 'Your report has been exported to Word format successfully',
    });
  };
  
  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Traffic Boosting Tools</h1>
          <p className="text-muted-foreground">
            Boost your website traffic, analyze page speed, and scan URLs for comprehensive traffic insights
          </p>
        </div>
      </div>
      
      <Tabs defaultValue="boost" onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="boost">
            <Wifi className="mr-2 h-4 w-4" />
            Traffic Boost
          </TabsTrigger>
          <TabsTrigger value="pagespeed">
            <Gauge className="mr-2 h-4 w-4" />
            Page Speed
          </TabsTrigger>
          <TabsTrigger value="urlscan">
            <Globe className="mr-2 h-4 w-4" />
            URL Scan
          </TabsTrigger>
        </TabsList>
        
        {/* Traffic Boost Tab */}
        <TabsContent value="boost" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Boost Traffic with Proxies</CardTitle>
                <CardDescription>
                  Simulate real traffic from different geolocations and device types
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="url">Website URL</Label>
                  <Input 
                    id="url" 
                    placeholder="https://example.com" 
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="proxyAmount">Number of Proxies: {proxyAmount}</Label>
                  </div>
                  <Slider 
                    id="proxyAmount"
                    min={10} 
                    max={500} 
                    step={10}
                    value={[proxyAmount]}
                    onValueChange={(value) => setProxyAmount(value[0])}
                    className="py-2"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="duration">Duration (minutes): {duration}</Label>
                  </div>
                  <Slider 
                    id="duration"
                    min={5} 
                    max={120} 
                    step={5}
                    value={[duration]}
                    onValueChange={(value) => setDuration(value[0])}
                    className="py-2"
                  />
                </div>
                
                <div className="border rounded-md p-3">
                  <h4 className="font-medium mb-3">Advanced Settings</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <Label htmlFor="use-imported" className="block mb-1">Use imported proxies</Label>
                        <span className="text-xs text-muted-foreground">
                          {importedProxies.length > 0 ? `${importedProxies.length} proxies imported` : 'No proxies imported yet'}
                        </span>
                      </div>
                      <div className="flex space-x-2">
                        <Switch 
                          id="use-imported" 
                          checked={useImportedProxies}
                          onCheckedChange={setUseImportedProxies}
                          disabled={importedProxies.length === 0}
                        />
                        <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Upload className="mr-2 h-3 w-3" />
                              Import
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Import Proxy List</DialogTitle>
                              <DialogDescription>
                                Paste your proxy list in the format specified below
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="space-y-2">
                                <Label>Format</Label>
                                <Select value={proxyImportFormat} onValueChange={setProxyImportFormat}>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select format" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="txt">TXT (IP:Port)</SelectItem>
                                    <SelectItem value="csv">CSV</SelectItem>
                                    <SelectItem value="json">JSON</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              
                              <div className="space-y-2">
                                <Label>Proxy List</Label>
                                <Textarea
                                  placeholder={
                                    proxyImportFormat === 'txt' ? '127.0.0.1:8080\n192.168.1.1:3128'
                                      : proxyImportFormat === 'csv' ? 'ip,port,country\n127.0.0.1,8080,US'
                                      : '[{"ip":"127.0.0.1","port":8080}]'
                                  }
                                  value={proxyImportText}
                                  onChange={(e) => setProxyImportText(e.target.value)}
                                  rows={8}
                                />
                              </div>
                            </div>
                            <DialogFooter>
                              <Button variant="ghost" onClick={() => setShowImportDialog(false)}>Cancel</Button>
                              <Button onClick={handleImportProxies}>Import Proxies</Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                        
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={handleScrapeProxies}
                          disabled={scrapingInProgress}
                        >
                          {scrapingInProgress ? (
                            <>Scraping {scrapingCount}...</>
                          ) : (
                            <>
                              <Database className="mr-2 h-3 w-3" />
                              Scrape Free
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <Label htmlFor="api-provider" className="block mb-1">Proxy API</Label>
                        <span className="text-xs text-muted-foreground">Use a commercial proxy provider</span>
                      </div>
                      <div className="flex space-x-2">
                        <Select value={proxyApiProvider} onValueChange={setProxyApiProvider} disabled={useImportedProxies}>
                          <SelectTrigger className="w-32">
                            <SelectValue placeholder="Provider" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="proxyscrape">ProxyScrape</SelectItem>
                            <SelectItem value="webshare">Webshare</SelectItem>
                            <SelectItem value="brightdata">Bright Data</SelectItem>
                            <SelectItem value="smartproxy">SmartProxy</SelectItem>
                          </SelectContent>
                        </Select>
                        <Input 
                          placeholder="API Key" 
                          value={proxyApiKey}
                          onChange={(e) => setProxyApiKey(e.target.value)}
                          className="w-32"
                          disabled={useImportedProxies}
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <Label htmlFor="use-free" className="block mb-1">Use free proxies</Label>
                        <span className="text-xs text-muted-foreground">Lower quality but free to use</span>
                      </div>
                      <Switch 
                        id="use-free" 
                        checked={useFreeProxies}
                        onCheckedChange={setUseFreeProxies}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Reset</Button>
                <Button 
                  onClick={handleStartBoost}
                  disabled={isRunning || !url}
                >
                  {isRunning ? 'Boosting...' : 'Start Boost'}
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Traffic Boost Sessions</CardTitle>
                <CardDescription>
                  View your active and completed traffic boost sessions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isRunning && (
                  <div className="border rounded-md p-4 mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Active Boost: {url}</h4>
                      <Badge>Running</Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress:</span>
                        <span>{Math.floor(runningProgress)}%</span>
                      </div>
                      <Progress value={runningProgress} />
                      <div className="grid grid-cols-3 gap-2 text-sm">
                        <div>
                          <span className="text-muted-foreground">Proxies:</span>
                          <p>{proxyAmount}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Duration:</span>
                          <p>{duration} min</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Est. Traffic:</span>
                          <p>{proxyAmount * 5}-{proxyAmount * 10}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {trafficBoosts && trafficBoosts.length > 0 ? (
                  <div className="space-y-4">
                    {trafficBoosts.map((boost) => (
                      <div key={boost.id} className="border rounded-md p-4">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">{boost.url}</h4>
                          <Badge variant={boost.status === 'active' ? 'default' : 'secondary'}>
                            {boost.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-sm mb-2">
                          <div>
                            <span className="text-muted-foreground">Proxies:</span>
                            <p>{boost.proxyAmount}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Duration:</span>
                            <p>{boost.duration} min</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Date:</span>
                            <p>{new Date(boost.startDate).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <div className="flex justify-end space-x-2 mt-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleExportToPdf('traffic-boost', boost)}
                          >
                            <Download className="mr-2 h-3 w-3" />
                            Export PDF
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleExportToWord('traffic-boost', boost)}
                          >
                            <Download className="mr-2 h-3 w-3" />
                            Export Word
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <div className="flex justify-center mb-2">
                      <Wifi className="h-12 w-12 opacity-20" />
                    </div>
                    <h3 className="text-lg font-medium mb-1">No traffic boosts yet</h3>
                    <p>Start your first traffic boost to see the results here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Page Speed Tab */}
        <TabsContent value="pagespeed" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Page Speed Analysis</CardTitle>
                <CardDescription>
                  Measure and analyze your page loading speed and performance metrics
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="speedUrl">Website URL</Label>
                  <Input 
                    id="speedUrl" 
                    placeholder="https://example.com" 
                    value={speedUrl}
                    onChange={(e) => setSpeedUrl(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="deviceType">Device Type</Label>
                  <Select value={deviceType} onValueChange={setDeviceType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select device type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mobile">Mobile</SelectItem>
                      <SelectItem value="desktop">Desktop</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Reset</Button>
                <Button 
                  onClick={handleAnalyzePageSpeed}
                  disabled={isAnalyzing || !speedUrl}
                >
                  {isAnalyzing ? 'Analyzing...' : 'Analyze Speed'}
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Speed Analysis Results</CardTitle>
                <CardDescription>
                  View and compare page speed analysis results
                </CardDescription>
              </CardHeader>
              <CardContent>
                {pageSpeedAnalyses && pageSpeedAnalyses.length > 0 ? (
                  <div className="space-y-6">
                    {pageSpeedAnalyses.slice(0, 1).map((analysis) => (
                      <div key={analysis.id} className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-lg font-medium">{analysis.url}</h3>
                            <p className="text-sm text-muted-foreground">
                              Analyzed on {new Date(analysis.analysisDate).toLocaleString()}
                              {analysis.deviceType && ` • ${analysis.deviceType.charAt(0).toUpperCase() + analysis.deviceType.slice(1)}`}
                            </p>
                          </div>
                          <div className="flex items-center">
                            <ProgressCircle
                              value={analysis.score || 0}
                              size={60}
                              strokeWidth={6}
                              textSize={18}
                              className={
                                analysis.score >= 90 ? 'text-green-500' 
                                : analysis.score >= 50 ? 'text-amber-500' 
                                : 'text-red-500'
                              }
                            />
                          </div>
                        </div>
                        
                        <div className="space-y-4">
                          <h4 className="font-medium">Core Web Vitals</h4>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <h5 className="text-sm font-medium mb-1">Largest Contentful Paint (LCP)</h5>
                              <div className="flex items-center">
                                <div className="flex-grow">
                                  <Progress 
                                    value={
                                      (analysis.metrics?.lcp || 0) <= 2500 ? 100 : 
                                      (analysis.metrics?.lcp || 0) >= 4000 ? 0 : 
                                      100 - (((analysis.metrics?.lcp || 0) - 2500) / 1500 * 100)
                                    } 
                                    className={
                                      (analysis.metrics?.lcp || 0) <= 2500 ? 'bg-green-500' : 
                                      (analysis.metrics?.lcp || 0) >= 4000 ? 'bg-red-500' : 
                                      'bg-amber-500'
                                    }
                                  />
                                </div>
                                <span className="ml-2 text-sm">{analysis.metrics?.lcp}ms</span>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {(analysis.metrics?.lcp || 0) <= 2500 ? 'Good' : 
                                 (analysis.metrics?.lcp || 0) >= 4000 ? 'Poor' : 
                                 'Needs Improvement'}
                              </p>
                            </div>
                            
                            <div>
                              <h5 className="text-sm font-medium mb-1">First Input Delay (FID)</h5>
                              <div className="flex items-center">
                                <div className="flex-grow">
                                  <Progress 
                                    value={
                                      (analysis.metrics?.fid || 0) <= 100 ? 100 : 
                                      (analysis.metrics?.fid || 0) >= 300 ? 0 : 
                                      100 - (((analysis.metrics?.fid || 0) - 100) / 200 * 100)
                                    } 
                                    className={
                                      (analysis.metrics?.fid || 0) <= 100 ? 'bg-green-500' : 
                                      (analysis.metrics?.fid || 0) >= 300 ? 'bg-red-500' : 
                                      'bg-amber-500'
                                    }
                                  />
                                </div>
                                <span className="ml-2 text-sm">{analysis.metrics?.fid}ms</span>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {(analysis.metrics?.fid || 0) <= 100 ? 'Good' : 
                                 (analysis.metrics?.fid || 0) >= 300 ? 'Poor' : 
                                 'Needs Improvement'}
                              </p>
                            </div>
                            
                            <div>
                              <h5 className="text-sm font-medium mb-1">Cumulative Layout Shift (CLS)</h5>
                              <div className="flex items-center">
                                <div className="flex-grow">
                                  <Progress 
                                    value={
                                      parseFloat(analysis.metrics?.cls || '0') <= 0.1 ? 100 : 
                                      parseFloat(analysis.metrics?.cls || '0') >= 0.25 ? 0 : 
                                      100 - (((parseFloat(analysis.metrics?.cls || '0') - 0.1) / 0.15) * 100)
                                    } 
                                    className={
                                      parseFloat(analysis.metrics?.cls || '0') <= 0.1 ? 'bg-green-500' : 
                                      parseFloat(analysis.metrics?.cls || '0') >= 0.25 ? 'bg-red-500' : 
                                      'bg-amber-500'
                                    }
                                  />
                                </div>
                                <span className="ml-2 text-sm">{analysis.metrics?.cls}</span>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {parseFloat(analysis.metrics?.cls || '0') <= 0.1 ? 'Good' : 
                                 parseFloat(analysis.metrics?.cls || '0') >= 0.25 ? 'Poor' : 
                                 'Needs Improvement'}
                              </p>
                            </div>
                            
                            <div>
                              <h5 className="text-sm font-medium mb-1">Time to First Byte (TTFB)</h5>
                              <div className="flex items-center">
                                <div className="flex-grow">
                                  <Progress 
                                    value={
                                      (analysis.metrics?.ttfb || 0) <= 200 ? 100 : 
                                      (analysis.metrics?.ttfb || 0) >= 600 ? 0 : 
                                      100 - (((analysis.metrics?.ttfb || 0) - 200) / 400 * 100)
                                    } 
                                    className={
                                      (analysis.metrics?.ttfb || 0) <= 200 ? 'bg-green-500' : 
                                      (analysis.metrics?.ttfb || 0) >= 600 ? 'bg-red-500' : 
                                      'bg-amber-500'
                                    }
                                  />
                                </div>
                                <span className="ml-2 text-sm">{analysis.metrics?.ttfb}ms</span>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {(analysis.metrics?.ttfb || 0) <= 200 ? 'Good' : 
                                 (analysis.metrics?.ttfb || 0) >= 600 ? 'Poor' : 
                                 'Needs Improvement'}
                              </p>
                            </div>
                          </div>
                          
                          <div className="border-t pt-4 mt-4">
                            <h4 className="font-medium mb-3">Performance Recommendations</h4>
                            <div className="space-y-2 text-sm">
                              {analysis.score < 90 && (
                                <>
                                  <div className="flex items-start">
                                    <AlertTriangle className="h-4 w-4 mr-2 mt-0.5 text-amber-500" />
                                    <p>Optimize images and use modern formats like WebP</p>
                                  </div>
                                  <div className="flex items-start">
                                    <AlertTriangle className="h-4 w-4 mr-2 mt-0.5 text-amber-500" />
                                    <p>Minimize and defer non-critical JavaScript</p>
                                  </div>
                                  <div className="flex items-start">
                                    <AlertTriangle className="h-4 w-4 mr-2 mt-0.5 text-amber-500" />
                                    <p>Implement proper caching strategies for static assets</p>
                                  </div>
                                </>
                              )}
                              {analysis.score >= 90 && (
                                <p>Great job! Your page is performing well.</p>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-end space-x-2 mt-4">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleExportToPdf('page-speed', analysis)}
                          >
                            <Download className="mr-2 h-3 w-3" />
                            Export PDF
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleExportToWord('page-speed', analysis)}
                          >
                            <Download className="mr-2 h-3 w-3" />
                            Export Word
                          </Button>
                        </div>
                      </div>
                    ))}
                    
                    {pageSpeedAnalyses.length > 1 && (
                      <div className="border rounded-md p-4 mt-4">
                        <h4 className="font-medium mb-3">Previous Analyses</h4>
                        <div className="space-y-2">
                          {pageSpeedAnalyses.slice(1, 5).map((analysis) => (
                            <div key={analysis.id} className="flex justify-between items-center py-1 border-b last:border-0">
                              <div className="flex-grow">
                                <div className="flex items-center">
                                  <span className="text-sm truncate max-w-[250px]">{analysis.url}</span>
                                  <Badge variant="outline" className="ml-2">{analysis.deviceType}</Badge>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  {new Date(analysis.analysisDate).toLocaleString()}
                                </p>
                              </div>
                              <div className="flex items-center">
                                <span className="font-medium text-sm mr-2">{analysis.score}</span>
                                <Button variant="ghost" size="sm">
                                  <ExternalLink className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <div className="flex justify-center mb-2">
                      <Gauge className="h-12 w-12 opacity-20" />
                    </div>
                    <h3 className="text-lg font-medium mb-1">No speed analyses yet</h3>
                    <p>Analyze your first page to see the results here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* URL Scan Tab */}
        <TabsContent value="urlscan" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>URL Scanner</CardTitle>
                <CardDescription>
                  Scan any URL for security vulnerabilities, SEO issues, and performance problems
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="scanUrl">Website URL</Label>
                  <Input 
                    id="scanUrl" 
                    placeholder="https://example.com" 
                    value={scanUrl}
                    onChange={(e) => setScanUrl(e.target.value)}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Reset</Button>
                <Button 
                  onClick={handleScanUrl}
                  disabled={isScanningUrl || !scanUrl}
                >
                  {isScanningUrl ? 'Scanning...' : 'Scan URL'}
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>URL Scan Results</CardTitle>
                <CardDescription>
                  Comprehensive analysis of scanned URLs
                </CardDescription>
              </CardHeader>
              <CardContent>
                {urlScans && urlScans.length > 0 ? (
                  <div className="space-y-6">
                    {urlScans.slice(0, 1).map((scan) => (
                      <div key={scan.id} className="space-y-4">
                        <div>
                          <h3 className="text-lg font-medium">{scan.url}</h3>
                          <p className="text-sm text-muted-foreground">
                            Scanned on {new Date(scan.scanDate).toLocaleString()}
                          </p>
                        </div>
                        
                        <Tabs defaultValue="security" className="w-full">
                          <TabsList className="grid w-full grid-cols-3">
                            <TabsTrigger value="security">Security</TabsTrigger>
                            <TabsTrigger value="seo">SEO</TabsTrigger>
                            <TabsTrigger value="performance">Performance</TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="security" className="space-y-4 pt-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">HTTPS</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.security?.https ? 'Secure connection' : 'Insecure connection'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.security?.https ? 'bg-green-500' : 'bg-red-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">HTTP Strict Transport</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.security?.httpStrict ? 'Enabled' : 'Not enabled'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.security?.httpStrict ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Mixed Content</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.security?.mixedContent ? 'Issues found' : 'No issues'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${!scan.security?.mixedContent ? 'bg-green-500' : 'bg-red-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Security Headers</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {(scan.security?.securityHeaders || 0) > 6 ? 'Good' : 'Needs improvement'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${(scan.security?.securityHeaders || 0) > 6 ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                            </div>
                          </TabsContent>
                          
                          <TabsContent value="seo" className="space-y-4 pt-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Meta Title</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.seo?.metaTitle ? 'Present' : 'Missing'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.seo?.metaTitle ? 'bg-green-500' : 'bg-red-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Meta Description</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.seo?.metaDescription ? 'Present' : 'Missing'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.seo?.metaDescription ? 'bg-green-500' : 'bg-red-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">H1 Tag</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.seo?.h1Tag ? 'Present' : 'Missing'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.seo?.h1Tag ? 'bg-green-500' : 'bg-red-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Canonical Tag</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.seo?.canonicalTag ? 'Present' : 'Missing'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.seo?.canonicalTag ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Robots.txt</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.seo?.robotsTxt ? 'Present' : 'Missing'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.seo?.robotsTxt ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Sitemap</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.seo?.sitemap ? 'Present' : 'Missing'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.seo?.sitemap ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                            </div>
                          </TabsContent>
                          
                          <TabsContent value="performance" className="space-y-4 pt-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Resource Size</h4>
                                <div className="flex items-center">
                                  <div className="flex-grow">
                                    <Progress 
                                      value={
                                        (scan.performance?.resourceSize || 0) <= 1000 ? 100 : 
                                        (scan.performance?.resourceSize || 0) >= 2500 ? 0 : 
                                        100 - (((scan.performance?.resourceSize || 0) - 1000) / 1500 * 100)
                                      } 
                                      className={
                                        (scan.performance?.resourceSize || 0) <= 1000 ? 'bg-green-500' : 
                                        (scan.performance?.resourceSize || 0) >= 2500 ? 'bg-red-500' : 
                                        'bg-amber-500'
                                      }
                                    />
                                  </div>
                                  <span className="ml-2 text-sm">{scan.performance?.resourceSize}KB</span>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Request Count</h4>
                                <div className="flex items-center">
                                  <div className="flex-grow">
                                    <Progress 
                                      value={
                                        (scan.performance?.requestCount || 0) <= 30 ? 100 : 
                                        (scan.performance?.requestCount || 0) >= 100 ? 0 : 
                                        100 - (((scan.performance?.requestCount || 0) - 30) / 70 * 100)
                                      } 
                                      className={
                                        (scan.performance?.requestCount || 0) <= 30 ? 'bg-green-500' : 
                                        (scan.performance?.requestCount || 0) >= 100 ? 'bg-red-500' : 
                                        'bg-amber-500'
                                      }
                                    />
                                  </div>
                                  <span className="ml-2 text-sm">{scan.performance?.requestCount}</span>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Cache Policy</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.performance?.cachePolicy ? 'Implemented' : 'Not implemented'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.performance?.cachePolicy ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">Image Optimization</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.performance?.imageOptimization ? 'Optimized' : 'Not optimized'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.performance?.imageOptimization ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">CSS Minification</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.performance?.cssMinification ? 'Minified' : 'Not minified'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.performance?.cssMinification ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                              
                              <div className="border rounded-md p-3">
                                <h4 className="font-medium mb-2">JS Minification</h4>
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">
                                    {scan.performance?.jsMinification ? 'Minified' : 'Not minified'}
                                  </span>
                                  <div className={`h-2 w-2 rounded-full ${scan.performance?.jsMinification ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                                </div>
                              </div>
                            </div>
                          </TabsContent>
                        </Tabs>
                        
                        <div className="flex justify-end space-x-2 mt-4">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleExportToPdf('url-scan', scan)}
                          >
                            <Download className="mr-2 h-3 w-3" />
                            Export PDF
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleExportToWord('url-scan', scan)}
                          >
                            <Download className="mr-2 h-3 w-3" />
                            Export Word
                          </Button>
                        </div>
                      </div>
                    ))}
                    
                    {urlScans.length > 1 && (
                      <div className="border rounded-md p-4 mt-4">
                        <h4 className="font-medium mb-3">Previous Scans</h4>
                        <div className="space-y-2">
                          {urlScans.slice(1, 5).map((scan) => (
                            <div key={scan.id} className="flex justify-between items-center py-1 border-b last:border-0">
                              <div className="flex-grow">
                                <div className="flex items-center">
                                  <span className="text-sm truncate max-w-[250px]">{scan.url}</span>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  {new Date(scan.scanDate).toLocaleString()}
                                </p>
                              </div>
                              <Button variant="ghost" size="sm">
                                <ExternalLink className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <div className="flex justify-center mb-2">
                      <Globe className="h-12 w-12 opacity-20" />
                    </div>
                    <h3 className="text-lg font-medium mb-1">No URL scans yet</h3>
                    <p>Scan your first URL to see the results here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}