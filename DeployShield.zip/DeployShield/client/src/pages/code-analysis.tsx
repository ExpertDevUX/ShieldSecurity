import { useState } from "react";
import CodeAnalysisForm from "@/components/code-analysis/CodeAnalysisForm";
import CodeViewer from "@/components/code-analysis/CodeViewer";
import AIRecommendation from "@/components/code-analysis/AIRecommendation";
import { Button } from "@/components/ui/button";
import { exportToPdf, exportToWord } from "@/lib/exportUtils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, FileText, FileDown } from "lucide-react";
import { AIProvider } from "@/lib/aiService";

interface AnalysisResult {
  issues: Array<{
    type: string;
    description: string;
    lineNumber: number;
    recommendation: string;
  }>;
  fixedCode: string;
  summary: string;
  code: string;
  language: string;
  provider: AIProvider;
}

export default function CodeAnalysis() {
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  
  const handleAnalysisCompleted = (result: AnalysisResult) => {
    setAnalysisResult(result);
  };
  
  const handleExport = async (format: 'pdf' | 'word') => {
    if (!analysisResult) return;
    
    setIsExporting(true);
    
    try {
      const data = {
        issues: analysisResult.issues,
        language: analysisResult.language,
        provider: analysisResult.provider,
        code: analysisResult.code,
        fixedCode: analysisResult.fixedCode,
        summary: analysisResult.summary
      };
      
      if (format === 'pdf') {
        await exportToPdf("code-analysis", data, "code-analysis-report.pdf");
      } else {
        await exportToWord("code-analysis", data, "code-analysis-report.docx");
      }
    } catch (error) {
      console.error(`Error exporting to ${format}:`, error);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Code Analysis</h1>
        
        {analysisResult && (
          <div className="flex space-x-2">
            <Button
              variant="outline"
              onClick={() => handleExport("pdf")}
              disabled={isExporting}
            >
              {isExporting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <FileText className="mr-2 h-4 w-4" />
              )}
              Export to PDF
            </Button>
            
            <Button
              variant="outline"
              onClick={() => handleExport("word")}
              disabled={isExporting}
            >
              {isExporting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <FileDown className="mr-2 h-4 w-4" />
              )}
              Export to Word
            </Button>
          </div>
        )}
      </div>
      
      {!analysisResult ? (
        <CodeAnalysisForm onAnalysisCompleted={handleAnalysisCompleted} />
      ) : (
        <>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Analysis Results
                <span className="text-sm font-normal bg-primary/10 text-primary px-2 py-1 rounded">
                  Provider: {analysisResult.provider === "openai" ? "OpenAI GPT-4o" : 
                            analysisResult.provider === "gemini" ? "Google Gemini" : "Demo Mode"}
                </span>
              </CardTitle>
              <CardDescription>
                Found {analysisResult.issues.length} issues in your {analysisResult.language} code
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-muted-foreground">
                {analysisResult.summary}
              </p>
              
              <Button 
                variant="outline" 
                className="mb-6"
                onClick={() => setAnalysisResult(null)}
              >
                Analyze New Code
              </Button>
            </CardContent>
          </Card>
          
          <Tabs defaultValue="code" className="w-full">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="code">Original & Fixed Code</TabsTrigger>
              <TabsTrigger value="recommendations">Issue Details</TabsTrigger>
            </TabsList>
            
            <TabsContent value="code" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Original Code</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CodeViewer 
                      code={analysisResult.code} 
                      language={analysisResult.language} 
                      issues={analysisResult.issues}
                    />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Fixed Code</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CodeViewer 
                      code={analysisResult.fixedCode} 
                      language={analysisResult.language}
                      issues={[]}
                    />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="recommendations">
              <AIRecommendation 
                issues={analysisResult.issues}
                fixedCode={analysisResult.fixedCode}
                language={analysisResult.language}
                summary={analysisResult.summary}
              />
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}