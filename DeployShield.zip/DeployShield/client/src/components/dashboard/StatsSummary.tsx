import { Shield, AlertTriangle, CheckCircle, Upload } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface StatsProps {
  stats: {
    projectsSecured: number;
    securityAlerts: number;
    issuesFixed: number;
    deployments: number;
  };
  isLoading: boolean;
}

export default function StatsSummary({ stats, isLoading }: StatsProps) {
  return (
    <div className="flex flex-wrap -mx-3">
      <div className="w-full md:w-1/2 xl:w-1/4 px-3 mb-6">
        <div className="flex items-center px-5 py-6 bg-white rounded-md shadow-sm">
          <div className="p-3 bg-blue-500 bg-opacity-10 rounded-full">
            <Shield className="w-8 h-8 text-blue-500" />
          </div>

          <div className="mx-5">
            {isLoading ? (
              <Skeleton className="h-8 w-12 mb-1" />
            ) : (
              <h4 className="text-2xl font-semibold text-gray-700">{stats.projectsSecured}</h4>
            )}
            <div className="text-gray-500">Projects Secured</div>
          </div>
        </div>
      </div>

      <div className="w-full md:w-1/2 xl:w-1/4 px-3 mb-6">
        <div className="flex items-center px-5 py-6 bg-white rounded-md shadow-sm">
          <div className="p-3 bg-red-500 bg-opacity-10 rounded-full">
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
          
          <div className="mx-5">
            {isLoading ? (
              <Skeleton className="h-8 w-12 mb-1" />
            ) : (
              <h4 className="text-2xl font-semibold text-gray-700">{stats.securityAlerts}</h4>
            )}
            <div className="text-gray-500">Security Alerts</div>
          </div>
        </div>
      </div>

      <div className="w-full md:w-1/2 xl:w-1/4 px-3 mb-6">
        <div className="flex items-center px-5 py-6 bg-white rounded-md shadow-sm">
          <div className="p-3 bg-green-500 bg-opacity-10 rounded-full">
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>

          <div className="mx-5">
            {isLoading ? (
              <Skeleton className="h-8 w-12 mb-1" />
            ) : (
              <h4 className="text-2xl font-semibold text-gray-700">{stats.issuesFixed}</h4>
            )}
            <div className="text-gray-500">Issues Fixed</div>
          </div>
        </div>
      </div>

      <div className="w-full md:w-1/2 xl:w-1/4 px-3 mb-6">
        <div className="flex items-center px-5 py-6 bg-white rounded-md shadow-sm">
          <div className="p-3 bg-purple-500 bg-opacity-10 rounded-full">
            <Upload className="w-8 h-8 text-purple-500" />
          </div>

          <div className="mx-5">
            {isLoading ? (
              <Skeleton className="h-8 w-12 mb-1" />
            ) : (
              <h4 className="text-2xl font-semibold text-gray-700">{stats.deployments}</h4>
            )}
            <div className="text-gray-500">Deployments</div>
          </div>
        </div>
      </div>
    </div>
  );
}
