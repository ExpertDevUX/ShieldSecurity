import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Project, SecurityScan } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface SecurityTableProps {
  scans: SecurityScan[];
  projects: Project[];
  isLoading: boolean;
}

export default function SecurityTable({ scans, projects, isLoading }: SecurityTableProps) {
  const { toast } = useToast();

  const getProjectName = (projectId: number) => {
    const project = projects.find(p => p.id === projectId);
    return project ? project.name : "Unknown Project";
  };

  const getProjectLanguage = (projectId: number) => {
    const project = projects.find(p => p.id === projectId);
    return project ? project.language : "Unknown";
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "Needs Attention":
        return "px-2 py-1 text-xs text-red-600 bg-red-100 rounded-full";
      case "Low Risk":
        return "px-2 py-1 text-xs text-orange-600 bg-orange-100 rounded-full";
      case "Secure":
        return "px-2 py-1 text-xs text-green-600 bg-green-100 rounded-full";
      default:
        return "px-2 py-1 text-xs text-gray-600 bg-gray-100 rounded-full";
    }
  };

  const getFormattedTime = (date: Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  const handleFixClick = async (scanId: number) => {
    try {
      // Get vulnerabilities for this scan
      const response = await fetch(`/api/vulnerabilities?scanId=${scanId}`);
      if (!response.ok) throw new Error("Failed to fetch vulnerabilities");
      
      const vulnerabilities = await response.json();
      
      // Update each vulnerability to fixed status
      for (const vuln of vulnerabilities) {
        await apiRequest("PATCH", `/api/vulnerabilities/${vuln.id}`, { fixed: true });
      }
      
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ["/api/vulnerabilities"] });
      
      toast({
        title: "Issues fixed",
        description: "All vulnerabilities have been marked as fixed",
      });
    } catch (error) {
      console.error("Error fixing issues:", error);
      toast({
        title: "Error",
        description: "Failed to fix issues. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="p-5 overflow-x-auto">
        <div className="space-y-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-5 overflow-x-auto">
      <table className="w-full table-auto">
        <thead>
          <tr className="text-left text-sm font-semibold text-gray-600 border-b">
            <th className="px-4 py-3">Project</th>
            <th className="px-4 py-3">Language</th>
            <th className="px-4 py-3">Last Scan</th>
            <th className="px-4 py-3">Vulnerabilities</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {scans.length === 0 ? (
            <tr>
              <td colSpan={6} className="px-4 py-3 text-sm text-center text-gray-500">
                No security scans found. Start a new scan to see results here.
              </td>
            </tr>
          ) : (
            scans.map((scan) => (
              <tr key={scan.id} className="border-b">
                <td className="px-4 py-3 text-sm">{getProjectName(scan.projectId)}</td>
                <td className="px-4 py-3 text-sm">{getProjectLanguage(scan.projectId)}</td>
                <td className="px-4 py-3 text-sm">{getFormattedTime(scan.scanDate)}</td>
                <td className="px-4 py-3 text-sm">
                  <div className="flex items-center">
                    {scan.highSeverity > 0 && (
                      <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 bg-red-500 rounded">{scan.highSeverity}</span>
                    )}
                    {scan.mediumSeverity > 0 && (
                      <span className="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-orange-100 bg-orange-500 rounded">{scan.mediumSeverity}</span>
                    )}
                    {scan.lowSeverity > 0 && (
                      <span className="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-blue-100 bg-blue-500 rounded">{scan.lowSeverity}</span>
                    )}
                    {scan.highSeverity === 0 && scan.mediumSeverity === 0 && scan.lowSeverity === 0 && (
                      <span className="text-green-500 text-xs">No issues found</span>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className={getStatusBadgeClass(scan.status)}>{scan.status}</span>
                </td>
                <td className="px-4 py-3 text-sm">
                  <div className="flex space-x-2">
                    {(scan.highSeverity > 0 || scan.mediumSeverity > 0 || scan.lowSeverity > 0) && (
                      <Button 
                        variant="default" 
                        size="sm" 
                        className="px-2 py-1 text-xs text-white bg-blue-500 rounded hover:bg-blue-600"
                        onClick={() => handleFixClick(scan.id)}
                      >
                        Fix
                      </Button>
                    )}
                    <Link href={`/security-scan?id=${scan.id}`}>
                      <Button 
                        variant="secondary" 
                        size="sm" 
                        className="px-2 py-1 text-xs text-white bg-gray-500 rounded hover:bg-gray-600"
                      >
                        Details
                      </Button>
                    </Link>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
