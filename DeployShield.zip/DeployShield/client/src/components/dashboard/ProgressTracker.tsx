import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Clock, BarChart4 } from "lucide-react";
import { type Task } from "@shared/schema";
import UpdateTaskProgressDialog from "./UpdateTaskProgressDialog";

interface ProgressTrackerProps {
  tasks: Task[];
}

export default function ProgressTracker({ tasks }: ProgressTrackerProps) {
  const [activeFilter, setActiveFilter] = useState<string>("all");
  
  const completedTasks = tasks.filter(task => task.status === "completed");
  const inProgressTasks = tasks.filter(task => task.status === "in-progress");
  const pendingTasks = tasks.filter(task => task.status === "pending");
  
  const filteredTasks = activeFilter === "all" 
    ? tasks 
    : tasks.filter(task => task.status === activeFilter);
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "in-progress":
        return <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>;
      case "pending":
        return <Badge className="bg-gray-100 text-gray-800">Pending</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getOverallProgress = () => {
    if (tasks.length === 0) return 0;
    const total = tasks.reduce((sum, task) => sum + task.progress, 0);
    return Math.round(total / tasks.length);
  };
  
  const getFormattedDate = (date: Date | null) => {
    if (!date) return "No deadline";
    return new Date(date).toLocaleDateString();
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center">
          <BarChart4 className="w-5 h-5 mr-2 text-blue-500" />
          Project Progress Tracker
        </CardTitle>
        <CardDescription>
          <div className="flex justify-between items-center">
            <div>Track and manage your security and deployment tasks</div>
            <Badge 
              className={
                getOverallProgress() >= 80 
                  ? "bg-green-100 text-green-800" 
                  : getOverallProgress() >= 50 
                    ? "bg-yellow-100 text-yellow-800" 
                    : "bg-red-100 text-red-800"
              }
            >
              {getOverallProgress()}% Complete
            </Badge>
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-gray-700">Overall Progress</h3>
            <span className="text-sm text-gray-500">{completedTasks.length}/{tasks.length} tasks</span>
          </div>
          <Progress value={getOverallProgress()} className="h-2" />
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-green-50 p-3 rounded-md border border-green-100 flex justify-between items-center">
            <div>
              <div className="text-xs text-gray-500 mb-1">Completed</div>
              <div className="text-lg font-semibold text-green-600">{completedTasks.length}</div>
            </div>
            <CheckCircle className="h-8 w-8 text-green-500 opacity-20" />
          </div>
          
          <div className="bg-blue-50 p-3 rounded-md border border-blue-100 flex justify-between items-center">
            <div>
              <div className="text-xs text-gray-500 mb-1">In Progress</div>
              <div className="text-lg font-semibold text-blue-600">{inProgressTasks.length}</div>
            </div>
            <BarChart4 className="h-8 w-8 text-blue-500 opacity-20" />
          </div>
          
          <div className="bg-gray-50 p-3 rounded-md border border-gray-100 flex justify-between items-center">
            <div>
              <div className="text-xs text-gray-500 mb-1">Pending</div>
              <div className="text-lg font-semibold text-gray-600">{pendingTasks.length}</div>
            </div>
            <Clock className="h-8 w-8 text-gray-500 opacity-20" />
          </div>
        </div>
        
        <div className="flex space-x-2 mb-4">
          <Button 
            variant={activeFilter === "all" ? "default" : "outline"} 
            size="sm"
            onClick={() => setActiveFilter("all")}
          >
            All ({tasks.length})
          </Button>
          <Button 
            variant={activeFilter === "completed" ? "default" : "outline"} 
            size="sm"
            onClick={() => setActiveFilter("completed")}
            className={activeFilter === "completed" ? "bg-green-600" : ""}
          >
            Completed ({completedTasks.length})
          </Button>
          <Button 
            variant={activeFilter === "in-progress" ? "default" : "outline"} 
            size="sm"
            onClick={() => setActiveFilter("in-progress")}
            className={activeFilter === "in-progress" ? "bg-blue-600" : ""}
          >
            In Progress ({inProgressTasks.length})
          </Button>
          <Button 
            variant={activeFilter === "pending" ? "default" : "outline"} 
            size="sm"
            onClick={() => setActiveFilter("pending")}
            className={activeFilter === "pending" ? "bg-gray-500" : ""}
          >
            Pending ({pendingTasks.length})
          </Button>
        </div>
        
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {filteredTasks.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No tasks found with the selected filter
            </div>
          ) : (
            filteredTasks.map(task => (
              <div key={task.id} className="p-3 bg-white border rounded-md flex justify-between items-center">
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{task.name}</h4>
                  <div className="flex items-center mt-1">
                    <Badge variant="outline" className="text-xs mr-2">{task.category}</Badge>
                    {getStatusBadge(task.status)}
                  </div>
                </div>
                <div className="text-right flex items-center">
                  <div>
                    <div className="flex items-center">
                      <Progress value={task.progress} className="h-2 w-20 mr-2" />
                      <span className="text-xs text-gray-600">{task.progress}%</span>
                    </div>
                    <div className="text-xs text-gray-500 mt-1 flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {getFormattedDate(task.dueDate)}
                    </div>
                  </div>
                  <UpdateTaskProgressDialog task={task} />
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}