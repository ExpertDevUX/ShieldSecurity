import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Project } from "@shared/schema";
import { CheckCircle, XCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DeploymentPanelProps {
  projects: Project[];
}

export default function DeploymentPanel({ projects }: DeploymentPanelProps) {
  const [selectedProject, setSelectedProject] = useState("");
  const [deploymentTarget, setDeploymentTarget] = useState("AWS EC2");
  const { toast } = useToast();

  const handleProjectChange = (value: string) => {
    setSelectedProject(value);
    
    // Find selected project to update repository field
    const project = projects.find(p => p.id.toString() === value);
    if (project) {
      setRepository(project.repository);
    }
  };

  const [repository, setRepository] = useState(
    projects.length > 0 ? projects[0].repository : "https://github.com/username/repo"
  );

  const deploymentTargets = [
    "AWS EC2",
    "Google Cloud",
    "Microsoft Azure",
    "Heroku",
    "Netlify"
  ];

  // For demo purposes
  const recentDeployments = [
    { project: "Admin Dashboard", time: "2 days ago", status: "success" },
    { project: "Marketing Website", time: "4 days ago", status: "success" },
    { project: "E-commerce API", time: "1 week ago", status: "failed" }
  ];
  
  const handleDeploy = async () => {
    if (!selectedProject) {
      toast({
        title: "Error",
        description: "Please select a project to deploy",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const projectId = parseInt(selectedProject);
      const response = await apiRequest("POST", "/api/deployments", {
        projectId,
        target: deploymentTarget,
        status: "In Progress",
        logs: `Starting deployment to ${deploymentTarget}...`
      });
      
      toast({
        title: "Deployment started",
        description: `Deploying to ${deploymentTarget}`,
      });
      
      // In a real app, this would trigger a background job
      // For demo, we'll simulate deployment completion after a delay
      setTimeout(async () => {
        await apiRequest("PATCH", `/api/deployments/${response.id}`, {
          status: "Success",
          logs: `Deployment to ${deploymentTarget} completed successfully.`
        });
        
        toast({
          title: "Deployment successful",
          description: `Your application has been deployed to ${deploymentTarget}`,
        });
        
        window.location.reload();
      }, 3000);
      
    } catch (error) {
      console.error("Deployment error:", error);
      toast({
        title: "Deployment failed",
        description: "An error occurred during deployment",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-white rounded-md shadow-sm h-full">
      <div className="px-5 py-4 border-b">
        <h3 className="text-lg font-semibold text-gray-700">One-Click Deployment</h3>
      </div>
      
      <div className="p-5 space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="project-select">
            Project
          </label>
          <Select value={selectedProject} onValueChange={handleProjectChange}>
            <SelectTrigger id="project-select">
              <SelectValue placeholder="Select project" />
            </SelectTrigger>
            <SelectContent>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="project-repository">
            Project Repository
          </label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <Input
              id="project-repository"
              value={repository}
              onChange={(e) => setRepository(e.target.value)}
              className="block w-full pr-10 border-gray-300 focus:ring-primary focus:border-primary rounded-md"
              placeholder="https://github.com/username/repo"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="deployment-target">
            Deployment Target
          </label>
          <Select value={deploymentTarget} onValueChange={setDeploymentTarget}>
            <SelectTrigger id="deployment-target">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {deploymentTargets.map((target) => (
                <SelectItem key={target} value={target}>
                  {target}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Pre-Deployment Checks
          </label>
          <div className="bg-gray-50 rounded-md p-3">
            <div className="flex items-center space-x-2 text-sm">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span className="text-gray-600">Code quality verified</span>
            </div>
            <div className="flex items-center space-x-2 text-sm mt-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span className="text-gray-600">Security scan completed</span>
            </div>
            <div className="flex items-center space-x-2 text-sm mt-2">
              <XCircle className="h-5 w-5 text-red-500" />
              <span className="text-gray-600">High-risk vulnerabilities found</span>
            </div>
          </div>
        </div>

        <div className="pt-2">
          <Button
            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-500 hover:bg-blue-600 focus:outline-none"
            onClick={handleDeploy}
          >
            Deploy Application
          </Button>
          <div className="text-center mt-2 text-xs text-gray-500">
            Recommended: Fix security issues before deployment
          </div>
        </div>

        <div className="border-t pt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Recent Deployments</h4>
          <div className="space-y-3">
            {recentDeployments.map((deployment, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <span 
                    className={`inline-block w-2 h-2 ${deployment.status === 'success' ? 'bg-green-500' : 'bg-red-500'} rounded-full mr-2`}
                  ></span>
                  <span>{deployment.project}</span>
                </div>
                <span className="text-gray-500 text-xs">{deployment.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
