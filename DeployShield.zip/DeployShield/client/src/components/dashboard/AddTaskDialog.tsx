import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import TaskForm from "./TaskForm";
import type { Project } from "@shared/schema";

interface AddTaskDialogProps {
  projects: Project[];
}

export default function AddTaskDialog({ projects }: AddTaskDialogProps) {
  const [open, setOpen] = useState(false);
  
  const handleSuccess = () => {
    // Close dialog when task is successfully created
    setOpen(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full bg-blue-500 hover:bg-blue-600">
          <Plus className="mr-2 h-4 w-4" /> Add New Task
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Task</DialogTitle>
          <DialogDescription>
            Create a new task to track your progress on deployments, security fixes, or 
            other project work items.
          </DialogDescription>
        </DialogHeader>
        <div className="mt-4">
          <TaskForm projects={projects} onSuccess={handleSuccess} />
        </div>
      </DialogContent>
    </Dialog>
  );
}