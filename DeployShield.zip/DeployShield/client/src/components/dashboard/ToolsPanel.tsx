import { Link } from "wouter";
import { Shield, Terminal, BarChart } from "lucide-react";

export default function ToolsPanel() {
  const tools = [
    {
      title: "Code Security Scan",
      description: "Automatically detect and fix security vulnerabilities in your code with AI-powered analysis.",
      icon: <Shield className="h-6 w-6 text-blue-600" />,
      color: "bg-blue-100",
      path: "/security-scan",
      action: "Start a new scan"
    },
    {
      title: "Penetration Testing",
      description: "Run automated penetration tests to identify security weaknesses in your web applications.",
      icon: <Terminal className="h-6 w-6 text-purple-600" />,
      color: "bg-purple-100",
      path: "/pen-testing",
      action: "Run pen test"
    },
    {
      title: "SEO Analysis",
      description: "Analyze and improve your website's search engine ranking with comprehensive SEO reports.",
      icon: <BarChart className="h-6 w-6 text-green-600" />,
      color: "bg-green-100",
      path: "/seo-analysis",
      action: "Analyze SEO"
    }
  ];

  return (
    <div className="mt-6">
      <h3 className="text-lg font-semibold text-gray-700 mb-4">Available Tools</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool, index) => (
          <div key={index} className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className={`flex-shrink-0 p-3 rounded-md ${tool.color}`}>
                  {tool.icon}
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium text-gray-900">{tool.title}</h4>
                  <p className="mt-1 text-sm text-gray-500">
                    {tool.title.split(" ")[0]} tools
                  </p>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-500">
                  {tool.description}
                </p>
              </div>
            </div>
            <div className="bg-gray-50 px-5 py-3">
              <div className="text-sm">
                <Link href={tool.path} className="font-medium text-blue-500 hover:text-blue-700">
                  {tool.action} &rarr;
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
