import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Project } from "@shared/schema";
import { AlertCircle, CheckCircle } from "lucide-react";

interface CodeAnalysisProps {
  projects: Project[];
}

export default function CodeAnalysis({ projects }: CodeAnalysisProps) {
  const [selectedProject, setSelectedProject] = useState<string>("");

  const handleProjectChange = (value: string) => {
    setSelectedProject(value);
  };

  // For demo purposes, we'll use a hardcoded code sample
  const codeSnippet = `const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

// Missing input validation (High Risk)
app.post('/api/users', (req, res) => {
  const user = req.body;
  // Direct use of user input without validation
  db.query(\`INSERT INTO users VALUES (\${user.id}, '\${user.name}')\`);
  res.json({ success: true });
});

// Missing error handling (Medium Risk)
app.get('/api/products', (req, res) => {
  db.query('SELECT * FROM products', (result) => {
    res.json(result.rows);
    // No error handling here
  });
});

app.listen(port, () => {
  console.log(\`Server running on port \${port}\`);
});`;

  return (
    <div className="bg-white rounded-md shadow-sm h-full">
      <div className="flex items-center justify-between px-5 py-4 border-b">
        <h3 className="text-lg font-semibold text-gray-700">AI Code Analysis</h3>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">Project:</span>
          <Select value={selectedProject} onValueChange={handleProjectChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select project" />
            </SelectTrigger>
            <SelectContent>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="p-5">
        {/* Code View with highlight */}
        <div className="mb-5 bg-gray-800 rounded-md overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2 bg-gray-900">
            <div className="text-sm text-gray-200 font-mono">server.js</div>
            <div className="text-xs text-gray-400">NodeJS</div>
          </div>
          <div className="p-4 text-gray-100 font-mono text-sm overflow-x-auto">
            <pre>
              <code>
                {codeSnippet.split('\n').map((line, index) => {
                  let className = "";
                  if (line.includes("INSERT INTO") || line.includes("// Missing input validation")) {
                    className = "bg-red-900 bg-opacity-40 px-1 -mx-1 block";
                  } else if (line.includes("// Missing error handling") || line.includes("db.query('SELECT * FROM products")) {
                    className = "bg-yellow-900 bg-opacity-40 px-1 -mx-1 block";
                  }
                  
                  // Apply syntax highlighting (simplified version)
                  const highlightedLine = line
                    .replace(/(const|let|var|require)/g, '<span class="text-blue-400">$1</span>')
                    .replace(/('.+?'|".+?"|`[^`]*`)/g, '<span class="text-green-400">$1</span>')
                    .replace(/(\/\/.+)/g, '<span class="text-gray-500">$1</span>')
                    .replace(/\b(\d+)\b/g, '<span class="text-yellow-400">$1</span>');
                  
                  return (
                    <div key={index} className={className} dangerouslySetInnerHTML={{ __html: highlightedLine }} />
                  );
                })}
              </code>
            </pre>
          </div>
        </div>

        {/* AI Suggestions */}
        <div className="bg-gray-50 rounded-md p-4 border">
          <h4 className="text-md font-semibold text-gray-700 mb-3">AI-Powered Fix Suggestions</h4>
          <div className="space-y-4">
            <div className="p-3 bg-red-50 border border-red-200 rounded-md">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </div>
                <div className="ml-3">
                  <h5 className="text-sm font-medium text-red-800">SQL Injection Vulnerability (High Risk)</h5>
                  <div className="mt-1 text-xs text-red-700">
                    Direct insertion of user input into SQL query on line 8 creates SQL injection vulnerability.
                  </div>
                  <div className="mt-2 bg-white p-2 rounded border border-red-200 text-xs text-gray-800 font-mono">
                    <span className="text-green-600">// Use parameterized queries</span><br />
                    db.query('INSERT INTO users VALUES($1, $2)', [user.id, user.name]);
                  </div>
                </div>
              </div>
            </div>

            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                </div>
                <div className="ml-3">
                  <h5 className="text-sm font-medium text-yellow-800">Missing Error Handling (Medium Risk)</h5>
                  <div className="mt-1 text-xs text-yellow-700">
                    Database query on line 14 lacks error handling, could lead to unhandled exceptions.
                  </div>
                  <div className="mt-2 bg-white p-2 rounded border border-yellow-200 text-xs text-gray-800 font-mono">
                    <span className="text-green-600">// Add proper error handling</span><br />
                    db.query('SELECT * FROM products', (err, result) =&gt; &#123;<br />
                    &nbsp;&nbsp;if (err) &#123;<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;return res.status(500).json(&#123; error: 'Database error' &#125;);<br />
                    &nbsp;&nbsp;&#125;<br />
                    &nbsp;&nbsp;res.json(result.rows);<br />
                    &#125;);
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <Button className="px-4 py-2 bg-blue-500 text-white text-sm font-medium rounded-md hover:bg-blue-600 focus:outline-none">
              Apply All Fixes
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
