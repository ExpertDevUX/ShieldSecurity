import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Download,
  Copy,
  CheckCircle,
  AlertTriangle,
  XCircle,
  FileText,
  Code,
  Sparkles,
  ArrowRight,
  ExternalLink,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

interface SEOAdvancedSuggestionsProps {
  analysisReport: Record<string, any>;
  url: string;
}

export default function SEOAdvancedSuggestions({
  analysisReport,
  url,
}: SEOAdvancedSuggestionsProps) {
  const { toast } = useToast();
  const [expandedSection, setExpandedSection] = useState<string | undefined>(undefined);
  const [showAllSuggestions, setShowAllSuggestions] = useState(false);

  // Extract data from the analysis
  const metaTags = analysisReport?.metaTags || {};
  const links = analysisReport?.links || {};
  const images = analysisReport?.images || {};
  const performance = analysisReport?.performance || {};
  const mobile = analysisReport?.mobile || {};

  // Generate priority score for each suggestion
  const suggestions = [
    // Meta tags suggestions
    ...(metaTags.title === "Missing" 
      ? [{
          id: "missing-title",
          category: "metaTags",
          priority: "high",
          title: "Add a title tag",
          description: "Title tags are critical for SEO and user experience",
          impact: "High impact on search rankings and click-through rates",
          implementation: `<title>Your Primary Keyword - Your Brand Name</title>`,
          codeLanguage: "html",
          additionalTips: [
            "Keep titles under 60 characters",
            "Place important keywords near the beginning",
            "Make each page title unique",
          ],
          tools: [
            {
              name: "Title Tag Preview Tool",
              url: "https://mangools.com/free-seo-tools/serp-simulator",
            },
          ],
        }]
      : []),
    ...(metaTags.title === "Present but could be improved"
      ? [{
          id: "improve-title",
          category: "metaTags",
          priority: "medium",
          title: "Optimize your title tag",
          description: "Your title could be more effective for SEO",
          impact: "Medium impact on search rankings and click-through rates",
          implementation: `<title>Primary Keyword | Secondary Keyword | Brand</title>`,
          codeLanguage: "html",
          additionalTips: [
            "Use a compelling call-to-action if appropriate",
            "Consider using numbers (e.g., '5 Ways to...')",
            "Use power words that trigger emotional responses",
          ],
          tools: [
            {
              name: "CoSchedule Headline Analyzer",
              url: "https://coschedule.com/headline-analyzer",
            },
          ],
        }]
      : []),
    ...(metaTags.description === "Missing"
      ? [{
          id: "missing-description",
          category: "metaTags",
          priority: "high",
          title: "Add a meta description",
          description: "Meta descriptions help search engines and users understand your page content",
          impact: "High impact on click-through rates from search results",
          implementation: `<meta name="description" content="Your compelling description that includes key phrases and a call to action, kept under 160 characters for optimal display in search results.">`,
          codeLanguage: "html",
          additionalTips: [
            "Include your primary keyword naturally",
            "Create a unique description for each page",
            "Add a call-to-action when appropriate",
          ],
          tools: [
            {
              name: "Meta Description Preview Tool",
              url: "https://www.portent.com/serp-preview-tool",
            },
          ],
        }]
      : []),
    ...(metaTags.description === "Present but too short"
      ? [{
          id: "improve-description",
          category: "metaTags",
          priority: "medium",
          title: "Extend your meta description",
          description: "Your description is too short to be fully effective",
          impact: "Medium impact on click-through rates from search results",
          implementation: `<meta name="description" content="Expand your description to between 120-160 characters. Include relevant keywords and a compelling reason for users to click through to your page from search results.">`,
          codeLanguage: "html",
          additionalTips: [
            "Aim for 120-160 characters",
            "Incorporate relevant keywords naturally",
            "Highlight unique selling points",
          ],
          tools: [
            {
              name: "SERP Preview Tool",
              url: "https://www.portent.com/serp-preview-tool",
            },
          ],
        }]
      : []),
      
    // Links suggestions
    ...(links.broken > 0
      ? [{
          id: "fix-broken-links",
          category: "links",
          priority: "high",
          title: `Fix ${links.broken} broken links`,
          description: "Broken links harm user experience and SEO performance",
          impact: "High impact on search rankings and user experience",
          implementation: `Use a tool like Screaming Frog to identify and fix all broken links`,
          codeLanguage: "text",
          additionalTips: [
            "Regularly audit your site for broken links",
            "Set up proper 301 redirects for changed URLs",
            "Update or remove outdated content and links",
          ],
          tools: [
            {
              name: "Screaming Frog SEO Spider",
              url: "https://www.screamingfrog.co.uk/seo-spider/",
            },
            {
              name: "Broken Link Checker",
              url: "https://www.brokenlinkcheck.com/",
            },
          ],
        }]
      : []),
    ...(links.internal < 3
      ? [{
          id: "increase-internal-links",
          category: "links",
          priority: "medium",
          title: "Add more internal links",
          description: "Internal linking helps search engines discover and understand your content",
          impact: "Medium impact on site structure and page authority",
          implementation: `Identify opportunities to link to related content within your site`,
          codeLanguage: "html",
          exampleCode: `<a href="/related-page">descriptive anchor text</a>`,
          additionalTips: [
            "Use descriptive anchor text containing relevant keywords",
            "Link to your most important pages more frequently",
            "Create a logical hierarchy with your internal linking",
          ],
          tools: [
            {
              name: "Internal Link Analyzer",
              url: "https://sitebulb.com/",
            },
          ],
        }]
      : []),
      
    // Images suggestions
    ...(images.missingAlt > 0
      ? [{
          id: "add-alt-text",
          category: "images",
          priority: "high",
          title: `Add alt text to ${images.missingAlt} images`,
          description: "Alt text improves accessibility and helps search engines understand your images",
          impact: "Medium impact on accessibility and image search visibility",
          implementation: `<img src="image.jpg" alt="Descriptive text about the image">`,
          codeLanguage: "html",
          additionalTips: [
            "Make alt text descriptive but concise",
            "Include relevant keywords when appropriate",
            "Don't stuff keywords into alt text",
          ],
          tools: [
            {
              name: "WebAIM's Alternative Text Guide",
              url: "https://webaim.org/techniques/alttext/",
            },
          ],
        }]
      : []),
    ...(images.oversized > 0
      ? [{
          id: "optimize-images",
          category: "images",
          priority: "high",
          title: `Optimize ${images.oversized} oversized images`,
          description: "Large images slow down your page loading time",
          impact: "High impact on page speed and user experience",
          implementation: `Use an image optimization tool to reduce file sizes without compromising quality`,
          codeLanguage: "text",
          additionalTips: [
            "Use next-gen formats like WebP",
            "Implement lazy loading for images",
            "Specify image dimensions in HTML",
            "Consider using responsive images with srcset",
          ],
          tools: [
            {
              name: "TinyPNG",
              url: "https://tinypng.com/",
            },
            {
              name: "Squoosh",
              url: "https://squoosh.app/",
            },
          ],
          exampleCode: `<!-- Responsive images example -->
<img 
  srcset="small.jpg 500w, medium.jpg 1000w, large.jpg 1500w" 
  sizes="(max-width: 600px) 500px, (max-width: 1200px) 1000px, 1500px" 
  src="fallback.jpg" 
  alt="Description of image"
>`,
        }]
      : []),
      
    // Performance suggestions
    ...(performance.pageSpeed && parseFloat(performance.pageSpeed) > 3
      ? [{
          id: "improve-page-speed",
          category: "performance",
          priority: "high",
          title: "Improve page loading speed",
          description: `Your page load time is ${performance.pageSpeed} which is slower than recommended`,
          impact: "High impact on user experience and search rankings",
          implementation: `Follow web performance best practices to improve loading speed`,
          codeLanguage: "text",
          additionalTips: [
            "Minimize and combine CSS and JavaScript files",
            "Enable browser caching",
            "Use a Content Delivery Network (CDN)",
            "Optimize server response time",
            "Implement critical CSS",
          ],
          tools: [
            {
              name: "Google PageSpeed Insights",
              url: "https://pagespeed.web.dev/",
            },
            {
              name: "GTmetrix",
              url: "https://gtmetrix.com/",
            },
          ],
          exampleCode: `<!-- Example critical CSS implementation -->
<style>
  /* Critical styles that appear above the fold */
  .header { ... }
  .hero { ... }
</style>
<link rel="preload" href="styles.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="styles.css"></noscript>`,
        }]
      : []),
      
    // Mobile suggestions
    ...(mobile.responsive === "No"
      ? [{
          id: "make-responsive",
          category: "mobile",
          priority: "critical",
          title: "Make your website mobile responsive",
          description: "Your site isn't optimized for mobile devices",
          impact: "Critical impact on mobile rankings and user experience",
          implementation: `Implement responsive design principles or use a mobile-first framework`,
          codeLanguage: "html",
          additionalTips: [
            "Use viewport meta tag",
            "Implement media queries",
            "Test on multiple device sizes",
            "Consider a mobile-first approach",
          ],
          tools: [
            {
              name: "Google's Mobile-Friendly Test",
              url: "https://search.google.com/test/mobile-friendly",
            },
          ],
          exampleCode: `<!-- Viewport meta tag -->
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Example media query -->
<style>
  @media (max-width: 768px) {
    .container {
      width: 100%;
      padding: 0 15px;
    }
  }
</style>`,
        }]
      : []),
    ...(mobile.touchElements === "Needs improvement"
      ? [{
          id: "improve-touch-elements",
          category: "mobile",
          priority: "medium",
          title: "Improve touch elements for mobile users",
          description: "Some clickable elements may be too small for mobile users",
          impact: "Medium impact on mobile user experience",
          implementation: `Ensure all touch targets are at least 44x44 pixels`,
          codeLanguage: "css",
          additionalTips: [
            "Add sufficient spacing between touch elements",
            "Make buttons and links large enough to tap easily",
            "Use :hover, :active, and :focus states appropriately",
          ],
          exampleCode: `.button {
  min-height: 44px;
  min-width: 44px;
  padding: 8px 16px;
  margin: 8px 0;
}

/* Add appropriate spacing between elements */
.nav-items > li {
  margin-right: 16px;
}`,
          tools: [
            {
              name: "Material Design Touch Targets",
              url: "https://material.io/design/usability/accessibility.html#layout-and-typography",
            },
          ],
        }]
      : []),
  ];

  // Count suggestions by priority
  const criticalCount = suggestions.filter(s => s.priority === "critical").length;
  const highCount = suggestions.filter(s => s.priority === "high").length;
  const mediumCount = suggestions.filter(s => s.priority === "medium").length;
  const lowCount = suggestions.filter(s => s.priority === "low").length;

  // Filter suggestions based on showAllSuggestions flag
  const displayedSuggestions = showAllSuggestions 
    ? suggestions 
    : suggestions.filter(s => s.priority === "critical" || s.priority === "high");

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The code sample has been copied to your clipboard.",
    });
  };

  const getSuggestionIcon = (priority: string) => {
    switch (priority) {
      case "critical":
        return <XCircle className="h-5 w-5 text-red-500" />;
      case "high":
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case "medium":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case "low":
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      default:
        return <AlertTriangle className="h-5 w-5 text-gray-500" />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "critical":
        return <Badge className="bg-red-100 text-red-800">Critical</Badge>;
      case "high":
        return <Badge className="bg-orange-100 text-orange-800">High</Badge>;
      case "medium":
        return <Badge className="bg-yellow-100 text-yellow-800">Medium</Badge>;
      case "low":
        return <Badge className="bg-green-100 text-green-800">Low</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Sparkles className="w-5 h-5 mr-2 text-blue-500" />
          Advanced SEO Recommendations
        </CardTitle>
        <CardDescription>
          Actionable insights to improve the SEO performance of {url}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {suggestions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">
              No issues detected!
            </h3>
            <p className="text-sm text-gray-500 max-w-md">
              Your website appears to follow SEO best practices in the analyzed areas.
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="bg-red-50 p-3 rounded-md border border-red-100 flex flex-col items-center justify-center">
                <span className="text-xs text-gray-500 mb-1">Critical</span>
                <span className="text-lg font-semibold text-red-600">{criticalCount}</span>
              </div>
              <div className="bg-orange-50 p-3 rounded-md border border-orange-100 flex flex-col items-center justify-center">
                <span className="text-xs text-gray-500 mb-1">High</span>
                <span className="text-lg font-semibold text-orange-600">{highCount}</span>
              </div>
              <div className="bg-yellow-50 p-3 rounded-md border border-yellow-100 flex flex-col items-center justify-center">
                <span className="text-xs text-gray-500 mb-1">Medium</span>
                <span className="text-lg font-semibold text-yellow-600">{mediumCount}</span>
              </div>
              <div className="bg-green-50 p-3 rounded-md border border-green-100 flex flex-col items-center justify-center">
                <span className="text-xs text-gray-500 mb-1">Low</span>
                <span className="text-lg font-semibold text-green-600">{lowCount}</span>
              </div>
            </div>

            {!showAllSuggestions && mediumCount + lowCount > 0 && (
              <div className="mb-6 p-3 bg-blue-50 rounded-md border border-blue-100 flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-blue-800">
                    {mediumCount + lowCount} more suggestions available
                  </p>
                  <p className="text-xs text-blue-600">
                    View all recommendations to see medium and low priority items
                  </p>
                </div>
                <Button 
                  size="sm" 
                  onClick={() => setShowAllSuggestions(true)}
                  className="bg-blue-600"
                >
                  Show All
                </Button>
              </div>
            )}

            <Accordion
              type="single"
              collapsible
              value={expandedSection}
              onValueChange={setExpandedSection}
              className="space-y-4"
            >
              {displayedSuggestions.map((suggestion) => (
                <AccordionItem
                  key={suggestion.id}
                  value={suggestion.id}
                  className="border rounded-md overflow-hidden"
                >
                  <AccordionTrigger className="px-4 py-3 hover:bg-gray-50">
                    <div className="flex items-center text-left">
                      {getSuggestionIcon(suggestion.priority)}
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-gray-900">
                          {suggestion.title}
                        </h3>
                        <p className="text-xs text-gray-500 mt-1">
                          {suggestion.description}
                        </p>
                      </div>
                    </div>
                    <div className="ml-auto mr-4">
                      {getPriorityBadge(suggestion.priority)}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4 pt-1">
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                          Impact
                        </h4>
                        <p className="text-sm text-gray-700">{suggestion.impact}</p>
                      </div>

                      <div>
                        <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                          Implementation
                        </h4>
                        <div className="bg-gray-50 rounded-md p-3 relative">
                          <pre className="text-xs text-gray-800 whitespace-pre-wrap font-mono">
                            {suggestion.implementation}
                          </pre>
                          {suggestion.codeLanguage === "html" && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-6 w-6 absolute top-2 right-2"
                                    onClick={() => copyToClipboard(suggestion.implementation)}
                                  >
                                    <Copy className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Copy code</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </div>
                      </div>

                      {suggestion.exampleCode && (
                        <div>
                          <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                            Example Code
                          </h4>
                          <div className="bg-gray-50 rounded-md p-3 relative">
                            <pre className="text-xs text-gray-800 whitespace-pre-wrap font-mono">
                              {suggestion.exampleCode}
                            </pre>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-6 w-6 absolute top-2 right-2"
                                    onClick={() => copyToClipboard(suggestion.exampleCode)}
                                  >
                                    <Copy className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Copy code</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </div>
                      )}

                      {suggestion.additionalTips && suggestion.additionalTips.length > 0 && (
                        <div>
                          <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                            Additional Tips
                          </h4>
                          <ul className="text-sm text-gray-700 list-disc pl-5 space-y-1">
                            {suggestion.additionalTips.map((tip, index) => (
                              <li key={index}>{tip}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {suggestion.tools && suggestion.tools.length > 0 && (
                        <div>
                          <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                            Helpful Tools
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {suggestion.tools.map((tool, index) => (
                              <a
                                key={index}
                                href={tool.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center text-xs bg-white border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors"
                              >
                                {tool.name}
                                <ExternalLink className="h-3 w-3 ml-1" />
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>

            <Separator className="my-6" />

            <div className="flex justify-between items-center">
              <div>
                <Button
                  variant="outline"
                  className="mr-2"
                  onClick={() => {
                    toast({
                      title: "Report generated",
                      description: "Full SEO report has been downloaded.",
                    });
                  }}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Report
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    toast({
                      description: "Generating PDF report...",
                    });
                  }}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Export as PDF
                </Button>
              </div>
              
              {!showAllSuggestions && mediumCount + lowCount > 0 ? (
                <Button 
                  onClick={() => setShowAllSuggestions(true)}
                  className="bg-blue-600"
                >
                  Show All {mediumCount + lowCount} Suggestions
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                showAllSuggestions && (
                  <Button 
                    onClick={() => setShowAllSuggestions(false)}
                    variant="outline"
                  >
                    Show Only High Priority
                  </Button>
                )
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}