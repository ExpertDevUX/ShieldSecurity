import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, AlertTriangle, CheckCircle, XCircle, Globe, Image, Zap, Smartphone } from "lucide-react";
import { SEOAnalysis } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface SEOReportProps {
  analysis: SEOAnalysis | undefined;
  isLoading: boolean;
}

export default function SEOReport({ analysis, isLoading }: SEOReportProps) {
  const getScoreColor = (score: number | null | undefined) => {
    if (!score) return "bg-gray-500";
    if (score >= 80) return "bg-green-500";
    if (score >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };
  
  const getFormattedTime = (date: Date | undefined) => {
    if (!date) return "Never";
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-3/4 mb-2" />
          <Skeleton className="h-4 w-full" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-40 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!analysis) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart className="w-5 h-5 mr-2 text-blue-500" />
            SEO Analysis Report
          </CardTitle>
          <CardDescription>
            Run an SEO analysis to see results here.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Globe className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">No Analysis Selected</h3>
            <p className="text-sm text-gray-500 max-w-md">
              Enter a website URL and run an SEO analysis to see detailed results and improvement suggestions.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Extract data from the analysis
  const report = analysis.report as Record<string, any>;
  const metaTags = report?.metaTags || {};
  const links = report?.links || {};
  const images = report?.images || {};
  const performance = report?.performance || {};
  const mobile = report?.mobile || {};
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <BarChart className="w-5 h-5 mr-2 text-blue-500" />
            SEO Analysis: {analysis.url}
          </CardTitle>
        </div>
        <CardDescription>
          Analysis performed {getFormattedTime(analysis.analysisDate)}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-gray-700">Overall SEO Score</h3>
            <span className="text-sm text-gray-500">{analysis.score}/100</span>
          </div>
          <Progress
            value={analysis.score || 0}
            className="h-2"
          />
          <div className="mt-2 flex justify-between text-xs text-gray-500">
            <span>Poor</span>
            <span>Good</span>
            <span>Excellent</span>
          </div>
        </div>
        
        <Tabs defaultValue="overview">
          <TabsList className="mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="meta">Meta Tags</TabsTrigger>
            <TabsTrigger value="links">Links</TabsTrigger>
            <TabsTrigger value="images">Images</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <CategoryOverview 
                title="Meta Tags" 
                icon={<Globe className="h-4 w-4" />}
                score={metaTags.score}
                issues={[
                  metaTags.title === "Missing" ? "Missing title tag" : null,
                  metaTags.description === "Missing" ? "Missing meta description" : null,
                  metaTags.description === "Present but too short" ? "Meta description too short" : null,
                  metaTags.keywords === "Missing" ? "Missing keywords" : null,
                ].filter(Boolean)}
              />
              
              <CategoryOverview 
                title="Links" 
                icon={<Globe className="h-4 w-4" />}
                score={links.score}
                issues={[
                  links.broken > 0 ? `${links.broken} broken links` : null,
                  links.external < 2 ? "Too few external links" : null,
                ].filter(Boolean)}
              />
              
              <CategoryOverview 
                title="Images" 
                icon={<Image className="h-4 w-4" />}
                score={images.score}
                issues={[
                  images.missingAlt > 0 ? `${images.missingAlt} images missing alt text` : null,
                  images.oversized > 0 ? `${images.oversized} oversized images` : null,
                ].filter(Boolean)}
              />
              
              <CategoryOverview 
                title="Performance" 
                icon={<Zap className="h-4 w-4" />}
                score={performance.score}
                issues={[
                  performance.pageSpeed && parseFloat(performance.pageSpeed) > 3 ? "Slow page loading time" : null,
                  performance.serverResponse && parseFloat(performance.serverResponse) > 0.5 ? "Slow server response" : null,
                ].filter(Boolean)}
              />
              
              <CategoryOverview 
                title="Mobile Friendliness" 
                icon={<Smartphone className="h-4 w-4" />}
                score={mobile.score}
                issues={[
                  mobile.responsive === "No" ? "Not mobile responsive" : null,
                  mobile.viewportSet === "No" ? "Viewport not set" : null,
                  mobile.touchElements === "Needs improvement" ? "Touch elements too small" : null,
                ].filter(Boolean)}
              />
            </div>
            
            <Separator className="my-6" />
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Top Recommendations</h3>
              <ul className="space-y-2">
                {metaTags.title === "Present but could be improved" && (
                  <li className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Improve page title</p>
                      <p className="text-xs text-gray-600">
                        Your title tag should be between 50-60 characters and include your primary keyword.
                      </p>
                    </div>
                  </li>
                )}
                
                {metaTags.description === "Present but too short" && (
                  <li className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Extend meta description</p>
                      <p className="text-xs text-gray-600">
                        Your meta description is too short. Aim for 150-160 characters that accurately summarize the page content.
                      </p>
                    </div>
                  </li>
                )}
                
                {links.broken > 0 && (
                  <li className="flex items-start">
                    <XCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Fix broken links</p>
                      <p className="text-xs text-gray-600">
                        Your page has {links.broken} broken links which negatively impact user experience and SEO.
                      </p>
                    </div>
                  </li>
                )}
                
                {images.missingAlt > 0 && (
                  <li className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Add image alt text</p>
                      <p className="text-xs text-gray-600">
                        {images.missingAlt} images are missing alt text. Add descriptive alt text to improve accessibility and SEO.
                      </p>
                    </div>
                  </li>
                )}
                
                {performance.pageSpeed && parseFloat(performance.pageSpeed) > 3 && (
                  <li className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Improve page speed</p>
                      <p className="text-xs text-gray-600">
                        Your page loading time is {performance.pageSpeed} which is slower than recommended. Compress images and minimize JavaScript.
                      </p>
                    </div>
                  </li>
                )}
              </ul>
            </div>
          </TabsContent>
          
          <TabsContent value="meta">
            <MetaTagsTab metaTags={metaTags} />
          </TabsContent>
          
          <TabsContent value="links">
            <LinksTab links={links} />
          </TabsContent>
          
          <TabsContent value="images">
            <ImagesTab images={images} />
          </TabsContent>
          
          <TabsContent value="performance">
            <PerformanceTab performance={performance} mobile={mobile} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

interface CategoryOverviewProps {
  title: string;
  icon: React.ReactNode;
  score: number | null | undefined;
  issues: (string | null)[];
}

function CategoryOverview({ title, icon, score, issues }: CategoryOverviewProps) {
  const getScoreColor = (score: number | null | undefined) => {
    if (!score) return "text-gray-500";
    if (score >= 80) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    return "text-red-500";
  };
  
  const getScoreIcon = (score: number | null | undefined) => {
    if (!score) return <AlertTriangle className="h-5 w-5 text-gray-500" />;
    if (score >= 80) return <CheckCircle className="h-5 w-5 text-green-500" />;
    if (score >= 60) return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
    return <XCircle className="h-5 w-5 text-red-500" />;
  };

  return (
    <div className="bg-white p-4 rounded-md border">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center">
          {icon}
          <h3 className="text-sm font-medium text-gray-700 ml-1">{title}</h3>
        </div>
        <div className="flex items-center">
          {getScoreIcon(score)}
          <span className={`ml-1 text-sm font-medium ${getScoreColor(score)}`}>{score || 'N/A'}</span>
        </div>
      </div>
      
      {issues.length > 0 ? (
        <ul className="mt-2 space-y-1">
          {issues.map((issue, index) => (
            <li key={index} className="text-xs text-gray-600 flex items-start">
              <span className="inline-block w-1 h-1 rounded-full bg-red-500 mt-1.5 mr-1.5"></span>
              {issue}
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-2 text-xs text-green-600 flex items-center">
          <CheckCircle className="h-3 w-3 mr-1" />
          No issues found
        </p>
      )}
    </div>
  );
}

function MetaTagsTab({ metaTags }: { metaTags: Record<string, any> }) {
  return (
    <div>
      <div className="mb-4">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Meta Tags Score: {metaTags.score}/100</h3>
        <Progress
          value={metaTags.score || 0}
          className={`h-2 ${metaTags.score && metaTags.score >= 80 ? 'bg-green-500' : metaTags.score && metaTags.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
        />
      </div>
      
      <div className="space-y-4">
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Title Tag</h4>
          <div className="text-xs text-gray-600">
            <p>Status: <span className={`font-medium ${metaTags.title === "Missing" ? 'text-red-600' : metaTags.title === "Present but could be improved" ? 'text-yellow-600' : 'text-green-600'}`}>{metaTags.title || "Not checked"}</span></p>
            <p className="mt-1">Recommendation: Keep your title between 50-60 characters and include your primary keyword.</p>
          </div>
        </div>
        
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Meta Description</h4>
          <div className="text-xs text-gray-600">
            <p>Status: <span className={`font-medium ${metaTags.description === "Missing" ? 'text-red-600' : metaTags.description === "Present but too short" ? 'text-yellow-600' : 'text-green-600'}`}>{metaTags.description || "Not checked"}</span></p>
            <p className="mt-1">Recommendation: Write a compelling meta description between 150-160 characters that accurately summarizes the page content.</p>
          </div>
        </div>
        
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Keywords</h4>
          <div className="text-xs text-gray-600">
            <p>Status: <span className={`font-medium ${metaTags.keywords === "Missing" ? 'text-red-600' : 'text-green-600'}`}>{metaTags.keywords || "Not checked"}</span></p>
            <p className="mt-1">Recommendation: While not as important as they once were, meta keywords can still help with some search engines. Include 3-5 relevant keywords.</p>
          </div>
        </div>
        
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Other Recommendations</h4>
          <ul className="text-xs text-gray-600 list-disc pl-5 space-y-1">
            <li>Ensure each page has a unique title and meta description</li>
            <li>Include your primary keyword near the beginning of the title</li>
            <li>Add structured data to enhance search result appearance</li>
            <li>Include a proper canonical URL to prevent duplicate content issues</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function LinksTab({ links }: { links: Record<string, any> }) {
  return (
    <div>
      <div className="mb-4">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Links Score: {links.score}/100</h3>
        <Progress
          value={links.score || 0}
          className={`h-2 ${links.score && links.score >= 80 ? 'bg-green-500' : links.score && links.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">Internal Links</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">{links.internal || 'N/A'}</p>
        </div>
        
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">External Links</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">{links.external || 'N/A'}</p>
        </div>
        
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">Broken Links</p>
          <p className="text-2xl font-semibold text-red-600 mt-1">{links.broken || '0'}</p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Link Issues</h4>
          <ul className="text-xs text-gray-600 space-y-2">
            {links.broken > 0 && (
              <li className="flex items-start">
                <XCircle className="h-4 w-4 text-red-500 mr-1.5 flex-shrink-0 mt-0.5" />
                <span>There are {links.broken} broken links on your page that need to be fixed</span>
              </li>
            )}
            {links.external < 3 && links.external !== null && (
              <li className="flex items-start">
                <AlertTriangle className="h-4 w-4 text-yellow-500 mr-1.5 flex-shrink-0 mt-0.5" />
                <span>Your page has very few external links ({links.external}). Adding more high-quality outbound links can improve authority</span>
              </li>
            )}
            {!links.broken && !(links.external < 3 && links.external !== null) && (
              <li className="flex items-start">
                <CheckCircle className="h-4 w-4 text-green-500 mr-1.5 flex-shrink-0 mt-0.5" />
                <span>No major link issues detected</span>
              </li>
            )}
          </ul>
        </div>
        
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Recommendations</h4>
          <ul className="text-xs text-gray-600 list-disc pl-5 space-y-1">
            <li>Fix all broken links to improve user experience and SEO</li>
            <li>Include descriptive anchor text for all links</li>
            <li>Add internal links to enhance site navigation and distribute page authority</li>
            <li>Include relevant external links to authoritative sites in your industry</li>
            <li>Use the rel="nofollow" attribute for untrusted content or sponsored links</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function ImagesTab({ images }: { images: Record<string, any> }) {
  return (
    <div>
      <div className="mb-4">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Images Score: {images.score}/100</h3>
        <Progress
          value={images.score || 0}
          className={`h-2 ${images.score && images.score >= 80 ? 'bg-green-500' : images.score && images.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">Total Images</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">{images.total || 'N/A'}</p>
        </div>
        
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">Missing Alt Text</p>
          <p className="text-2xl font-semibold text-red-600 mt-1">{images.missingAlt || '0'}</p>
        </div>
        
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">Oversized Images</p>
          <p className="text-2xl font-semibold text-yellow-600 mt-1">{images.oversized || '0'}</p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Image Issues</h4>
          <ul className="text-xs text-gray-600 space-y-2">
            {images.missingAlt > 0 && (
              <li className="flex items-start">
                <XCircle className="h-4 w-4 text-red-500 mr-1.5 flex-shrink-0 mt-0.5" />
                <span>{images.missingAlt} images are missing alt text, which impacts accessibility and SEO</span>
              </li>
            )}
            {images.oversized > 0 && (
              <li className="flex items-start">
                <AlertTriangle className="h-4 w-4 text-yellow-500 mr-1.5 flex-shrink-0 mt-0.5" />
                <span>{images.oversized} images are oversized and should be optimized to improve page loading speed</span>
              </li>
            )}
            {!images.missingAlt && !images.oversized && (
              <li className="flex items-start">
                <CheckCircle className="h-4 w-4 text-green-500 mr-1.5 flex-shrink-0 mt-0.5" />
                <span>No major image issues detected</span>
              </li>
            )}
          </ul>
        </div>
        
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Recommendations</h4>
          <ul className="text-xs text-gray-600 list-disc pl-5 space-y-1">
            <li>Add descriptive alt text to all images for better accessibility and SEO</li>
            <li>Compress and optimize all images to improve loading speed</li>
            <li>Use modern image formats like WebP for better compression</li>
            <li>Implement lazy loading for images below the fold</li>
            <li>Provide appropriate width and height attributes to prevent layout shifts</li>
            <li>Use responsive images with srcset for different screen sizes</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function PerformanceTab({ performance, mobile }: { performance: Record<string, any>, mobile: Record<string, any> }) {
  return (
    <div>
      <div className="mb-4">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Performance Score: {performance.score}/100</h3>
        <Progress
          value={performance.score || 0}
          className={`h-2 ${performance.score && performance.score >= 80 ? 'bg-green-500' : performance.score && performance.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">Page Load Time</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">{performance.pageSpeed || 'N/A'}</p>
        </div>
        
        <div className="bg-white p-4 rounded-md border text-center">
          <p className="text-sm text-gray-500">Server Response Time</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">{performance.serverResponse || 'N/A'}</p>
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Mobile Friendliness Score: {mobile.score}/100</h3>
        <Progress
          value={mobile.score || 0}
          className={`h-2 ${mobile.score && mobile.score >= 80 ? 'bg-green-500' : mobile.score && mobile.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
        />
      </div>
      
      <div className="space-y-4">
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Mobile Overview</h4>
          <ul className="text-xs text-gray-600 space-y-2">
            <li className="flex justify-between">
              <span>Responsive Design:</span>
              <span className={mobile.responsive === "Yes" ? "text-green-600" : "text-red-600"}>
                {mobile.responsive || 'Not checked'}
              </span>
            </li>
            <li className="flex justify-between">
              <span>Viewport Set:</span>
              <span className={mobile.viewportSet === "Yes" ? "text-green-600" : "text-red-600"}>
                {mobile.viewportSet || 'Not checked'}
              </span>
            </li>
            <li className="flex justify-between">
              <span>Touch Elements:</span>
              <span className={mobile.touchElements === "Yes" ? "text-green-600" : mobile.touchElements === "Needs improvement" ? "text-yellow-600" : "text-red-600"}>
                {mobile.touchElements || 'Not checked'}
              </span>
            </li>
          </ul>
        </div>
        
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Performance Recommendations</h4>
          <ul className="text-xs text-gray-600 list-disc pl-5 space-y-1">
            <li>Minimize and compress HTML, CSS, and JavaScript files</li>
            <li>Optimize and compress images</li>
            <li>Implement browser caching</li>
            <li>Reduce server response time</li>
            <li>Use a Content Delivery Network (CDN)</li>
            <li>Eliminate render-blocking resources</li>
            <li>Optimize CSS delivery</li>
            <li>Prioritize visible content</li>
          </ul>
        </div>
        
        <div className="p-3 bg-gray-50 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Mobile Recommendations</h4>
          <ul className="text-xs text-gray-600 list-disc pl-5 space-y-1">
            <li>Ensure responsive design that adapts to all screen sizes</li>
            <li>Set proper viewport meta tag</li>
            <li>Make touch elements (buttons, links) at least 48px by 48px</li>
            <li>Avoid using Flash content</li>
            <li>Keep font sizes readable without zooming</li>
            <li>Avoid horizontal scrolling</li>
            <li>Optimize for mobile data usage</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
