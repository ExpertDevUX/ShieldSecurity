import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { BarChart } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SEOFormProps {
  onAnalysisCompleted: (analysisId: number) => void;
}

const seoFormSchema = z.object({
  url: z.string().url("Please enter a valid URL"),
  checkMeta: z.boolean().default(true),
  checkLinks: z.boolean().default(true),
  checkImages: z.boolean().default(true),
  checkPerformance: z.boolean().default(true),
  checkMobile: z.boolean().default(true),
});

type SEOFormValues = z.infer<typeof seoFormSchema>;

export default function SEOForm({ onAnalysisCompleted }: SEOFormProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<SEOFormValues>({
    resolver: zodResolver(seoFormSchema),
    defaultValues: {
      url: "",
      checkMeta: true,
      checkLinks: true,
      checkImages: true,
      checkPerformance: true,
      checkMobile: true
    },
  });

  const onSubmit = async (data: SEOFormValues) => {
    setIsAnalyzing(true);
    try {
      // Generate mock report data for demonstration
      const reportData = {
        metaTags: {
          title: data.checkMeta ? "Present but could be improved" : null,
          description: data.checkMeta ? "Present but too short" : null,
          keywords: data.checkMeta ? "Missing" : null,
          score: data.checkMeta ? 65 : null
        },
        links: {
          internal: data.checkLinks ? 24 : null,
          external: data.checkLinks ? 8 : null,
          broken: data.checkLinks ? 3 : null,
          score: data.checkLinks ? 75 : null
        },
        images: {
          total: data.checkImages ? 15 : null,
          missingAlt: data.checkImages ? 6 : null,
          oversized: data.checkImages ? 4 : null,
          score: data.checkImages ? 60 : null
        },
        performance: {
          pageSpeed: data.checkPerformance ? "3.2s" : null,
          serverResponse: data.checkPerformance ? "0.8s" : null,
          score: data.checkPerformance ? 70 : null
        },
        mobile: {
          responsive: data.checkMobile ? "Yes" : null,
          viewportSet: data.checkMobile ? "Yes" : null,
          touchElements: data.checkMobile ? "Needs improvement" : null,
          score: data.checkMobile ? 80 : null
        }
      };
      
      // Calculate overall score
      const enabledCategories = [
        data.checkMeta, 
        data.checkLinks, 
        data.checkImages, 
        data.checkPerformance, 
        data.checkMobile
      ].filter(Boolean).length;
      
      const totalScore = data.checkMeta ? reportData.metaTags.score : 0 +
        data.checkLinks ? reportData.links.score : 0 +
        data.checkImages ? reportData.images.score : 0 +
        data.checkPerformance ? reportData.performance.score : 0 +
        data.checkMobile ? reportData.mobile.score : 0;
      
      const overallScore = Math.floor(totalScore / enabledCategories);
      
      // Create the SEO analysis
      const response = await apiRequest("POST", "/api/seo-analyses", {
        url: data.url,
        score: overallScore,
        report: reportData
      });
      
      toast({
        title: "SEO analysis completed",
        description: `Analysis for ${data.url} has been completed with a score of ${overallScore}/100.`,
      });
      
      onAnalysisCompleted(response.id);
      
    } catch (error) {
      console.error("Error performing SEO analysis:", error);
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing the website. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <BarChart className="w-5 h-5 mr-2 text-blue-500" />
          SEO Analysis
        </CardTitle>
        <CardDescription>
          Analyze website SEO and get recommendations for improvement.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Website URL</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="https://example.com" />
                  </FormControl>
                  <FormDescription>
                    Enter the full URL of the website you want to analyze.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-700">Analysis Options</h3>
              
              <FormField
                control={form.control}
                name="checkMeta"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Meta Tags</FormLabel>
                      <FormDescription>
                        Check title, description, and other meta tags
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="checkLinks"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Links & Structure</FormLabel>
                      <FormDescription>
                        Analyze internal and external links, broken links
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="checkImages"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Images</FormLabel>
                      <FormDescription>
                        Check image optimization, alt tags, and sizes
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="checkPerformance"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Performance</FormLabel>
                      <FormDescription>
                        Analyze page speed and loading performance
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="checkMobile"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Mobile Friendliness</FormLabel>
                      <FormDescription>
                        Check responsive design and mobile optimization
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>
            
            <Button type="submit" className="w-full" disabled={isAnalyzing}>
              {isAnalyzing ? "Analyzing..." : "Analyze Website"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
