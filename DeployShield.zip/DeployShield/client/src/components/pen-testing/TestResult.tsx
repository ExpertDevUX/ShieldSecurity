import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Terminal, AlertTriangle, ShieldAlert, AlertCircle, CheckCircle, Shield } from "lucide-react";
import { PenTest } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface TestResultProps {
  test: PenTest | undefined;
  isLoading: boolean;
}

export default function TestResult({ test, isLoading }: TestResultProps) {
  const getFormattedTime = (date: Date | undefined) => {
    if (!date) return "Never";
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "Critical":
        return <ShieldAlert className="h-5 w-5 text-red-600" />;
      case "High":
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case "Medium":
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case "Low":
        return <AlertCircle className="h-5 w-5 text-blue-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-500" />;
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "Critical":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Critical</Badge>;
      case "High":
        return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-200">High</Badge>;
      case "Medium":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Medium</Badge>;
      case "Low":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Low</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-3/4 mb-2" />
          <Skeleton className="h-4 w-full" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-40 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!test) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Terminal className="w-5 h-5 mr-2 text-blue-500" />
            Penetration Test Results
          </CardTitle>
          <CardDescription>
            Run a penetration test to see results here.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Shield className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">No Test Results Available</h3>
            <p className="text-sm text-gray-500 max-w-md">
              Select a target and configure your test options to begin a penetration test.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Extract data from the test findings
  const findings = test.findings as any;
  const summary = findings?.summary || {};
  const vulnerabilities = findings?.vulnerabilities || [];
  
  // Calculate totals
  const totalIssues = 
    (summary.critical || 0) + 
    (summary.high || 0) + 
    (summary.medium || 0) + 
    (summary.low || 0);

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <Terminal className="w-5 h-5 mr-2 text-blue-500" />
            Penetration Test: {test.target}
          </CardTitle>
          <Badge className={`${test.score >= 80 ? 'bg-green-100 text-green-800' : test.score >= 60 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
            Score: {test.score}/100
          </Badge>
        </div>
        <CardDescription>
          Test performed {getFormattedTime(test.testDate)}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-gray-700">Security Score</h3>
            <span className="text-sm text-gray-500">{test.score}/100</span>
          </div>
          <Progress
            value={test.score || 0}
            className={`h-2.5 ${
              test.score >= 80 
                ? 'bg-green-500' 
                : test.score >= 60 
                  ? 'bg-yellow-500' 
                  : 'bg-red-500'
            }`}
          />
          <div className="mt-1 flex justify-between text-xs text-gray-500">
            <span>High Risk</span>
            <span>Medium Risk</span>
            <span>Low Risk</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-red-50 p-4 rounded-md border border-red-100">
            <div className="text-xs text-gray-500 mb-1">Critical</div>
            <div className="text-2xl font-semibold text-red-600">{summary.critical || 0}</div>
          </div>
          
          <div className="bg-orange-50 p-4 rounded-md border border-orange-100">
            <div className="text-xs text-gray-500 mb-1">High</div>
            <div className="text-2xl font-semibold text-orange-600">{summary.high || 0}</div>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-md border border-yellow-100">
            <div className="text-xs text-gray-500 mb-1">Medium</div>
            <div className="text-2xl font-semibold text-yellow-600">{summary.medium || 0}</div>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
            <div className="text-xs text-gray-500 mb-1">Low</div>
            <div className="text-2xl font-semibold text-blue-600">{summary.low || 0}</div>
          </div>
        </div>
        
        <Tabs defaultValue="vulnerabilities">
          <TabsList className="mb-4">
            <TabsTrigger value="vulnerabilities">Vulnerabilities</TabsTrigger>
            <TabsTrigger value="details">Test Details</TabsTrigger>
            <TabsTrigger value="remediation">Remediation</TabsTrigger>
          </TabsList>
          
          <TabsContent value="vulnerabilities">
            {vulnerabilities.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No Vulnerabilities Found</h3>
                <p className="text-sm text-gray-500 max-w-md">
                  Great job! No security vulnerabilities were detected during the penetration test.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {vulnerabilities.map((vulnerability: any, index: number) => (
                  <div key={index} className="p-4 bg-white border rounded-md">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mt-0.5">
                        {getSeverityIcon(vulnerability.severity)}
                      </div>
                      <div className="ml-3 flex-grow">
                        <div className="flex justify-between items-center">
                          <h5 className="text-sm font-medium text-gray-900 flex items-center">
                            {vulnerability.name}
                            <span className="ml-2">
                              {getSeverityBadge(vulnerability.severity)}
                            </span>
                          </h5>
                        </div>
                        
                        <div className="mt-1 text-xs text-gray-500">
                          {vulnerability.location && (
                            <span className="inline-flex items-center mr-3">
                              <span className="font-medium">Location:</span> {vulnerability.location}
                            </span>
                          )}
                        </div>
                        
                        <p className="mt-2 text-sm text-gray-600">
                          {vulnerability.description}
                        </p>
                        
                        {vulnerability.recommendation && (
                          <div className="mt-2 text-xs text-green-600">
                            <strong>Recommendation:</strong> {vulnerability.recommendation}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="details">
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-md border">
                <h3 className="text-sm font-medium text-gray-700 mb-3">Test Information</h3>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Target:</span>
                    <span className="font-medium">{test.target}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Test Date:</span>
                    <span>{new Date(test.testDate).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Total Issues:</span>
                    <span>{totalIssues}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Security Score:</span>
                    <span className={`font-medium ${
                      test.score >= 80 
                        ? 'text-green-600' 
                        : test.score >= 60 
                          ? 'text-yellow-600' 
                          : 'text-red-600'
                    }`}>{test.score}/100</span>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-md border">
                <h3 className="text-sm font-medium text-gray-700 mb-3">Test Scope</h3>
                <div className="space-y-2">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span>HTTP Headers Analysis</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span>Form Input Testing</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span>Cookie & Session Security</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span>Cross-Site Scripting (XSS) Detection</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span>SQL Injection Testing</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="remediation">
            <div className="space-y-4">
              <div className="p-4 bg-white border rounded-md">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Remediation Plan</h3>
                
                <ul className="mt-3 space-y-3">
                  {vulnerabilities.map((vulnerability: any, index: number) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0 mt-0.5">
                        {getSeverityIcon(vulnerability.severity)}
                      </div>
                      <div className="ml-3">
                        <h4 className="text-sm font-medium text-gray-900">{vulnerability.name}</h4>
                        <p className="mt-1 text-xs text-gray-600">{vulnerability.recommendation}</p>
                      </div>
                    </li>
                  ))}
                  
                  {vulnerabilities.length === 0 && (
                    <li className="flex items-center text-green-600 text-sm">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      No remediation actions needed. Your application is secure!
                    </li>
                  )}
                </ul>
              </div>
              
              <div className="p-4 bg-white border rounded-md">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Security Best Practices</h3>
                <ul className="list-disc pl-5 text-xs text-gray-700 space-y-2">
                  <li>Keep all software and dependencies up to date with the latest security patches</li>
                  <li>Implement proper input validation and sanitization for all user inputs</li>
                  <li>Use parameterized queries to prevent SQL injection attacks</li>
                  <li>Implement Content Security Policy (CSP) to mitigate XSS attacks</li>
                  <li>Set secure and HttpOnly flags on sensitive cookies</li>
                  <li>Use HTTPS for all connections with proper TLS configuration</li>
                  <li>Implement CSRF tokens for all state-changing operations</li>
                  <li>Follow the principle of least privilege for all user accounts and services</li>
                  <li>Regularly backup your data and test restore procedures</li>
                  <li>Conduct regular security audits and penetration tests</li>
                </ul>
              </div>
              
              <div className="p-4 bg-white border rounded-md">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Next Steps</h3>
                <ol className="list-decimal pl-5 text-xs text-gray-700 space-y-2">
                  <li>Review all identified vulnerabilities and prioritize fixes based on severity</li>
                  <li>Implement the recommended fixes and security improvements</li>
                  <li>Conduct a follow-up scan to verify fixes are effective</li>
                  <li>Establish a regular security testing schedule</li>
                  <li>Implement security awareness training for development team</li>
                </ol>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
