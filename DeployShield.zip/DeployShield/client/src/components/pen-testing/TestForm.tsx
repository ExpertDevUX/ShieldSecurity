import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Terminal } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TestFormProps {
  onTestCompleted: (testId: number) => void;
}

const testFormSchema = z.object({
  target: z.string().url("Please enter a valid URL"),
  testType: z.string().min(1, "Please select a test type"),
  intensity: z.number().min(1).max(5),
  scanHeaders: z.boolean().default(true),
  scanForms: z.boolean().default(true),
  scanCookies: z.boolean().default(true),
  scanXss: z.boolean().default(true),
  scanSql: z.boolean().default(true),
  scanCsrf: z.boolean().default(false),
});

type TestFormValues = z.infer<typeof testFormSchema>;

export default function TestForm({ onTestCompleted }: TestFormProps) {
  const [isTesting, setIsTesting] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<TestFormValues>({
    resolver: zodResolver(testFormSchema),
    defaultValues: {
      target: "",
      testType: "standard",
      intensity: 3,
      scanHeaders: true,
      scanForms: true,
      scanCookies: true,
      scanXss: true,
      scanSql: true,
      scanCsrf: false,
    },
  });

  const onSubmit = async (data: TestFormValues) => {
    setIsTesting(true);
    try {
      // Form the test configuration based on user selections
      const testConfig = {
        target: data.target,
        testType: data.testType,
        options: {
          intensity: data.intensity,
          scanHeaders: data.scanHeaders,
          scanForms: data.scanForms,
          scanCookies: data.scanCookies,
          scanXss: data.scanXss,
          scanSql: data.scanSql,
          scanCsrf: data.scanCsrf
        }
      };
      
      // Make API call to perform the actual penetration test
      // This will now use actual test logic on the server rather than generating mock data
      const response = await apiRequest("POST", "/api/run-pen-test", testConfig);
      
      // If we get a successful response, create the pen test record
      if (response && response.findings) {
        // Create the pen test record with the results from the actual test
        const penTestResponse = await apiRequest("POST", "/api/pen-tests", {
          target: data.target,
          findings: response.findings,
          score: response.score
        });
        
        // Show success message
        toast({
          title: "Penetration test completed",
          description: `Found ${response.findings.vulnerabilities?.length || 0} potential vulnerabilities in ${data.target}`,
        });
        
        // Call the callback with the new test ID
        onTestCompleted(penTestResponse.id);
      } else {
        throw new Error("Invalid response from penetration test");
      }
    } catch (error) {
      console.error("Error performing penetration test:", error);
      toast({
        title: "Test failed",
        description: "There was an error running the penetration test. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsTesting(false);
    }
  };

  const intensityLabel = () => {
    const intensity = form.watch("intensity");
    switch (intensity) {
      case 1: return "Light - Basic checks only";
      case 2: return "Low - Limited testing";
      case 3: return "Medium - Standard security checks";
      case 4: return "High - Thorough security assessment";
      case 5: return "Intensive - Comprehensive security audit";
      default: return "Medium";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Terminal className="w-5 h-5 mr-2 text-blue-500" />
          Penetration Testing
        </CardTitle>
        <CardDescription>
          Test your application for security vulnerabilities.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="target"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Target URL</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="https://example.com" />
                  </FormControl>
                  <FormDescription>
                    The URL of the website or application to test.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="testType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Test Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select test type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="standard">Standard Security Test</SelectItem>
                      <SelectItem value="comprehensive">Comprehensive Audit</SelectItem>
                      <SelectItem value="api">API Security Testing</SelectItem>
                      <SelectItem value="webapp">Web Application Test</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The type of security test to perform.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="intensity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Test Intensity: {intensityLabel()}</FormLabel>
                  <FormControl>
                    <Slider
                      min={1}
                      max={5}
                      step={1}
                      defaultValue={[field.value]}
                      onValueChange={(vals) => field.onChange(vals[0])}
                      className="py-4"
                    />
                  </FormControl>
                  <FormDescription>
                    Higher intensity means more thorough testing but takes longer.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-700">Test Components</h3>
              
              <FormField
                control={form.control}
                name="scanHeaders"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>HTTP Headers</FormLabel>
                      <FormDescription>
                        Check for security-related HTTP headers
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="scanForms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Form Inputs</FormLabel>
                      <FormDescription>
                        Test form inputs for vulnerabilities
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="scanCookies"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Cookies & Session</FormLabel>
                      <FormDescription>
                        Check cookie security configurations
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="scanXss"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>XSS Detection</FormLabel>
                      <FormDescription>
                        Test for Cross-Site Scripting vulnerabilities
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="scanSql"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>SQL Injection</FormLabel>
                      <FormDescription>
                        Test for SQL injection vulnerabilities
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="scanCsrf"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>CSRF Testing</FormLabel>
                      <FormDescription>
                        Test for Cross-Site Request Forgery vulnerabilities
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>
            
            <Button type="submit" className="w-full" disabled={isTesting}>
              {isTesting ? "Running Tests..." : "Start Penetration Test"}
            </Button>
            
            <div className="text-center mt-2 text-xs text-gray-500">
              For demonstration purposes only. Do not run against production systems without proper authorization.
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
