import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader, ShieldCheck } from "lucide-react";

interface TwoFactorSetupProps {
  userId: number;
  onComplete?: () => void;
}

export function TwoFactorSetup({ userId, onComplete }: TwoFactorSetupProps) {
  const [step, setStep] = useState<'initial' | 'verify'>('initial');
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const setupTwoFactor = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest('/api/auth/setup-2fa', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId }),
      });
      
      setQrCode(response.qrCode);
      setSecret(response.secret);
      setStep('verify');
    } catch (err) {
      setError('Failed to set up 2FA. Please try again.');
      toast({
        title: 'Error',
        description: 'Failed to set up 2FA',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const verifyTwoFactor = async () => {
    if (!verificationCode || !secret) return;
    
    setLoading(true);
    setError(null);
    
    try {
      await apiRequest('/api/auth/confirm-2fa', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          token: verificationCode,
          secret,
        }),
      });
      
      toast({
        title: 'Success',
        description: '2FA has been set up successfully',
      });
      
      if (onComplete) {
        onComplete();
      }
    } catch (err) {
      setError('Invalid verification code. Please try again.');
      toast({
        title: 'Error',
        description: 'Failed to verify 2FA code',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary" />
          Two-Factor Authentication Setup
        </CardTitle>
        <CardDescription>
          Enhance your account security by enabling two-factor authentication
        </CardDescription>
      </CardHeader>
      <CardContent>
        {step === 'initial' ? (
          <div className="space-y-4">
            <p className="text-sm">
              Two-factor authentication adds an extra layer of security to your account. In addition to your password, you'll need to enter a code from your authenticator app when signing in.
            </p>
            
            <div className="flex items-center p-4 bg-primary/10 rounded-md">
              <div className="mr-4 flex-shrink-0">
                <ShieldCheck className="h-10 w-10 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium">Why use two-factor authentication?</h4>
                <p className="text-sm text-muted-foreground">
                  Protect your account from unauthorized access, even if your password is compromised.
                </p>
              </div>
            </div>
            
            <Button 
              onClick={setupTwoFactor} 
              disabled={loading}
              className="w-full"
            >
              {loading && <Loader className="mr-2 h-4 w-4 animate-spin" />}
              Set Up Two-Factor Authentication
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {error && (
              <div className="p-3 bg-destructive/10 text-destructive rounded-md text-sm">
                {error}
              </div>
            )}
            
            <div className="space-y-2">
              <h3 className="text-lg font-medium">1. Scan QR Code</h3>
              <p className="text-sm text-muted-foreground">
                Use an authenticator app like Google Authenticator, Microsoft Authenticator, or Authy to scan the QR code below.
              </p>
              
              {qrCode && (
                <div className="flex justify-center my-4">
                  <img src={qrCode} alt="QR Code" className="border p-4 rounded-md" />
                </div>
              )}
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-medium">2. Enter Verification Code</h3>
              <p className="text-sm text-muted-foreground">
                Enter the 6-digit code from your authenticator app to verify setup.
              </p>
              
              <div className="flex space-x-2">
                <Input
                  type="text"
                  placeholder="000000"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  className="text-center tracking-widest"
                  maxLength={6}
                />
                <Button 
                  onClick={verifyTwoFactor} 
                  disabled={loading || verificationCode.length !== 6}
                >
                  {loading ? <Loader className="h-4 w-4 animate-spin" /> : "Verify"}
                </Button>
              </div>
            </div>
            
            {secret && (
              <div className="space-y-2 mt-6 p-4 border rounded-md">
                <h3 className="text-sm font-medium">Manual Setup</h3>
                <p className="text-xs text-muted-foreground">
                  If you can't scan the QR code, enter this secret key manually in your authenticator app:
                </p>
                <div className="p-2 bg-primary/10 rounded text-center font-mono tracking-wider text-sm">
                  {secret}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}