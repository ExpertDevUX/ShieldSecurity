import React from 'react';

export interface ProgressCircleProps {
  value: number;
  size?: number;
  strokeWidth?: number;
  textClassName?: string;
  className?: string;
}

export function ProgressCircle({ 
  value, 
  size = 36, 
  strokeWidth = 3,
  textClassName = '',
  className = ''
}: ProgressCircleProps) {
  const radius = size / 2 - strokeWidth;
  const circumference = radius * 2 * Math.PI;
  const dash = (value * circumference) / 100;

  return (
    <div className="relative inline-flex" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle
          className="text-muted-foreground/20"
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
        />
        <circle
          className={className || "text-primary"}
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - dash}
          strokeLinecap="round"
          strokeWidth={strokeWidth}
          style={{
            transformOrigin: "center",
            transform: "rotate(-90deg)",
          }}
        />
      </svg>
      <div 
        className={`absolute inset-0 flex items-center justify-center font-medium ${textClassName}`}
        style={{ fontSize: size / 3 }}
      >
        {Math.round(value)}
      </div>
    </div>
  );
}