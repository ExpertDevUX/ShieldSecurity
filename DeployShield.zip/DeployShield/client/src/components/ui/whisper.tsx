import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

const whisperVariants = cva(
  "fixed bottom-6 right-6 flex items-center justify-between gap-4 rounded-lg border p-4 shadow-lg transition-all",
  {
    variants: {
      variant: {
        default: "bg-background text-foreground",
        primary: "bg-primary text-primary-foreground",
        secondary: "bg-secondary text-secondary-foreground",
        destructive: "bg-destructive text-destructive-foreground",
        info: "bg-blue-100 border-blue-200 text-blue-800 dark:bg-blue-900 dark:border-blue-800 dark:text-blue-200",
        success: "bg-green-100 border-green-200 text-green-800 dark:bg-green-900 dark:border-green-800 dark:text-green-200",
        warning: "bg-yellow-100 border-yellow-200 text-yellow-800 dark:bg-yellow-900 dark:border-yellow-800 dark:text-yellow-200",
        error: "bg-red-100 border-red-200 text-red-800 dark:bg-red-900 dark:border-red-800 dark:text-red-200",
      },
      size: {
        default: "max-w-md",
        sm: "max-w-sm",
        lg: "max-w-lg",
        xl: "max-w-xl",
        full: "max-w-screen-md",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface WhisperProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof whisperVariants> {
  open?: boolean;
  onClose?: () => void;
  duration?: number | null;
  icon?: React.ReactNode;
  dismissable?: boolean;
}

const Whisper = React.forwardRef<HTMLDivElement, WhisperProps>(
  ({ className, variant, size, open = false, onClose, duration = 5000, icon, dismissable = true, children, ...props }, ref) => {
    const [isVisible, setIsVisible] = React.useState(open);
    
    React.useEffect(() => {
      setIsVisible(open);
      
      if (open && duration) {
        const timer = setTimeout(() => {
          setIsVisible(false);
          if (onClose) onClose();
        }, duration);
        
        return () => clearTimeout(timer);
      }
    }, [open, duration, onClose]);
    
    if (!isVisible) return null;
    
    return (
      <div
        ref={ref}
        className={cn(whisperVariants({ variant, size, className }))}
        {...props}
      >
        {icon && <div className="flex-shrink-0">{icon}</div>}
        <div className="flex-grow">{children}</div>
        {dismissable && (
          <button 
            onClick={() => {
              setIsVisible(false);
              if (onClose) onClose();
            }}
            className="flex-shrink-0 rounded-md p-1 opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
    );
  }
);

Whisper.displayName = "Whisper";

export { Whisper, whisperVariants };