import React, { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import Editor from "@monaco-editor/react";
import { Loader2 } from "lucide-react";

interface CodePreviewProps {
  code: string;
  language?: string;
  fileName?: string;
  theme?: "vs-dark" | "light";
  height?: string;
  maxWidth?: string;
  className?: string;
  showLineNumbers?: boolean;
}

export function CodePreview({
  code,
  language = "javascript",
  fileName,
  theme = "vs-dark",
  height = "200px",
  maxWidth = "500px",
  className,
  showLineNumbers = true,
}: CodePreviewProps) {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 10, scale: 0.98 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className={cn(
        "rounded-md border border-border shadow-lg overflow-hidden",
        className
      )}
      style={{ maxWidth }}
    >
      {fileName && (
        <div className="bg-muted px-4 py-2 border-b border-border text-sm font-medium flex items-center justify-between">
          <span>{fileName}</span>
          <span className="text-xs text-muted-foreground">{language}</span>
        </div>
      )}
      <div className="relative" style={{ height }}>
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-background z-10">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        )}
        <Editor
          value={code}
          language={language}
          theme={theme}
          options={{
            readOnly: true,
            minimap: { enabled: false },
            scrollBeyondLastLine: false,
            lineNumbers: showLineNumbers ? "on" : "off",
            folding: false,
            glyphMargin: false,
            lineDecorationsWidth: 10,
            lineNumbersMinChars: 3,
            wordWrap: "on",
            wrappingIndent: "same",
          }}
          onMount={() => setIsLoading(false)}
          className="min-h-full w-full"
        />
      </div>
    </motion.div>
  );
}

interface HoverCodePreviewProps {
  code: string;
  language?: string;
  fileName?: string;
  children: React.ReactNode;
  theme?: "vs-dark" | "light";
  position?: "top" | "bottom" | "left" | "right";
  previewHeight?: string;
  previewWidth?: string;
  delay?: number;
  showLineNumbers?: boolean;
}

export function HoverCodePreview({
  code,
  language = "javascript",
  fileName,
  children,
  theme = "vs-dark",
  position = "bottom",
  previewHeight = "200px",
  previewWidth = "500px",
  delay = 300,
  showLineNumbers = true,
}: HoverCodePreviewProps) {
  const [showPreview, setShowPreview] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Calculate placement based on position prop
  const getPlacementStyles = () => {
    switch (position) {
      case "top":
        return "bottom-full left-1/2 transform -translate-x-1/2 mb-2";
      case "bottom":
        return "top-full left-1/2 transform -translate-x-1/2 mt-2";
      case "left":
        return "right-full top-1/2 transform -translate-y-1/2 mr-2";
      case "right":
        return "left-full top-1/2 transform -translate-y-1/2 ml-2";
      default:
        return "top-full left-1/2 transform -translate-x-1/2 mt-2";
    }
  };

  // Handle mouse events with delay
  const handleMouseEnter = () => {
    setIsHovering(true);
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    timerRef.current = setTimeout(() => {
      setShowPreview(true);
    }, delay);
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    timerRef.current = setTimeout(() => {
      if (!isHovering) {
        setShowPreview(false);
      }
    }, 100);
  };

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);

  return (
    <span
      className="relative inline-block"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      ref={containerRef}
    >
      <span className="cursor-pointer">{children}</span>
      <AnimatePresence>
        {showPreview && (
          <span 
            className={cn(
              "absolute z-50",
              getPlacementStyles()
            )}
          >
            <CodePreview
              code={code}
              language={language}
              fileName={fileName}
              theme={theme}
              height={previewHeight}
              maxWidth={previewWidth}
              showLineNumbers={showLineNumbers}
            />
          </span>
        )}
      </AnimatePresence>
    </span>
  );
}