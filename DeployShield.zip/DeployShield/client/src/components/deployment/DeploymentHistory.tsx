import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Project, Deployment } from "@shared/schema";

export interface DeploymentHistoryProps {
  deployments: Deployment[];
  projects: Project[];
  selectedProjectId?: number | null;
  isLoading: boolean;
}

export default function DeploymentHistory({ 
  deployments = [], 
  projects = [], 
  selectedProjectId = null,
  isLoading = false
}: DeploymentHistoryProps) {
  const [filter, setFilter] = useState<"all" | "success" | "failed" | "in-progress">("all");
  
  // Filter deployments based on status
  const filteredDeployments = deployments.filter(deployment => {
    if (filter === "all") return true;
    if (filter === "success") return deployment.status.toLowerCase() === "success";
    if (filter === "failed") return deployment.status.toLowerCase() === "failed";
    if (filter === "in-progress") return deployment.status.toLowerCase() === "in progress";
    return true;
  });
  
  // Helper to get project name
  const getProjectName = (projectId: number) => {
    const project = projects.find(p => p.id === projectId);
    return project ? project.name : "Unknown Project";
  };
  
  // Helper for status badge
  const getStatusBadge = (status: string) => {
    const lowerStatus = status.toLowerCase();
    if (lowerStatus === "success") {
      return <Badge className="bg-green-500">Success</Badge>;
    } else if (lowerStatus === "failed") {
      return <Badge variant="destructive">Failed</Badge>;
    } else if (lowerStatus === "in progress") {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">In Progress</Badge>;
    }
    return <Badge variant="secondary">{status}</Badge>;
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Deployment History</h3>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Filter:</span>
          <Select value={filter} onValueChange={(value: any) => setFilter(value)}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="success">Success</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {isLoading ? (
        <div className="h-48 flex items-center justify-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      ) : filteredDeployments.length === 0 ? (
        <Card>
          <CardContent className="py-10">
            <div className="text-center">
              <h3 className="text-lg font-medium mb-2">No deployments found</h3>
              <p className="text-sm text-muted-foreground mb-4">
                You haven't created any deployments yet or none match your filter criteria.
              </p>
              <Button>Create New Deployment</Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Project</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDeployments.map((deployment) => (
                  <TableRow key={deployment.id}>
                    <TableCell className="font-medium">{getProjectName(deployment.projectId)}</TableCell>
                    <TableCell>{deployment.target}</TableCell>
                    <TableCell>{new Date(deployment.deploymentDate).toLocaleDateString()}</TableCell>
                    <TableCell>{getStatusBadge(deployment.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">View Details</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}