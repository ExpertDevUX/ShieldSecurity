import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Code, CheckCircle, Server, Globe, Database, Lock } from "lucide-react";

// Define available template types
const TEMPLATES = [
  {
    id: "nextjs",
    name: "Next.js Application",
    description: "Full-stack React app with server-side rendering and API routes",
    icon: <Globe className="h-8 w-8 text-blue-500" />,
    technologies: ["React", "Next.js", "TypeScript", "Tailwind CSS"],
    options: {
      database: true,
      authentication: true,
      cms: true,
    }
  },
  {
    id: "react",
    name: "React SPA",
    description: "Client-side rendered React app with modern tooling",
    icon: <Code className="h-8 w-8 text-teal-500" />,
    technologies: ["React", "Vite", "TypeScript", "CSS Modules"],
    options: {
      database: false,
      authentication: true,
      cms: false,
    }
  },
  {
    id: "express-api",
    name: "Express API",
    description: "RESTful API built with Express.js and Node.js",
    icon: <Server className="h-8 w-8 text-green-500" />,
    technologies: ["Node.js", "Express", "TypeScript", "RESTful API"],
    options: {
      database: true,
      authentication: true,
      cms: false,
    }
  },
  {
    id: "fullstack-mern",
    name: "MERN Stack",
    description: "MongoDB, Express, React, and Node.js full-stack application",
    icon: <Database className="h-8 w-8 text-purple-500" />,
    technologies: ["MongoDB", "Express", "React", "Node.js"],
    options: {
      database: true,
      authentication: true,
      cms: true,
    }
  }
];

interface TemplatePreviewProps {
  templateId: string;
  options: {
    database: boolean;
    authentication: boolean;
    cms: boolean;
    name: string;
  };
}

// Enhanced Replit-like preview component
function TemplatePreview({ templateId, options }: TemplatePreviewProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [isBuilt, setIsBuilt] = useState(false);
  const [buildLogs, setBuildLogs] = useState<string[]>([]);
  const [previewUrl, setPreviewUrl] = useState("");
  const [buildStage, setBuildStage] = useState<"init" | "build" | "deploy" | "complete">("init");
  const [buildStats, setBuildStats] = useState({
    duration: 0,
    packages: 0,
    files: 0,
    size: "0 MB"
  });
  const [buildProgress, setBuildProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const template = TEMPLATES.find(t => t.id === templateId);
  
  // Simulate a Replit-like build process
  const handleBuild = () => {
    setIsLoading(true);
    setBuildLogs([]);
    setIsBuilt(false);
    setPreviewUrl("");
    setBuildStage("init");
    setBuildProgress(0);
    setError(null);
    
    // Calculate random stats for the build
    const packageCount = Math.floor(Math.random() * 30) + 50; // 50-80 packages
    const fileCount = Math.floor(Math.random() * 100) + 200; // 200-300 files
    const sizeMB = (Math.random() * 10 + 5).toFixed(1); // 5-15 MB
    
    // Mock build process with delayed logs and stages
    setTimeout(() => {
      setBuildStage("init");
      setBuildProgress(5);
      setBuildLogs(prev => [...prev, "🚀 Starting build process..."]);
      setBuildLogs(prev => [...prev, "📋 Reading configuration..."]);
      
      setTimeout(() => {
        setBuildProgress(10);
        setBuildLogs(prev => [...prev, `🔧 Initializing ${template?.name} template`]);
        setBuildLogs(prev => [...prev, "📦 Setting up project structure"]);
        
        setTimeout(() => {
          setBuildProgress(20);
          setBuildLogs(prev => [...prev, "🔍 Analyzing template requirements"]);
          if (options.database) {
            setBuildLogs(prev => [...prev, "🗄️ Setting up database connections"]);
            setBuildLogs(prev => [...prev, "🔐 Configuring database credentials"]);
          }
          
          setTimeout(() => {
            setBuildStage("build");
            setBuildProgress(30);
            setBuildLogs(prev => [...prev, "📚 Resolving dependencies"]);
            if (options.authentication) {
              setBuildLogs(prev => [...prev, "🔒 Configuring authentication system"]);
              setBuildLogs(prev => [...prev, "👤 Setting up user models and routes"]);
            }
            
            setTimeout(() => {
              setBuildProgress(40);
              if (options.cms) {
                setBuildLogs(prev => [...prev, "📝 Integrating CMS capabilities"]);
                setBuildLogs(prev => [...prev, "🖼️ Setting up media handling"]);
              }
              
              setTimeout(() => {
                setBuildProgress(50);
                setBuildLogs(prev => [...prev, `📥 Installing dependencies (${packageCount} packages)...`]);
                
                // Simulate installing individual packages
                let pkgCount = 0;
                const pkgInterval = setInterval(() => {
                  pkgCount += 1;
                  const pkgProgress = Math.min(70, 50 + Math.floor((pkgCount / packageCount) * 20));
                  setBuildProgress(pkgProgress);
                  
                  if (pkgCount >= 3) {
                    clearInterval(pkgInterval);
                    
                    setTimeout(() => {
                      setBuildProgress(75);
                      setBuildLogs(prev => [...prev, "📦 Dependencies installed successfully"]);
                      setBuildLogs(prev => [...prev, "🔨 Building project..."]);
                      
                      setTimeout(() => {
                        setBuildStage("deploy");
                        setBuildProgress(85);
                        setBuildLogs(prev => [...prev, `📁 Processed ${fileCount} files (${sizeMB} MB)`]);
                        setBuildLogs(prev => [...prev, "✅ Build completed successfully"]);
                        setBuildLogs(prev => [...prev, "🚀 Starting preview server..."]);
                        
                        // Set build stats
                        setBuildStats({
                          duration: Math.floor(Math.random() * 10) + 20, // 20-30 seconds
                          packages: packageCount,
                          files: fileCount,
                          size: `${sizeMB} MB`
                        });
                        
                        setTimeout(() => {
                          setBuildStage("complete");
                          setBuildProgress(100);
                          const previewUrlBase = `preview-${options.name.toLowerCase().replace(/\s+/g, '-')}`;
                          setBuildLogs(prev => [...prev, `🌐 Preview environment created`]);
                          setBuildLogs(prev => [...prev, `🔗 Preview available at: ${previewUrlBase}.repl.co`]);
                          setPreviewUrl(`https://${previewUrlBase}.repl.co`);
                          setIsLoading(false);
                          setIsBuilt(true);
                        }, 1000);
                      }, 1500);
                    }, 800);
                  }
                }, 500);
              }, 600);
            }, 700);
          }, 500);
        }, 600);
      }, 500);
    }, 500);
  };

  return (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle>Preview: {options.name}</CardTitle>
        <CardDescription>
          Based on {template?.name} template
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="build">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="build">Build</TabsTrigger>
            <TabsTrigger value="preview" disabled={!isBuilt}>Preview</TabsTrigger>
          </TabsList>
          <TabsContent value="build" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Build Configuration</h3>
                  <p className="text-sm text-muted-foreground">
                    Create a preview deployment of your template
                  </p>
                </div>
                <Button 
                  onClick={handleBuild} 
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Building...
                    </>
                  ) : (
                    'Build Preview'
                  )}
                </Button>
              </div>
              
              {/* Build Progress */}
              {isLoading && (
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">
                      {buildStage === "init" && "Initializing..."}
                      {buildStage === "build" && "Building..."}
                      {buildStage === "deploy" && "Deploying..."}
                      {buildStage === "complete" && "Completed"}
                    </span>
                    <span>{buildProgress}%</span>
                  </div>
                  <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary transition-all duration-300 ease-in-out"
                      style={{ width: `${buildProgress}%` }}
                    />
                  </div>
                </div>
              )}
              
              {/* Build Stats (visible when build is complete) */}
              {isBuilt && (
                <div className="grid grid-cols-4 gap-4 mb-4">
                  <div className="bg-secondary/20 p-3 rounded-md text-center">
                    <div className="text-2xl font-semibold">{buildStats.duration}s</div>
                    <div className="text-xs text-muted-foreground">Build Time</div>
                  </div>
                  <div className="bg-secondary/20 p-3 rounded-md text-center">
                    <div className="text-2xl font-semibold">{buildStats.packages}</div>
                    <div className="text-xs text-muted-foreground">Packages</div>
                  </div>
                  <div className="bg-secondary/20 p-3 rounded-md text-center">
                    <div className="text-2xl font-semibold">{buildStats.files}</div>
                    <div className="text-xs text-muted-foreground">Files</div>
                  </div>
                  <div className="bg-secondary/20 p-3 rounded-md text-center">
                    <div className="text-2xl font-semibold">{buildStats.size}</div>
                    <div className="text-xs text-muted-foreground">Build Size</div>
                  </div>
                </div>
              )}
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm font-semibold">Build Logs</h4>
                  {buildLogs.length > 0 && (
                    <div className="flex gap-2 text-xs">
                      <span className={`px-2 py-0.5 rounded-full ${buildStage === 'init' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' : 'bg-secondary/50 text-muted-foreground'}`}>
                        Init
                      </span>
                      <span className={`px-2 py-0.5 rounded-full ${buildStage === 'build' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-secondary/50 text-muted-foreground'}`}>
                        Build
                      </span>
                      <span className={`px-2 py-0.5 rounded-full ${buildStage === 'deploy' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400' : 'bg-secondary/50 text-muted-foreground'}`}>
                        Deploy
                      </span>
                      <span className={`px-2 py-0.5 rounded-full ${buildStage === 'complete' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-secondary/50 text-muted-foreground'}`}>
                        Complete
                      </span>
                    </div>
                  )}
                </div>
                <ScrollArea className="h-[200px] w-full rounded-md border p-4 font-mono text-xs">
                  {buildLogs.length === 0 ? (
                    <div className="text-muted-foreground p-2">
                      Build logs will appear here...
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {buildLogs.map((log, i) => (
                        <div key={i} className="flex">
                          <span className="text-muted-foreground mr-2">[{new Date().toLocaleTimeString()}]</span>
                          <span>{log}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </div>
              
              {isBuilt && (
                <div className="rounded-md bg-green-50 dark:bg-green-900/20 p-4 flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                  <div>
                    <p className="text-sm font-medium text-green-800 dark:text-green-300">
                      Preview successfully built
                    </p>
                    <p className="text-xs text-green-700 dark:text-green-400">
                      Your preview is available at: <a href={previewUrl} target="_blank" rel="noopener noreferrer" className="underline">{previewUrl}</a>
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="preview" className="mt-4">
            <div className="space-y-4">
              {/* Replit-style header with URL and controls */}
              <div className="flex items-center justify-between bg-secondary/20 rounded-t-md border p-2">
                <div className="flex items-center gap-2">
                  <div className="bg-white dark:bg-black p-1 rounded-full">
                    <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                  </div>
                  <div className="flex items-center bg-background rounded-md border px-2 py-1 text-xs w-[300px]">
                    <span className="text-muted-foreground mr-2">https://</span>
                    <span className="truncate">{`preview-${options.name.toLowerCase().replace(/\s+/g, '-')}.repl.co`}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">Refresh</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
                      <path d="M3 3v5h5"></path>
                    </svg>
                  </Button>
                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">External</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                      <path d="M7 7h10v10"></path>
                      <path d="M7 17 17 7"></path>
                    </svg>
                  </Button>
                </div>
              </div>
              
              {/* Mock app preview UI */}
              <div className="border-x border-b rounded-b-md bg-background">
                <div className="p-6 min-h-[400px] relative">
                  {/* App header */}
                  <div className="mb-8 pb-4 border-b">
                    <h3 className="text-2xl font-bold mb-2">{options.name}</h3>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {template?.technologies.map((tech) => (
                        <span key={tech} className="bg-primary/10 text-primary py-1 px-2 rounded-full text-xs">
                          {tech}
                        </span>
                      ))}
                      
                      {options.database && (
                        <span className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 py-1 px-2 rounded-full text-xs flex items-center gap-1">
                          <Database className="h-3 w-3" /> Database
                        </span>
                      )}
                      
                      {options.authentication && (
                        <span className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400 py-1 px-2 rounded-full text-xs flex items-center gap-1">
                          <Lock className="h-3 w-3" /> Authentication
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {/* Mock app content based on template type */}
                  {template?.id === "nextjs" && (
                    <div className="space-y-6">
                      <div className="p-6 bg-gradient-to-r from-primary/30 to-primary/10 rounded-lg">
                        <h2 className="text-xl font-bold mb-2">Welcome to {options.name}</h2>
                        <p className="text-muted-foreground mb-4">This is a Next.js application with server-side rendering capabilities.</p>
                        <div className="flex gap-2">
                          <Button size="sm">Get Started</Button>
                          <Button size="sm" variant="outline">Documentation</Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium mb-2">Feature 1</h3>
                          <p className="text-sm text-muted-foreground">Description of the first feature</p>
                        </div>
                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium mb-2">Feature 2</h3>
                          <p className="text-sm text-muted-foreground">Description of the second feature</p>
                        </div>
                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium mb-2">Feature 3</h3>
                          <p className="text-sm text-muted-foreground">Description of the third feature</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {template?.id === "react" && (
                    <div className="space-y-4">
                      <div className="text-center p-8">
                        <div className="inline-block mb-4 p-4 bg-primary/10 rounded-full">
                          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <circle cx="12" cy="12" r="4"></circle>
                            <line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line>
                          </svg>
                        </div>
                        <h2 className="text-2xl font-bold mb-2">React SPA Template</h2>
                        <p className="text-gray-500 mb-4">This is a React single-page application.</p>
                        <div className="flex justify-center gap-2">
                          <Button>Explore Features</Button>
                          <Button variant="outline">View Components</Button>
                        </div>
                      </div>
                      <div className="border-t pt-4">
                        <p className="text-sm text-center text-muted-foreground">Edit <code className="bg-muted px-1 py-0.5 rounded">src/App.tsx</code> to customize this template</p>
                      </div>
                    </div>
                  )}
                  
                  {template?.id === "express-api" && (
                    <div className="space-y-4">
                      <div className="p-4 rounded-md bg-muted font-mono text-sm">
                        <div className="text-green-500 mb-2">// API Endpoints</div>
                        <div className="ml-2">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400 rounded">GET</span>
                            <span>/api/users</span>
                          </div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="px-2 py-0.5 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 rounded">POST</span>
                            <span>/api/users</span>
                          </div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400 rounded">GET</span>
                            <span>/api/users/:id</span>
                          </div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="px-2 py-0.5 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400 rounded">PUT</span>
                            <span>/api/users/:id</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 rounded">DELETE</span>
                            <span>/api/users/:id</span>
                          </div>
                        </div>
                      </div>
                      <div className="border rounded-md p-4">
                        <h3 className="font-medium mb-2">API Documentation</h3>
                        <p className="text-sm text-muted-foreground mb-2">Your Express API is running. Test endpoints using the included documentation.</p>
                        <Button size="sm" variant="outline">View Docs</Button>
                      </div>
                    </div>
                  )}
                  
                  {template?.id === "fullstack-mern" && (
                    <div className="space-y-4">
                      <nav className="border-b pb-4 flex justify-between items-center">
                        <div className="text-lg font-bold">{options.name}</div>
                        <div className="flex gap-4">
                          <a href="#" className="text-sm">Home</a>
                          <a href="#" className="text-sm">Features</a>
                          <a href="#" className="text-sm">Pricing</a>
                          <a href="#" className="text-sm">Contact</a>
                        </div>
                        <Button size="sm">Login</Button>
                      </nav>
                      
                      <div className="p-6 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-lg">
                        <h1 className="text-2xl font-bold mb-2">MERN Stack Application</h1>
                        <p className="text-muted-foreground mb-4">A complete fullstack application with MongoDB, Express, React, and Node.js.</p>
                        <div className="flex gap-2">
                          <Button>Get Started</Button>
                          <Button variant="outline">Learn More</Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium mb-2">Frontend</h3>
                          <p className="text-sm text-muted-foreground">React-based frontend with modern UI components</p>
                        </div>
                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium mb-2">Backend</h3>
                          <p className="text-sm text-muted-foreground">Express server with MongoDB integration</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Replit watermark */}
                  <div className="absolute bottom-4 right-4 flex items-center gap-1 text-xs text-muted-foreground">
                    <span>Powered by</span>
                    <span className="font-semibold">Replit</span>
                  </div>
                </div>
              </div>
              
              {/* Preview controls */}
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 text-sm">
                    <span className="w-3 h-3 rounded-full bg-green-500"></span>
                    <span className="text-muted-foreground">Live</span>
                  </div>
                </div>
                <a 
                  href={previewUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-primary text-sm"
                >
                  <span>Open in new tab</span>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                    <path d="M7 7h10v10"></path>
                    <path d="M7 17 17 7"></path>
                  </svg>
                </a>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-end gap-2">
        <Button variant="outline">Cancel</Button>
        <Button disabled={!isBuilt}>Deploy to Production</Button>
      </CardFooter>
    </Card>
  );
}

export default function AutoDeployTemplate() {
  const { toast } = useToast();
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [projectName, setProjectName] = useState("");
  const [options, setOptions] = useState({
    database: false,
    authentication: false,
    cms: false,
  });
  
  const template = TEMPLATES.find(t => t.id === selectedTemplate);
  
  const handleOptionChange = (option: keyof typeof options, value: boolean) => {
    setOptions(prev => ({
      ...prev,
      [option]: value
    }));
  };
  
  const handleTemplateSelect = (id: string) => {
    const template = TEMPLATES.find(t => t.id === id);
    setSelectedTemplate(id);
    
    if (template) {
      setOptions({
        database: template.options.database,
        authentication: template.options.authentication,
        cms: template.options.cms,
      });
    }
  };
  
  const isConfigValid = selectedTemplate && projectName.trim().length > 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-xl font-semibold mb-4">Choose a Template</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {TEMPLATES.map((template) => (
              <Card 
                key={template.id}
                className={`cursor-pointer transition-all ${selectedTemplate === template.id ? 'ring-2 ring-primary' : 'hover:border-primary/50'}`}
                onClick={() => handleTemplateSelect(template.id)}
              >
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    {template.icon}
                    {selectedTemplate === template.id && (
                      <CheckCircle className="h-4 w-4 text-primary" />
                    )}
                  </div>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{template.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        <div>
          <h2 className="text-xl font-semibold mb-4">Configure Deployment</h2>
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="project-name">Project Name</Label>
                  <Input 
                    id="project-name" 
                    placeholder="My Awesome Project"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="region">Deployment Region</Label>
                  <Select defaultValue="us-east">
                    <SelectTrigger id="region">
                      <SelectValue placeholder="Select a region" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>North America</SelectLabel>
                        <SelectItem value="us-east">US East (N. Virginia)</SelectItem>
                        <SelectItem value="us-west">US West (Oregon)</SelectItem>
                      </SelectGroup>
                      <SelectGroup>
                        <SelectLabel>Europe</SelectLabel>
                        <SelectItem value="eu-central">EU Central (Frankfurt)</SelectItem>
                        <SelectItem value="eu-west">EU West (Ireland)</SelectItem>
                      </SelectGroup>
                      <SelectGroup>
                        <SelectLabel>Asia Pacific</SelectLabel>
                        <SelectItem value="ap-southeast">Asia Pacific (Singapore)</SelectItem>
                        <SelectItem value="ap-northeast">Asia Pacific (Tokyo)</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
                
                {template && (
                  <div className="space-y-3 pt-2">
                    <Label>Template Options</Label>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="database" 
                        checked={options.database}
                        onCheckedChange={(checked) => handleOptionChange("database", checked as boolean)}
                      />
                      <label
                        htmlFor="database"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Include Database
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="authentication" 
                        checked={options.authentication}
                        onCheckedChange={(checked) => handleOptionChange("authentication", checked as boolean)}
                      />
                      <label
                        htmlFor="authentication"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Authentication System
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="cms" 
                        checked={options.cms}
                        onCheckedChange={(checked) => handleOptionChange("cms", checked as boolean)}
                      />
                      <label
                        htmlFor="cms"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Content Management
                      </label>
                    </div>
                  </div>
                )}
                
                <Button 
                  className="w-full mt-2" 
                  disabled={!isConfigValid}
                  onClick={() => {
                    if (isConfigValid) {
                      toast({
                        title: "Configuration saved",
                        description: "Your template configuration has been created",
                      });
                    }
                  }}
                >
                  Save Configuration
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {selectedTemplate && projectName && (
        <TemplatePreview 
          templateId={selectedTemplate} 
          options={{
            ...options,
            name: projectName
          }}
        />
      )}
    </div>
  );
}