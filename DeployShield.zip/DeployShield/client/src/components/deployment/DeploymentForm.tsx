import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Check, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Project } from "@shared/schema";

const formSchema = z.object({
  projectId: z.coerce.number().min(1, "Please select a project"),
  target: z.string().min(3, "Target must be at least 3 characters"),
  buildCommand: z.string().optional(),
  deployCommand: z.string().min(1, "Deploy command is required"),
  notes: z.string().optional(),
});

export interface DeploymentFormProps {
  projects: Project[];
  isLoading: boolean;
  onProjectSelect?: (projectId: number) => void;
}

export default function DeploymentForm({ 
  projects = [], 
  isLoading = false,
  onProjectSelect = () => {} 
}: DeploymentFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deploymentSuccess, setDeploymentSuccess] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectId: 0,
      target: "",
      buildCommand: "",
      deployCommand: "npm run build && npm run deploy",
      notes: "",
    },
  });
  
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsSubmitting(true);
    setDeploymentSuccess(false);
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simulate success
      setDeploymentSuccess(true);
      toast({
        title: "Deployment started",
        description: "Your deployment has been initiated successfully.",
      });
      
      // Reset form
      form.reset({
        projectId: 0,
        target: "",
        buildCommand: "",
        deployCommand: "npm run build && npm run deploy",
        notes: "",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to start deployment. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="space-y-6">
      {deploymentSuccess && (
        <Alert className="bg-green-50 border-green-200 text-green-800 dark:bg-green-900/20 dark:border-green-800 dark:text-green-300">
          <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertTitle>Deployment initiated</AlertTitle>
          <AlertDescription>
            Your deployment has been started successfully. You can check the status in the deployment history tab.
          </AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="projectId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project</FormLabel>
                    <Select
                      disabled={isLoading || isSubmitting}
                      onValueChange={(value) => {
                        field.onChange(parseInt(value));
                        onProjectSelect(parseInt(value));
                      }}
                      value={field.value.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a project" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {projects.map((project) => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Choose the project you want to deploy
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="target"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deployment Target</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g., AWS EC2, Vercel, Netlify"
                        {...field}
                        disabled={isLoading || isSubmitting}
                      />
                    </FormControl>
                    <FormDescription>
                      Where you want to deploy your application
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="buildCommand"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Build Command (Optional)</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., npm run build"
                          {...field}
                          disabled={isLoading || isSubmitting}
                        />
                      </FormControl>
                      <FormDescription>
                        Command to build your application
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="deployCommand"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Deploy Command</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., npm run deploy"
                          {...field}
                          disabled={isLoading || isSubmitting}
                        />
                      </FormControl>
                      <FormDescription>
                        Command to deploy your application
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Any additional information about this deployment"
                        {...field}
                        disabled={isLoading || isSubmitting}
                      />
                    </FormControl>
                    <FormDescription>
                      Add notes or comments about this deployment
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end">
                <Button type="submit" disabled={isLoading || isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Starting Deployment...
                    </>
                  ) : (
                    "Deploy Project"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}