import { useState } from "react";
import { Code, Play, Bug, List, LayoutGrid, BookOpen, Settings2, Download, AlertCircle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import CodeEditor from "./CodeEditor";

interface OnlineIDEProps {
  defaultLanguage?: string;
}

interface PerfIssue {
  id: string;
  line: number;
  message: string;
  severity: "error" | "warning" | "info";
  suggestion: string;
}

// Sample performance issues for demonstration
const SAMPLE_PERFORMANCE_ISSUES: {
  [key: string]: PerfIssue[];
} = {
  javascript: [
    {
      id: "perf-1",
      line: 3,
      message: "O(n²) nested loops",
      severity: "error",
      suggestion: "Use a Set data structure for O(n) time complexity"
    },
    {
      id: "perf-2",
      line: 16,
      message: "Inefficient DOM manipulation",
      severity: "error",
      suggestion: "Use DocumentFragment for batch DOM updates"
    },
    {
      id: "perf-3",
      line: 24,
      message: "Potential memory leak",
      severity: "warning",
      suggestion: "Clean up event listeners when no longer needed"
    }
  ],
  python: [
    {
      id: "perf-1",
      line: 3,
      message: "Inefficient string concatenation",
      severity: "error",
      suggestion: "Use join() method instead of string addition in loops"
    },
    {
      id: "perf-2",
      line: 9,
      message: "Inefficient list building",
      severity: "warning",
      suggestion: "Use list comprehension instead of repeated append()"
    },
    {
      id: "perf-3",
      line: 16,
      message: "Exponential time complexity",
      severity: "error",
      suggestion: "Implement memoization to avoid redundant calculations"
    }
  ],
  css: [
    {
      id: "perf-1",
      line: 2,
      message: "Duplicate CSS properties",
      severity: "warning",
      suggestion: "Extract common styles into a shared class"
    },
    {
      id: "perf-2",
      line: 22,
      message: "Overly specific selectors",
      severity: "warning",
      suggestion: "Simplify selector chains for better performance"
    }
  ],
  html: [
    {
      id: "perf-1",
      line: 5,
      message: "Render-blocking resources",
      severity: "error",
      suggestion: "Defer non-critical JavaScript and CSS"
    },
    {
      id: "perf-2",
      line: 10,
      message: "Missing image dimensions",
      severity: "warning",
      suggestion: "Add width and height attributes to prevent layout shifts"
    },
    {
      id: "perf-3",
      line: 22,
      message: "Synchronous script execution blocks rendering",
      severity: "error",
      suggestion: "Use async or defer attributes or move script to end of body"
    }
  ]
};

export default function OnlineIDE({ defaultLanguage = "javascript" }: OnlineIDEProps) {
  const { toast } = useToast();
  const [selectedLanguage, setSelectedLanguage] = useState(defaultLanguage);
  const [activeTab, setActiveTab] = useState("editor");
  const [codeOutput, setCodeOutput] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [optimizedCode, setOptimizedCode] = useState("");
  const [performanceIssues, setPerformanceIssues] = useState<PerfIssue[]>(
    SAMPLE_PERFORMANCE_ISSUES[defaultLanguage] || []
  );

  const handleRunCode = async () => {
    setIsRunning(true);
    setCodeOutput("");
    
    try {
      // Simulate code execution
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Sample output based on language
      let output = "";
      
      if (selectedLanguage === "javascript") {
        output = `> Running JavaScript code...
> findDuplicates([1, 2, 3, 2, 1, 5])
[1, 2]
> addItems(['apple', 'banana', 'cherry'])
DOM elements created
> setupEventListeners()
Event listeners attached`;
      } else if (selectedLanguage === "python") {
        output = `>>> Running Python code...
>>> build_string(['apple', 'banana', 'cherry'])
'apple, banana, cherry'
>>> get_squares(5)
[0, 1, 4, 9, 16]
>>> fibonacci(10)
55`;
      } else {
        output = `// ${selectedLanguage.toUpperCase()} code doesn't have runtime output in this environment`;
      }
      
      setCodeOutput(output);
      
      toast({
        title: "Code Executed",
        description: "Code execution completed successfully.",
      });
    } catch (error) {
      console.error("Execution error:", error);
      setCodeOutput("Error: Failed to execute code. Check your syntax and try again.");
      
      toast({
        title: "Execution Failed",
        description: "There was an error running your code.",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  const handleOptimize = (optimized: string) => {
    setOptimizedCode(optimized);
    setActiveTab("issues");
    setPerformanceIssues(SAMPLE_PERFORMANCE_ISSUES[selectedLanguage] || []);
  };

  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    setOptimizedCode("");
    setCodeOutput("");
    setPerformanceIssues(SAMPLE_PERFORMANCE_ISSUES[language] || []);
  };

  return (
    <Card className="shadow-lg border-t-4 border-t-blue-500">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <Code className="h-5 w-5 text-blue-500" />
              Performance IDE
            </CardTitle>
            <CardDescription>
              Edit, analyze, and optimize your code in real-time
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedLanguage} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="javascript">JavaScript</SelectItem>
                <SelectItem value="python">Python</SelectItem>
                <SelectItem value="css">CSS</SelectItem>
                <SelectItem value="html">HTML</SelectItem>
              </SelectContent>
            </Select>
            <Button size="sm" variant="outline" onClick={handleRunCode} disabled={isRunning || ['css', 'html'].includes(selectedLanguage)}>
              {isRunning ? (
                <svg className="animate-spin h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                <Play className="h-4 w-4 mr-2" />
              )}
              Run
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <Separator />
      
      <CardContent className="p-0">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex border-b px-6">
            <TabsList className="h-10 bg-transparent p-0">
              <TabsTrigger 
                value="editor" 
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:shadow-none px-4"
              >
                <Code className="h-4 w-4 mr-2" />
                Editor
              </TabsTrigger>
              <TabsTrigger 
                value="output" 
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:shadow-none px-4"
              >
                <LayoutGrid className="h-4 w-4 mr-2" />
                Output
              </TabsTrigger>
              <TabsTrigger 
                value="issues" 
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:shadow-none px-4"
              >
                <Bug className="h-4 w-4 mr-2" />
                Performance Issues
              </TabsTrigger>
              <TabsTrigger 
                value="docs" 
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:shadow-none px-4"
              >
                <BookOpen className="h-4 w-4 mr-2" />
                Best Practices
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="editor" className="p-6 m-0 h-[600px] overflow-y-auto">
            <CodeEditor 
              language={selectedLanguage} 
              onOptimize={handleOptimize}
            />
          </TabsContent>
          
          <TabsContent value="output" className="p-6 m-0 min-h-[600px]">
            {codeOutput ? (
              <pre className="bg-gray-100 dark:bg-gray-900 p-4 rounded-md whitespace-pre-wrap font-mono text-sm overflow-auto h-[500px]">
                {codeOutput}
              </pre>
            ) : (
              <div className="flex flex-col items-center justify-center h-[500px] text-center">
                <Play className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Output Yet</h3>
                <p className="text-muted-foreground max-w-md">
                  {['css', 'html'].includes(selectedLanguage) 
                    ? `${selectedLanguage.toUpperCase()} is not executable in this environment.`
                    : "Run your code to see the output here."}
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="issues" className="p-6 m-0 min-h-[600px]">
            {performanceIssues.length > 0 ? (
              <div className="space-y-6">
                <div className="rounded-md border">
                  <div className="bg-muted px-4 py-3 flex items-center justify-between border-b">
                    <h3 className="font-medium">Performance Issues Found</h3>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Export Report
                    </Button>
                  </div>
                  
                  <div className="divide-y">
                    {performanceIssues.map((issue) => (
                      <div key={issue.id} className="p-4">
                        <div className="flex items-start gap-3">
                          {issue.severity === "error" ? (
                            <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
                          ) : issue.severity === "warning" ? (
                            <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                          ) : (
                            <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                          )}
                          
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{issue.message}</span>
                              <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">Line {issue.line}</span>
                            </div>
                            <p className="text-sm text-muted-foreground">{issue.suggestion}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {optimizedCode && (
                  <div className="rounded-md border">
                    <div className="bg-muted px-4 py-3 flex items-center justify-between border-b">
                      <h3 className="font-medium">Optimized Code</h3>
                      <span className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 px-2 py-1 rounded-full flex items-center">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Performance Improved
                      </span>
                    </div>
                    <div className="p-4">
                      <pre className="bg-gray-100 dark:bg-gray-900 p-4 rounded-md whitespace-pre-wrap font-mono text-sm overflow-auto max-h-[300px]">
                        {optimizedCode}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[500px] text-center">
                <Bug className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Issues Detected</h3>
                <p className="text-muted-foreground max-w-md">
                  Optimize your code to detect performance issues and see recommendations here.
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="docs" className="p-6 m-0 min-h-[600px]">
            <div className="prose prose-blue dark:prose-invert max-w-none">
              <h3>Performance Best Practices: {selectedLanguage.charAt(0).toUpperCase() + selectedLanguage.slice(1)}</h3>
              
              {selectedLanguage === "javascript" && (
                <>
                  <h4>JavaScript Performance Tips</h4>
                  <ul>
                    <li><strong>Avoid nested loops</strong> when possible - they create O(n²) complexity.</li>
                    <li><strong>Use modern data structures</strong> like Map and Set for better performance.</li>
                    <li><strong>Batch DOM manipulations</strong> using DocumentFragment to reduce reflows and repaints.</li>
                    <li><strong>Clean up event listeners</strong> to prevent memory leaks, especially in components that unmount.</li>
                    <li><strong>Use debounce and throttle</strong> for expensive operations triggered by frequent events.</li>
                    <li><strong>Consider web workers</strong> for CPU-intensive tasks to avoid blocking the main thread.</li>
                  </ul>
                </>
              )}
              
              {selectedLanguage === "python" && (
                <>
                  <h4>Python Performance Tips</h4>
                  <ul>
                    <li><strong>Use comprehensions</strong> instead of loops for creating lists, dictionaries, and sets.</li>
                    <li><strong>Avoid string concatenation in loops</strong> - use join() instead.</li>
                    <li><strong>Implement memoization</strong> for expensive recursive functions.</li>
                    <li><strong>Use built-in functions</strong> like map(), filter(), and reduce() for better performance.</li>
                    <li><strong>Consider NumPy</strong> for numerical operations on large datasets.</li>
                    <li><strong>Profile your code</strong> with tools like cProfile to identify bottlenecks.</li>
                  </ul>
                </>
              )}
              
              {selectedLanguage === "css" && (
                <>
                  <h4>CSS Performance Tips</h4>
                  <ul>
                    <li><strong>Minimize specificity</strong> of selectors to improve rendering performance.</li>
                    <li><strong>Group related styles</strong> to reduce duplication and file size.</li>
                    <li><strong>Use efficient selectors</strong> - avoid deep nesting and universal selectors.</li>
                    <li><strong>Prefer classes</strong> over attribute selectors for better performance.</li>
                    <li><strong>Consider will-change</strong> for elements that will animate, but use sparingly.</li>
                    <li><strong>Use transform and opacity</strong> for animations to trigger GPU acceleration.</li>
                  </ul>
                </>
              )}
              
              {selectedLanguage === "html" && (
                <>
                  <h4>HTML Performance Tips</h4>
                  <ul>
                    <li><strong>Defer non-critical JavaScript</strong> using async or defer attributes.</li>
                    <li><strong>Specify image dimensions</strong> to prevent layout shifts during page load.</li>
                    <li><strong>Lazy load offscreen images</strong> using the loading="lazy" attribute.</li>
                    <li><strong>Keep the DOM size small</strong> - fewer elements mean faster rendering.</li>
                    <li><strong>Use semantic elements</strong> for better accessibility and potentially better performance.</li>
                    <li><strong>Put scripts at the end</strong> of the body to avoid blocking render.</li>
                  </ul>
                </>
              )}
              
              <h4>General Optimization Strategies</h4>
              <p>
                Performance optimization should be approached systematically:
              </p>
              <ol>
                <li><strong>Measure first</strong> - identify actual bottlenecks rather than making premature optimizations.</li>
                <li><strong>Focus on high-impact issues</strong> that affect user experience.</li>
                <li><strong>Test on real devices</strong> to understand real-world performance.</li>
                <li><strong>Consider trade-offs</strong> between code readability and optimization.</li>
              </ol>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <CardFooter className="flex justify-between bg-muted/50 p-3">
        <Button variant="ghost" size="sm">
          <Settings2 className="h-4 w-4 mr-2" />
          IDE Settings
        </Button>
        
        <div className="text-xs text-muted-foreground">
          Performance IDE v1.0 | {selectedLanguage.charAt(0).toUpperCase() + selectedLanguage.slice(1)} mode
        </div>
      </CardFooter>
    </Card>
  );
}