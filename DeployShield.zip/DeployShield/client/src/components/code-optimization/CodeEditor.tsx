import { useState, useEffect } from "react";
import { Copy, Download, Check, Code2, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";

interface CodeEditorProps {
  initialCode?: string;
  language?: string;
  onOptimize?: (optimizedCode: string) => void;
}

const SAMPLE_CODE = {
  javascript: `// Inefficient code with nested loops
function findDuplicates(array) {
  const duplicates = [];
  
  for (let i = 0; i < array.length; i++) {
    for (let j = 0; j < array.length; j++) {
      if (i !== j && array[i] === array[j] && !duplicates.includes(array[i])) {
        duplicates.push(array[i]);
      }
    }
  }
  
  return duplicates;
}

// Inefficient DOM manipulation in a loop
function addItems(items) {
  const container = document.getElementById('container');
  
  for (let i = 0; i < items.length; i++) {
    container.innerHTML += '<div class="item">' + items[i] + '</div>';
  }
}

// Function with memory leak
function setupEventListeners() {
  const button = document.getElementById('button');
  
  button.addEventListener('click', function() {
    fetch('/api/data')
      .then(response => response.json())
      .then(data => {
        processData(data);
      });
  });
}`,

  python: `# Inefficient string concatenation
def build_string(items):
    result = ""
    for item in items:
        result = result + item + ", "  # String concatenation in a loop is inefficient
    return result[:-2]

# Inefficient list creation
def get_squares(n):
    squares = []
    for i in range(n):
        squares.append(i * i)  # Repeatedly appending is slower than comprehension
    return squares

# Repeated calculations
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)  # Exponential time complexity due to redundant calculations`,

  css: `/* Inefficient CSS with many duplications */
.header {
    display: flex;
    padding: 10px;
    background-color: #f5f5f5;
    border-radius: 4px;
}

.footer {
    display: flex;
    padding: 10px;
    background-color: #f5f5f5;
    border-radius: 4px;
}

.sidebar {
    display: flex;
    padding: 10px;
    background-color: #f5f5f5;
    border-radius: 4px;
}

/* Overspecified selectors */
body div.container ul.navigation li.nav-item a.nav-link.active {
    color: blue;
}`,

  html: `<!DOCTYPE html>
<html>
<head>
    <title>Unoptimized Page</title>
    <!-- Render-blocking resources -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.example.com/huge-library.js"></script>
    <link rel="stylesheet" href="https://cdn.example.com/large-framework.css">
</head>
<body>
    <!-- Unoptimized images without dimensions -->
    <img src="large-image.jpg">
    
    <!-- Inefficient nesting -->
    <div>
        <div>
            <div>
                <p>Deeply nested content</p>
            </div>
        </div>
    </div>
    
    <!-- Inline script blocks rendering -->
    <script>
        for (let i = 0; i < 1000; i++) {
            console.log('Blocking the main thread');
        }
    </script>
</body>
</html>`,
};

const OPTIMIZED_CODE = {
  javascript: `// Optimized code with single pass using Set
function findDuplicates(array) {
  const seen = new Set();
  const duplicates = new Set();
  
  for (const item of array) {
    if (seen.has(item)) {
      duplicates.add(item);
    } else {
      seen.add(item);
    }
  }
  
  return Array.from(duplicates);
}

// Optimized DOM manipulation with DocumentFragment
function addItems(items) {
  const container = document.getElementById('container');
  const fragment = document.createDocumentFragment();
  
  for (const item of items) {
    const div = document.createElement('div');
    div.className = 'item';
    div.textContent = item;
    fragment.appendChild(div);
  }
  
  container.appendChild(fragment);
}

// Function with proper cleanup to prevent memory leaks
function setupEventListeners() {
  const button = document.getElementById('button');
  
  const handleClick = () => {
    fetch('/api/data')
      .then(response => response.json())
      .then(data => {
        processData(data);
      });
  };
  
  button.addEventListener('click', handleClick);
  
  // Return cleanup function
  return () => {
    button.removeEventListener('click', handleClick);
  };
}`,

  python: `# Efficient string joining
def build_string(items):
    return ", ".join(items)  # Uses optimized string joining

# Efficient list creation with comprehension
def get_squares(n):
    return [i * i for i in range(n)]  # List comprehension is faster

# Memoized fibonacci to avoid repeated calculations
def fibonacci(n, memo={}):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fibonacci(n-1, memo) + fibonacci(n-2, memo)
    return memo[n]`,

  css: `/* Efficient CSS with shared classes */
.flex-card {
    display: flex;
    padding: 10px;
    background-color: #f5f5f5;
    border-radius: 4px;
}

.header, .footer, .sidebar {
    /* Inherit common styles from flex-card */
    composes: flex-card;
}

/* Simplified selector */
.nav-link.active {
    color: blue;
}`,

  html: `<!DOCTYPE html>
<html>
<head>
    <title>Optimized Page</title>
    <!-- Deferred non-critical scripts -->
    <link rel="stylesheet" href="https://cdn.example.com/large-framework.css" media="print" onload="this.media='all'">
    <script defer src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script defer src="https://cdn.example.com/huge-library.js"></script>
</head>
<body>
    <!-- Optimized images with dimensions to prevent layout shifts -->
    <img src="large-image.jpg" width="800" height="600" loading="lazy" alt="Description">
    
    <!-- Simplified nesting -->
    <div class="content">
        <p>Simplified content structure</p>
    </div>
    
    <!-- Script at the end with async execution -->
    <script>
        // Use requestIdleCallback for non-critical operations
        window.requestIdleCallback(() => {
            for (let i = 0; i < 1000; i++) {
                console.log('No longer blocking the main thread');
            }
        });
    </script>
</body>
</html>`,
};

export default function CodeEditor({ initialCode = "", language = "javascript", onOptimize }: CodeEditorProps) {
  const { toast } = useToast();
  const [code, setCode] = useState(initialCode || SAMPLE_CODE[language as keyof typeof SAMPLE_CODE]);
  const [selectedLanguage, setSelectedLanguage] = useState(language);
  const [optimizedCode, setOptimizedCode] = useState("");
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setCode(SAMPLE_CODE[selectedLanguage as keyof typeof SAMPLE_CODE] || SAMPLE_CODE.javascript);
    setOptimizedCode("");
  }, [selectedLanguage]);

  const handleOptimize = async () => {
    setIsOptimizing(true);
    setOptimizedCode("");

    try {
      // In a real app, we would send this to the server for actual optimization
      // For now, we'll use pre-defined optimized code examples
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API call
      
      const optimized = OPTIMIZED_CODE[selectedLanguage as keyof typeof OPTIMIZED_CODE];
      setOptimizedCode(optimized || "// No optimization suggestions available for this language");
      
      if (onOptimize) {
        onOptimize(optimized);
      }
      
      toast({
        title: "Code Optimized",
        description: "We found several improvements for your code.",
      });
      
    } catch (error) {
      console.error("Optimization error:", error);
      toast({
        title: "Optimization Failed",
        description: "Failed to optimize code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsOptimizing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    
    toast({
      title: "Copied!",
      description: "Code copied to clipboard",
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Code2 className="h-5 w-5" />
                Code Optimizer
              </CardTitle>
              <CardDescription>
                Analyze and optimize your code for better performance
              </CardDescription>
            </div>
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="javascript">JavaScript</SelectItem>
                <SelectItem value="python">Python</SelectItem>
                <SelectItem value="css">CSS</SelectItem>
                <SelectItem value="html">HTML</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1">
            <label className="text-sm font-medium">Original Code</label>
            <div className="relative">
              <textarea
                className="w-full h-64 p-4 font-mono text-sm bg-secondary/30 border rounded-md resize-none"
                value={code}
                onChange={(e) => setCode(e.target.value)}
              />
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute top-2 right-2" 
                onClick={() => copyToClipboard(code)}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {optimizedCode && (
            <div className="space-y-1">
              <label className="text-sm font-medium">Optimized Code</label>
              <div className="relative">
                <textarea
                  className="w-full h-64 p-4 font-mono text-sm bg-secondary/30 border rounded-md resize-none"
                  value={optimizedCode}
                  readOnly
                />
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="absolute top-2 right-2" 
                  onClick={() => copyToClipboard(optimizedCode)}
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => setCode(SAMPLE_CODE[selectedLanguage as keyof typeof SAMPLE_CODE])}>
            Reset to Sample
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => copyToClipboard(optimizedCode || code)}>
              <Copy className="mr-2 h-4 w-4" />
              Copy
            </Button>
            <Button onClick={handleOptimize} disabled={isOptimizing} className="bg-blue-600 hover:bg-blue-700">
              {isOptimizing ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Optimizing...
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Optimize Code
                </>
              )}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}