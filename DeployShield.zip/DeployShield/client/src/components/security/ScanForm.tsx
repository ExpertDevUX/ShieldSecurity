import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, AlertCircle } from "lucide-react";
import { Project } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

interface ScanFormProps {
  projects: Project[];
  isLoading: boolean;
  onScanComplete: (scanId: number) => void;
}

const scanFormSchema = z.object({
  projectId: z.string().min(1, "Project selection is required"),
  comprehensive: z.boolean().default(false),
  vulnerabilityCheck: z.boolean().default(true),
  configCheck: z.boolean().default(true),
  dependencyCheck: z.boolean().default(true)
});

type ScanFormValues = z.infer<typeof scanFormSchema>;

export default function ScanForm({ projects, isLoading, onScanComplete }: ScanFormProps) {
  const [scanning, setScanning] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<ScanFormValues>({
    resolver: zodResolver(scanFormSchema),
    defaultValues: {
      projectId: "",
      comprehensive: false,
      vulnerabilityCheck: true,
      configCheck: true,
      dependencyCheck: true
    }
  });

  const onSubmit = async (data: ScanFormValues) => {
    setScanning(true);
    
    try {
      const projectId = parseInt(data.projectId);
      
      // Create a scan record
      const scan = await apiRequest("POST", "/api/security-scans", {
        projectId,
        highSeverity: Math.floor(Math.random() * 3),
        mediumSeverity: Math.floor(Math.random() * 4),
        lowSeverity: Math.floor(Math.random() * 5),
        status: "In Progress"
      });
      
      toast({
        title: "Security scan started",
        description: "The scan is now running. Results will be available shortly.",
      });
      
      // Simulate scan processing
      setTimeout(async () => {
        // Add some vulnerabilities
        if (data.comprehensive) {
          await apiRequest("POST", "/api/vulnerabilities", {
            scanId: scan.id,
            description: "Outdated dependency with known vulnerability",
            severity: "Medium",
            codeSnippet: "package.json: \"express\": \"^4.16.0\"",
            recommendation: "Update to the latest version: \"express\": \"^4.18.2\"",
            filePath: "package.json",
            lineNumber: 12,
            fixed: false
          });
          
          await apiRequest("POST", "/api/vulnerabilities", {
            scanId: scan.id,
            description: "Cross-Site Scripting (XSS) vulnerability",
            severity: "High",
            codeSnippet: "res.send(`<div>${userInput}</div>`);",
            recommendation: "Use a template engine or sanitize input before rendering",
            filePath: "routes/user.js",
            lineNumber: 24,
            fixed: false
          });
        }
        
        if (data.vulnerabilityCheck) {
          await apiRequest("POST", "/api/vulnerabilities", {
            scanId: scan.id,
            description: "SQL Injection risk",
            severity: "High",
            codeSnippet: "db.query(`SELECT * FROM users WHERE id = ${userId}`);",
            recommendation: "Use parameterized queries: db.query('SELECT * FROM users WHERE id = ?', [userId])",
            filePath: "models/user.js",
            lineNumber: 35,
            fixed: false
          });
        }
        
        if (data.configCheck) {
          await apiRequest("POST", "/api/vulnerabilities", {
            scanId: scan.id,
            description: "Insecure configuration setting",
            severity: "Medium",
            codeSnippet: "app.use(cors({ origin: '*' }));",
            recommendation: "Restrict CORS to specific domains",
            filePath: "app.js",
            lineNumber: 8,
            fixed: false
          });
        }
        
        // Update scan status
        await apiRequest("PATCH", `/api/security-scans/${scan.id}`, {
          status: "Needs Attention"
        });
        
        setScanning(false);
        onScanComplete(scan.id);
        
        toast({
          title: "Security scan completed",
          description: "Vulnerabilities have been detected. Review the results.",
        });
      }, 2000);
      
    } catch (error) {
      console.error("Error starting security scan:", error);
      setScanning(false);
      toast({
        title: "Scan failed",
        description: "There was an error starting the security scan. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-3/4 mb-2" />
          <Skeleton className="h-4 w-full" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-full" />
          </div>
        </CardContent>
        <CardFooter>
          <Skeleton className="h-10 w-full" />
        </CardFooter>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Shield className="w-5 h-5 mr-2 text-blue-500" />
          Security Scan
        </CardTitle>
        <CardDescription>
          Select a project and scan options to begin analyzing your code for security vulnerabilities.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="projectId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a project to scan" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name} ({project.language})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Choose the project you want to analyze for security issues.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="comprehensive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Comprehensive Scan</FormLabel>
                      <FormDescription>
                        Perform a deep analysis with detailed reporting (takes longer)
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="vulnerabilityCheck"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Vulnerability Check</FormLabel>
                      <FormDescription>
                        Detect code vulnerabilities like SQL injection and XSS
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="configCheck"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Configuration Check</FormLabel>
                      <FormDescription>
                        Review security settings and configurations
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="dependencyCheck"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Dependency Check</FormLabel>
                      <FormDescription>
                        Scan dependencies for known vulnerabilities
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>
            
            <Button type="submit" className="w-full" disabled={scanning}>
              {scanning ? "Scanning..." : "Start Security Scan"}
            </Button>
          </form>
        </Form>
      </CardContent>
      
      {!projects.length && (
        <CardFooter>
          <div className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-md flex items-start">
            <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5 mr-2" />
            <div>
              <h5 className="text-sm font-medium text-yellow-800">No Projects Found</h5>
              <p className="text-xs text-yellow-700 mt-1">
                Create a project first to perform security scans.
              </p>
            </div>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}
