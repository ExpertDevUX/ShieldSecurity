import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, AlertTriangle, Code, CheckCircle, XCircle } from "lucide-react";
import { Project, SecurityScan, Vulnerability } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SecurityResultProps {
  scan: SecurityScan | undefined;
  vulnerabilities: Vulnerability[];
  projects: Project[];
  isLoading: boolean;
}

export default function SecurityResult({ scan, vulnerabilities, projects, isLoading }: SecurityResultProps) {
  const [activeTab, setActiveTab] = useState("summary");
  const { toast } = useToast();
  
  const getProjectName = (projectId: number | undefined) => {
    if (!projectId) return "Unknown Project";
    const project = projects.find(p => p.id === projectId);
    return project ? project.name : "Unknown Project";
  };
  
  const getProjectLanguage = (projectId: number | undefined) => {
    if (!projectId) return "Unknown";
    const project = projects.find(p => p.id === projectId);
    return project ? project.language : "Unknown";
  };

  const getFormattedTime = (date: Date | undefined) => {
    if (!date) return "Never";
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };
  
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "High":
        return "text-red-500 bg-red-100";
      case "Medium":
        return "text-orange-500 bg-orange-100";
      case "Low":
        return "text-blue-500 bg-blue-100";
      default:
        return "text-gray-500 bg-gray-100";
    }
  };
  
  const handleFixAll = async () => {
    try {
      // Update all vulnerabilities to fixed status
      for (const vuln of vulnerabilities) {
        await apiRequest("PATCH", `/api/vulnerabilities/${vuln.id}`, { fixed: true });
      }
      
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ["/api/vulnerabilities"] });
      
      toast({
        title: "Issues fixed",
        description: "All vulnerabilities have been marked as fixed",
      });
      
      // Reload the page to show updated status
      window.location.reload();
    } catch (error) {
      console.error("Error fixing issues:", error);
      toast({
        title: "Error",
        description: "Failed to fix issues. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const handleFixIssue = async (id: number) => {
    try {
      await apiRequest("PATCH", `/api/vulnerabilities/${id}`, { fixed: true });
      
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ["/api/vulnerabilities"] });
      
      toast({
        title: "Issue fixed",
        description: "The vulnerability has been marked as fixed",
      });
      
      // Reload the page to show updated status
      window.location.reload();
    } catch (error) {
      console.error("Error fixing issue:", error);
      toast({
        title: "Error",
        description: "Failed to fix the issue. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-3/4 mb-2" />
          <Skeleton className="h-4 w-full" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-40 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!scan) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="w-5 h-5 mr-2 text-blue-500" />
            Security Scan Results
          </CardTitle>
          <CardDescription>
            Run a security scan to see results here.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <AlertTriangle className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">No Scan Selected</h3>
            <p className="text-sm text-gray-500 max-w-md">
              Select a project and run a security scan to analyze your code for vulnerabilities and security issues.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalVulnerabilities = scan.highSeverity + scan.mediumSeverity + scan.lowSeverity;
  const highVulnerabilities = vulnerabilities.filter(v => v.severity === "High");
  const mediumVulnerabilities = vulnerabilities.filter(v => v.severity === "Medium");
  const lowVulnerabilities = vulnerabilities.filter(v => v.severity === "Low");
  const fixedVulnerabilities = vulnerabilities.filter(v => v.fixed);
  
  const securityScore = Math.max(0, 100 - (
    (highVulnerabilities.length * 15) + 
    (mediumVulnerabilities.length * 5) + 
    (lowVulnerabilities.length * 2)
  ));

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <Shield className="w-5 h-5 mr-2 text-blue-500" />
            {getProjectName(scan.projectId)} Security Scan
          </CardTitle>
          <Badge variant={scan.status === "Secure" ? "success" : scan.status === "Low Risk" ? "warning" : "destructive"}>
            {scan.status}
          </Badge>
        </div>
        <CardDescription>
          Scan performed {getFormattedTime(scan.scanDate)} on {getProjectLanguage(scan.projectId)} project
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="summary" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="issues">Issues ({totalVulnerabilities})</TabsTrigger>
            <TabsTrigger value="remediation">Remediation</TabsTrigger>
          </TabsList>
          
          <TabsContent value="summary">
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700">Security Score</h3>
                <span className="text-sm text-gray-500">{securityScore}/100</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className={`h-2.5 rounded-full ${
                    securityScore > 80 
                      ? 'bg-green-500' 
                      : securityScore > 50 
                        ? 'bg-yellow-500' 
                        : 'bg-red-500'
                  }`} 
                  style={{ width: `${securityScore}%` }}
                ></div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-4 rounded-md">
                <div className="text-sm text-gray-500 mb-1">Issues Found</div>
                <div className="text-2xl font-semibold">{totalVulnerabilities}</div>
                <div className="flex mt-2 space-x-2">
                  {scan.highSeverity > 0 && (
                    <Badge variant="destructive">{scan.highSeverity} High</Badge>
                  )}
                  {scan.mediumSeverity > 0 && (
                    <Badge variant="warning">{scan.mediumSeverity} Medium</Badge>
                  )}
                  {scan.lowSeverity > 0 && (
                    <Badge variant="secondary">{scan.lowSeverity} Low</Badge>
                  )}
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-md">
                <div className="text-sm text-gray-500 mb-1">Fixed</div>
                <div className="text-2xl font-semibold">{fixedVulnerabilities.length}</div>
                <div className="mt-2">
                  <Badge variant="outline" className="bg-white">
                    {fixedVulnerabilities.length} of {totalVulnerabilities} Fixed
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button
                variant="default"
                onClick={() => setActiveTab("issues")}
                disabled={totalVulnerabilities === 0}
              >
                View All Issues
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="issues">
            {vulnerabilities.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No Issues Found</h3>
                <p className="text-sm text-gray-500 max-w-md">
                  Great job! No security vulnerabilities were detected in your code.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {vulnerabilities.map((vulnerability) => (
                  <div
                    key={vulnerability.id}
                    className={`p-3 border rounded-md ${vulnerability.fixed ? 'bg-green-50 border-green-200' : 'bg-white border-gray-200'}`}
                  >
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mt-0.5">
                        {vulnerability.fixed ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : (
                          <AlertTriangle className={`h-5 w-5 ${vulnerability.severity === 'High' ? 'text-red-500' : vulnerability.severity === 'Medium' ? 'text-orange-500' : 'text-blue-500'}`} />
                        )}
                      </div>
                      <div className="ml-3 flex-grow">
                        <div className="flex justify-between items-center">
                          <h5 className="text-sm font-medium text-gray-900 flex items-center">
                            {vulnerability.description}
                            <Badge 
                              variant="outline" 
                              className={`ml-2 ${getSeverityColor(vulnerability.severity)}`}
                            >
                              {vulnerability.severity}
                            </Badge>
                          </h5>
                          {!vulnerability.fixed && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="text-xs"
                              onClick={() => handleFixIssue(vulnerability.id)}
                            >
                              Fix
                            </Button>
                          )}
                        </div>
                        
                        <div className="mt-1 text-xs text-gray-500">
                          {vulnerability.filePath && (
                            <span className="inline-flex items-center mr-3">
                              <Code className="h-3 w-3 mr-1" />
                              {vulnerability.filePath}:{vulnerability.lineNumber}
                            </span>
                          )}
                        </div>
                        
                        {vulnerability.codeSnippet && (
                          <div className="mt-2 bg-gray-800 text-gray-100 p-2 rounded-md text-xs font-mono overflow-x-auto">
                            {vulnerability.codeSnippet}
                          </div>
                        )}
                        
                        {vulnerability.recommendation && (
                          <div className="mt-2 text-xs text-green-600">
                            <strong>Recommendation:</strong> {vulnerability.recommendation}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="flex justify-end">
                  <Button
                    variant="default"
                    onClick={handleFixAll}
                    disabled={vulnerabilities.every(v => v.fixed)}
                  >
                    Fix All Issues
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="remediation">
            <div className="space-y-4">
              <div className="p-4 bg-white border rounded-md">
                <h3 className="text-sm font-medium text-gray-900 mb-2">Remediation Plan</h3>
                
                {highVulnerabilities.length > 0 && (
                  <div className="mb-4">
                    <h4 className="text-xs font-semibold text-red-600 mb-1">Critical Actions Required</h4>
                    <ul className="list-disc pl-5 text-xs text-gray-700 space-y-1">
                      {highVulnerabilities.map((v, i) => (
                        <li key={i}>
                          {v.description} in {v.filePath} 
                          {v.fixed && <span className="text-green-500 ml-1">(Fixed)</span>}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {mediumVulnerabilities.length > 0 && (
                  <div className="mb-4">
                    <h4 className="text-xs font-semibold text-orange-600 mb-1">Important Actions</h4>
                    <ul className="list-disc pl-5 text-xs text-gray-700 space-y-1">
                      {mediumVulnerabilities.map((v, i) => (
                        <li key={i}>
                          {v.description} in {v.filePath}
                          {v.fixed && <span className="text-green-500 ml-1">(Fixed)</span>}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {lowVulnerabilities.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-blue-600 mb-1">Recommended Actions</h4>
                    <ul className="list-disc pl-5 text-xs text-gray-700 space-y-1">
                      {lowVulnerabilities.map((v, i) => (
                        <li key={i}>
                          {v.description} in {v.filePath}
                          {v.fixed && <span className="text-green-500 ml-1">(Fixed)</span>}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {vulnerabilities.length === 0 && (
                  <div className="flex items-center text-green-600 text-sm">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    No remediation actions needed. Your code is secure!
                  </div>
                )}
              </div>
              
              <div className="p-4 bg-white border rounded-md">
                <h3 className="text-sm font-medium text-gray-900 mb-2">Best Practices</h3>
                <ul className="list-disc pl-5 text-xs text-gray-700 space-y-2">
                  <li>Always validate and sanitize user input to prevent injection attacks</li>
                  <li>Use parameterized queries for database operations</li>
                  <li>Keep dependencies updated to latest secure versions</li>
                  <li>Implement proper error handling without exposing sensitive information</li>
                  <li>Use HTTPS for all connections and set secure cookie flags</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
