import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { 
  Folder, 
  File, 
  FileText, 
  Image, 
  Code2, 
  ArrowUp, 
  RefreshCw, 
  Plus, 
  Trash2, 
  Edit, 
  Download, 
  Eye, 
  Save, 
  FileCog, 
  Server
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { apiRequest } from "@/lib/queryClient";

interface FileEntry {
  name: string;
  type: "file" | "directory";
  size: number;
  lastModified: string;
  permissions: string;
  extension?: string;
}

// Define response type for file content
interface FileContentResponse {
  content: string;
}

export default function ServerFileBrowser({ rootPath = "/var/www/html" }: { rootPath?: string }) {
  const { toast } = useToast();
  const [currentPath, setCurrentPath] = useState(rootPath);
  const [files, setFiles] = useState<FileEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedFile, setSelectedFile] = useState<FileEntry | null>(null);
  const [fileContent, setFileContent] = useState("");
  const [newFileContent, setNewFileContent] = useState("");
  const [newFileName, setNewFileName] = useState("");
  const [newFolderName, setNewFolderName] = useState("");
  const [activeTab, setActiveTab] = useState("browse");
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateFileDialogOpen, setIsCreateFileDialogOpen] = useState(false);
  const [isCreateFolderDialogOpen, setIsCreateFolderDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  // Load files from the current path
  const loadFiles = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest(`/api/server-files?path=${encodeURIComponent(currentPath)}`, "", {
        method: "GET",
      });
      
      if (response && Array.isArray(response)) {
        setFiles(response);
      } else {
        throw new Error("Invalid response format");
      }
    } catch (err) {
      console.error("Error loading files:", err);
      setError("Failed to load files. Make sure the server has proper permissions to access this directory.");
      setFiles([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Load file content
  const loadFileContent = async (file: FileEntry) => {
    if (file.type !== "file") return;
    
    setIsLoading(true);
    try {
      const response = await apiRequest<FileContentResponse>(`/api/server-files/content?path=${encodeURIComponent(`${currentPath}/${file.name}`)}`, "", {
        method: "GET",
      });
      
      if (response && response.content && typeof response.content === "string") {
        setFileContent(response.content);
        setNewFileContent(response.content);
      } else {
        throw new Error("Invalid response format");
      }
    } catch (err) {
      console.error("Error loading file content:", err);
      toast({
        title: "Error",
        description: "Failed to load file content",
        variant: "destructive",
      });
      setFileContent("");
      setNewFileContent("");
    } finally {
      setIsLoading(false);
    }
  };

  // Save file content
  const saveFileContent = async () => {
    if (!selectedFile) return;
    
    setIsLoading(true);
    try {
      await apiRequest(`/api/server-files/content`, JSON.stringify({
        path: `${currentPath}/${selectedFile.name}`,
        content: newFileContent,
      }), {
        method: "POST",
      });
      
      setFileContent(newFileContent);
      setIsEditing(false);
      
      toast({
        title: "Success",
        description: "File saved successfully",
      });
    } catch (err) {
      console.error("Error saving file:", err);
      toast({
        title: "Error",
        description: "Failed to save file",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Create a new file
  const createFile = async () => {
    if (!newFileName) return;
    
    setIsLoading(true);
    try {
      await apiRequest(`/api/server-files/create`, JSON.stringify({
        path: `${currentPath}/${newFileName}`,
        content: "",
        type: "file",
      }), {
        method: "POST",
      });
      
      setIsCreateFileDialogOpen(false);
      setNewFileName("");
      loadFiles();
      
      toast({
        title: "Success",
        description: "File created successfully",
      });
    } catch (err) {
      console.error("Error creating file:", err);
      toast({
        title: "Error",
        description: "Failed to create file",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Create a new folder
  const createFolder = async () => {
    if (!newFolderName) return;
    
    setIsLoading(true);
    try {
      await apiRequest(`/api/server-files/create`, JSON.stringify({
        path: `${currentPath}/${newFolderName}`,
        type: "directory",
      }), {
        method: "POST",
      });
      
      setIsCreateFolderDialogOpen(false);
      setNewFolderName("");
      loadFiles();
      
      toast({
        title: "Success",
        description: "Folder created successfully",
      });
    } catch (err) {
      console.error("Error creating folder:", err);
      toast({
        title: "Error",
        description: "Failed to create folder",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Delete a file or folder
  const deleteFileOrFolder = async () => {
    if (!selectedFile) return;
    
    setIsLoading(true);
    try {
      await apiRequest(`/api/server-files/delete`, JSON.stringify({
        path: `${currentPath}/${selectedFile.name}`,
        type: selectedFile.type,
      }), {
        method: "DELETE",
      });
      
      setIsDeleteDialogOpen(false);
      setSelectedFile(null);
      setFileContent("");
      setNewFileContent("");
      loadFiles();
      
      toast({
        title: "Success",
        description: `${selectedFile.type === "file" ? "File" : "Folder"} deleted successfully`,
      });
    } catch (err) {
      console.error("Error deleting:", err);
      toast({
        title: "Error",
        description: `Failed to delete ${selectedFile.type}`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Navigate to a directory
  const navigateTo = (path: string) => {
    setCurrentPath(path);
    setSelectedFile(null);
    setFileContent("");
    setNewFileContent("");
    setActiveTab("browse");
  };

  // Navigate up one directory
  const navigateUp = () => {
    if (currentPath === rootPath) return;
    
    const parts = currentPath.split("/");
    parts.pop();
    navigateTo(parts.join("/") || rootPath);
  };

  // Handle file or folder click
  const handleFileClick = (file: FileEntry) => {
    if (file.type === "directory") {
      navigateTo(`${currentPath}/${file.name}`);
    } else {
      setSelectedFile(file);
      loadFileContent(file);
      setActiveTab("view");
    }
  };

  // Get icon for file type
  const getFileIcon = (file: FileEntry) => {
    if (file.type === "directory") {
      return <Folder className="h-5 w-5 text-yellow-500" />;
    }
    
    const extension = file.extension?.toLowerCase() || "";
    
    if (["jpg", "jpeg", "png", "gif", "svg", "webp"].includes(extension)) {
      return <Image className="h-5 w-5 text-blue-500" />;
    }
    
    if (["html", "css", "js", "ts", "jsx", "tsx", "php", "py", "java", "c", "cpp", "go", "rb"].includes(extension)) {
      return <Code2 className="h-5 w-5 text-green-500" />;
    }
    
    if (["txt", "md", "json", "xml", "csv", "log"].includes(extension)) {
      return <FileText className="h-5 w-5 text-gray-500" />;
    }
    
    return <File className="h-5 w-5 text-gray-500" />;
  };

  // Format file size
  const formatFileSize = (size: number) => {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(2)} KB`;
    if (size < 1024 * 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(2)} MB`;
    return `${(size / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };

  // Format date
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString();
  };

  // Filter files based on search query
  const filteredFiles = searchQuery 
    ? files.filter(file => file.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : files;

  // Get breadcrumbs for navigation
  const getBreadcrumbs = () => {
    const parts = currentPath.split("/").filter(Boolean);
    let path = "";
    
    return (
      <Breadcrumb className="mb-4">
        <BreadcrumbItem>
          <BreadcrumbLink onClick={() => navigateTo(rootPath)}>
            <Server className="h-4 w-4 mr-1" />
            root
          </BreadcrumbLink>
        </BreadcrumbItem>
        
        {parts.map((part, index) => {
          path += `/${part}`;
          return (
            <BreadcrumbItem key={index}>
              <BreadcrumbSeparator>/</BreadcrumbSeparator>
              <BreadcrumbLink onClick={() => navigateTo(path)}>
                {part}
              </BreadcrumbLink>
            </BreadcrumbItem>
          );
        })}
      </Breadcrumb>
    );
  };

  // Load files when the component mounts or when currentPath changes
  useEffect(() => {
    loadFiles();
  }, [currentPath]);

  return (
    <Card className="shadow-lg">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <Server className="h-5 w-5 text-primary" />
              Server File Browser
            </CardTitle>
            <CardDescription>
              Browse and manage files in {rootPath}
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={navigateUp} disabled={currentPath === rootPath}>
              <ArrowUp className="h-4 w-4 mr-1" />
              Up
            </Button>
            <Button variant="outline" size="sm" onClick={loadFiles}>
              <RefreshCw className="h-4 w-4 mr-1" />
              Refresh
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="browse" value={activeTab} onValueChange={setActiveTab}>
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger value="browse">
                <Folder className="h-4 w-4 mr-2" />
                Browse
              </TabsTrigger>
              {selectedFile && (
                <TabsTrigger value="view">
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </TabsTrigger>
              )}
              {selectedFile && selectedFile.type === "file" && (
                <TabsTrigger value="edit">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </TabsTrigger>
              )}
            </TabsList>
            
            <div className="flex gap-2">
              <Dialog open={isCreateFileDialogOpen} onOpenChange={setIsCreateFileDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    New File
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New File</DialogTitle>
                    <DialogDescription>
                      Enter a name for the new file in {currentPath}
                    </DialogDescription>
                  </DialogHeader>
                  <Input
                    placeholder="filename.ext"
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                  />
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCreateFileDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createFile} disabled={!newFileName}>
                      Create
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              
              <Dialog open={isCreateFolderDialogOpen} onOpenChange={setIsCreateFolderDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Folder className="h-4 w-4 mr-1" />
                    New Folder
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Folder</DialogTitle>
                    <DialogDescription>
                      Enter a name for the new folder in {currentPath}
                    </DialogDescription>
                  </DialogHeader>
                  <Input
                    placeholder="folder_name"
                    value={newFolderName}
                    onChange={(e) => setNewFolderName(e.target.value)}
                  />
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCreateFolderDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createFolder} disabled={!newFolderName}>
                      Create
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              
              {selectedFile && (
                <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Confirm Deletion</DialogTitle>
                      <DialogDescription>
                        Are you sure you want to delete {selectedFile.name}? This action cannot be undone.
                      </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button variant="destructive" onClick={deleteFileOrFolder}>
                        Delete
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
          
          <TabsContent value="browse" className="p-0 m-0">
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            {getBreadcrumbs()}
            
            <div className="mb-4">
              <Input
                placeholder="Search files and folders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>
            
            <ScrollArea className="h-[400px] border rounded-md">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <RefreshCw className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : (
                <div className="p-1">
                  {filteredFiles.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      {searchQuery ? "No matching files or folders found" : "This directory is empty"}
                    </div>
                  ) : (
                    <table className="w-full">
                      <thead>
                        <tr className="text-xs text-muted-foreground border-b">
                          <th className="text-left py-2 px-3">Name</th>
                          <th className="text-left py-2 px-3">Size</th>
                          <th className="text-left py-2 px-3">Modified</th>
                          <th className="text-left py-2 px-3">Permissions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredFiles.map((file, index) => (
                          <tr 
                            key={file.name}
                            className={`text-sm hover:bg-muted/50 cursor-pointer ${selectedFile && selectedFile.name === file.name ? 'bg-muted' : ''}`}
                            onClick={() => handleFileClick(file)}
                          >
                            <td className="py-2 px-3 flex items-center gap-2">
                              {getFileIcon(file)}
                              <span>{file.name}</span>
                            </td>
                            <td className="py-2 px-3">{file.type === "directory" ? "--" : formatFileSize(file.size)}</td>
                            <td className="py-2 px-3">{formatDate(file.lastModified)}</td>
                            <td className="py-2 px-3">{file.permissions}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="view" className="p-0 m-0">
            {selectedFile && (
              <>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    {getFileIcon(selectedFile)}
                    <span className="font-medium">{selectedFile.name}</span>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setActiveTab("edit")} disabled={isLoading}>
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button variant="outline" size="sm" disabled={isLoading}>
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
                
                <div className="text-xs text-muted-foreground mb-2">
                  <div className="flex gap-6">
                    <span>Size: {formatFileSize(selectedFile.size)}</span>
                    <span>Modified: {formatDate(selectedFile.lastModified)}</span>
                    <span>Permissions: {selectedFile.permissions}</span>
                  </div>
                </div>
                
                <Separator className="my-2" />
                
                {isLoading ? (
                  <div className="flex items-center justify-center h-64">
                    <RefreshCw className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  selectedFile.type === "file" && (
                    <ScrollArea className="h-[400px] border rounded-md">
                      <pre className="p-4 text-sm font-mono whitespace-pre-wrap">{fileContent}</pre>
                    </ScrollArea>
                  )
                )}
              </>
            )}
          </TabsContent>
          
          <TabsContent value="edit" className="p-0 m-0">
            {selectedFile && selectedFile.type === "file" && (
              <>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileCog className="h-5 w-5 text-primary" />
                    <span className="font-medium">Editing: {selectedFile.name}</span>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setActiveTab("view")} disabled={isLoading}>
                      Cancel
                    </Button>
                    <Button size="sm" onClick={saveFileContent} disabled={isLoading}>
                      <Save className="h-4 w-4 mr-1" />
                      Save
                    </Button>
                  </div>
                </div>
                
                <Separator className="my-2" />
                
                {isLoading ? (
                  <div className="flex items-center justify-center h-64">
                    <RefreshCw className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <textarea
                    className="w-full h-[400px] p-4 font-mono text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-primary/50"
                    value={newFileContent}
                    onChange={(e) => setNewFileContent(e.target.value)}
                  />
                )}
              </>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <CardFooter className="text-xs text-muted-foreground justify-between">
        <div>
          Current path: {currentPath}
        </div>
        <div>
          {files.length} items • {files.filter(f => f.type === "directory").length} folders, {files.filter(f => f.type === "file").length} files
        </div>
      </CardFooter>
    </Card>
  );
}