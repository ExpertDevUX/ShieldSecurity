import React, { useState, useEffect, useRef } from 'react';
import { Editor } from '@monaco-editor/react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Save, Play, Terminal } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CodeEditorProps {
  initialValue?: string;
  language?: string;
  readOnly?: boolean;
  onSave?: (code: string) => void;
  onRun?: (code: string) => void;
  showConsole?: boolean;
  height?: string;
  theme?: 'vs-dark' | 'light';
  collaborationId?: string;
}

const CodeEditor: React.FC<CodeEditorProps> = ({
  initialValue = '',
  language = 'javascript',
  readOnly = false,
  onSave,
  onRun,
  showConsole = true,
  height = '500px',
  theme = 'vs-dark',
  collaborationId,
}) => {
  const [code, setCode] = useState(initialValue);
  const [output, setOutput] = useState<Array<{ type: 'info' | 'error' | 'warning' | 'result'; content: string }>>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState<'vs-dark' | 'light'>(theme);
  const consoleEndRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();
  
  // Sync with initialValue prop
  useEffect(() => {
    setCode(initialValue);
  }, [initialValue]);

  // Connect to WebSocket for real-time collaboration
  useEffect(() => {
    if (collaborationId) {
      // Get user information from local storage or session
      const userId = localStorage.getItem('userId') || 'anonymous-' + Math.floor(Math.random() * 1000);
      const username = localStorage.getItem('username') || 'Anonymous User';
      
      console.log(`Establishing connection for collaboration session ${collaborationId}`);
      
      // Create WebSocket connection
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/collaboration?sessionId=${collaborationId}&userId=${userId}&username=${username}`;
      const socket = new WebSocket(wsUrl);
      
      // Store socket reference
      socketRef.current = socket;
      
      // Handle connection opened
      socket.addEventListener('open', () => {
        console.log(`WebSocket connection established for session ${collaborationId}`);
        toast({
          title: 'Connected to collaboration session',
          description: 'You can now collaborate in real-time with other users.',
        });
      });
      
      // Handle incoming messages
      socket.addEventListener('message', (event) => {
        try {
          const message = JSON.parse(event.data);
          
          switch (message.type) {
            case 'system':
              console.log('System message:', message.payload);
              break;
              
            case 'user_joined':
              console.log(`User joined: ${message.payload.username}`);
              toast({
                title: 'User joined',
                description: `${message.payload.username} has joined the session.`,
              });
              break;
              
            case 'user_left':
              console.log(`User left: ${message.payload.username}`);
              toast({
                title: 'User left',
                description: `${message.payload.username} has left the session.`,
              });
              break;
              
            case 'code_update':
              if (message.payload.code) {
                // Update the code state with the received code
                setCode(message.payload.code);
              }
              break;
              
            case 'chat_message':
              console.log(`Chat message from ${message.payload.sender.username}: ${message.payload.message}`);
              // In a real implementation, you would update a chat component
              break;
              
            default:
              console.log('Unknown message type:', message.type);
          }
        } catch (error) {
          console.error('Error processing WebSocket message:', error);
        }
      });
      
      // Handle errors
      socket.addEventListener('error', (error) => {
        console.error('WebSocket error:', error);
        toast({
          title: 'Connection error',
          description: 'Failed to connect to collaboration session.',
          variant: 'destructive',
        });
      });
      
      // Handle connection closing
      socket.addEventListener('close', (event) => {
        if (event.wasClean) {
          console.log(`WebSocket connection closed cleanly, code=${event.code}, reason=${event.reason}`);
        } else {
          console.error('WebSocket connection died');
          toast({
            title: 'Connection lost',
            description: 'Connection to collaboration session was lost.',
            variant: 'destructive',
          });
        }
      });
      
      // Set up ping to keep connection alive
      const pingInterval = setInterval(() => {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({
            type: 'ping',
            sessionId: collaborationId,
            timestamp: Date.now()
          }));
        }
      }, 30000); // Ping every 30 seconds
      
      // Clean up on unmount
      return () => {
        console.log(`Closing WebSocket connection for session ${collaborationId}`);
        clearInterval(pingInterval);
        socket.close();
      };
    }
  }, [collaborationId, toast]);

  // socketRef is already declared above
  const handleEditorChange = (value: string | undefined) => {
    if (value !== undefined) {
      setCode(value);
      
      // Send code updates to other connected clients if in collaboration mode
      if (collaborationId && socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify({
          type: 'code_update',
          payload: {
            code: value,
            language
          },
          sessionId: collaborationId,
          timestamp: Date.now()
        }));
      }
    }
  };

  const handleSave = () => {
    if (onSave) {
      onSave(code);
      toast({
        title: 'Code saved',
        description: 'Your code has been saved successfully.',
      });
    }
  };

  const handleRun = async () => {
    if (!onRun) {
      // If no custom run handler is provided, we'll execute the code in the browser
      // This is a simple implementation that works for JavaScript
      // In a real app, you would want a more robust solution with proper sandboxing
      
      setIsRunning(true);
      setOutput([{ type: 'info', content: 'Running code...' }]);
      
      try {
        // Create a safe console to capture logs
        const logs: Array<{ type: 'info' | 'error' | 'warning'; content: string }> = [];
        const safeConsole = {
          log: (...args: any[]) => {
            const content = args.map(arg => 
              typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
            ).join(' ');
            logs.push({ type: 'info', content });
          },
          error: (...args: any[]) => {
            const content = args.map(arg => 
              typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
            ).join(' ');
            logs.push({ type: 'error', content });
          },
          warn: (...args: any[]) => {
            const content = args.map(arg => 
              typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
            ).join(' ');
            logs.push({ type: 'warning', content });
          }
        };
        
        if (language === 'javascript' || language === 'typescript') {
          // Execute the code in a sandboxed environment
          const executeCode = new Function('console', `
            try {
              ${code}
              return { success: true };
            } catch (error) {
              console.error(error.message);
              return { success: false, error: error.message };
            }
          `);
          
          const result = executeCode(safeConsole);
          setOutput([
            ...logs,
            result.success 
              ? { type: 'result', content: 'Code executed successfully.' }
              : { type: 'error', content: `Execution failed: ${result.error}` }
          ]);
        } else {
          setOutput([
            { type: 'warning', content: `Running code for ${language} is not supported in the browser.` },
            { type: 'info', content: 'This would be executed on the server in a real implementation.' }
          ]);
        }
      } catch (error) {
        setOutput([
          { type: 'error', content: `Failed to execute code: ${error instanceof Error ? error.message : String(error)}` }
        ]);
      } finally {
        setIsRunning(false);
      }
    } else {
      // Use the provided handler
      setIsRunning(true);
      try {
        onRun(code);
      } catch (error) {
        console.error('Error running code:', error);
      } finally {
        setIsRunning(false);
      }
    }
  };

  const clearConsole = () => {
    setOutput([]);
  };

  // Auto-scroll console to bottom when new output appears
  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [output]);

  const toggleTheme = () => {
    setSelectedTheme(prev => prev === 'vs-dark' ? 'light' : 'vs-dark');
  };

  return (
    <div className="code-editor-container" style={{ height }}>
      <div className="flex flex-col h-full">
        <div className="flex justify-between items-center p-2 bg-background border-b">
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium">Language: {language}</span>
            {collaborationId && (
              <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">
                Collaborative
              </span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Tabs value={selectedTheme} onValueChange={(value) => setSelectedTheme(value as 'vs-dark' | 'light')}>
              <TabsList className="h-8">
                <TabsTrigger value="vs-dark" className="text-xs px-2 py-1">Dark</TabsTrigger>
                <TabsTrigger value="light" className="text-xs px-2 py-1">Light</TabsTrigger>
              </TabsList>
            </Tabs>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleSave}
              disabled={readOnly}
            >
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
            
            {onRun && (
              <Button 
                variant="default" 
                size="sm" 
                onClick={handleRun}
                disabled={isRunning}
              >
                {isRunning ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Running...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Run
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
        
        <div className="editor-wrapper flex-grow">
          <Editor
            height="100%"
            language={language}
            value={code}
            onChange={handleEditorChange}
            theme={selectedTheme}
            options={{
              readOnly,
              minimap: { enabled: true },
              scrollBeyondLastLine: false,
              fontSize: 14,
              lineNumbers: 'on',
              renderLineHighlight: 'all',
              automaticLayout: true,
            }}
          />
        </div>
        
        {showConsole && (
          <div className="console-area border-t bg-gray-900 text-white">
            <div className="flex justify-between items-center p-2 bg-gray-800">
              <div className="flex items-center">
                <Terminal className="h-4 w-4 mr-2" />
                <span className="text-sm font-medium">Console</span>
              </div>
              <Button variant="ghost" size="sm" className="text-white text-xs" onClick={clearConsole}>
                Clear
              </Button>
            </div>
            <ScrollArea className="h-[150px]">
              <div className="p-2 font-mono text-sm">
                {output.length === 0 ? (
                  <div className="text-gray-400 italic">No output yet. Run your code to see results here.</div>
                ) : (
                  output.map((item, index) => (
                    <div 
                      key={index} 
                      className={`mb-1 ${
                        item.type === 'error' 
                          ? 'text-red-400' 
                          : item.type === 'warning' 
                            ? 'text-yellow-400' 
                            : item.type === 'result' 
                              ? 'text-green-400' 
                              : 'text-gray-200'
                      }`}
                    >
                      <span className="opacity-70">{`> `}</span>
                      {item.content}
                    </div>
                  ))
                )}
                <div ref={consoleEndRef} />
              </div>
            </ScrollArea>
          </div>
        )}
      </div>
    </div>
  );
};

export default CodeEditor;