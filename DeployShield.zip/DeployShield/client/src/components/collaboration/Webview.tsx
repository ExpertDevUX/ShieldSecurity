import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, RefreshCw, ExternalLink, Maximize2, Minimize2 } from 'lucide-react';
import CodeEditor from './CodeEditor';

interface WebviewProps {
  url?: string;
  initialTab?: 'preview' | 'editor' | 'console';
  code?: string;
  language?: string;
  allowFullscreen?: boolean;
  height?: string;
  onCodeChange?: (code: string) => void;
  onRefresh?: () => void;
}

const Webview: React.FC<WebviewProps> = ({
  url = '',
  initialTab = 'preview',
  code = '',
  language = 'html',
  allowFullscreen = true,
  height = '600px',
  onCodeChange,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState(initialTab);
  const [currentUrl, setCurrentUrl] = useState(url);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editorCode, setEditorCode] = useState(code);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [consoleMessages, setConsoleMessages] = useState<Array<{type: string, content: string}>>([]);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Handle URL change
  useEffect(() => {
    setCurrentUrl(url);
  }, [url]);

  // Handle initial code
  useEffect(() => {
    setEditorCode(code);
  }, [code]);

  const handleRefresh = () => {
    setLoading(true);
    setError(null);
    if (onRefresh) {
      onRefresh();
    } else if (iframeRef.current) {
      iframeRef.current.src = currentUrl;
    }
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentUrl(e.target.value);
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    if (iframeRef.current) {
      iframeRef.current.src = currentUrl;
    }
  };

  const handleIframeLoad = () => {
    setLoading(false);
    
    // Try to capture console messages from the iframe
    try {
      if (iframeRef.current && iframeRef.current.contentWindow) {
        const iframeWindow = iframeRef.current.contentWindow;
        
        // Override console methods in the iframe
        const originalConsoleLog = iframeWindow.console.log;
        const originalConsoleError = iframeWindow.console.error;
        const originalConsoleWarn = iframeWindow.console.warn;
        
        iframeWindow.console.log = (...args: any[]) => {
          originalConsoleLog.apply(iframeWindow.console, args);
          setConsoleMessages(prev => [...prev, {
            type: 'log',
            content: args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ')
          }]);
        };
        
        iframeWindow.console.error = (...args: any[]) => {
          originalConsoleError.apply(iframeWindow.console, args);
          setConsoleMessages(prev => [...prev, {
            type: 'error',
            content: args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ')
          }]);
        };
        
        iframeWindow.console.warn = (...args: any[]) => {
          originalConsoleWarn.apply(iframeWindow.console, args);
          setConsoleMessages(prev => [...prev, {
            type: 'warn',
            content: args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ')
          }]);
        };
      }
    } catch (err) {
      // Cross-origin issues might prevent accessing the iframe's console
      console.error('Could not capture iframe console:', err);
    }
  };

  const handleIframeError = () => {
    setLoading(false);
    setError('Failed to load the requested URL. It might be blocked by CORS policy or the resource doesn\'t exist.');
  };

  const handleCodeChange = (newCode: string) => {
    setEditorCode(newCode);
    if (onCodeChange) {
      onCodeChange(newCode);
    }
  };

  const renderPreview = () => {
    // For HTML content, we can render it directly in an iframe using data URI
    if (language === 'html' && editorCode) {
      const htmlContent = `data:text/html;charset=utf-8,${encodeURIComponent(editorCode)}`;
      return (
        <iframe
          ref={iframeRef}
          src={htmlContent}
          className="w-full h-full border-0"
          onLoad={handleIframeLoad}
          onError={handleIframeError}
          sandbox="allow-scripts allow-same-origin"
          title="Preview"
        />
      );
    }
    
    // For other URL-based content
    return (
      <iframe
        ref={iframeRef}
        src={currentUrl}
        className="w-full h-full border-0"
        onLoad={handleIframeLoad}
        onError={handleIframeError}
        sandbox="allow-scripts allow-same-origin"
        title="Preview"
      />
    );
  };

  const toggleFullscreen = () => {
    if (containerRef.current) {
      if (!isFullscreen) {
        if (containerRef.current.requestFullscreen) {
          containerRef.current.requestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        }
      }
      setIsFullscreen(!isFullscreen);
    }
  };

  // Listen for fullscreen change events
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const clearConsole = () => {
    setConsoleMessages([]);
  };

  return (
    <div ref={containerRef} className={`webview-container ${isFullscreen ? 'fixed inset-0 z-50 bg-background' : ''}`}>
      <Card className="w-full shadow-lg">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-bold">Webview</CardTitle>
            {allowFullscreen && (
              <Button variant="ghost" size="sm" onClick={toggleFullscreen}>
                {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
            )}
          </div>
          
          {activeTab === 'preview' && (
            <form onSubmit={handleUrlSubmit} className="flex w-full space-x-2 mt-2">
              <Input
                type="text"
                placeholder="Enter URL to preview"
                value={currentUrl}
                onChange={handleUrlChange}
                className="flex-grow"
              />
              <Button type="submit" variant="outline" size="sm" className="flex-shrink-0">
                <ExternalLink className="h-4 w-4 mr-2" />
                Go
              </Button>
              <Button type="button" variant="outline" size="sm" onClick={handleRefresh} className="flex-shrink-0">
                <RefreshCw className="h-4 w-4" />
              </Button>
            </form>
          )}
        </CardHeader>
        
        <CardContent className="p-0">
          <Tabs defaultValue={activeTab} value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="w-full">
            <TabsList className="w-full grid grid-cols-3">
              <TabsTrigger value="preview">Preview</TabsTrigger>
              <TabsTrigger value="editor">Code Editor</TabsTrigger>
              <TabsTrigger value="console">Console</TabsTrigger>
            </TabsList>
            
            <TabsContent value="preview" className={`mt-0 ${isFullscreen ? 'h-screen' : ''}`}>
              <div className="relative" style={{ height: isFullscreen ? 'calc(100vh - 120px)' : height }}>
                {loading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                )}
                
                {error && (
                  <Alert variant="destructive" className="m-4">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                
                {renderPreview()}
              </div>
            </TabsContent>
            
            <TabsContent value="editor" className="mt-0">
              <div style={{ height: isFullscreen ? 'calc(100vh - 120px)' : height }}>
                <CodeEditor
                  initialValue={editorCode}
                  language={language}
                  onSave={handleCodeChange}
                  showConsole={false}
                  height="100%"
                />
              </div>
            </TabsContent>
            
            <TabsContent value="console" className="mt-0">
              <div 
                className="bg-gray-900 text-gray-200 p-4 font-mono text-sm overflow-y-auto" 
                style={{ height: isFullscreen ? 'calc(100vh - 120px)' : height }}
              >
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-white font-bold">Console Output</h3>
                  <Button variant="ghost" size="sm" onClick={clearConsole}>Clear</Button>
                </div>
                
                {consoleMessages.length === 0 ? (
                  <p className="text-gray-400 italic">No console messages captured yet.</p>
                ) : (
                  consoleMessages.map((msg, index) => (
                    <div key={index} className="mb-1 border-b border-gray-800 pb-1">
                      <span className={`inline-block w-16 ${msg.type === 'error' ? 'text-red-400' : msg.type === 'warn' ? 'text-yellow-400' : 'text-green-400'}`}>
                        {msg.type}:
                      </span> 
                      <span>{msg.content}</span>
                    </div>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default Webview;