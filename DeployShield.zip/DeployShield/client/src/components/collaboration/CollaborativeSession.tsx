import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Users, MessageSquare, Code, Share2, Clipboard, Globe, Lock } from 'lucide-react';
import CodeEditor from './CodeEditor';
import Webview from './Webview';

interface Participant {
  id: number;
  username: string;
  role: string;
  avatar?: string;
  isActive: boolean;
}

interface Message {
  id: number;
  userId: number;
  username: string;
  content: string;
  timestamp: string;
  avatar?: string;
}

interface CollaborativeSessionProps {
  sessionId?: string;
  projectId?: number;
  initialCode?: string;
  language?: string;
  previewUrl?: string;
  isOwner?: boolean;
}

const CollaborativeSession: React.FC<CollaborativeSessionProps> = ({
  sessionId,
  projectId,
  initialCode = '',
  language = 'javascript',
  previewUrl = '',
  isOwner = false,
}) => {
  const [code, setCode] = useState(initialCode);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [activeTab, setActiveTab] = useState('code');
  const [sessionUrl, setSessionUrl] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const { toast } = useToast();

  // Mock data for demonstration
  useEffect(() => {
    // In a real implementation, this would be fetched from the server
    setParticipants([
      { id: 1, username: 'CurrentUser', role: 'owner', isActive: true },
      { id: 2, username: 'Developer1', role: 'editor', avatar: 'https://github.com/shadcn.png', isActive: true },
      { id: 3, username: 'Reviewer', role: 'viewer', avatar: 'https://github.com/shadcn.png', isActive: false },
    ]);

    setMessages([
      { id: 1, userId: 2, username: 'Developer1', content: 'I added some optimizations to the rendering loop', timestamp: '10:30 AM', avatar: 'https://github.com/shadcn.png' },
      { id: 2, userId: 1, username: 'CurrentUser', content: 'Looks good! Let\'s update the documentation too.', timestamp: '10:32 AM' },
    ]);

    // Generate a shareable URL for the session
    const baseUrl = window.location.origin;
    setSessionUrl(`${baseUrl}/collaborate/${sessionId || 'demo-session'}`);

    // Simulate connection after a delay
    const timer = setTimeout(() => {
      setIsConnected(true);
      toast({
        title: 'Connected',
        description: 'You are now connected to the collaborative session.',
      });
    }, 1500);

    return () => clearTimeout(timer);
  }, [sessionId, toast]);

  const handleCodeChange = (newCode: string) => {
    setCode(newCode);
    // In a real implementation, this would be sent to other participants via WebSockets
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const newMsg: Message = {
      id: messages.length + 1,
      userId: 1,
      username: 'CurrentUser',
      content: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages([...messages, newMsg]);
    setNewMessage('');
    // In a real implementation, this would be sent to other participants via WebSockets
  };

  const handleCopySessionUrl = () => {
    navigator.clipboard.writeText(sessionUrl);
    toast({
      title: 'Link Copied',
      description: 'Collaboration link copied to clipboard.',
    });
  };

  const toggleSessionVisibility = () => {
    setIsPublic(!isPublic);
    toast({
      title: `Session is now ${!isPublic ? 'public' : 'private'}`,
      description: `Anyone with the link can ${!isPublic ? 'join' : 'request to join'} this session.`,
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-full">
      {/* Main editing area */}
      <div className="md:col-span-3 space-y-4">
        <Card className="shadow-lg">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-xl font-bold">Collaborative Session {sessionId && `#${sessionId}`}</CardTitle>
                <CardDescription>
                  {isConnected ? (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Connected
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                      Connecting...
                    </Badge>
                  )}
                </CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={toggleSessionVisibility}>
                  {isPublic ? <Globe className="h-4 w-4 mr-2" /> : <Lock className="h-4 w-4 mr-2" />}
                  {isPublic ? 'Public' : 'Private'}
                </Button>
                <Button variant="outline" size="sm" onClick={handleCopySessionUrl}>
                  <Clipboard className="h-4 w-4 mr-2" />
                  Copy Link
                </Button>
                <Button variant="default" size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Invite
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="code" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full grid grid-cols-2">
                <TabsTrigger value="code">
                  <Code className="h-4 w-4 mr-2" />
                  Code Editor
                </TabsTrigger>
                <TabsTrigger value="preview">
                  <Globe className="h-4 w-4 mr-2" />
                  Preview
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="code" className="mt-0">
                <CodeEditor
                  initialValue={code}
                  language={language}
                  onSave={handleCodeChange}
                  height="600px"
                  collaborationId={sessionId}
                />
              </TabsContent>
              
              <TabsContent value="preview" className="mt-0">
                <Webview
                  url={previewUrl}
                  code={code}
                  language={language}
                  height="600px"
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Sidebar with participants and chat */}
      <div className="space-y-4">
        {/* Participants */}
        <Card className="shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Participants ({participants.filter(p => p.isActive).length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {participants.map(participant => (
                <div key={participant.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Avatar>
                      <AvatarImage src={participant.avatar} />
                      <AvatarFallback>{participant.username.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{participant.username}</div>
                      <div className="text-xs text-muted-foreground capitalize">{participant.role}</div>
                    </div>
                  </div>
                  <div>
                    {participant.isActive ? (
                      <div className="w-2 h-2 bg-green-500 rounded-full" title="Online" />
                    ) : (
                      <div className="w-2 h-2 bg-gray-300 rounded-full" title="Offline" />
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {isOwner && (
              <Button variant="outline" className="w-full mt-3" size="sm">
                Manage Participants
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Chat */}
        <Card className="shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold flex items-center">
              <MessageSquare className="h-5 w-5 mr-2" />
              Chat
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex flex-col">
              <div className="flex-1 overflow-y-auto space-y-3 mb-3">
                {messages.length === 0 ? (
                  <div className="text-center text-muted-foreground py-4">
                    No messages yet. Start the conversation!
                  </div>
                ) : (
                  messages.map(message => (
                    <div key={message.id} className={`flex ${message.userId === 1 ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[80%] ${message.userId === 1 ? 'bg-primary text-primary-foreground' : 'bg-muted'} rounded-lg p-2`}>
                        {message.userId !== 1 && (
                          <div className="font-semibold text-xs">{message.username}</div>
                        )}
                        <div>{message.content}</div>
                        <div className="text-xs opacity-70 text-right mt-1">{message.timestamp}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <form onSubmit={handleSendMessage} className="flex space-x-2">
                <Input
                  type="text"
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit" size="sm">Send</Button>
              </form>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CollaborativeSession;