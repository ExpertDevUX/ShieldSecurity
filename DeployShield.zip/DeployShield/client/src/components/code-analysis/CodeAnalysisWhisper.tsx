import React, { useState } from "react";
import { AlertCircle, Code, Clipboard, ThumbsUp, ThumbsDown, ArrowRight, Zap } from "lucide-react";
import { Whisper } from "@/components/ui/whisper";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

interface CodeAnalysisWhisperProps {
  open: boolean;
  onClose: () => void;
  initialCode?: string;
}

const PROVIDERS = [
  { id: "gemini", name: "Gemini", badge: "AI" },
  { id: "mock", name: "Mock", badge: "DEMO" }
];

export function CodeAnalysisWhisper({
  open,
  onClose,
  initialCode = "",
}: CodeAnalysisWhisperProps) {
  const { toast } = useToast();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [code, setCode] = useState(initialCode);
  const [result, setResult] = useState<{
    issues: Array<{
      id: string;
      description: string;
      severity: "high" | "medium" | "low";
      suggestion?: string;
      code?: string;
    }>;
    score?: number;
    summary?: string;
  } | null>(null);
  const [provider, setProvider] = useState("gemini");
  const [feedback, setFeedback] = useState<"thumbsUp" | "thumbsDown" | null>(null);

  // Generate mock analysis for development purposes when auth is not available
  const generateMockAnalysis = (code: string) => {
    const language = detectLanguage(code);
    const mockIssues = [
      {
        id: "mock-1",
        description: "Using console.log statements in production code",
        severity: "medium" as const,
        suggestion: "Remove console.log statements before deploying to production",
        code: "console.log('debug info')"
      },
      {
        id: "mock-2",
        description: "Potential memory leak in event listener",
        severity: "high" as const,
        suggestion: "Remember to remove event listeners when components unmount",
        code: "window.addEventListener('resize', handleResize)"
      },
      {
        id: "mock-3", 
        description: "Inefficient string concatenation in loop",
        severity: "low" as const,
        suggestion: "Use array join or template literals for better performance",
        code: "for(let i=0; i<items.length; i++) { str += items[i] }"
      }
    ];
    
    return {
      issues: mockIssues,
      score: 76,
      summary: `Analysis complete for ${language} code. Found 3 issues that could be improved for better code quality.`
    };
  };
  
  const analyzeCode = async () => {
    if (!code.trim()) {
      toast({
        title: "Empty Code",
        description: "Please enter code to analyze",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setResult(null);

    try {
      const response = await apiRequest(
        "/api/ai/analyze-code",
        JSON.stringify({
          code,
          provider,
          options: {
            languageHint: detectLanguage(code),
          },
        }),
        { method: "POST" }
      );

      setResult(response);
    } catch (error: any) {
      console.error("Error analyzing code:", error);
      
      // When unauthorized (401) or other API errors, use mock data for development
      if (error.status === 401) {
        // Use mock data for development when auth is not available
        toast({
          title: "Using Development Mode",
          description: "Authentication required. Using mock analysis for development.",
          variant: "default",
        });
        
        setTimeout(() => {
          setResult(generateMockAnalysis(code));
          setIsAnalyzing(false);
        }, 1000); // Simulate API delay
        return;
      }
      
      toast({
        title: "Analysis Failed",
        description: "Failed to analyze code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const detectLanguage = (code: string): string => {
    // Simple language detection based on common patterns
    if (code.includes("import React") || code.includes("function") || code.includes("const") || code.includes("=>")) {
      return "javascript";
    } else if (code.includes("def ") || code.includes("import ") || code.includes("class ") && code.includes(":")) {
      return "python";
    } else if (code.includes("public class") || code.includes("private ") || code.includes("void ")) {
      return "java";
    } else if (code.includes("<?php")) {
      return "php";
    } else if (code.includes("<html>") || code.includes("<!DOCTYPE")) {
      return "html";
    } else if (code.includes("SELECT") || code.includes("FROM") || code.includes("WHERE")) {
      return "sql";
    }
    return "text";
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Copied to Clipboard",
      description: "Code has been copied to your clipboard",
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "destructive";
      case "medium":
        return "secondary"; // Use secondary instead of warning which isn't a valid variant
      case "low":
        return "outline";
      default:
        return "default";
    }
  };

  const handleFeedback = (type: "thumbsUp" | "thumbsDown") => {
    setFeedback(type);
    toast({
      title: "Feedback Received",
      description: "Thank you for your feedback on the code analysis",
    });
    // In a real application, you would send this feedback to your backend
  };

  return (
    <Whisper
      open={open}
      onClose={onClose}
      variant="info"
      size="full"
      icon={<Code className="h-5 w-5" />}
      duration={null}
      className="flex flex-col space-y-4 p-6"
    >
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Code className="h-5 w-5" />
            Code Analysis Whisper
          </h3>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              {PROVIDERS.map((p) => (
                <Button
                  key={p.id}
                  size="sm"
                  variant={provider === p.id ? "default" : "outline"}
                  onClick={() => setProvider(p.id)}
                  className="gap-1.5"
                >
                  {p.name}
                  <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                    {p.badge}
                  </Badge>
                </Button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="code-input">Code to Analyze</Label>
            <Textarea
              id="code-input"
              className="font-mono h-60 overflow-auto"
              placeholder="Paste your code here..."
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
            <div className="flex justify-between">
              <Button
                size="sm"
                variant="outline"
                onClick={copyToClipboard}
                className="gap-1"
              >
                <Clipboard className="h-4 w-4" />
                Copy
              </Button>
              <Button
                onClick={analyzeCode}
                disabled={isAnalyzing}
                className="gap-1"
              >
                {isAnalyzing ? (
                  <>
                    <Zap className="h-4 w-4 animate-pulse" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <ArrowRight className="h-4 w-4" />
                    Analyze Code
                  </>
                )}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Analysis Results</Label>
            <div className="border rounded-md p-4 bg-background h-60 overflow-auto">
              {isAnalyzing ? (
                <div className="flex items-center justify-center h-full">
                  <div className="flex flex-col items-center gap-2">
                    <Zap className="h-8 w-8 animate-pulse text-blue-500" />
                    <p>Analyzing your code...</p>
                  </div>
                </div>
              ) : result ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Analysis Summary</h4>
                    {result.score !== undefined && (
                      <Badge
                        variant={
                          result.score > 80
                            ? "outline" // Use outline for high scores instead of "success"
                            : result.score > 60
                            ? "secondary" // Use secondary for medium scores instead of "warning"
                            : "destructive"
                        }
                      >
                        Score: {result.score}/100
                      </Badge>
                    )}
                  </div>
                  {result.summary && <p className="text-sm">{result.summary}</p>}

                  <Separator />

                  <Tabs defaultValue="issues">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="issues">
                        Issues {result.issues.length > 0 && `(${result.issues.length})`}
                      </TabsTrigger>
                      <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                    </TabsList>
                    <TabsContent value="issues" className="space-y-4 mt-2">
                      {result.issues.length === 0 ? (
                        <p className="text-sm text-muted-foreground">
                          No issues found in your code.
                        </p>
                      ) : (
                        result.issues.map((issue) => (
                          <div key={issue.id} className="space-y-2">
                            <div className="flex gap-2 items-start">
                              <Badge variant={getSeverityColor(issue.severity)}>
                                {issue.severity}
                              </Badge>
                              <p className="text-sm">{issue.description}</p>
                            </div>
                            {issue.suggestion && (
                              <p className="text-sm text-muted-foreground">
                                <span className="font-medium">Suggestion: </span>
                                {issue.suggestion}
                              </p>
                            )}
                            {issue.code && (
                              <pre className="text-xs bg-slate-100 dark:bg-slate-800 p-2 rounded overflow-x-auto">
                                {issue.code}
                              </pre>
                            )}
                          </div>
                        ))
                      )}
                    </TabsContent>
                    <TabsContent value="suggestions" className="space-y-2">
                      {result.issues.length === 0 ? (
                        <p className="text-sm text-muted-foreground">
                          No suggestions available.
                        </p>
                      ) : (
                        result.issues
                          .filter((issue) => issue.suggestion)
                          .map((issue) => (
                            <div key={issue.id} className="space-y-1">
                              <p className="text-sm font-medium">{issue.description}</p>
                              <p className="text-sm text-muted-foreground">
                                {issue.suggestion}
                              </p>
                              {issue.code && (
                                <pre className="text-xs bg-slate-100 dark:bg-slate-800 p-2 rounded overflow-x-auto">
                                  {issue.code}
                                </pre>
                              )}
                            </div>
                          ))
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-center">
                  <div className="max-w-sm space-y-2">
                    <AlertCircle className="h-8 w-8 mx-auto text-muted-foreground" />
                    <h4 className="font-medium">No Analysis Yet</h4>
                    <p className="text-sm text-muted-foreground">
                      Paste your code and click "Analyze Code" to get insights
                      and suggestions for improvement.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {result && (
              <div className="flex justify-end gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleFeedback("thumbsDown")}
                  className={
                    feedback === "thumbsDown" ? "bg-red-100 dark:bg-red-900" : ""
                  }
                >
                  <ThumbsDown className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleFeedback("thumbsUp")}
                  className={
                    feedback === "thumbsUp"
                      ? "bg-green-100 dark:bg-green-900"
                      : ""
                  }
                >
                  <ThumbsUp className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Whisper>
  );
}