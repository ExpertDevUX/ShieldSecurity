import { ScrollArea } from "@/components/ui/scroll-area";

interface CodeViewerProps {
  code: string;
  language: string;
  issues: Array<{
    type: string;
    description: string;
    lineNumber: number;
    recommendation: string;
  }>;
}

export default function CodeViewer({ code, language, issues }: CodeViewerProps) {
  // Create a map of line numbers with issues
  const issueMap = new Map();
  issues.forEach((issue) => {
    issueMap.set(issue.lineNumber, issue);
  });

  // Split code into lines
  const lines = code.split('\n');

  return (
    <ScrollArea className="h-[500px] w-full">
      <pre className="relative font-mono text-sm bg-secondary/30 p-4 rounded-md">
        <code>
          {lines.map((line, index) => {
            const lineNumber = index + 1;
            const issue = issueMap.get(lineNumber);
            const hasIssue = !!issue;
            
            return (
              <div 
                key={lineNumber} 
                className={`flex ${hasIssue ? 'bg-amber-200/20 dark:bg-amber-900/20 relative' : ''}`}
                title={hasIssue ? `${issue.type}: ${issue.description}` : undefined}
              >
                <span className="inline-block w-8 text-right mr-4 text-muted-foreground select-none">
                  {lineNumber}
                </span>
                <span 
                  className={`flex-1 ${hasIssue ? 'border-l-2 border-amber-500 pl-2' : ''}`}
                >
                  {line.length === 0 ? ' ' : line}
                </span>
                
                {hasIssue && (
                  <div className="absolute right-0 flex items-center justify-center h-full">
                    <span className="h-4 w-4 rounded-full bg-amber-500 text-white flex items-center justify-center text-xs cursor-help mr-2" title={issue.recommendation}>
                      !
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </code>
      </pre>
    </ScrollArea>
  );
}