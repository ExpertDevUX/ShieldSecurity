import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { CodeAnalysisWhisper } from "./CodeAnalysisWhisper";
import { Code, Zap } from "lucide-react";

interface CodeAnalysisButtonProps {
  code?: string;
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  size?: "default" | "sm" | "lg" | "icon";
  label?: string;
  className?: string;
}

export function CodeAnalysisButton({
  code = "",
  variant = "default",
  size = "default",
  label = "Analyze Code",
  className,
}: CodeAnalysisButtonProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button
        variant={variant}
        size={size}
        onClick={() => setIsOpen(true)}
        className={className}
      >
        {size === "icon" ? (
          <Code className="h-4 w-4" />
        ) : (
          <>
            <Code className="mr-2 h-4 w-4" />
            {label}
          </>
        )}
      </Button>

      <CodeAnalysisWhisper
        open={isOpen}
        onClose={() => setIsOpen(false)}
        initialCode={code}
      />
    </>
  );
}