import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { analyzeCode, AIProvider, AI_PROVIDERS } from "@/lib/aiService";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Form validation schema
const codeAnalysisFormSchema = z.object({
  code: z.string().min(5, { message: "Please enter at least 5 characters of code" }),
  language: z.string().min(1, { message: "Please select a programming language" }),
  provider: z.custom<AIProvider>(),
  apiKey: z.string().optional(),
});

type CodeAnalysisFormValues = z.infer<typeof codeAnalysisFormSchema>;

// Available languages
const LANGUAGES = [
  { id: "javascript", name: "JavaScript" },
  { id: "typescript", name: "TypeScript" },
  { id: "python", name: "Python" },
  { id: "java", name: "Java" },
  { id: "csharp", name: "C#" },
  { id: "php", name: "PHP" },
  { id: "ruby", name: "Ruby" },
  { id: "go", name: "Go" },
  { id: "swift", name: "Swift" },
  { id: "rust", name: "Rust" },
  { id: "cpp", name: "C++" },
  { id: "c", name: "C" },
];

interface CodeAnalysisFormProps {
  onAnalysisCompleted: (result: any) => void;
}

export default function CodeAnalysisForm({ onAnalysisCompleted }: CodeAnalysisFormProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [configuredProviders, setConfiguredProviders] = useState<string[]>([]);
  const [loadingProviders, setLoadingProviders] = useState(true);

  // Initialize form with default values
  const form = useForm<CodeAnalysisFormValues>({
    resolver: zodResolver(codeAnalysisFormSchema),
    defaultValues: {
      code: "",
      language: "javascript",
      provider: "mock",
      apiKey: "",
    },
  });

  const selectedProvider = form.watch("provider");
  
  // Check if provider requires API key input
  // Admin can provide API key directly, regular users rely on admin-configured keys
  const isApiKeyRequired = isAdmin && (
    selectedProvider === "openai" || 
    (selectedProvider === "gemini" && !import.meta.env.VITE_GEMINI_API_KEY)
  );

  // Check if the selected provider has been configured by the admin
  const isProviderConfigured = selectedProvider === "mock" || configuredProviders.includes(selectedProvider);

  // Fetch user role and configured API providers on component mount
  useEffect(() => {
    const fetchUserRoleAndProviders = async () => {
      try {
        // Check if user is admin
        const userResponse = await apiRequest<{ isAdmin: boolean }>("/api/auth/check-role", {
          method: "GET"
        }).catch(() => ({ isAdmin: false }));
        
        setIsAdmin(userResponse.isAdmin);
        
        // Get configured providers
        const providersResponse = await apiRequest<{ providers: string[] }>("/api/api-configurations/available-providers", {
          method: "GET"
        }).catch(() => ({ providers: [] }));
        
        setConfiguredProviders(providersResponse.providers || []);
      } catch (error) {
        console.error("Error fetching user role or providers:", error);
      } finally {
        setLoadingProviders(false);
      }
    };
    
    fetchUserRoleAndProviders();
  }, []);

  // Handle form submission
  async function onSubmit(data: CodeAnalysisFormValues) {
    setIsLoading(true);
    
    try {
      // For regular users, if the provider is not configured, show an error
      if (!isAdmin && !isProviderConfigured && data.provider !== "mock") {
        throw new Error("The Provider API not found, please try other API");
      }
      
      // Analyze code using the selected AI provider
      const result = await analyzeCode(data.code, data.language, data.provider, data.apiKey);
      
      // Inform parent component of results
      onAnalysisCompleted({
        ...result,
        code: data.code,
        language: data.language,
        provider: data.provider,
      });
      
      toast({
        title: "Analysis Complete",
        description: `Found ${result.issues.length} issues to review`,
      });
    } catch (error) {
      console.error("Error analyzing code:", error);
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Code Analysis</CardTitle>
        <CardDescription>
          Paste your code below for security and best practices analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="provider"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>AI Provider</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      disabled={isLoading}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select AI provider" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {AI_PROVIDERS.map((provider) => (
                          <SelectItem key={provider.id} value={provider.id}>
                            {provider.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="language"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Programming Language</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      disabled={isLoading}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {LANGUAGES.map((language) => (
                          <SelectItem key={language.id} value={language.id}>
                            {language.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Show API key field only for admins */}
            {isApiKeyRequired && (
              <FormField
                control={form.control}
                name="apiKey"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {selectedProvider === "openai" ? "OpenAI API Key" : "Gemini API Key"}
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder={`Enter your ${selectedProvider === "openai" ? "OpenAI" : "Gemini"} API key`}
                        {...field}
                        type="password"
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {/* Show warning for regular users if provider is not configured */}
            {!isAdmin && !loadingProviders && selectedProvider !== "mock" && !isProviderConfigured && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  The Provider API not found, please try other API
                </AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Code to Analyze</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Paste your code here..." 
                      className="font-mono h-[400px]" 
                      {...field}
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full" 
              disabled={isLoading || (!isAdmin && !isProviderConfigured && selectedProvider !== "mock")}
            >
              {isLoading ? "Analyzing..." : "Analyze Code"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}