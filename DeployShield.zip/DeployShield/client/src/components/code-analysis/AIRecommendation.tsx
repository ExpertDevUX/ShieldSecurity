import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

interface AIRecommendationProps {
  issues: Array<{
    type: string;
    description: string;
    lineNumber: number;
    recommendation: string;
  }>;
  fixedCode: string;
  language: string;
  summary: string;
}

// Get badge variant based on issue type
function getIssueTypeVariant(type: string): "default" | "destructive" | "outline" | "secondary" {
  type = type.toLowerCase();
  
  if (type.includes("security") || type.includes("vulnerability") || type === "high" || type === "critical") {
    return "destructive";
  }
  
  if (type.includes("performance") || type === "medium") {
    return "secondary";
  }
  
  if (type.includes("warning") || type.includes("best") || type.includes("practice") || type === "low") {
    return "outline";
  }
  
  return "default";
}

export default function AIRecommendation({ issues, fixedCode, language, summary }: AIRecommendationProps) {
  const securityIssues = issues.filter(issue => 
    issue.type.toLowerCase().includes("security") || 
    issue.type.toLowerCase().includes("vulnerability") ||
    issue.type.toLowerCase() === "high" ||
    issue.type.toLowerCase() === "critical"
  );
  
  const performanceIssues = issues.filter(issue => 
    issue.type.toLowerCase().includes("performance") || 
    issue.type.toLowerCase() === "medium"
  );
  
  const bestPracticeIssues = issues.filter(issue => 
    issue.type.toLowerCase().includes("best") || 
    issue.type.toLowerCase().includes("practice") ||
    issue.type.toLowerCase() === "low" ||
    issue.type.toLowerCase().includes("warning")
  );
  
  const otherIssues = issues.filter(issue => 
    !securityIssues.includes(issue) && 
    !performanceIssues.includes(issue) && 
    !bestPracticeIssues.includes(issue)
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Analysis Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="leading-7">{summary}</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Issue Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Security Issues</span>
                <Badge variant="destructive">{securityIssues.length}</Badge>
              </div>
              
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Performance Issues</span>
                <Badge variant="secondary">{performanceIssues.length}</Badge>
              </div>
              
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Best Practice Issues</span>
                <Badge variant="outline">{bestPracticeIssues.length}</Badge>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="font-medium">Other Issues</span>
                <Badge variant="default">{otherIssues.length}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Severity Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col h-full justify-center">
              <div className="h-8 w-full flex rounded-md overflow-hidden mb-4">
                {securityIssues.length > 0 && (
                  <div 
                    className="bg-destructive h-full" 
                    style={{ width: `${(securityIssues.length / issues.length) * 100}%` }}
                    title={`Security: ${securityIssues.length}`}
                  />
                )}
                {performanceIssues.length > 0 && (
                  <div 
                    className="bg-secondary h-full" 
                    style={{ width: `${(performanceIssues.length / issues.length) * 100}%` }}
                    title={`Performance: ${performanceIssues.length}`}
                  />
                )}
                {bestPracticeIssues.length > 0 && (
                  <div 
                    className="bg-muted h-full" 
                    style={{ width: `${(bestPracticeIssues.length / issues.length) * 100}%` }}
                    title={`Best Practices: ${bestPracticeIssues.length}`}
                  />
                )}
                {otherIssues.length > 0 && (
                  <div 
                    className="bg-primary h-full" 
                    style={{ width: `${(otherIssues.length / issues.length) * 100}%` }}
                    title={`Other: ${otherIssues.length}`}
                  />
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-destructive rounded-sm mr-2" />
                  <span>Security</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-secondary rounded-sm mr-2" />
                  <span>Performance</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-muted rounded-sm mr-2" />
                  <span>Best Practices</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-primary rounded-sm mr-2" />
                  <span>Other</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Detailed Issues</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" className="w-full">
            {issues.map((issue, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">
                  <div className="flex items-center gap-2">
                    <Badge variant={getIssueTypeVariant(issue.type)}>{issue.type}</Badge>
                    <span>Line {issue.lineNumber}: {issue.description}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="pl-4 border-l-2 border-muted-foreground/20 ml-2 mt-2">
                    <h4 className="text-sm font-medium mb-2">Recommendation:</h4>
                    <p className="text-sm text-muted-foreground">{issue.recommendation}</p>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}