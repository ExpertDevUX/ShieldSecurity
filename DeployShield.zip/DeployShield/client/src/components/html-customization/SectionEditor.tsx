import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileCode, Layout, Info } from 'lucide-react';

interface SectionEditorProps {
  content: string;
  onChange: (content: string) => void;
  section: string;
}

export default function SectionEditor({ content, onChange, section }: SectionEditorProps) {
  const [mode, setMode] = useState<'html' | 'visual'>('html');
  
  // Extract the specified section from the HTML content
  const extractSection = (): string => {
    if (!content) return '';
    
    if (section === 'full') {
      return content;
    }
    
    try {
      if (section === 'header') {
        const headerMatch = content.match(/<header[^>]*>([\s\S]*?)<\/header>/i);
        return headerMatch ? headerMatch[0] : '';
      } else if (section === 'footer') {
        const footerMatch = content.match(/<footer[^>]*>([\s\S]*?)<\/footer>/i);
        return footerMatch ? footerMatch[0] : '';
      } else if (section === 'main') {
        const mainMatch = content.match(/<main[^>]*>([\s\S]*?)<\/main>/i);
        if (mainMatch) {
          return mainMatch[0];
        } else {
          // Try to get body content excluding header and footer
          const bodyMatch = content.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
          if (bodyMatch) {
            let bodyContent = bodyMatch[1];
            const headerMatch = bodyContent.match(/<header[^>]*>([\s\S]*?)<\/header>/i);
            if (headerMatch) {
              bodyContent = bodyContent.replace(headerMatch[0], '');
            }
            const footerMatch = bodyContent.match(/<footer[^>]*>([\s\S]*?)<\/footer>/i);
            if (footerMatch) {
              bodyContent = bodyContent.replace(footerMatch[0], '');
            }
            return bodyContent.trim();
          }
        }
      }
    } catch (error) {
      console.error('Error extracting section:', error);
    }
    
    return '';
  };
  
  // Update the section in the full HTML content
  const updateSectionInHtml = (sectionContent: string): string => {
    if (section === 'full') {
      return sectionContent;
    }
    
    let updatedHtml = content;
    
    try {
      if (section === 'header') {
        const headerMatch = updatedHtml.match(/<header[^>]*>([\s\S]*?)<\/header>/i);
        if (headerMatch) {
          updatedHtml = updatedHtml.replace(headerMatch[0], sectionContent);
        }
      } else if (section === 'footer') {
        const footerMatch = updatedHtml.match(/<footer[^>]*>([\s\S]*?)<\/footer>/i);
        if (footerMatch) {
          updatedHtml = updatedHtml.replace(footerMatch[0], sectionContent);
        }
      } else if (section === 'main') {
        const mainMatch = updatedHtml.match(/<main[^>]*>([\s\S]*?)<\/main>/i);
        if (mainMatch) {
          updatedHtml = updatedHtml.replace(mainMatch[0], sectionContent);
        } else {
          // Try to replace content between header and footer
          const bodyMatch = updatedHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
          if (bodyMatch) {
            let bodyContent = bodyMatch[1];
            const headerMatch = bodyContent.match(/<header[^>]*>([\s\S]*?)<\/header>/i);
            const footerMatch = bodyContent.match(/<footer[^>]*>([\s\S]*?)<\/footer>/i);
            
            if (headerMatch && footerMatch) {
              const newBodyContent = headerMatch[0] + sectionContent + footerMatch[0];
              updatedHtml = updatedHtml.replace(bodyMatch[0], `<body>${newBodyContent}</body>`);
            }
          }
        }
      }
    } catch (error) {
      console.error('Error updating section:', error);
    }
    
    return updatedHtml;
  };

  // Handle HTML section edit
  const handleHtmlChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newSectionContent = e.target.value;
    const updatedHtml = updateSectionInHtml(newSectionContent);
    onChange(updatedHtml);
  };
  
  return (
    <Tabs defaultValue="html" onValueChange={(value) => setMode(value as 'html' | 'visual')}>
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="html">
          <FileCode className="mr-2 h-4 w-4" />
          HTML Code
        </TabsTrigger>
        <TabsTrigger value="visual">
          <Layout className="mr-2 h-4 w-4" />
          Visual Editor
        </TabsTrigger>
      </TabsList>
      
      <TabsContent value="html" className="space-y-4 mt-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            {section === 'full' 
              ? 'Editing the full HTML document' 
              : `Editing the ${section} section of the HTML document`}
          </AlertDescription>
        </Alert>
        <Textarea
          className="min-h-[300px] font-mono"
          value={extractSection()}
          onChange={handleHtmlChange}
        />
      </TabsContent>
      
      <TabsContent value="visual" className="space-y-4 mt-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            Visual editor is now available for all editable sections.
          </AlertDescription>
        </Alert>
      </TabsContent>
    </Tabs>
  );
}