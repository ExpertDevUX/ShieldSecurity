import React, { useState, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Edit, Save, Trash2, Copy, Plus, MoveVertical } from 'lucide-react';

// Simple HTML elements that can be edited
interface EditableElement {
  id: string;
  type: 'heading' | 'paragraph' | 'image' | 'button' | 'link' | 'divider' | 'container';
  content: string;
  attributes?: { [key: string]: string };
  children?: EditableElement[];
}

interface DragDropEditorProps {
  content: string;
  onChange: (content: string) => void;
}

// Parse HTML content into editable elements
const parseHtml = (html: string): EditableElement[] => {
  // This is a very simplified parsing logic
  // In a real implementation, you'd use a proper HTML parser
  
  const elements: EditableElement[] = [];
  let id = 0;
  
  // Extract common elements with regex (very basic implementation)
  // Headings
  const headingMatches = html.match(/<h[1-6][^>]*>(.*?)<\/h[1-6]>/gi) || [];
  headingMatches.forEach(match => {
    const content = match.replace(/<\/?h[1-6][^>]*>/gi, '');
    elements.push({
      id: `element-${id++}`,
      type: 'heading',
      content: content,
      attributes: { level: match.match(/<h([1-6])/i)?.[1] || '1' }
    });
  });
  
  // Paragraphs
  const paragraphMatches = html.match(/<p[^>]*>(.*?)<\/p>/gi) || [];
  paragraphMatches.forEach(match => {
    const content = match.replace(/<\/?p[^>]*>/gi, '');
    elements.push({
      id: `element-${id++}`,
      type: 'paragraph',
      content: content
    });
  });
  
  // Images
  const imageMatches = html.match(/<img[^>]*>/gi) || [];
  imageMatches.forEach(match => {
    const src = match.match(/src="([^"]*)"/i)?.[1] || '';
    const alt = match.match(/alt="([^"]*)"/i)?.[1] || '';
    elements.push({
      id: `element-${id++}`,
      type: 'image',
      content: '',
      attributes: { src, alt }
    });
  });
  
  // Buttons
  const buttonMatches = html.match(/<button[^>]*>(.*?)<\/button>/gi) || [];
  buttonMatches.forEach(match => {
    const content = match.replace(/<\/?button[^>]*>/gi, '');
    elements.push({
      id: `element-${id++}`,
      type: 'button',
      content: content
    });
  });
  
  // If no elements were found or html is too complex, fallback to a single paragraph
  if (elements.length === 0 && html.trim()) {
    elements.push({
      id: `element-${id++}`,
      type: 'paragraph',
      content: 'Use the visual editor to add content elements'
    });
  }
  
  return elements;
};

// Generate HTML from editable elements
const generateHtml = (elements: EditableElement[]): string => {
  return elements.map(element => {
    switch (element.type) {
      case 'heading': {
        const level = element.attributes?.level || '2';
        return `<h${level}>${element.content}</h${level}>`;
      }
      case 'paragraph':
        return `<p>${element.content}</p>`;
      case 'image': {
        const src = element.attributes?.src || '';
        const alt = element.attributes?.alt || '';
        return `<img src="${src}" alt="${alt}" />`;
      }
      case 'button':
        return `<button class="btn">${element.content}</button>`;
      case 'link': {
        const href = element.attributes?.href || '#';
        return `<a href="${href}">${element.content}</a>`;
      }
      case 'divider':
        return '<hr />';
      case 'container': {
        const children = element.children ? generateHtml(element.children) : '';
        return `<div class="container">${children}</div>`;
      }
      default:
        return '';
    }
  }).join('\n');
};

export default function DragDropEditor({ content, onChange }: DragDropEditorProps) {
  const [mode, setMode] = useState<'visual' | 'code'>('visual');
  const [elements, setElements] = useState<EditableElement[]>([]);
  
  // Initialize on content change
  useEffect(() => {
    if (content) {
      setElements(parseHtml(content));
    }
  }, [content]);
  
  // Handle manual HTML edits
  const handleCodeChange = (newCode: string) => {
    onChange(newCode);
  };
  
  // Handle drag and drop reordering
  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    const items = Array.from(elements);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    setElements(items);
    onChange(generateHtml(items));
  };
  
  // Handle element content editing
  const handleElementChange = (id: string, updatedElement: Partial<EditableElement>) => {
    const updatedElements = elements.map(element => {
      if (element.id === id) {
        return { ...element, ...updatedElement };
      }
      return element;
    });
    
    setElements(updatedElements);
    onChange(generateHtml(updatedElements));
  };
  
  // Add a new element
  const addElement = (type: EditableElement['type']) => {
    const newElement: EditableElement = {
      id: `element-${Date.now()}`,
      type,
      content: type === 'heading' ? 'New Heading' : 
              type === 'paragraph' ? 'New paragraph text' : 
              type === 'button' ? 'Click me' : 
              type === 'link' ? 'Link text' : '',
      attributes: type === 'heading' ? { level: '2' } :
                 type === 'image' ? { src: '/placeholder.jpg', alt: 'Image description' } :
                 type === 'link' ? { href: '#' } : {}
    };
    
    const updatedElements = [...elements, newElement];
    setElements(updatedElements);
    onChange(generateHtml(updatedElements));
  };
  
  // Delete an element
  const deleteElement = (id: string) => {
    const updatedElements = elements.filter(element => element.id !== id);
    setElements(updatedElements);
    onChange(generateHtml(updatedElements));
  };
  
  // Duplicate an element
  const duplicateElement = (id: string) => {
    const elementToDuplicate = elements.find(element => element.id === id);
    if (!elementToDuplicate) return;
    
    const duplicatedElement = {
      ...elementToDuplicate,
      id: `element-${Date.now()}`
    };
    
    const elementIndex = elements.findIndex(element => element.id === id);
    const updatedElements = [
      ...elements.slice(0, elementIndex + 1),
      duplicatedElement,
      ...elements.slice(elementIndex + 1)
    ];
    
    setElements(updatedElements);
    onChange(generateHtml(updatedElements));
  };
  
  return (
    <Tabs defaultValue="visual" onValueChange={(value) => setMode(value as 'visual' | 'code')}>
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="visual">
          <Edit className="w-4 h-4 mr-2" />
          Visual Editor
        </TabsTrigger>
        <TabsTrigger value="code">
          <Edit className="w-4 h-4 mr-2" />
          Code Editor
        </TabsTrigger>
      </TabsList>
      
      <TabsContent value="visual" className="mt-4">
        <div className="mb-4 flex justify-between items-center">
          <div>
            <h3 className="text-lg font-medium">Add Elements</h3>
            <div className="flex space-x-2 mt-2">
              <Button variant="outline" size="sm" onClick={() => addElement('heading')}>Heading</Button>
              <Button variant="outline" size="sm" onClick={() => addElement('paragraph')}>Paragraph</Button>
              <Button variant="outline" size="sm" onClick={() => addElement('image')}>Image</Button>
              <Button variant="outline" size="sm" onClick={() => addElement('button')}>Button</Button>
              <Button variant="outline" size="sm" onClick={() => addElement('link')}>Link</Button>
              <Button variant="outline" size="sm" onClick={() => addElement('divider')}>Divider</Button>
            </div>
          </div>
        </div>
        
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="elements">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="space-y-4"
              >
                {elements.map((element, index) => (
                  <Draggable key={element.id} draggableId={element.id} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className="border rounded-md p-4 bg-white"
                      >
                        <div className="flex justify-between items-center mb-2">
                          <div className="font-medium capitalize flex items-center">
                            <span {...provided.dragHandleProps}>
                              <MoveVertical className="w-5 h-5 mr-2 cursor-move" />
                            </span>
                            {element.type}
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => duplicateElement(element.id)}>
                              <Copy className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => deleteElement(element.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        
                        {/* Element-specific editor */}
                        {element.type === 'heading' && (
                          <div className="space-y-2">
                            <div className="grid grid-cols-4 gap-4">
                              <div className="col-span-3">
                                <Label htmlFor={`heading-${element.id}`}>Text</Label>
                                <Input
                                  id={`heading-${element.id}`}
                                  value={element.content}
                                  onChange={(e) => handleElementChange(element.id, { content: e.target.value })}
                                />
                              </div>
                              <div>
                                <Label htmlFor={`heading-level-${element.id}`}>Level</Label>
                                <select
                                  id={`heading-level-${element.id}`}
                                  className="w-full rounded-md border border-input px-3 py-2"
                                  value={element.attributes?.level || '2'}
                                  onChange={(e) => handleElementChange(element.id, { 
                                    attributes: { ...element.attributes, level: e.target.value } 
                                  })}
                                >
                                  <option value="1">H1</option>
                                  <option value="2">H2</option>
                                  <option value="3">H3</option>
                                  <option value="4">H4</option>
                                  <option value="5">H5</option>
                                  <option value="6">H6</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        )}
                        
                        {element.type === 'paragraph' && (
                          <div className="space-y-2">
                            <Label htmlFor={`paragraph-${element.id}`}>Text</Label>
                            <Textarea
                              id={`paragraph-${element.id}`}
                              value={element.content}
                              onChange={(e) => handleElementChange(element.id, { content: e.target.value })}
                              rows={3}
                            />
                          </div>
                        )}
                        
                        {element.type === 'image' && (
                          <div className="space-y-2">
                            <div className="grid grid-cols-1 gap-4 mb-2">
                              <div>
                                <Label htmlFor={`image-src-${element.id}`}>Image URL</Label>
                                <Input
                                  id={`image-src-${element.id}`}
                                  value={element.attributes?.src || ''}
                                  onChange={(e) => handleElementChange(element.id, { 
                                    attributes: { ...element.attributes, src: e.target.value } 
                                  })}
                                />
                              </div>
                              <div>
                                <Label htmlFor={`image-alt-${element.id}`}>Alt Text</Label>
                                <Input
                                  id={`image-alt-${element.id}`}
                                  value={element.attributes?.alt || ''}
                                  onChange={(e) => handleElementChange(element.id, { 
                                    attributes: { ...element.attributes, alt: e.target.value } 
                                  })}
                                />
                              </div>
                            </div>
                            {element.attributes?.src && (
                              <div className="mt-2 border rounded-md p-2">
                                <img 
                                  src={element.attributes.src} 
                                  alt={element.attributes.alt || ''} 
                                  className="max-w-full h-auto max-h-24 mx-auto"
                                />
                              </div>
                            )}
                          </div>
                        )}
                        
                        {element.type === 'button' && (
                          <div className="space-y-2">
                            <Label htmlFor={`button-${element.id}`}>Button Text</Label>
                            <Input
                              id={`button-${element.id}`}
                              value={element.content}
                              onChange={(e) => handleElementChange(element.id, { content: e.target.value })}
                            />
                            <div className="mt-2">
                              <Button variant="secondary" size="sm" className="opacity-70 pointer-events-none mt-2">
                                {element.content || 'Button'}
                              </Button>
                            </div>
                          </div>
                        )}
                        
                        {element.type === 'link' && (
                          <div className="space-y-2">
                            <div className="grid grid-cols-1 gap-4 mb-2">
                              <div>
                                <Label htmlFor={`link-text-${element.id}`}>Link Text</Label>
                                <Input
                                  id={`link-text-${element.id}`}
                                  value={element.content}
                                  onChange={(e) => handleElementChange(element.id, { content: e.target.value })}
                                />
                              </div>
                              <div>
                                <Label htmlFor={`link-href-${element.id}`}>URL</Label>
                                <Input
                                  id={`link-href-${element.id}`}
                                  value={element.attributes?.href || '#'}
                                  onChange={(e) => handleElementChange(element.id, { 
                                    attributes: { ...element.attributes, href: e.target.value } 
                                  })}
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
                
                {elements.length === 0 && (
                  <div className="text-center p-8 border-2 border-dashed rounded-md">
                    <p className="text-gray-500 mb-4">No content elements yet</p>
                    <Button onClick={() => addElement('paragraph')}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Element
                    </Button>
                  </div>
                )}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </TabsContent>
      
      <TabsContent value="code">
        <div className="space-y-4">
          <Textarea
            placeholder="Enter HTML code here"
            className="min-h-[300px] font-mono"
            value={content}
            onChange={(e) => handleCodeChange(e.target.value)}
          />
        </div>
      </TabsContent>
    </Tabs>
  );
}