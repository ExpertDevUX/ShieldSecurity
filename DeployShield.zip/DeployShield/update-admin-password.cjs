const { Pool } = require('pg');
const crypto = require('crypto');
const { promisify } = require('util');

// Promisify scrypt
const scryptAsync = promisify(crypto.scrypt);

// Hash password with salt (same implementation as in auth.ts)
async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}

async function updateAdminPassword() {
  try {
    // Create a connection to the database
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL
    });

    // Admin user details
    const username = 'admin';
    const password = 'admin123';
    
    // Check if user already exists
    const existingUser = await pool.query(
      'SELECT * FROM users WHERE username = $1',
      [username]
    );
    
    if (existingUser.rows.length === 0) {
      console.log('Admin user does not exist');
      await pool.end();
      return;
    }

    // Hash the password using the same method as in auth.ts
    const passwordHash = await hashPassword(password);
    
    // Update the admin user's password
    const result = await pool.query(
      `UPDATE users SET password_hash = $1 WHERE username = $2 RETURNING *`,
      [passwordHash, username]
    );

    console.log('Admin password updated successfully:', result.rows[0].username);
    
    // Close pool connection
    await pool.end();
  } catch (error) {
    console.error('Error updating admin password:', error);
  }
}

// Self-executing async function
(async () => {
  await updateAdminPassword();
  process.exit(0);
})();