import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, pgEnum, decimal, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Tutorial difficulty enum
export const tutorialDifficultyEnum = pgEnum("tutorial_difficulty", ["beginner", "intermediate", "advanced"]);

// Projects
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  repository: text("repository").notNull(),
  language: text("language").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
});

// Security Scans
export const securityScans = pgTable("security_scans", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  scanDate: timestamp("scan_date").notNull().defaultNow(),
  highSeverity: integer("high_severity").notNull().default(0),
  mediumSeverity: integer("medium_severity").notNull().default(0),
  lowSeverity: integer("low_severity").notNull().default(0),
  status: text("status").notNull(),
});

export const insertSecurityScanSchema = createInsertSchema(securityScans).omit({
  id: true,
  scanDate: true,
});

// Vulnerabilities
export const vulnerabilities = pgTable("vulnerabilities", {
  id: serial("id").primaryKey(),
  scanId: integer("scan_id").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull(),
  codeSnippet: text("code_snippet"),
  recommendation: text("recommendation"),
  filePath: text("file_path"),
  lineNumber: integer("line_number"),
  fixed: boolean("fixed").default(false),
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilities).omit({
  id: true,
});

// Deployments
export const deployments = pgTable("deployments", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  deploymentDate: timestamp("deployment_date").notNull().defaultNow(),
  target: text("target").notNull(),
  status: text("status").notNull(),
  logs: text("logs"),
});

export const insertDeploymentSchema = createInsertSchema(deployments).omit({
  id: true,
  deploymentDate: true,
});

// SEO Analyses
export const seoAnalyses = pgTable("seo_analyses", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  score: integer("score"),
  analysisDate: timestamp("analysis_date").notNull().defaultNow(),
  report: jsonb("report"),
});

export const insertSeoAnalysisSchema = createInsertSchema(seoAnalyses).omit({
  id: true,
  analysisDate: true,
});

// Pen Tests
export const penTests = pgTable("pen_tests", {
  id: serial("id").primaryKey(),
  target: text("target").notNull(),
  testDate: timestamp("test_date").notNull().defaultNow(),
  findings: jsonb("findings"),
  score: integer("score"),
});

export const insertPenTestSchema = createInsertSchema(penTests).omit({
  id: true,
  testDate: true,
});

// Traffic Boosts
export const trafficBoosts = pgTable("traffic_boosts", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  startDate: timestamp("start_date").notNull().defaultNow(),
  endDate: timestamp("end_date"),
  status: text("status").notNull().default("pending"),
  proxyAmount: integer("proxy_amount").notNull(),
  duration: integer("duration").notNull(), // in minutes
  settings: jsonb("settings"),
});

export const insertTrafficBoostSchema = createInsertSchema(trafficBoosts).omit({
  id: true,
  startDate: true,
  endDate: true,
});

// Page Speed Analyses
export const pageSpeedAnalyses = pgTable("page_speed_analyses", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  analysisDate: timestamp("analysis_date").notNull().defaultNow(),
  score: integer("score").notNull(),
  deviceType: text("device_type").notNull().default("mobile"),
  metrics: jsonb("metrics").notNull(),
});

export const insertPageSpeedAnalysisSchema = createInsertSchema(pageSpeedAnalyses).omit({
  id: true,
  analysisDate: true,
});

// URL Scans
export const urlScans = pgTable("url_scans", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  scanDate: timestamp("scan_date").notNull().defaultNow(),
  security: jsonb("security"),
  seo: jsonb("seo"),
  performance: jsonb("performance"),
});

export const insertUrlScanSchema = createInsertSchema(urlScans).omit({
  id: true,
  scanDate: true,
});

// Tasks for progress tracking
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  status: text("status").notNull().default("pending"),
  progress: integer("progress").notNull().default(0),
  projectId: integer("project_id"),
  dueDate: timestamp("due_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

// Export types
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type SecurityScan = typeof securityScans.$inferSelect;
export type InsertSecurityScan = z.infer<typeof insertSecurityScanSchema>;

export type Vulnerability = typeof vulnerabilities.$inferSelect;
export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;

export type Deployment = typeof deployments.$inferSelect;
export type InsertDeployment = z.infer<typeof insertDeploymentSchema>;

export type SEOAnalysis = typeof seoAnalyses.$inferSelect;
export type InsertSEOAnalysis = z.infer<typeof insertSeoAnalysisSchema>;

export type PenTest = typeof penTests.$inferSelect;
export type InsertPenTest = z.infer<typeof insertPenTestSchema>;

export type TrafficBoost = typeof trafficBoosts.$inferSelect;
export type InsertTrafficBoost = z.infer<typeof insertTrafficBoostSchema>;

export type PageSpeedAnalysis = typeof pageSpeedAnalyses.$inferSelect;
export type InsertPageSpeedAnalysis = z.infer<typeof insertPageSpeedAnalysisSchema>;

export type UrlScan = typeof urlScans.$inferSelect;
export type InsertUrlScan = z.infer<typeof insertUrlScanSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

// User Role Enum
export const userRoleEnum = pgEnum('user_role', ['admin', 'user', 'developer']);
export const userStatusEnum = pgEnum('user_status', ['active', 'inactive', 'banned']);

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: userRoleEnum("role").notNull().default('user'),
  status: userStatusEnum("status").notNull().default('active'),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastLogin: timestamp("last_login"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

// API Configurations for various third-party services
export const apiConfigurations = pgTable("api_configurations", {
  id: serial("id").primaryKey(),
  provider: varchar("provider", { length: 50 }).notNull(), // e.g., 'render', 'syndica'
  apiKey: text("api_key").notNull(),
  baseUrl: text("base_url"),
  isActive: boolean("is_active").notNull().default(true),
  settings: jsonb("settings"), // Additional provider-specific settings
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertApiConfigurationSchema = createInsertSchema(apiConfigurations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Deployment Providers
export const deploymentProviders = pgTable("deployment_providers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(), // e.g., 'render', 'syndica', 'custom'
  apiConfigId: integer("api_config_id").references(() => apiConfigurations.id),
  isActive: boolean("is_active").notNull().default(true),
  settings: jsonb("settings"), // Provider-specific deployment settings
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertDeploymentProviderSchema = createInsertSchema(deploymentProviders).omit({
  id: true,
  createdAt: true,
});

// Export user types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Export API configuration types
export type ApiConfiguration = typeof apiConfigurations.$inferSelect;
export type InsertApiConfiguration = z.infer<typeof insertApiConfigurationSchema>;

// Two Factor Authentication
export const twoFactorAuth = pgTable("two_factor_auth", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  secret: text("secret").notNull(),
  verified: boolean("verified").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertTwoFactorAuthSchema = createInsertSchema(twoFactorAuth).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Export deployment provider types
export type DeploymentProvider = typeof deploymentProviders.$inferSelect;
export type InsertDeploymentProvider = z.infer<typeof insertDeploymentProviderSchema>;

// Export two-factor auth types
export type TwoFactorAuth = typeof twoFactorAuth.$inferSelect;
export type InsertTwoFactorAuth = z.infer<typeof insertTwoFactorAuthSchema>;

// Notifications
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'info', 'warning', 'success', 'error'
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

// Payment Plans
export const paymentPlanEnum = pgEnum('payment_plan', ['free', 'basic', 'pro', 'enterprise']);

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  plan: paymentPlanEnum("plan").notNull().default('free'),
  status: text("status").notNull(), // 'active', 'canceled', 'expired'
  startDate: timestamp("start_date").notNull().defaultNow(),
  endDate: timestamp("end_date"),
  paymentMethod: text("payment_method"),
  paymentId: text("payment_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  currency: text("currency").default("USD"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;

// Payment Transactions
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  subscriptionId: integer("subscription_id").references(() => subscriptions.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("USD"),
  status: text("status").notNull(), // 'pending', 'completed', 'failed', 'refunded'
  paymentMethod: text("payment_method").notNull(), // 'paypal', 'credit_card', etc.
  paymentId: text("payment_id"), // External payment reference ID
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

// User Template Settings
export const userTemplateTypes = pgEnum('user_template_type', ['user', 'developer', 'manager']);

export const templateSettings = pgTable("template_settings", {
  id: serial("id").primaryKey(),
  type: userTemplateTypes("type").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  features: jsonb("features").notNull(), // Array of feature access controls
  permissions: jsonb("permissions").notNull(), // Permissions matrix
  uiSettings: jsonb("ui_settings").notNull(), // UI customization settings
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  isDefault: boolean("is_default").notNull().default(false),
  createdBy: integer("created_by").notNull().references(() => users.id),
});

export const insertTemplateSettingsSchema = createInsertSchema(templateSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type TemplateSettings = typeof templateSettings.$inferSelect;
export type InsertTemplateSettings = z.infer<typeof insertTemplateSettingsSchema>;

// Performance Optimizations
export const performanceOptimizationTypeEnum = pgEnum('performance_optimization_type', [
  'image', 'css', 'javascript', 'caching', 'server', 'database', 'cdn', 'compression'
]);

export const performanceOptimizationStatusEnum = pgEnum('performance_optimization_status', [
  'pending', 'in_progress', 'completed', 'failed'
]);

export const performanceOptimizations = pgTable("performance_optimizations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  status: performanceOptimizationStatusEnum("status").notNull().default('pending'),
  optimizationTypes: text("optimization_types").array().notNull(),
  results: jsonb("results"),
  beforeScore: integer("before_score"),
  afterScore: integer("after_score"),
  recommendations: jsonb("recommendations"),
  appliedChanges: jsonb("applied_changes"),
});

export const insertPerformanceOptimizationSchema = createInsertSchema(performanceOptimizations).omit({
  id: true,
  createdAt: true,
  completedAt: true,
  results: true,
  afterScore: true,
  appliedChanges: true,
});

export type PerformanceOptimization = typeof performanceOptimizations.$inferSelect;
export type InsertPerformanceOptimization = z.infer<typeof insertPerformanceOptimizationSchema>;

// 1. AI-Powered Code Generation (Feature 1)
export const codeGenerationTypeEnum = pgEnum('code_generation_type', [
  'component', 'function', 'api', 'schema', 'test', 'refactor', 'optimization', 'custom'
]);

export const codeGenerations = pgTable("code_generations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  userId: integer("user_id").notNull().references(() => users.id),
  type: codeGenerationTypeEnum("type").notNull(),
  prompt: text("prompt").notNull(),
  result: text("result"),
  language: text("language").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  aiProvider: text("ai_provider").notNull(), // 'openai', 'gemini', 'mock', etc.
  metadata: jsonb("metadata"),
  rating: integer("rating"), // User rating of the generated code
  usedInProject: boolean("used_in_project").default(false),
});

export const insertCodeGenerationSchema = createInsertSchema(codeGenerations).omit({
  id: true,
  createdAt: true,
  result: true,
});

export type CodeGeneration = typeof codeGenerations.$inferSelect;
export type InsertCodeGeneration = z.infer<typeof insertCodeGenerationSchema>;

// 2. Real-time Collaboration (Feature 2)
export const collaborationSessionStatusEnum = pgEnum('collaboration_session_status', [
  'active', 'paused', 'completed', 'canceled'
]);

export const collaborationSessions = pgTable("collaboration_sessions", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  name: text("name").notNull(),
  status: collaborationSessionStatusEnum("status").notNull().default('active'),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  metadata: jsonb("metadata"),
  createdBy: integer("created_by").notNull().references(() => users.id),
});

export const insertCollaborationSessionSchema = createInsertSchema(collaborationSessions).omit({
  id: true,
  startTime: true,
  endTime: true,
});

export type CollaborationSession = typeof collaborationSessions.$inferSelect;
export type InsertCollaborationSession = z.infer<typeof insertCollaborationSessionSchema>;

export const collaborationParticipants = pgTable("collaboration_participants", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => collaborationSessions.id),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role").notNull().default('viewer'), // 'owner', 'editor', 'viewer'
  joinTime: timestamp("join_time").notNull().defaultNow(),
  leaveTime: timestamp("leave_time"),
  active: boolean("active").notNull().default(true),
});

export const insertCollaborationParticipantSchema = createInsertSchema(collaborationParticipants).omit({
  id: true,
  joinTime: true,
  leaveTime: true,
});

export type CollaborationParticipant = typeof collaborationParticipants.$inferSelect;
export type InsertCollaborationParticipant = z.infer<typeof insertCollaborationParticipantSchema>;

export const collaborationMessages = pgTable("collaboration_messages", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => collaborationSessions.id),
  userId: integer("user_id").notNull().references(() => users.id),
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  type: text("type").notNull().default('chat'), // 'chat', 'code', 'system'
  metadata: jsonb("metadata"),
});

export const insertCollaborationMessageSchema = createInsertSchema(collaborationMessages).omit({
  id: true,
  timestamp: true,
});

export type CollaborationMessage = typeof collaborationMessages.$inferSelect;
export type InsertCollaborationMessage = z.infer<typeof insertCollaborationMessageSchema>;

// 3. Deployment Rollback and Version Control (Feature 3)
export const deploymentVersions = pgTable("deployment_versions", {
  id: serial("id").primaryKey(),
  deploymentId: integer("deployment_id").notNull().references(() => deployments.id),
  version: text("version").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  status: text("status").notNull(), // 'active', 'rolled_back', 'archived'
  metadata: jsonb("metadata"),
  configSnapshot: jsonb("config_snapshot"),
  createdBy: integer("created_by").notNull().references(() => users.id),
});

export const insertDeploymentVersionSchema = createInsertSchema(deploymentVersions).omit({
  id: true,
  timestamp: true,
});

export type DeploymentVersion = typeof deploymentVersions.$inferSelect;
export type InsertDeploymentVersion = z.infer<typeof insertDeploymentVersionSchema>;

export const rollbacks = pgTable("rollbacks", {
  id: serial("id").primaryKey(),
  deploymentId: integer("deployment_id").notNull().references(() => deployments.id),
  fromVersionId: integer("from_version_id").notNull().references(() => deploymentVersions.id),
  toVersionId: integer("to_version_id").notNull().references(() => deploymentVersions.id),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  reason: text("reason"),
  status: text("status").notNull(), // 'success', 'failed', 'in_progress'
  logs: text("logs"),
  initiatedBy: integer("initiated_by").notNull().references(() => users.id),
});

export const insertRollbackSchema = createInsertSchema(rollbacks).omit({
  id: true,
  timestamp: true,
});

export type Rollback = typeof rollbacks.$inferSelect;
export type InsertRollback = z.infer<typeof insertRollbackSchema>;

// 4. Enhanced Security Compliance (Feature 4)
export const complianceTypeEnum = pgEnum('compliance_type', [
  'gdpr', 'hipaa', 'pci_dss', 'sox', 'ccpa', 'iso27001', 'nist', 'custom'
]);

export const complianceScans = pgTable("compliance_scans", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  complianceType: complianceTypeEnum("compliance_type").notNull(),
  scanDate: timestamp("scan_date").notNull().defaultNow(),
  status: text("status").notNull(), // 'pending', 'in_progress', 'completed', 'failed'
  score: integer("score"),
  report: jsonb("report"),
  issues: jsonb("issues"),
  recommendations: jsonb("recommendations"),
  initiatedBy: integer("initiated_by").notNull().references(() => users.id),
});

export const insertComplianceScanSchema = createInsertSchema(complianceScans).omit({
  id: true,
  scanDate: true,
  report: true,
  issues: true,
  recommendations: true,
});

export type ComplianceScan = typeof complianceScans.$inferSelect;
export type InsertComplianceScan = z.infer<typeof insertComplianceScanSchema>;

// 5. CI/CD Pipeline Integration (Feature 5)
export const ciCdProviderEnum = pgEnum('ci_cd_provider', [
  'github_actions', 'gitlab_ci', 'jenkins', 'travis_ci', 'circle_ci', 'azure_devops', 'custom'
]);

export const ciCdIntegrations = pgTable("ci_cd_integrations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  provider: ciCdProviderEnum("provider").notNull(),
  name: text("name").notNull(),
  configuration: jsonb("configuration").notNull(),
  webhookUrl: text("webhook_url"),
  apiKey: text("api_key"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  createdBy: integer("created_by").notNull().references(() => users.id),
});

export const insertCiCdIntegrationSchema = createInsertSchema(ciCdIntegrations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type CiCdIntegration = typeof ciCdIntegrations.$inferSelect;
export type InsertCiCdIntegration = z.infer<typeof insertCiCdIntegrationSchema>;

export const ciCdPipelines = pgTable("ci_cd_pipelines", {
  id: serial("id").primaryKey(),
  integrationId: integer("integration_id").notNull().references(() => ciCdIntegrations.id),
  name: text("name").notNull(),
  status: text("status").notNull(), // 'idle', 'running', 'succeeded', 'failed'
  lastRun: timestamp("last_run"),
  configuration: jsonb("configuration").notNull(),
  steps: jsonb("steps"),
  active: boolean("active").notNull().default(true),
});

export const insertCiCdPipelineSchema = createInsertSchema(ciCdPipelines).omit({
  id: true,
  lastRun: true,
});

export type CiCdPipeline = typeof ciCdPipelines.$inferSelect;
export type InsertCiCdPipeline = z.infer<typeof insertCiCdPipelineSchema>;

export const ciCdRuns = pgTable("ci_cd_runs", {
  id: serial("id").primaryKey(),
  pipelineId: integer("pipeline_id").notNull().references(() => ciCdPipelines.id),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  status: text("status").notNull(), // 'running', 'succeeded', 'failed', 'canceled'
  logs: text("logs"),
  triggeredBy: text("triggered_by").notNull(), // 'manual', 'webhook', 'scheduled'
  initiatedBy: integer("initiated_by").references(() => users.id),
  commitHash: text("commit_hash"),
  branch: text("branch"),
});

export const insertCiCdRunSchema = createInsertSchema(ciCdRuns).omit({
  id: true,
  startTime: true,
  endTime: true,
});

export type CiCdRun = typeof ciCdRuns.$inferSelect;
export type InsertCiCdRun = z.infer<typeof insertCiCdRunSchema>;

// 6. Application Performance Monitoring (Feature 6)
export const apmAlertSeverityEnum = pgEnum('apm_alert_severity', [
  'critical', 'high', 'medium', 'low', 'info'
]);

export const apmMetrics = pgTable("apm_metrics", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  metricType: text("metric_type").notNull(), // 'cpu', 'memory', 'latency', 'error_rate', etc.
  value: decimal("value", { precision: 10, scale: 4 }).notNull(),
  unit: text("unit").notNull(), // 'percentage', 'ms', 'count', 'bytes', etc.
  dimensions: jsonb("dimensions"),
  source: text("source"), // 'api', 'agent', 'log_analysis', etc.
});

export const insertApmMetricSchema = createInsertSchema(apmMetrics).omit({
  id: true,
  timestamp: true,
});

export type ApmMetric = typeof apmMetrics.$inferSelect;
export type InsertApmMetric = z.infer<typeof insertApmMetricSchema>;

export const apmAlerts = pgTable("apm_alerts", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: apmAlertSeverityEnum("severity").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  status: text("status").notNull(), // 'active', 'acknowledged', 'resolved'
  metric: text("metric"), // Related metric
  thresholdValue: decimal("threshold_value", { precision: 10, scale: 4 }),
  actualValue: decimal("actual_value", { precision: 10, scale: 4 }),
  resolvedAt: timestamp("resolved_at"),
  resolvedBy: integer("resolved_by").references(() => users.id),
  notificationSent: boolean("notification_sent").default(false),
});

export const insertApmAlertSchema = createInsertSchema(apmAlerts).omit({
  id: true,
  timestamp: true,
  resolvedAt: true,
});

export type ApmAlert = typeof apmAlerts.$inferSelect;
export type InsertApmAlert = z.infer<typeof insertApmAlertSchema>;

// 7. AI-Driven Incident Response (Feature 7)
export const incidentSeverityEnum = pgEnum('incident_severity', [
  'critical', 'high', 'medium', 'low'
]);

export const incidentStatusEnum = pgEnum('incident_status', [
  'detected', 'analyzing', 'mitigating', 'resolved', 'closed'
]);

export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: incidentSeverityEnum("severity").notNull(),
  status: incidentStatusEnum("status").notNull().default('detected'),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at"),
  source: text("source").notNull(), // 'monitoring', 'security_scan', 'user_reported', 'apm'
  affectedComponents: text("affected_components").array(),
  assignedTo: integer("assigned_to").references(() => users.id),
  metadata: jsonb("metadata"),
});

export const insertIncidentSchema = createInsertSchema(incidents).omit({
  id: true,
  detectedAt: true,
  resolvedAt: true,
});

export type Incident = typeof incidents.$inferSelect;
export type InsertIncident = z.infer<typeof insertIncidentSchema>;

export const incidentResponses = pgTable("incident_responses", {
  id: serial("id").primaryKey(),
  incidentId: integer("incident_id").notNull().references(() => incidents.id),
  response: text("response").notNull(),
  aiGenerated: boolean("ai_generated").notNull().default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  status: text("status").notNull(), // 'suggested', 'applied', 'failed', 'rejected'
  appliedAt: timestamp("applied_at"),
  appliedBy: integer("applied_by").references(() => users.id),
  result: text("result"),
});

export const insertIncidentResponseSchema = createInsertSchema(incidentResponses).omit({
  id: true,
  timestamp: true,
  appliedAt: true,
});

export type IncidentResponse = typeof incidentResponses.$inferSelect;
export type InsertIncidentResponse = z.infer<typeof insertIncidentResponseSchema>;

// 8. Multi-Environment Deployment Management (Feature 8)
export const environmentTypeEnum = pgEnum('environment_type', [
  'development', 'staging', 'qa', 'production', 'custom'
]);

export const deploymentEnvironments = pgTable("deployment_environments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  type: environmentTypeEnum("type").notNull(),
  configuration: jsonb("configuration").notNull(),
  variables: jsonb("variables"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  createdBy: integer("created_by").notNull().references(() => users.id),
});

export const insertDeploymentEnvironmentSchema = createInsertSchema(deploymentEnvironments).omit({
  id: true,
  createdAt: true,
});

export type DeploymentEnvironment = typeof deploymentEnvironments.$inferSelect;
export type InsertDeploymentEnvironment = z.infer<typeof insertDeploymentEnvironmentSchema>;

export const environmentDeployments = pgTable("environment_deployments", {
  id: serial("id").primaryKey(),
  environmentId: integer("environment_id").notNull().references(() => deploymentEnvironments.id),
  deploymentId: integer("deployment_id").notNull().references(() => deployments.id),
  status: text("status").notNull(), // 'in_progress', 'completed', 'failed', 'rolled_back'
  deployedAt: timestamp("deployed_at").notNull().defaultNow(),
  deployedBy: integer("deployed_by").notNull().references(() => users.id),
});

export const insertEnvironmentDeploymentSchema = createInsertSchema(environmentDeployments).omit({
  id: true,
  deployedAt: true,
});

export type EnvironmentDeployment = typeof environmentDeployments.$inferSelect;
export type InsertEnvironmentDeployment = z.infer<typeof insertEnvironmentDeploymentSchema>;

// 9. Cost Optimization Analysis (Feature 9)
export const costOptimizationStatusEnum = pgEnum('cost_optimization_status', [
  'pending', 'analyzing', 'completed', 'implementing', 'finished'
]);

export const costOptimizations = pgTable("cost_optimizations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  provider: text("provider").notNull(), // 'aws', 'azure', 'gcp', etc.
  startDate: timestamp("start_date").notNull().defaultNow(),
  endDate: timestamp("end_date"),
  status: costOptimizationStatusEnum("status").notNull().default('pending'),
  currentCost: decimal("current_cost", { precision: 10, scale: 2 }),
  projectedSavings: decimal("projected_savings", { precision: 10, scale: 2 }),
  currency: text("currency").notNull().default('USD'),
  recommendations: jsonb("recommendations"),
  analysis: jsonb("analysis"),
  implementedChanges: jsonb("implemented_changes"),
  initiatedBy: integer("initiated_by").notNull().references(() => users.id),
});

export const insertCostOptimizationSchema = createInsertSchema(costOptimizations).omit({
  id: true,
  startDate: true,
  endDate: true,
  recommendations: true,
  analysis: true,
  implementedChanges: true,
});

export type CostOptimization = typeof costOptimizations.$inferSelect;
export type InsertCostOptimization = z.infer<typeof insertCostOptimizationSchema>;

// AWS Credentials (For Secure Deployment)
export const awsCredentials = pgTable("aws_credentials", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  accessKeyId: text("access_key_id").notNull(),
  secretAccessKey: text("secret_access_key").notNull(),
  region: text("region").notNull().default('us-east-1'),
  isEncrypted: boolean("is_encrypted").notNull().default(true),
  isActive: boolean("is_active").notNull().default(true),
  lastUsed: timestamp("last_used"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertAwsCredentialsSchema = createInsertSchema(awsCredentials).omit({
  id: true,
  lastUsed: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  // Add optional password field for secure credential access
  // This is not stored in the database but used for credential verification
  password: z.string().optional(),
});

export type AwsCredentials = typeof awsCredentials.$inferSelect;
export type InsertAwsCredentials = z.infer<typeof insertAwsCredentialsSchema>;

// Cloud Credentials (Generic for various cloud services)
export const cloudCredentials = pgTable("cloud_credentials", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  provider: text("provider").notNull(), // 'aws', 'azure', 'gcp', etc.
  name: text("name").notNull(),
  credentials: jsonb("credentials").notNull(), // JSON object with credentials
  isEncrypted: boolean("is_encrypted").notNull().default(true),
  passwordHash: text("password_hash"), // Hashed password for accessing encrypted credentials
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCloudCredentialsSchema = createInsertSchema(cloudCredentials).omit({
  id: true,
  createdAt: true,
}).extend({
  // Add password field for credential verification
  // This is not stored directly but hashed first
  password: z.string(),
});

export type CloudCredential = typeof cloudCredentials.$inferSelect;
export type InsertCloudCredential = z.infer<typeof insertCloudCredentialsSchema>;

// 10. Custom Plugin System (Feature 10)
export const pluginStatusEnum = pgEnum('plugin_status', [
  'active', 'inactive', 'error', 'needs_update'
]);

export const plugins = pgTable("plugins", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  version: text("version").notNull(),
  entryPoint: text("entry_point").notNull(),
  author: text("author"),
  status: pluginStatusEnum("status").notNull().default('inactive'),
  configuration: jsonb("configuration"),
  permissions: text("permissions").array(),
  installDate: timestamp("install_date").notNull().defaultNow(),
  lastUpdated: timestamp("last_updated"),
  installedBy: integer("installed_by").notNull().references(() => users.id),
});

export const insertPluginSchema = createInsertSchema(plugins).omit({
  id: true,
  installDate: true,
  lastUpdated: true,
});

export type Plugin = typeof plugins.$inferSelect;
export type InsertPlugin = z.infer<typeof insertPluginSchema>;

export const pluginUsages = pgTable("plugin_usages", {
  id: serial("id").primaryKey(),
  pluginId: integer("plugin_id").notNull().references(() => plugins.id),
  projectId: integer("project_id").notNull().references(() => projects.id),
  enabled: boolean("enabled").notNull().default(true),
  configuration: jsonb("configuration"),
  lastUsed: timestamp("last_used"),
  enabledBy: integer("enabled_by").notNull().references(() => users.id),
  enabledAt: timestamp("enabled_at").notNull().defaultNow(),
});

export const insertPluginUsageSchema = createInsertSchema(pluginUsages).omit({
  id: true,
  lastUsed: true,
  enabledAt: true,
});

export type PluginUsage = typeof pluginUsages.$inferSelect;
export type InsertPluginUsage = z.infer<typeof insertPluginUsageSchema>;

// Define relations between tables
export const projectsRelations = relations(projects, ({ many }) => ({
  securityScans: many(securityScans),
  deployments: many(deployments),
  tasks: many(tasks),
  codeGenerations: many(codeGenerations),
  collaborationSessions: many(collaborationSessions),
  complianceScans: many(complianceScans),
  ciCdIntegrations: many(ciCdIntegrations),
  apmMetrics: many(apmMetrics),
  apmAlerts: many(apmAlerts),
  incidents: many(incidents),
  deploymentEnvironments: many(deploymentEnvironments),
  costOptimizations: many(costOptimizations),
  performanceOptimizations: many(performanceOptimizations),
}));

export const usersRelations = relations(users, ({ many }) => ({
  twoFactorAuth: many(twoFactorAuth),
  notifications: many(notifications),
  subscriptions: many(subscriptions),
  transactions: many(transactions),
  codeGenerations: many(codeGenerations),
  collaborationSessions: many(collaborationSessions, { relationName: "created_sessions" }),
  collaborationParticipants: many(collaborationParticipants),
  collaborationMessages: many(collaborationMessages),
  deploymentVersions: many(deploymentVersions, { relationName: "created_versions" }),
  rollbacks: many(rollbacks, { relationName: "initiated_rollbacks" }),
  complianceScans: many(complianceScans, { relationName: "initiated_compliance_scans" }),
  ciCdIntegrations: many(ciCdIntegrations, { relationName: "created_ci_cd_integrations" }),
  apmAlerts: many(apmAlerts, { relationName: "resolved_alerts" }),
  incidents: many(incidents, { relationName: "assigned_incidents" }),
  incidentResponses: many(incidentResponses, { relationName: "applied_responses" }),
  deploymentEnvironments: many(deploymentEnvironments, { relationName: "created_environments" }),
  environmentDeployments: many(environmentDeployments, { relationName: "deployed_to_environments" }),
  costOptimizations: many(costOptimizations, { relationName: "initiated_cost_optimizations" }),
  plugins: many(plugins, { relationName: "installed_plugins" }),
  pluginUsages: many(pluginUsages, { relationName: "enabled_plugins" }),
}));

export const securityScansRelations = relations(securityScans, ({ one, many }) => ({
  project: one(projects, {
    fields: [securityScans.projectId],
    references: [projects.id],
  }),
  vulnerabilities: many(vulnerabilities),
}));

export const vulnerabilitiesRelations = relations(vulnerabilities, ({ one }) => ({
  securityScan: one(securityScans, {
    fields: [vulnerabilities.scanId],
    references: [securityScans.id],
  }),
}));

export const deploymentsRelations = relations(deployments, ({ one, many }) => ({
  project: one(projects, {
    fields: [deployments.projectId],
    references: [projects.id],
  }),
  versions: many(deploymentVersions),
  rollbacks: many(rollbacks),
  environmentDeployments: many(environmentDeployments),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id],
    relationName: "project_tasks",
  }),
}));

// Interactive Learning Playground - Tutorial System

// Tutorials
export const tutorials = pgTable("tutorials", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  language: text("language").notNull(), // programming language
  difficulty: tutorialDifficultyEnum("difficulty").notNull(),
  estimatedTime: integer("estimated_time").notNull(), // in minutes
  image: text("image"),
  tags: text("tags").array(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  isPublished: boolean("is_published").notNull().default(false),
  totalSteps: integer("total_steps").notNull().default(0),
});

export const insertTutorialSchema = createInsertSchema(tutorials).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  totalSteps: true,
});

export type Tutorial = typeof tutorials.$inferSelect;
export type InsertTutorial = z.infer<typeof insertTutorialSchema>;

// Tutorial Steps
export const tutorialSteps = pgTable("tutorial_steps", {
  id: serial("id").primaryKey(),
  tutorialId: integer("tutorial_id").notNull().references(() => tutorials.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  stepNumber: integer("step_number").notNull(),
  startingCode: text("starting_code"),
  expectedOutput: text("expected_output"),
  hints: jsonb("hints"), // Array of hints for this step
  explanation: text("explanation").notNull(),
  solutions: jsonb("solutions"), // Array of possible solutions
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertTutorialStepSchema = createInsertSchema(tutorialSteps).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type TutorialStep = typeof tutorialSteps.$inferSelect;
export type InsertTutorialStep = z.infer<typeof insertTutorialStepSchema>;

// User Tutorial Progress
export const userTutorialProgress = pgTable("user_tutorial_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  tutorialId: integer("tutorial_id").notNull().references(() => tutorials.id),
  currentStep: integer("current_step").notNull().default(1),
  isCompleted: boolean("is_completed").notNull().default(false),
  completedSteps: integer("completed_steps").array(),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  lastAccessedAt: timestamp("last_accessed_at").notNull().defaultNow(),
});

export const insertUserTutorialProgressSchema = createInsertSchema(userTutorialProgress).omit({
  id: true,
  startedAt: true,
  lastAccessedAt: true,
  completedAt: true,
});

export type UserTutorialProgress = typeof userTutorialProgress.$inferSelect;
export type InsertUserTutorialProgress = z.infer<typeof insertUserTutorialProgressSchema>;

// User Tutorial Step Submissions
export const userStepSubmissions = pgTable("user_step_submissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  tutorialId: integer("tutorial_id").notNull().references(() => tutorials.id),
  stepId: integer("step_id").notNull().references(() => tutorialSteps.id),
  progressId: integer("progress_id").notNull().references(() => userTutorialProgress.id),
  submittedCode: text("submitted_code").notNull(),
  isCorrect: boolean("is_correct").notNull().default(false),
  output: text("output"),
  feedback: text("feedback"),
  hintsUsed: integer("hints_used").notNull().default(0),
  attemptNumber: integer("attempt_number").notNull().default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserStepSubmissionSchema = createInsertSchema(userStepSubmissions).omit({
  id: true,
  createdAt: true,
});

export type UserStepSubmission = typeof userStepSubmissions.$inferSelect;
export type InsertUserStepSubmission = z.infer<typeof insertUserStepSubmissionSchema>;

// Tutorial Relations
export const tutorialsRelations = relations(tutorials, ({ one, many }) => ({
  creator: one(users, {
    fields: [tutorials.createdBy],
    references: [users.id],
  }),
  steps: many(tutorialSteps),
  userProgress: many(userTutorialProgress),
}));

export const tutorialStepsRelations = relations(tutorialSteps, ({ one, many }) => ({
  tutorial: one(tutorials, {
    fields: [tutorialSteps.tutorialId],
    references: [tutorials.id],
  }),
  submissions: many(userStepSubmissions),
}));

export const userTutorialProgressRelations = relations(userTutorialProgress, ({ one, many }) => ({
  user: one(users, {
    fields: [userTutorialProgress.userId],
    references: [users.id],
  }),
  tutorial: one(tutorials, {
    fields: [userTutorialProgress.tutorialId],
    references: [tutorials.id],
  }),
}));

export const userStepSubmissionsRelations = relations(userStepSubmissions, ({ one }) => ({
  user: one(users, {
    fields: [userStepSubmissions.userId],
    references: [users.id],
  }),
  tutorial: one(tutorials, {
    fields: [userStepSubmissions.tutorialId],
    references: [tutorials.id],
  }),
  step: one(tutorialSteps, {
    fields: [userStepSubmissions.stepId],
    references: [tutorialSteps.id],
  }),
  progress: one(userTutorialProgress, {
    fields: [userStepSubmissions.progressId],
    references: [userTutorialProgress.id],
  }),
}));
