const { Pool } = require('pg');
const crypto = require('crypto');
const { promisify } = require('util');

// Promisify scrypt
const scryptAsync = promisify(crypto.scrypt);

// Hash password with salt (same implementation as in auth.ts)
async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}

async function createAdminUser() {
  try {
    // Create a connection to the database
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL
    });

    // Admin user details
    const username = 'admin';
    const email = 'admin@example.com';
    const password = 'admin123';
    
    // Check if user already exists
    const existingUser = await pool.query(
      'SELECT * FROM users WHERE username = $1',
      [username]
    );
    
    if (existingUser.rows.length > 0) {
      console.log('Admin user already exists');
      await pool.end();
      return;
    }

    // Hash the password using the same method as in auth.ts
    const passwordHash = await hashPassword(password);
    
    // Insert new admin user directly with SQL
    const result = await pool.query(
      `INSERT INTO users 
       (username, email, password_hash, role, status, created_at) 
       VALUES ($1, $2, $3, $4, $5, $6) 
       RETURNING *`,
      [username, email, passwordHash, 'admin', 'active', new Date()]
    );

    console.log('Admin user created successfully:', result.rows[0]);
    
    // Close pool connection
    await pool.end();
  } catch (error) {
    console.error('Error creating admin user:', error);
  }
}

// Self-executing async function
(async () => {
  await createAdminUser();
  process.exit(0);
})();