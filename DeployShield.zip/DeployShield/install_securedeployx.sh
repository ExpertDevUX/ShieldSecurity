#!/bin/bash

# SecureDeployX Full Installation Script
# This script installs and sets up the entire SecureDeployX application
# including all requirements and environment configuration

# Text colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Variables
APP_DIR="/opt/securedeployx"
DATA_DIR="/var/lib/securedeployx"
USER="securedeployx"
LOG_DIR="/var/log/securedeployx"
ENV_FILE="$APP_DIR/.env"
NGINX_CONF="/etc/nginx/sites-available/securedeployx.conf"
SERVICE_FILE="/etc/systemd/system/securedeployx.service"
NODE_VERSION="20.x"
POSTGRES_VERSION="16"

# Function to print section headers
section() {
  echo -e "${BLUE}==>${NC} ${GREEN}$1${NC}"
}

# Function to print errors
error() {
  echo -e "${RED}ERROR:${NC} $1"
  exit 1
}

# Function to print warnings
warning() {
  echo -e "${YELLOW}WARNING:${NC} $1"
}

# Check if script is run as root
if [ "$(id -u)" -ne 0 ]; then
  error "This script must be run as root. Try 'sudo $0'"
fi

section "Starting SecureDeployX installation"

# Create directories
section "Creating application directories"
mkdir -p "$APP_DIR" "$DATA_DIR" "$LOG_DIR" || error "Failed to create directories"
echo "Directories created successfully."

# Create user if it doesn't exist
section "Setting up system user"
if ! id "$USER" &>/dev/null; then
  useradd -r -d "$APP_DIR" -s /bin/bash "$USER" || error "Failed to create user"
  echo "User '$USER' created."
else
  echo "User '$USER' already exists."
fi

# Set appropriate permissions
chown -R "$USER:$USER" "$APP_DIR" "$DATA_DIR" "$LOG_DIR" || error "Failed to set permissions"

# Install dependencies
section "Installing system dependencies"
apt-get update || error "Failed to update package lists"

echo "Installing essential tools..."
apt-get install -y curl wget git unzip gnupg2 software-properties-common \
  build-essential ca-certificates lsb-release apt-transport-https \
  python3 python3-pip libpq-dev htop || error "Failed to install essential tools"

# Install Node.js
section "Installing Node.js $NODE_VERSION"
if ! command -v node &> /dev/null; then
  echo "Adding NodeSource repository..."
  curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION} | bash - || error "Failed to add NodeSource repository"
  apt-get install -y nodejs || error "Failed to install Node.js"
  echo "Node.js $(node -v) installed successfully."
else
  echo "Node.js $(node -v) is already installed."
fi

# Install PostgreSQL
section "Installing PostgreSQL $POSTGRES_VERSION"
if ! command -v psql &> /dev/null; then
  echo "Adding PostgreSQL repository..."
  sh -c 'echo "deb https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
  wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | apt-key add -
  apt-get update
  apt-get install -y postgresql-$POSTGRES_VERSION postgresql-contrib || error "Failed to install PostgreSQL"
  echo "PostgreSQL installed successfully."
  
  # Start PostgreSQL
  systemctl enable postgresql
  systemctl start postgresql
  echo "PostgreSQL service started and enabled."
else
  echo "PostgreSQL is already installed."
fi

# Install NGINX
section "Installing NGINX"
if ! command -v nginx &> /dev/null; then
  apt-get install -y nginx || error "Failed to install NGINX"
  echo "NGINX installed successfully."
else
  echo "NGINX is already installed."
fi

# Create database and user
section "Setting up PostgreSQL database"
if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw securedeployx; then
  echo "Database 'securedeployx' already exists."
else
  echo "Creating PostgreSQL user and database..."
  # Generate a secure password
  DB_PASSWORD=$(openssl rand -base64 12)
  
  # Create database and user
  sudo -u postgres psql -c "CREATE USER securedeployx WITH PASSWORD '$DB_PASSWORD';" || error "Failed to create database user"
  sudo -u postgres psql -c "CREATE DATABASE securedeployx OWNER securedeployx;" || error "Failed to create database"
  sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE securedeployx TO securedeployx;" || error "Failed to grant privileges"
  
  echo "PostgreSQL database and user created successfully."
fi

# Clone the repository
section "Cloning SecureDeployX repository"
cd "$APP_DIR" || error "Failed to change directory"
if [ -d "$APP_DIR/.git" ]; then
  echo "Repository already exists. Pulling latest changes..."
  git pull || warning "Failed to pull latest changes"
else
  git clone https://github.com/yourusername/securedeployx.git . || error "Failed to clone repository"
  echo "Repository cloned successfully."
fi

# Install Node.js dependencies
section "Installing Node.js dependencies"
cd "$APP_DIR" || error "Failed to change directory"
npm install || error "Failed to install Node.js dependencies"
echo "Node.js dependencies installed successfully."

# Create environment file if it doesn't exist
section "Setting up environment configuration"
if [ ! -f "$ENV_FILE" ]; then
  # Generate a secure session secret
  SESSION_SECRET=$(openssl rand -hex 32)
  
  cat > "$ENV_FILE" << EOF
# Database Configuration
DATABASE_URL=postgresql://securedeployx:$DB_PASSWORD@localhost:5432/securedeployx
PGUSER=securedeployx
PGPASSWORD=$DB_PASSWORD
PGDATABASE=securedeployx
PGPORT=5432
PGHOST=localhost

# Application Configuration
NODE_ENV=production
PORT=5000
SESSION_SECRET=$SESSION_SECRET

# Security Settings
COOKIE_SECRET=$SESSION_SECRET
JWT_SECRET=$(openssl rand -hex 32)

# Service Integration (add your API keys here)
# OPENAI_API_KEY=
# GEMINI_API_KEY=
# AWS_ACCESS_KEY_ID=
# AWS_SECRET_ACCESS_KEY=
# RENDER_API_KEY=
EOF

  echo "Environment configuration file created."
else
  echo "Environment configuration file already exists. Skipping."
fi

# Set permissions for the environment file
chmod 600 "$ENV_FILE" || error "Failed to set permissions for environment file"
chown "$USER:$USER" "$ENV_FILE" || error "Failed to change owner of environment file"

# Create systemd service
section "Setting up systemd service"
cat > "$SERVICE_FILE" << EOF
[Unit]
Description=SecureDeployX Application
After=network.target postgresql.service

[Service]
Type=simple
User=$USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/npm run start
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=securedeployx
Environment=NODE_ENV=production
EnvironmentFile=$ENV_FILE

[Install]
WantedBy=multi-user.target
EOF

echo "Systemd service file created."

# Configure NGINX
section "Configuring NGINX"
cat > "$NGINX_CONF" << 'EOF'
server {
    listen 80;
    server_name securedeployx.yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }

    location /assets {
        alias $APP_DIR/client/dist/assets;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
    }

    client_max_body_size 50M;
    access_log /var/log/nginx/securedeployx_access.log;
    error_log /var/log/nginx/securedeployx_error.log;
}
EOF

echo "NGINX configuration created."

# Enable and create symlink for NGINX config
ln -sf "$NGINX_CONF" /etc/nginx/sites-enabled/ || warning "Failed to create NGINX symlink"

# Create database migration script
section "Creating database migration script"
cat > "$APP_DIR/setup-db.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "Running database migrations..."
npx drizzle-kit push
echo "Creating admin user..."
node create-admin.cjs
echo "Database setup completed."
EOF

chmod +x "$APP_DIR/setup-db.sh" || error "Failed to set execute permission on database script"
chown "$USER:$USER" "$APP_DIR/setup-db.sh" || error "Failed to change owner of database script"

# Build the application
section "Building the application"
cd "$APP_DIR" || error "Failed to change directory"
npm run build || error "Failed to build application"
echo "Application built successfully."

# Setup the database
section "Setting up the database"
sudo -u "$USER" bash -c "cd $APP_DIR && ./setup-db.sh" || warning "Database setup may not have completed successfully"

# Enable and start services
section "Starting services"
systemctl daemon-reload || error "Failed to reload systemd daemon"
systemctl enable securedeployx.service || error "Failed to enable securedeployx service"
systemctl start securedeployx.service || error "Failed to start securedeployx service"
systemctl restart nginx || error "Failed to restart NGINX"

echo "Services started successfully."

# Print final instructions
section "Installation completed successfully!"
echo -e "${GREEN}SecureDeployX has been installed and configured on your system.${NC}"
echo ""
echo "Here's what to do next:"
echo "1. Edit your NGINX configuration at $NGINX_CONF to set your actual domain name"
echo "2. Configure SSL with Let's Encrypt: sudo certbot --nginx -d securedeployx.yourdomain.com"
echo "3. Add your API keys to the environment file at $ENV_FILE"
echo "4. Access the application at http://securedeployx.yourdomain.com (or https:// if SSL is configured)"
echo ""
echo "Admin credentials:"
echo "Username: admin"
echo "Password: Please check the output of the setup-db.sh script or run it again to create an admin user"
echo ""
echo "To check the status of the application: systemctl status securedeployx"
echo "To view logs: journalctl -u securedeployx"
echo ""
echo "Thank you for installing SecureDeployX!"