/**
 * SecureDeployX Database Migration Script
 * 
 * This script applies any pending database schema changes.
 * It's a more controlled version of `drizzle-kit push` for production use.
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

/**
 * Color formatting for console output
 */
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
};

/**
 * Logs a message with a specified color
 */
function colorLog(message, color = colors.reset) {
  console.log(`${color}${message}${colors.reset}`);
}

/**
 * Creates a backup of the database before migration
 */
async function createBackup() {
  if (!process.env.DATABASE_URL) {
    colorLog('No DATABASE_URL environment variable found. Cannot create backup.', colors.red);
    return false;
  }

  const backupDir = path.join(process.cwd(), 'backups');
  
  // Ensure backups directory exists
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/:/g, '-');
  const backupFile = path.join(backupDir, `backup_${timestamp}.sql`);

  try {
    colorLog('Creating database backup...', colors.yellow);
    
    // Parse connection string to get database details
    const connectionMatch = process.env.DATABASE_URL.match(/postgresql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/);
    
    if (!connectionMatch) {
      colorLog('Invalid DATABASE_URL format. Cannot create backup.', colors.red);
      return false;
    }
    
    const [, user, password, host, port, dbName] = connectionMatch;
    
    // Set environment variables for pg_dump
    const env = {
      ...process.env,
      PGPASSWORD: password,
    };
    
    // Execute pg_dump command
    execSync(
      `pg_dump -h ${host} -p ${port} -U ${user} -d ${dbName} -f ${backupFile}`,
      { env: env, stdio: 'inherit' }
    );
    
    colorLog(`Backup created successfully at ${backupFile}`, colors.green);
    return true;
  } catch (error) {
    colorLog(`Failed to create backup: ${error.message}`, colors.red);
    return false;
  }
}

/**
 * Runs the drizzle-kit push command to update the database schema
 */
async function updateSchema() {
  try {
    colorLog('Updating database schema...', colors.yellow);
    execSync('npx drizzle-kit push', { stdio: 'inherit' });
    colorLog('Database schema updated successfully!', colors.green);
    return true;
  } catch (error) {
    colorLog(`Failed to update schema: ${error.message}`, colors.red);
    return false;
  }
}

/**
 * Main migration function
 */
async function runMigration() {
  // Print banner
  colorLog(`
  _____                          _____             _                  __   __
 / ____|                        |  __ \\           | |                 \\ \\ / /
| (___   ___  ___ _   _ _ __ ___| |  | | ___ _ __ | | ___  _   _      \\ V / 
 \\___ \\ / _ \\/ __| | | | '__/ _ \\ |  | |/ _ \\ '_ \\| |/ _ \\| | | |      > <  
 ____) |  __/ (__| |_| | | |  __/ |__| |  __/ |_) | | (_) | |_| |     / . \\ 
|_____/ \\___|\\__|\\\__,_|_|  \\___|_____/ \\___| .__/|_|\\___/ \\__, |    /_/ \\_\\
                                            | |             __/ |           
                                            |_|            |___/            
`, colors.blue);
  colorLog('SecureDeployX Database Migration Tool', colors.yellow);
  console.log('');

  // Check if DATABASE_URL is set
  if (!process.env.DATABASE_URL) {
    colorLog('Error: DATABASE_URL environment variable is not set.', colors.red);
    colorLog('Please set the DATABASE_URL environment variable before running this script.', colors.yellow);
    process.exit(1);
  }

  // Create backup
  const backupSuccess = await createBackup();
  
  if (!backupSuccess) {
    colorLog('Warning: Failed to create a backup. Do you want to continue? (y/n)', colors.yellow);
    // In a normal script we would ask for confirmation here
    // Since this is a automated script we'll continue regardless
    colorLog('Continuing with migration...', colors.yellow);
  }
  
  // Update schema
  const updateSuccess = await updateSchema();
  
  if (!updateSuccess) {
    colorLog('Migration failed. Please check the errors above.', colors.red);
    process.exit(1);
  }
  
  colorLog('Migration completed successfully!', colors.green);
}

// Run the migration
runMigration();